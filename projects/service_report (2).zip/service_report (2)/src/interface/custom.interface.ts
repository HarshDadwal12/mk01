import express, { Response } from 'express';

export interface Request extends express.Request {
  dbConnectionInfo?: any;
  logId?: any;
  errorStatus?: any;
}

export interface Create {
  modelData: any;
  data: any;
  dbConnectionInfo: any;
}

export interface Update {
  modelData: any;
  data: any;
  condition: any;
  upsert?: boolean;
  dbConnectionInfo: any;
}
export interface FindOne {
  modelData: any;
  condition: any;
  dbConnectionInfo: any;
}
export interface Find {
  modelData: any;
  // condition: any;
  dbConnectionInfo: any;
  query: any;
}

export interface CreateResponse {
  req: Request;
  res: Response;
  data?: Array<any> | object | string | null;
  code?: number;
  addOn?: object;
}

export interface GenerateErrorObject {
  type?: string;
  message?: string;
  parameter?: string;
  code?: number;
}
export interface FindCustomResource {
  dbConnectionInfo: any;
  query: any;
}
