import { ReasonPhrases, StatusCodes } from 'http-status-codes';

export const HttpResponse = {
  200: {
    code: StatusCodes.OK,
    message: 'Success',
  },
  201: {
    code: StatusCodes.CREATED,
    message: 'Successfully Created',
  },
  204: {
    code: StatusCodes.NO_CONTENT,
    message: ReasonPhrases.NO_CONTENT,
  },
  400: {
    code: StatusCodes.BAD_REQUEST,
    message: ReasonPhrases.BAD_REQUEST,
  },
  401: {
    code: StatusCodes.UNAUTHORIZED,
    message: ReasonPhrases.UNAUTHORIZED,
  },
  403: {
    code: StatusCodes.FORBIDDEN,
    message: ReasonPhrases.FORBIDDEN,
  },
  404: {
    code: StatusCodes.NOT_FOUND,
    message: ReasonPhrases.NOT_FOUND,
  },
  408: {
    code: StatusCodes.REQUEST_TIMEOUT,
    message: ReasonPhrases.REQUEST_TIMEOUT,
  },
  409: {
    code: StatusCodes.CONFLICT,
    message: ReasonPhrases.CONFLICT,
  },
  500: {
    code: StatusCodes.INTERNAL_SERVER_ERROR,
    message: ReasonPhrases.INTERNAL_SERVER_ERROR,
  },
  504: {
    code: StatusCodes.GATEWAY_TIMEOUT,
    message: ReasonPhrases.GATEWAY_TIMEOUT,
  },
  lead_created: {
    event_name: 'lead_assigned',
    message: 'New lead assigned',
  },
};
