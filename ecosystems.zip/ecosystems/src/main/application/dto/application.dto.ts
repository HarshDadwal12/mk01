import { ApiProperty } from '@nestjs/swagger';
import {
  IsIn,
  IsNotEmpty,
  MaxLength,
  IsOptional,
  IsNumber,
  MinLength,
  IsDefined,
  ValidateNested,
  IsString,
  IsAlphanumeric,
  Min,
  Max,
  IsEmail,
  IsArray,
  ArrayNotEmpty,
  ArrayMinSize,
  Matches,
  ValidateIf,
} from 'class-validator';
import { Type } from 'class-transformer';

class OwnersData {
  @IsNotEmpty()
  @IsAlphanumeric()
  @IsString()
  @MinLength(10)
  @MaxLength(10)
  @ApiProperty()
  owner_pan: string;

  @IsAlphanumeric()
  @IsNotEmpty()
  @ApiProperty()
  owner_unique_id: string;

  @IsNotEmpty()
  @IsIn([
    'PARTNERSHIP',
    'LLP',
    'PUBLIC_LIMITED_COMPANY',
    'PRIVATE_LIMITED_COMPANY',
    'JOINT_VENTURE_COMPANY',
    'PARTNERSHIP_FIRM',
    'ONE_PERSON_COMPANY',
    'SOLE_PROPRIETORSHIP',
    'BRANCH_OFFICE',
    'NON_GOVERNMENT_ORGANIZATION',
  ])
  @ApiProperty()
  business_type: string;

  @IsDefined()
  @IsString()
  @IsNotEmpty()
  @IsIn(['OWNER', 'PARTNER', 'DIRECTOR', 'GUARANTOR'])
  @MinLength(1)
  @ApiProperty()
  owner_role: string;

  @IsDefined()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  owner_first_name: string;

  @IsDefined()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  owner_last_name: string;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @Min(0)
  @Max(100)
  @ApiProperty()
  ownership_percentage: number;

  @IsOptional()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  owner_gender: string;

  @IsOptional()
  @IsString()
  @IsNotEmpty()
  @IsIn(['PRIMARY', 'SECONDARY', 'GRADUATE', 'POST_GRADUATE', 'PHD'])
  @MinLength(1)
  @ApiProperty()
  owner_education: string;

  @IsOptional()
  @IsString()
  @IsNotEmpty()
  @IsIn(['MARRIED', 'UNMARRIED', 'SEPERATED', 'DIVORCED', 'OTHERS'])
  @MinLength(1)
  @ApiProperty()
  owner_marital_status: string;

  @IsOptional()
  @Matches(/^([0-2][0-9]|(3)[0-1])-(((0)[0-9])|((1)[0-2]))-\d{4}$/i, {
    message: 'owner_dob must be in DD-MM-YYYY format',
  })
  @ApiProperty()
  owner_dob: string;

  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  owner_aadhar: number;

  @IsOptional()
  @IsAlphanumeric()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  owner_passport_number: string;

  @IsOptional()
  @IsAlphanumeric()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  owner_voter_id: string;

  @IsOptional()
  @IsAlphanumeric()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  owner_driving_license: string;

  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  owner_mobile_number: number;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  owner_alternate_mobile_number: number;

  @IsEmail()
  @IsNotEmpty()
  @ApiProperty()
  owner_email: string;

  @IsOptional()
  @IsEmail()
  @IsNotEmpty()
  @ApiProperty()
  owner_alternate_email: string;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  owner_cibil_score: number;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  owner_experian_score: number;

  @IsOptional()
  @IsString()
  @IsIn(['PRIMARY', 'OTHERS'])
  @ApiProperty()
  owner_address_type: string;

  @IsOptional()
  @IsAlphanumeric()
  @IsString()
  @IsNotEmpty()
  @ApiProperty()
  owner_residential_address: string;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  owner_pin_code: number;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  owner_latitude: number;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  owner_longitude: number;

  @IsOptional()
  @IsString()
  @IsNotEmpty()
  @ApiProperty()
  owner_state: string;

  @IsOptional()
  @IsString()
  @IsNotEmpty()
  @ApiProperty()
  owner_city: string;

  @IsOptional()
  @IsString()
  @IsIn(['OWNED', 'RENTED'])
  @IsNotEmpty()
  @ApiProperty()
  owner_ownership_status: string;
}

export class UserApplicationDto {
  @IsDefined()
  @IsNotEmpty()
  @IsNumber()
  @ApiProperty()
  lead_id: number;

  @IsNotEmpty()
  @IsNumber()
  @ApiProperty()
  retailer_interest_rate: number;

  @IsDefined()
  @IsAlphanumeric()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  building_name: string;

  @IsDefined()
  @IsString()
  @IsNotEmpty()
  @IsIn(['PRIMARY', 'ALTERNATE'])
  @MinLength(1)
  @ApiProperty()
  borrower_address_type: string;

  @IsDefined()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  street_name: string;

  @IsOptional()
  @IsAlphanumeric()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  street_no: number;

  @IsDefined()
  @IsAlphanumeric()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  location: string;

  @IsDefined()
  @IsAlphanumeric()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  door_number: string;

  @IsDefined()
  @IsAlphanumeric()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  state: string;

  @IsDefined()
  @IsAlphanumeric()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  district: string;

  @IsDefined()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  city: string;

  @IsDefined()
  @IsAlphanumeric()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  floor_number: string;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  latitude: number;

  @IsDefined()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  pin_code: number;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  longitude: number;

  @IsOptional()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  nature_of_business: string;

  @IsOptional()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  business_industry: string;

  @IsOptional()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  sub_industry: string;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  cin: number;

  @IsDefined()
  @IsAlphanumeric()
  @IsString()
  @IsNotEmpty()
  @MinLength(10)
  @MaxLength(10)
  @ApiProperty()
  pan: string;

  @IsDefined()
  @Matches(/^([0-2][0-9]|(3)[0-1])-(((0)[0-9])|((1)[0-2]))-\d{4}$/i, {
    message: 'date_of_incorporation must be in DD-MM-YYYY format',
  })
  @ApiProperty()
  date_of_incorporation: string;

  @ValidateIf((o) => o.owner !== false)
  @IsDefined()
  @IsArray()
  @ArrayNotEmpty()
  @ArrayMinSize(1)
  @ValidateNested({ each: true })
  @Type(() => OwnersData)
  @ApiProperty()
  owners: OwnersData[];
}

export class GetApplicationDto {
  @IsDefined()
  @IsNotEmpty()
  @IsString()
  @MinLength(1)
  @ApiProperty()
  id: string;
}

export class ApplicationApprovedLimitDto {
  @IsNotEmpty()
  @IsNumber()
  @ApiProperty()
  application_id: number;

  @IsOptional()
  @IsNumber()
  @ApiProperty()
  loan_account_number: number;

  @IsNotEmpty()
  @IsNumber()
  @ApiProperty()
  approved_limit: number;

  @IsOptional()
  @IsNumber()
  @ApiProperty()
  sanctioned_limit: number;

  @IsOptional()
  @Matches(/^([0-2][0-9]|(3)[0-1])-(((0)[0-9])|((1)[0-2]))-\d{4}$/i, {
    message: 'limit_expiry_date must be in DD-MM-YYYY format',
  })
  @ApiProperty()
  limit_expiry_date: string;

  @IsNotEmpty()
  @IsString()
  @IsIn(['NEW', 'WHITELISTED', 'APPROVED', 'REJECTED'])
  @ApiProperty()
  lead_status: string;

  @IsNotEmpty()
  @IsString()
  @IsIn([
    'PROPOSED',
    'APPROVED',
    'PENDING',
    'REQUEST_SANCTION',
    'EXTEND',
    'SANCTIONED',
    'ALLOCATED',
    'TEMPORARY_BLOCKED',
    'PERMANENT_BLOCKED',
  ])
  @ApiProperty()
  limit_status: string;

  @ValidateIf((o) => o.limit_status === 'SANCTIONED')
  @IsDefined()
  @IsNotEmpty()
  @IsNumber()
  @ApiProperty()
  lender_interest_rate: number;
}

export class ApplicationAdditionalDto {
  @IsNotEmpty()
  @IsNumber()
  @ApiProperty()
  application_id: number;

  @IsNotEmpty()
  @IsAlphanumeric()
  @IsString()
  @ApiProperty()
  udhyam_registration_number: string;

  @IsNotEmpty()
  @Matches(/^([0-2][0-9]|(3)[0-1])-(((0)[0-9])|((1)[0-2]))-\d{4}$/i, {
    message: 'onboarding_date must be in DD-MM-YYYY format',
  })
  @ApiProperty()
  onboarding_date: string;

  // @IsOptional()
  // @IsNumber()
  // @IsNotEmpty()
  // @ApiProperty()
  // investment_in_plant_and_machinery: number;

  // @IsOptional()
  // @IsNumber()
  // @IsNotEmpty()
  // @ApiProperty()
  // monthly_loan_obligation: number;

  // @IsOptional()
  // @IsAlphanumeric()
  // @IsString()
  // @IsNotEmpty()
  // @MinLength(1)
  // @ApiProperty()
  // government_id_type: string;

  // @IsOptional()
  // @IsAlphanumeric()
  // @IsString()
  // @IsNotEmpty()
  // @MinLength(1)
  // @ApiProperty()
  // government_id_number: number;

  // @IsOptional()
  // @IsNumber()
  // @IsNotEmpty()
  // @ApiProperty()
  // experian_commercial_score: number;

  // @IsOptional()
  // @IsNumber()
  // @IsNotEmpty()
  // @ApiProperty()
  // borrower_rating: number;

  // @IsOptional()
  // @IsNumber()
  // @IsNotEmpty()
  // @ApiProperty()
  // overall_rating: number;

  // @IsOptional()
  // @IsNumber()
  // @IsNotEmpty()
  // @ApiProperty()
  // reliability_rating: number;

  // @IsOptional()
  // @IsNumber()
  // @IsNotEmpty()
  // @ApiProperty()
  // incident_rating: number;

  // @IsOptional()
  // @IsNumber()
  // @IsNotEmpty()
  // @ApiProperty()
  // quality_rating: number;

  // @IsOptional()
  // @IsNumber()
  // @IsNotEmpty()
  // @ApiProperty()
  // coverage_rating: number;

  // @IsOptional()
  // @IsNumber()
  // @IsNotEmpty()
  // @ApiProperty()
  // payment_rating: number;

  // @IsOptional()
  // @IsNumber()
  // @IsNotEmpty()
  // @ApiProperty()
  // time_period: number;

  // @IsOptional()
  // @IsNumber()
  // @IsNotEmpty()
  // @ApiProperty()
  // order_placed: number;

  // @IsOptional()
  // @IsNumber()
  // @IsNotEmpty()
  // @ApiProperty()
  // order_value_placed: number;

  // @IsOptional()
  // @IsNumber()
  // @IsNotEmpty()
  // @ApiProperty()
  // order_value_paid: number;

  // @IsOptional()
  // @IsNumber()
  // @IsNotEmpty()
  // @ApiProperty()
  // orders_delivered: number;

  // @IsOptional()
  // @IsNumber()
  // @IsNotEmpty()
  // @ApiProperty()
  // order_value_delivered: number;

  // @IsOptional()
  // @IsNumber()
  // @IsNotEmpty()
  // @ApiProperty()
  // orders_returned: number;

  // @IsOptional()
  // @IsNumber()
  // @IsNotEmpty()
  // @ApiProperty()
  // order_value_returned: number;

  // @IsOptional()
  // @IsNumber()
  // @IsNotEmpty()
  // @ApiProperty()
  // orders_cancelled: number;

  // @IsOptional()
  // @IsNumber()
  // @IsNotEmpty()
  // @ApiProperty()
  // order_value_cancelled: number;

  // @IsOptional()
  // @IsNumber()
  // @IsNotEmpty()
  // @ApiProperty()
  // business_vintage: number;

  // @IsOptional()
  // @IsNumber()
  // @IsNotEmpty()
  // @ApiProperty()
  // average_order_placed: number;

  // @IsOptional()
  // @IsNumber()
  // @IsNotEmpty()
  // @ApiProperty()
  // average_order_value_placed: number;

  // @IsOptional()
  // @IsNumber()
  // @IsNotEmpty()
  // @ApiProperty()
  // average_order_value_paid: number;

  // @IsOptional()
  // @IsNumber()
  // @IsNotEmpty()
  // @ApiProperty()
  // average_orders_delivered: number;

  // @IsOptional()
  // @IsNumber()
  // @IsNotEmpty()
  // @ApiProperty()
  // average_order_value_delivered: number;

  // @IsOptional()
  // @IsNumber()
  // @IsNotEmpty()
  // @ApiProperty()
  // average_orders_returned: number;

  // @IsOptional()
  // @IsNumber()
  // @IsNotEmpty()
  // @ApiProperty()
  // average_order_value_returned: number;

  // @IsOptional()
  // @IsNumber()
  // @IsNotEmpty()
  // @ApiProperty()
  // average_orders_cancelled: number;

  // @IsOptional()
  // @IsNumber()
  // @IsNotEmpty()
  // @ApiProperty()
  // average_order_value_cancelled: number;

  // @IsOptional()
  // @IsNumber()
  // @IsNotEmpty()
  // @ApiProperty()
  // vintage_order_placed: number;

  // @IsOptional()
  // @IsNumber()
  // @IsNotEmpty()
  // @ApiProperty()
  // vintage_order_value_placed: number;

  // @IsOptional()
  // @IsNumber()
  // @IsNotEmpty()
  // @ApiProperty()
  // vintage_order_value_paid: number;

  // @IsOptional()
  // @IsNumber()
  // @IsNotEmpty()
  // @ApiProperty()
  // vintage_orders_delivered: number;

  // @IsOptional()
  // @IsNumber()
  // @IsNotEmpty()
  // @ApiProperty()
  // vintage_orders_returns: number;

  // @IsOptional()
  // @IsNumber()
  // @IsNotEmpty()
  // @ApiProperty()
  // vintage_order_value_returns: number;

  // @IsOptional()
  // @IsNumber()
  // @IsNotEmpty()
  // @ApiProperty()
  // vintage_orders_cancelled: number;

  // @IsOptional()
  // @IsNumber()
  // @IsNotEmpty()
  // @ApiProperty()
  // vintage_order_value_cancelled: number;
}

export class applicationBusinessGstDto {
  @IsDefined()
  @IsNotEmpty()
  @IsNumber()
  @ApiProperty()
  application_id: number;

  @IsOptional()
  @IsAlphanumeric()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  state_jurisdiction_code: string;

  @IsOptional()
  @IsAlphanumeric()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  taxpayer_type: string;

  @IsOptional()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  legal_name_business: string;

  @IsOptional()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  state_jurisdiction: string;

  @IsOptional()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  centre_jurisdiction: string;

  @IsOptional()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  centre_jurisdiction_code: string;

  @IsOptional()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  nature_of_business_activity: string;

  @IsDefined()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  gstin: number;

  @IsOptional()
  @Matches(/^([0-2][0-9]|(3)[0-1])-(((0)[0-9])|((1)[0-2]))-\d{4}$/i, {
    message: 'last_update_date must be in DD-MM-YYYY format',
  })
  @ApiProperty()
  last_update_date: string;

  @IsOptional()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  constitution_of_business: string;

  @IsOptional()
  @Matches(/^([0-2][0-9]|(3)[0-1])-(((0)[0-9])|((1)[0-2]))-\d{4}$/i, {
    message: 'date_of_registration must be in DD-MM-YYYY format',
  })
  @ApiProperty()
  date_of_registration: string;

  @IsOptional()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  trade_name: string;

  @IsOptional()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  gstin_status: string;

  @IsOptional()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  business_owner_type: string;
}

export class applicationBusinessGstPatchDto {
  @IsDefined()
  @IsNotEmpty()
  @IsNumber()
  @ApiProperty()
  application_id: number;

  @IsOptional()
  @IsAlphanumeric()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  state_jurisdiction_code: string;

  @IsOptional()
  @IsAlphanumeric()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  taxpayer_type: string;

  @IsOptional()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  legal_name_business: string;

  @IsOptional()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  state_jurisdiction: string;

  @IsOptional()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  centre_jurisdiction: string;

  @IsOptional()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  centre_jurisdiction_code: string;

  @IsOptional()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  nature_of_business_activity: string;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  gstin: number;

  @IsOptional()
  @Matches(/^([0-2][0-9]|(3)[0-1])-(((0)[0-9])|((1)[0-2]))-\d{4}$/i, {
    message: 'last_update_date must be in DD-MM-YYYY format',
  })
  @ApiProperty()
  last_update_date: string;

  @IsOptional()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  constitution_of_business: string;

  @IsOptional()
  @Matches(/^([0-2][0-9]|(3)[0-1])-(((0)[0-9])|((1)[0-2]))-\d{4}$/i, {
    message: 'date_of_registration must be in DD-MM-YYYY format',
  })
  @ApiProperty()
  date_of_registration: number;

  @IsOptional()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  trade_name: string;

  @IsOptional()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  gstin_status: string;

  @IsOptional()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  business_owner_type: string;
}

export class ApplicationAdditionalPatchDto {
  @IsDefined()
  @IsNotEmpty()
  @IsNumber()
  @ApiProperty()
  application_id: number;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  investment_in_plant_and_machinery: number;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  monthly_loan_obligation: number;

  @IsOptional()
  @IsAlphanumeric()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  udhyam_registration_number: string;

  @IsOptional()
  @IsAlphanumeric()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  government_id_type: string;

  @IsOptional()
  @IsAlphanumeric()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  government_id_number: number;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  experian_commercial_score: number;

  @IsOptional()
  @Matches(/^([0-2][0-9]|(3)[0-1])-(((0)[0-9])|((1)[0-2]))-\d{4}$/i, {
    message: 'onboarding_date must be in DD-MM-YYYY format',
  })
  @ApiProperty()
  onboarding_date: string;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  borrower_rating: number;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  overall_rating: number;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  reliability_rating: number;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  incident_rating: number;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  quality_rating: number;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  coverage_rating: number;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  payment_rating: number;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  time_period: number;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  order_placed: number;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  order_value_placed: number;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  order_value_paid: number;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  orders_delivered: number;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  order_value_delivered: number;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  orders_returned: number;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  order_value_returned: number;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  orders_cancelled: number;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  order_value_cancelled: number;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  business_vintage: number;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  average_order_placed: number;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  average_order_value_placed: number;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  average_order_value_paid: number;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  average_orders_delivered: number;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  average_order_value_delivered: number;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  average_orders_returned: number;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  average_order_value_returned: number;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  average_orders_cancelled: number;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  average_order_value_cancelled: number;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  vintage_order_placed: number;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  vintage_order_value_placed: number;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  vintage_order_value_paid: number;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  vintage_orders_delivered: number;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  vintage_orders_returns: number;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  vintage_order_value_returns: number;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  vintage_orders_cancelled: number;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  vintage_order_value_cancelled: number;
}

export class invoiceTrancheDto {
  @IsDefined()
  @IsNotEmpty()
  @IsString()
  @ApiProperty()
  application_id: string;

  @IsDefined()
  @IsNotEmpty()
  @IsString()
  @IsIn(['INVOICE', 'DISBURSEMENT', 'REPAYMENT'])
  @ApiProperty()
  type: string;

  @ValidateIf((o: invoiceTrancheDto) => o.type === 'INVOICE')
  @IsDefined()
  @IsNotEmpty()
  @IsString()
  @ApiProperty()
  invoice_no: string;

  @ValidateIf((o: invoiceTrancheDto) => o.type === 'REPAYMENT')
  @IsDefined()
  @IsNotEmpty()
  @IsString()
  @ApiProperty()
  repayment_unique_id: string;

  @ValidateIf((o: invoiceTrancheDto) => o.type === 'DISBURSEMENT')
  @IsDefined()
  @IsNotEmpty()
  @IsString()
  @ApiProperty()
  disbursement_unique_id: string;
}

export class transactionInfoDto {
  @IsDefined()
  @IsNotEmpty()
  @IsString()
  @ApiProperty()
  id: string;
}

export class appSummaryDto {
  @IsDefined()
  @IsString()
  @ApiProperty()
  'application_id': string;
}

export class UserApplicationPatchDto {
  @IsDefined()
  @IsNotEmpty()
  @IsNumber()
  @ApiProperty()
  application_id: number;

  @IsOptional()
  @IsNotEmpty()
  @IsNumber()
  @ApiProperty()
  retailer_interest_rate: number;

  @IsOptional()
  @IsAlphanumeric()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  building_name: string;

  @IsOptional()
  @IsString()
  @IsNotEmpty()
  @IsIn(['PRIMARY', 'ALTERNATE'])
  @MinLength(1)
  @ApiProperty()
  borrower_address_type: string;

  @IsOptional()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  street_name: string;

  @IsOptional()
  @IsAlphanumeric()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  street_no: number;

  @IsOptional()
  @IsAlphanumeric()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  location: string;

  @IsOptional()
  @IsAlphanumeric()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  door_number: string;

  @IsOptional()
  @IsAlphanumeric()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  state: string;

  @IsOptional()
  @IsAlphanumeric()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  district: string;

  @IsOptional()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  city: string;

  @IsOptional()
  @IsAlphanumeric()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  floor_number: string;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  latitude: number;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  pin_code: number;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  longitude: number;

  @IsOptional()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  nature_of_business: string;

  @IsOptional()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  business_industry: string;

  @IsOptional()
  @IsString()
  @IsNotEmpty()
  @MinLength(1)
  @ApiProperty()
  sub_industry: string;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  cin: number;

  @IsOptional()
  @IsAlphanumeric()
  @IsString()
  @IsNotEmpty()
  @MinLength(10)
  @MaxLength(10)
  @ApiProperty()
  pan: string;

  @IsOptional()
  @Matches(/^([0-2][0-9]|(3)[0-1])-(((0)[0-9])|((1)[0-2]))-\d{4}$/i, {
    message: 'date_of_incorporation must be in DD-MM-YYYY format',
  })
  @ApiProperty()
  date_of_incorporation: string;

  @ValidateIf((o) => o.owner !== false)
  @IsOptional()
  @IsArray()
  @ArrayNotEmpty()
  @ArrayMinSize(1)
  @ValidateNested({ each: true })
  @Type(() => OwnersData)
  @ApiProperty()
  owners: OwnersData[];
}