import { Controller, Body, Post, Req, UseGuards } from '@nestjs/common';
import { AuthGuard } from '../../core/gaurd/auth.gaurd';
import {
  RepaymentRequestDto,
  RepaymentRequestReconDto,
  RepaymentResponseDto,
} from './dto/repayment.dto';
import { RepaymentService } from './repayment.service';

@Controller({
  version: '1.0',
})
@UseGuards(AuthGuard)
export class RepaymentController {
  constructor(private repaymentService: RepaymentService) {}

  @Post('request')
  async repaymentRequest(@Req() req: any, @Body() body: RepaymentRequestDto) {
    try {
      if (body?.disbursement_unique_id)
        await this.repaymentService.implementRepaymentRequestValidations(body);
      const data = await this.repaymentService.createAnalysis(
        {
          ...body,
          type: 'repayment_request',
          backend_user_id: req?.user?.backend_user_id,
        },
        'repayment_request',
      );
      return {
        data,
        key: 'repayment_request',
        filter: true,
        event: 'repayment.request',
        hook: true,
      };
    } catch (error) {
      throw error;
    }
  }

  @Post('response')
  async repaymentResponse(@Req() req: any, @Body() body: RepaymentResponseDto) {
    try {
      const data_after_interest_calculation =
        await this.repaymentService.performInterestCalculations(body);
      const data = await this.repaymentService.createAnalysis(
        {
          ...data_after_interest_calculation,
          type: 'repayment_response',
          backend_user_id: req?.user?.backend_user_id,
        },
        'repayment_response',
      );
      return {
        data: { application_id: body.application_id, ...data },
        key: 'repayment_response',
        filter: true,
        event: 'repayment.response',
        hook: true,
      };
    } catch (error) {
      throw error;
    }
  }
}
