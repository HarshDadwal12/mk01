import { Module } from '@nestjs/common';
import { RouterModule, Routes } from '@nestjs/core';

import { AuthModule } from './main/auth/auth.module';
import { LeadModule } from './main/lead/lead.module';
import { UserModule } from './main/user/user.module';
import { ApplicationModule } from './main/application/application.module';
import { RepaymentModule } from './main/repayment/repayment.module';
import { TestNotificationsModule } from './main/test_notifications/test_notifications.module';

const routes: Routes = [
  {
    path: '',
    module: AuthModule,
  },
  {
    path: 'api',
    children: [
      {
        path: 'leads',
        module: LeadModule,
      },
      {
        path: 'user',
        module: UserModule,
      },
      {
        path: 'application',
        module: ApplicationModule,
        children: [
          {
            path: 'repayment',
            module: RepaymentModule,
          },
        ],
      },
      {
        path: 'testnotifications',
        module: TestNotificationsModule,
      },
    ],
  },
];
@Module({
  imports: [RouterModule.register(routes)],
  controllers: [],
  providers: [],
})
export class AppRoutingModule {}
