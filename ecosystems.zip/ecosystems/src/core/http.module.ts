import { HttpService, HttpModule as BaseHttpModule } from '@nestjs/axios';
import { Module, OnModuleInit } from '@nestjs/common';

@Module({
  imports: [BaseHttpModule],
  exports: [BaseHttpModule],
})
export class HttpModule implements OnModuleInit {
  RETRY_TIMEOUT = 1000;
  RETRY_COUNT = 3;
  constructor(private readonly httpService: HttpService) {}

  public onModuleInit(): any {
    // Add request interceptor and response interceptor to log request infos
    const axios = this.httpService.axiosRef;

    axios.interceptors.request.use(function (config) {
      if (process.env.TENANT) {
        config.headers['x-tenant-id'] = process.env.TENANT;
      }
      return config;
    });

    axios.interceptors.response.use(
      (response: any) => {
        const parseResponse = this.isJson(response.data);

        const { status: statusText = 'success', data, total } = parseResponse;
        const modifiedResponse: any = {
          headerStatus: response.status,
          statusText,
          data: data || parseResponse,
        };

        if (total) modifiedResponse.total = total;
        // return modifiedResponse;
        return data || parseResponse;
      },
      async (error: any) => {
        let obj: object = {};
        const { response } = error;
        const { data } = response || obj;
        const { message, status } = data ? this.isJson(data) : obj;
        let { code: headerStatus, errors } = data ? this.isJson(data) : obj;
        error.config['retryCount'] = error.config['retryCount'] || 0;

        if (
          error.config &&
          error.config['retryCount'] < this.RETRY_COUNT &&
          !error.response
        ) {
          error.config['retryCount'] += 1;
          console.log(error.config['retryCount']);
          await this.timeout(this.RETRY_TIMEOUT * error.config['retryCount']);
          return axios.request(error.config);
        }

        if (error.code == 'ECONNREFUSED') {
          headerStatus = 503;
          errors = [
            {
              type: 'server_not_reachable',
              message: 'Server is not available of returning the request.',
            },
          ];
        }

        const errordata = {
          headerStatus,
          statusText: message || status || 'failed',
          errors,
          message: error.message,
        };
        return Promise.reject(errordata);
        // return Promise.reject(errors);
      },
    );
  }

  isJson(str: any) {
    try {
      return JSON.parse(str);
    } catch (e) {
      return str;
    }
  }

  timeout(ms: number): Promise<number> {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
}
