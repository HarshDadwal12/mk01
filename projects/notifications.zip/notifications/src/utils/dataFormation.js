const constant = require('./constant');

/**
 * @description Construct lead data
 * @author Ravi Pratap Singh <ravi.singh@biz2credit.com>
 * @param {*} data
 * @returns Array
 */
module.exports.formatLeadData = function (data, staticData = {}) {
  const leads = [];
  let status;
  for (const [index, val] of data.entries()) {
    let stage = val.stage;
    if (!stage && status != constant.USER_ID_CONFIG_MAPPING.UNDEFINED) {
      if (index == 0) status = constant.USER_ID_CONFIG_MAPPING.UNDEFINED;
      stage = status;
    } else {
      if (
        stage == constant.STAGE_LEAD.LEAD_CREATE ||
        stage == constant.STAGE_LEAD.LEAD_STATUS
      )
        status = stage;
      else {
        status = null;
      }
    }
    delete val.stage;
    switch (stage) {
      case constant.STAGE_LEAD.LEAD_CREATE:
        let {
          identifier,
          borrower_first_name,
          borrower_last_name,
          primary_email_id,
          pan,
          aadhar_id,
          borrower_type,
          primary_phone_number,
          additional_phone_number,
          additional_email_id,
          date_of_birth,
          gender,
          preferred_language,
          product_opportunity_id,
          lead_status,
          ...additional
        } = val;

        leads.push({
          identifier,
          borrower_first_name,
          borrower_last_name,
          primary_email_id,
          pan,
          aadhar_id,
          borrower_type,
          primary_phone_number,
          additional_phone_number,
          additional_email_id,
          date_of_birth,
          gender,
          preferred_language,
          product_opportunity_id,
          lead_status,
          ...staticData,
          additional,
          stage,
          url: constant.ECOSYSTEM_API + constant.CREATE_LEAD,
        });
        break;
      case constant.STAGE_LEAD.LEAD_STATUS:
        leads.push({
          ...val,
          ...staticData,
          stage,
          url: constant.ECOSYSTEM_API + constant.UPDATE_LEAD,
          identifier: 'lead_id',
        });
        break;
      default:
        if (stage != null)
          leads.push({
            stage,
          });
        break;
    }
  }
  return leads;
};
/**
 * @description Construct application data
 * @author Ravi Pratap Singh <ravi.singh@biz2credit.com>
 * @param {*} data
 * @returns Array
 */
module.exports.formatApplicationData = function (data) {
  const finalData = [];
  let status;
  data.map((res, index) => {
    let stage = res.stage;
    let upload_type = res.upload_type;
    if (!stage && status != constant.USER_ID_CONFIG_MAPPING.UNDEFINED) {
      if (index == 0) status = constant.USER_ID_CONFIG_MAPPING.UNDEFINED;
      stage = status;
    } else {
      if (
        stage == constant.STAGE_APPLICATION.CREATE ||
        stage == constant.STAGE_APPLICATION.APPROVE_LIMIT ||
        stage == constant.STAGE_APPLICATION.APPROVE_LIMIT_RESPONSE ||
        stage == constant.STAGE_APPLICATION.SANCTIONED_LIMIT
      )
        status = stage;
      else status = null;
    }
    delete res.stage;
    delete res.upload_type;
    if (
      stage == constant.STAGE_APPLICATION.CREATE ||
      stage == constant.STAGE_APPLICATION.APPROVE_LIMIT ||
      stage == constant.STAGE_APPLICATION.APPROVE_LIMIT_RESPONSE ||
      stage == constant.STAGE_APPLICATION.SANCTIONED_LIMIT
    ) {
      let temp = {};
      for (const key in res) {
        const main = key.split('_').shift();
        const sub = key.split('_');
        sub.shift();
        const subKey = sub.join('_');
        temp = {
          ...temp,
          [main]: {
            ...temp[main],
            [subKey]: res[key],
          },
        };
      }
      if (temp.application) {
        if (temp.owners) {
          temp.owners = [temp.owners];
        } else {
          temp.owners = [];
        }
      }
      if (
        !temp.application &&
        stage == constant.STAGE_APPLICATION.CREATE &&
        upload_type != constant.STAGE_APPLICATION.UPDATE
      ) {
        finalData[finalData.length - 1]['owners'].push(temp.owners);
      } else {
        if (stage == constant.STAGE_APPLICATION.CREATE) {
          temp = {
            ...temp,
            stage,
            upload_type,
            url: constant.ECOSYSTEM_API + constant.CREATE_APPLICATION,
            identifier: 'lead_id',
          };
        } else if (
          stage == constant.STAGE_APPLICATION.APPROVE_LIMIT ||
          stage == constant.STAGE_APPLICATION.APPROVE_LIMIT_RESPONSE
        ) {
          temp = {
            ...temp.approve,
            stage,
            url: constant.ECOSYSTEM_API + constant.CREATE_APPROVE_LIMIT,
            identifier: 'application_id',
          };
        } else if (stage == constant.STAGE_APPLICATION.SANCTIONED_LIMIT) {
          temp = {
            ...temp.approve,
            stage,
            url: constant.ECOSYSTEM_API + constant.CREATE_APPROVE_LIMIT,
            identifier: 'application_id',
          };
        }
        finalData.push(temp);
      }
    } else {
      if (stage != null) finalData.push({ stage });
    }
  });

  return finalData;
};

/**
 * @description disbursement Request Data
 * @author Ravi Pratap Singh <ravi.singh@biz2credit.com>
 * @param {*} data
 * @returns Array
 */
module.exports.formatDisReqData = function (data) {
  const disReq = [];

  for (let val of data) {
    const {
      application_id,
      disbursement_unique_id,
      payment_request_timestamp,
      retailer_name,
      loan_account_number,
      available_credit_limit,
      total_invoice_amount,
      total_payment_requested,
      total_invoices,
      ...invoice
    } = val;

    if (application_id) {
      disReq.push({
        application_id,
        disbursement_unique_id,
        payment_request_timestamp,
        retailer_name,
        loan_account_number,
        available_credit_limit,
        total_invoice_amount,
        total_payment_requested,
        total_invoices,
        invoices: [invoice],
      });
    } else {
      disReq[disReq.length - 1].invoices.push(invoice);
    }
  }

  return disReq;
};

/**
 * @description disbursement Response Data
 * @author Ravi Pratap Singh <ravi.singh@biz2credit.com>
 * @param {*} data
 * @returns Array
 */
module.exports.formatDisbursementData = function (data) {
  const disReq = [];
  let status;
  for (let [index, val] of data.entries()) {
    let stage = val.stage;
    if (!stage && status != constant.USER_ID_CONFIG_MAPPING.UNDEFINED) {
      if (index == 0) status = constant.USER_ID_CONFIG_MAPPING.UNDEFINED;
      stage = status;
    } else {
      if (
        stage == constant.STAGE_DISBURSEMENT.DISBURSEMENT_REQUEST ||
        stage == constant.STAGE_DISBURSEMENT.DISBURSEMENT_RESPONSE ||
        stage == constant.STAGE_DISBURSEMENT.REQUEST_RECONCILIATION ||
        stage == constant.STAGE_DISBURSEMENT.RESPONSE_RECONCILIATION
      )
        status = stage;
      else {
        status = null;
      }
    }
    delete val.stage;
    switch (stage) {
      case constant.STAGE_DISBURSEMENT.DISBURSEMENT_REQUEST:
        const {
          application_id,
          disbursement_unique_id,
          payment_request_timestamp,
          retailer_name,
          loan_account_number,
          available_credit_limit,
          total_invoice_amount,
          total_payment_requested,
          total_invoices,
          ...invoice
        } = val;

        if (application_id) {
          disReq.push({
            application_id,
            disbursement_unique_id,
            payment_request_timestamp,
            retailer_name,
            loan_account_number,
            available_credit_limit,
            total_invoice_amount,
            total_payment_requested,
            total_invoices,
            invoices: [invoice],
            stage: status,
            url: constant.ECOSYSTEM_API + constant.CREATE_DISBURSEMENT_REQUEST,
            identifier: 'application_id',
          });
        } else {
          disReq[disReq.length - 1].invoices.push(invoice);
        }
        break;
      case constant.STAGE_DISBURSEMENT.DISBURSEMENT_RESPONSE:
        let res_invoice;
        const {
          invoice_no,
          distributor_unique_code,
          payee_account_number,
          disbursement_amount,
          disbursed_date,
          disbursement_status,
          payment_requested,
          ...restData
        } = val;
        res_invoice = {
          invoice_no,
          distributor_unique_code,
          payee_account_number,
          disbursement_amount,
          disbursed_date,
          disbursement_status,
          payment_requested,
        };
        if (restData.application_id) {
          disReq.push({
            ...restData,
            invoices: [res_invoice],
            stage: status,
            url: constant.ECOSYSTEM_API + constant.CREATE_DISBURSEMENT_RESPONSE,
            identifier: 'application_id',
          });
        } else {
          disReq[disReq.length - 1].invoices.push(res_invoice);
        }
        break;
      case constant.STAGE_DISBURSEMENT.REQUEST_RECONCILIATION:
        disReq.push({
          ...val,
          stage: status,
          url:
            constant.ECOSYSTEM_API +
            constant.CREATE_DISBURSEMENT_REQUEST_RECONCILIATION,
          identifier: 'application_id',
        });
        break;
      case constant.STAGE_DISBURSEMENT.RESPONSE_RECONCILIATION:
        disReq.push({
          ...val,
          stage: status,
          url:
            constant.ECOSYSTEM_API +
            constant.CREATE_DISBURSEMENT_RESPONSE_RECONCILIATION,
          identifier: 'application_id',
        });
        break;
      default:
        if (stage != null)
          disReq.push({
            stage,
          });
    }
  }

  return disReq;
};

/**
 * @description repayment Response Data
 * @author Ravi Pratap Singh <ravi.singh@biz2credit.com>
 * @param {*} data
 * @returns Array
 */
module.exports.formatRepaymentData = function (data) {
  const repRes = [];
  let status;
  for (let [index, val] of data.entries()) {
    let body, invoice, category;
    let stage = val.stage;
    if (!stage && status != constant.USER_ID_CONFIG_MAPPING.UNDEFINED) {
      if (index == 0) status = constant.USER_ID_CONFIG_MAPPING.UNDEFINED;
      stage = status;
    } else {
      if (
        stage == constant.STAGE_REPAYMENT.REPAYMENT_REQUEST ||
        stage == constant.STAGE_REPAYMENT.REPAYMENT_RESPONSE
      )
        status = stage;
      else status = null;
    }
    if (
      stage == constant.STAGE_REPAYMENT.REPAYMENT_REQUEST ||
      stage == constant.STAGE_REPAYMENT.REPAYMENT_RESPONSE
    ) {
      if (stage === constant.STAGE_REPAYMENT.REPAYMENT_RESPONSE) {
        const {
          application_id,
          repayment_unique_id,
          repayment_timestamp,
          retailer_name,
          loan_account_number,
          total_repayment_received,
          payment_status,
          pending_repayment_amount,
          available_credit_limit,
          updated_credit_limit,
          ...fields
        } = val;
        body = {
          application_id,
          repayment_unique_id,
          repayment_timestamp,
          retailer_name,
          loan_account_number,
          total_repayment_received,
          payment_status,
          pending_repayment_amount,
          available_credit_limit,
          updated_credit_limit,
          url: constant.ECOSYSTEM_API + constant.CREATE_REPAYMENT_RESPONSE,
          identifier: 'application_id',
        };
        if (!fields.disbursement_unique_id) {
          const {
            invoice_no,
            status_of_invoice_repayment,
            disbursement_amount,
            invoice_principal_deduction,
            invoice_interest_deduction,
            invoice_penalty_deduction,
            total_invoice_deduction,
            principal_os,
            interest_os,
            penalty_os,
            total_invoice_outstanding,
          } = fields;
          invoice = {
            invoice_no,
            status_of_invoice_repayment,
            disbursement_amount,
            invoice_principal_deduction,
            invoice_interest_deduction,
            invoice_penalty_deduction,
            total_invoice_deduction,
            principal_os,
            interest_os,
            penalty_os,
            total_invoice_outstanding,
          };
        } else {
          category = constant.STAGE_REPAYMENT.REPAYMENT_CATEGORY;
          body = { ...body, ...fields };
        }
      } else if (stage === constant.STAGE_REPAYMENT.REPAYMENT_REQUEST) {
        let {
          application_id,
          repayment_unique_id,
          repayment_timestamp,
          retailer_name,
          loan_account_number,
          repayment_category,
          repayment_type,
          repayment_amount,
          ...fields
        } = val;
        category = repayment_category;
        body = {
          application_id,
          repayment_unique_id,
          repayment_timestamp,
          retailer_name,
          loan_account_number,
          repayment_category,
          repayment_type,
          repayment_amount,
          url: constant.ECOSYSTEM_API + constant.CREATE_REPAYMENT_REQUEST,
          identifier: 'application_id',
        };
        if (category != constant.STAGE_REPAYMENT.REPAYMENT_CATEGORY) {
          const { invoice_no, invoice_timestamp } = fields;
          invoice = {
            invoice_no,
            invoice_timestamp,
          };
        } else {
          body['disbursement_unique_id'] = fields.disbursement_unique_id;
        }
      } else if (!val.application_id) {
        invoice = val;
      }
      if (val.application_id) {
        if (category != constant.STAGE_REPAYMENT.REPAYMENT_CATEGORY) {
          repRes.push({
            ...body,
            invoices: [invoice],
            stage,
          });
        } else {
          repRes.push({
            ...body,
            stage,
          });
        }
      } else {
        if (category != constant.STAGE_REPAYMENT.REPAYMENT_CATEGORY)
          repRes[repRes.length - 1].invoices.push(invoice);
      }
    } else {
      if (stage != null) repRes.push({ stage });
    }
  }
  return repRes;
};
