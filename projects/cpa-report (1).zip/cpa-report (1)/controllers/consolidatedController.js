"use strict";

require("dotenv").config();
const datetime = require("node-datetime");
const momentTz = require("moment-timezone");
const mailer = require("../lib/mail");
const helper = require("../lib/helper");
const awsS3 = require("../lib/awsS3");
const { Parser } = require("json2csv");
const fastcsv = require("fast-csv");
const fs = require("fs");
const appRoot = require("app-root-path");
const path = require("path");
const user = require("../db/models/user");
const backendUser = require("../db/models/backendUser");
const businessInfo = require("../db/models/businessInfo");
const userTracking = require("../db/models/userTracking");
const deviceDetector = require("node-device-detector");
const mongoose = require('mongoose');

exports.getPPPConsUserReport = async function () {
    return new Promise(async function (resolve, reject) {
        try {
            let mailData = "";
            let filePath = "";
            let userFinalData = [];
            let finalData = [];

            const detector = new deviceDetector();
            // Set header of the csv
            const fields = [
                "Channelname",
                "Sourcename",
                "Subsourcename",
                "Trackname",
                "Lead Id",
                "Lead Register Date",
                "First Name",
                "Last Name",
                "Email",
                "Phone",
                "Business Name",
                "Type of User",
                "Device",
                "OS Name",
                "OS Version",
                "Brand",
                "Model",
                "Client name",
                "Client version",
                "Full Url",
            ];

            const opts = { fields };
            const parser = new Parser(opts);

            // Get start time
            let pastDate = '2020-07-16';

            let pastStartDt = datetime.create(pastDate);
            //pastStartDt.offsetInDays(-1);

            pastStartDt = pastStartDt.format("Y-m-d");

            let startDt = datetime.create(pastStartDt);
            let startTime = startDt.epoch();

            // Get End time
            let pastEndDt = datetime.create();
            pastEndDt = pastEndDt.format("Y-m-d");

            let endDt = datetime.create(pastEndDt);
            //endDt.offsetInDays(-1);
            let endTime = endDt.epoch();

            // Subject date
            let subjectDt = datetime.create();
            subjectDt.offsetInDays(-1);
            let subjectDate = subjectDt.format("Y-m-d");

            //console.log('lt:' + endTime + '====  gte:' + startTime);

            let userData = await user.find({
                    delete:{ $ne: true },
                    created_at: { $lt: endTime },
                    created_at: { $gte: startTime },
                    email_address: { $not: /^.*@(b2cdev|biz2credit)\.([a-zA-Z\.]{2,})/ },
                    email_address: { $ne: null },
            }, {
                name: 1,
                email_address: 1,
                phone_number: 1,
                created_at: 1
            });

           if (userData.length > 0) {
                const userIds = [];
                const userMap = {};
                userData.forEach((user) => {
                    userMap[user._id] = user.email_address;
                    userIds.push(user._id.toString());
                });

                //find all the tracking data
                //const usersTrackingsData = await userTracking.find({ user_id: { $in: userIds.map((id) => mongoose.Types.ObjectId(id)) } });
                const usersTrackingsData = await userTracking.getAggregate([
                    {
                        $match: {
                            user_id: { $in: userIds.map((id) => mongoose.Types.ObjectId(id)) }
                        }
                    }
                ]);

                const trackingMap = {};
                usersTrackingsData.forEach((userTrackingData) => {
                    const item = userTrackingData
                    trackingMap[item.user_id] = item;
                });
                // find all the business data
               // const businessData = await businessInfo.find({ user_id: { $in: userIds } }, { user_id: 1, primary_contact: 1, business_phone: 1, business_name: 1 });
                const businessData = await businessInfo.getAggregate([
                    {
                        $match: {
                            user_id: { $in: userIds }
                        }
                    },
                    {
                        $project: {
                            user_id: 1,
                            primary_contact: 1,
                            business_phone: 1,
                            business_name: 1
                        }
                    }
                ]);
                const businessMap = {};
                businessData.forEach((b) => {
                    const item = b;
                    businessMap[item.user_id] = item;
                });

                userData.forEach((item) => {

                    const user = item.toObject();
                    const user_id = user._id.toString();
                    const userTrackingData = trackingMap[user_id];
                    const userBusinessData = businessMap[user_id];

                    let firstName = "";
                    let lastName = "";
                    if (userBusinessData && userBusinessData.primary_contact) {
                        const fullname = userBusinessData.primary_contact.split(" ");
                        firstName = fullname.slice(0, 1).join(" ") || "";
                        lastName = fullname.slice(1).join(" ") || "";
                    }
                    const data = helper.prepareData(
                        userTrackingData,
                        user_id,
                        user.email_address,
                        "Customer",
                        firstName,
                        lastName,
                        user.created_at,
                        userBusinessData && userBusinessData.business_phone ? userBusinessData.business_phone : "",
                        { "Business Name": userBusinessData && userBusinessData.business_name ? userBusinessData.business_name : "" }
                    );
                    
                    finalData.push(data);
                });
            }

            if (finalData.length > 0) {
                 // Convert json data into csv
                 let contents = parser.parse(finalData);
 
                 // Temporary file name
                 let attach_fileName = "user-info-report.csv";
 
                 if (process.env.NODE_ENV == "local") {
                     filePath = path.resolve(attach_fileName);
                 } else {
                     filePath = path.resolve("/tmp/" + attach_fileName);
                 }
 
                 const writeStream = fs.createWriteStream(filePath);
                 writeStream.write(contents);
 
                 writeStream.on("finish", () => {
                     console.log("wrote all data to file");
                 });
 
                 writeStream.end();

                 let prefixDt = datetime.create();
                 prefixDt.offsetInDays(-1);
                 let prefixDate = prefixDt.format("Y-m-d");
                 let splitDate = prefixDate.split("-");
                 let prefix =
                     "reports/customer_info/" +
                     process.env.NODE_ENV +
                     "/" +
                     splitDate[0] +
                     "/" +
                     splitDate[1];
                 let fileName = prefixDate + "_pppforgiveness-customer-reg.csv";
                 let bucketName = process.env.BUCKET_NAME + "/" + prefix;
 
                 await awsS3.createLogFile(bucketName, fileName, contents);
 
                 let fileUrl = process.env.BUCKET_URL +"/" + prefix +"/"+ fileName;
                 let bodyText = "<p>Hi, Please download the report by clicking the following link and find related data.</p>Total number of customers on the platform: "+finalData.length+"</br><p><a href='"+fileUrl+"' target='_blank'>Download Report</a></p>";

                 mailData = {
                     from_email: process.env.USER_INFO_EMAIL_FROM,
                     to_email: process.env.USER_INFO_EMAIL_TO,
                     subject:
                         "PPPForgivenessTool.com – Consolidated Customer Registration details for " +
                         subjectDate,
                     html: bodyText
                 };
                 if (
                     process.env.USER_INFO_CC_EMAIL != undefined &&
                     process.env.USER_INFO_CC_EMAIL != ""
                 ) {
                     mailData["cc"] = process.env.USER_INFO_CC_EMAIL;
                 }
             } else {
                 mailData = {
                     from_email: process.env.USER_INFO_EMAIL_FROM,
                     to_email: process.env.USER_INFO_EMAIL_TO,
                     subject:
                         "PPPForgivenessTool.com – Consolidated CPA Registration details for " +
                         subjectDate,
                     text: "Hi, No new registration was found",
                 };
                 if (
                     process.env.USER_INFO_CC_EMAIL != undefined &&
                     process.env.USER_INFO_CC_EMAIL != ""
                 ) {
                     mailData["cc"] = process.env.USER_INFO_CC_EMAIL;
                 }
             }
 
             let notification = await mailer.mailSender(mailData);

             fs.unlink(filePath, function (err) {
                 if (err) {
                     reject(err);
                 }
             });
 
             if (notification) {
                 resolve(notification);
             } else {
                 throw new Error("Mail not sent");
             }

        } catch (error) {
            reject(error);
        }
    }).catch(function (error) {
        throw error;
    });
};

exports.getPPPConsCPAUserReport = async function () {
    return new Promise(async function (resolve, reject) {
        try {
            let mailData = "";
            let filePath = "";
            let finalData = [];
            const detector = new deviceDetector();

            // Set header of the csv
            const fields = [
                "Channelname",
                "Sourcename",
                "Subsourcename",
                "Trackname",
                "Lead Id",
                "Lead Register Date",
                "First Name",
                "Last Name",
                "Email",
                "Phone",
                "Type of User",
                "Device",
                "OS Name",
                "OS Version",
                "Brand",
                "Model",
                "Client name",
                "Client version",
                "Full Url",
                "Email Verified"
            ];

            const opts = { fields };
            const parser = new Parser(opts);

            // Get start time
            let pastDate = '2020-07-16';
            let pastStartDt = datetime.create(pastDate);
            // pastStartDt.offsetInDays(-1);
            pastStartDt = pastStartDt.format("Y-m-d");
            let startDt = datetime.create(pastStartDt);
            let startTime = startDt.epoch();

            // Get End time
            let pastEndDt = datetime.create();
            pastEndDt = pastEndDt.format("Y-m-d");
            let endDt = datetime.create(pastEndDt);
            //endDt.offsetInDays(-1);
            let endTime = endDt.epoch();

            // Subject date
            let subjectDt = datetime.create();
            subjectDt.offsetInDays(-1);
            let subjectDate = subjectDt.format("Y-m-d");

            // Fetch record from cpa user data collection according to time

            let backendUserData = await backendUser.find({
                $and: [
                    { delete: { $ne: true } },
                    { created_at: { $lt: endTime } },
                    { created_at: { $gte: startTime } },
                    { email_address: { $not: /^.*@(b2cdev|biz2credit)\.([a-zA-Z\.]{2,})/ } },
                    { email_address: { $ne: null } }
                ]
            },
            {
                name:1,
                email_address: 1,
                phone_number:1,
                created_at: 1,
                name:1,
                "data.first_name": 1,
                "data.last_name": 1,
                is_verified: 1
            });

            if (backendUserData.length > 0) {
                // userData = userData;

                const userIds = [];
                const userMap = {};
                backendUserData.forEach((user) => {
                    userMap[user._id] = user;
                    userIds.push(user._id.toString());
                });

                //find all the tracking data
                //const usersTrackingsData = await userTracking.find({ user_id: { $in:  userIds.map((id) => mongoose.Types.ObjectId(id))}});
                const usersTrackingsData = await userTracking.getAggregate([
                    {
                        $match: {
                            user_id: { $in: userIds.map((id) => mongoose.Types.ObjectId(id)) }
                        }
                    }
                ]);
                const trackingMap = {};
                usersTrackingsData.forEach((userTrackingData) =>  {
                    const item = userTrackingData;
                    trackingMap[item.user_id] = item;
                });

                
                backendUserData.forEach((item) => {
                    const user = item.toObject();
                    const user_id = user._id.toString();
                    const userTrackingData = trackingMap[user_id];
                    
                    let firstName = "";
                    let lastName = "";
                    if(user.name) {
                    const fullname = user.name.split(" ");
                        firstName = fullname.slice(0,1).join(" ") || "";
                        lastName = fullname.slice(1).join(" ") || "";
                    }


                    const data = helper.prepareData(
                        userTrackingData,
                        user_id, 
                        user.email_address,
                        "CPA User",
                        firstName,
                        lastName,
                        user.created_at,
                        !user.phone_number || isNaN(user.phone_number) ? "" : parseInt(user.phone_number),
                        {"Email Verified": user.is_verified}
                    );

                    finalData.push(data);
                });
            }
          
          if (finalData.length > 0) {
                // Convert json data into csv
                let contents = parser.parse(finalData);

                // Temporary file name
                let attach_fileName = "user-info-report.csv";

                if (process.env.NODE_ENV == "local") {
                    filePath = path.resolve(attach_fileName);
                } else {
                    filePath = path.resolve("/tmp/" + attach_fileName);
                }

                const writeStream = fs.createWriteStream(filePath);
                writeStream.write(contents);

                writeStream.on("finish", () => {
                    console.log("wrote all data to file");
                });

                writeStream.end();

                let prefixDt = datetime.create();
                prefixDt.offsetInDays(-1);
                let prefixDate = prefixDt.format("Y-m-d");
                let splitDate = prefixDate.split("-");
                let prefix =
                    "reports/cpa_user_info/" +
                    process.env.NODE_ENV +
                    "/" +
                    splitDate[0] +
                    "/" +
                    splitDate[1];
                let fileName = prefixDate + "_pppforgiveness-cpa-lead-reg.csv";
                let bucketName = process.env.BUCKET_NAME + "/" + prefix;

                await awsS3.createLogFile(bucketName, fileName, contents);

                let attachments = [
                    {
                        filename: fileName,
                        path: filePath,
                    },
                ];

                mailData = {
                    from_email: process.env.USER_INFO_EMAIL_FROM,
                    to_email: process.env.USER_INFO_EMAIL_TO,
                    subject:
                        "PPPForgivenessTool.com – Consolidated CPA Registration details for " +
                        subjectDate,
                    text: "Hi, PFA is the report.",
                    attachments: attachments,
                };
                if (
                    process.env.USER_INFO_CC_EMAIL != undefined &&
                    process.env.USER_INFO_CC_EMAIL != ""
                ) {
                    mailData["cc"] = process.env.USER_INFO_CC_EMAIL;
                }
            } else {
                mailData = {
                    from_email: process.env.USER_INFO_EMAIL_FROM,
                    to_email: process.env.USER_INFO_EMAIL_TO,
                    subject:
                        "PPPForgivenessTool.com – Consolidated CPA Registration details for " +
                        subjectDate,
                    text: "Hi, No new registration was found",
                };
                if (
                    process.env.USER_INFO_CC_EMAIL != undefined &&
                    process.env.USER_INFO_CC_EMAIL != ""
                ) {
                    mailData["cc"] = process.env.USER_INFO_CC_EMAIL;
                }
            }

            let notification = await mailer.mailSender(mailData);

            fs.unlink(filePath, function (err) {
                if (err) {
                    reject(err);
                }
            });

            if (notification) {
                resolve(notification);
            } else {
                throw new Error("Mail not sent");
            }

        } catch (error) {
            reject(error);
        }
    }).catch(function (error) {
        throw error;
    });
};