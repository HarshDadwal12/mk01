import {
  Body,
  Controller,
  Post,
  Get,
  Req,
  UseGuards,
  Query,
  Patch,
  Param,
  UsePipes,
  ValidationPipe,
} from '@nestjs/common';
import { File } from 'src/core/decorators/file.decorator';
import { AuthGuard } from '../../core/gaurd/auth.gaurd';
import { ApplicationService } from './application.service';
import {
  UserApplicationDto,
  GetApplicationDto,
  ApplicationApprovedLimitDto,
  ApplicationAdditionalDto,
  applicationBusinessGstDto,
  applicationBusinessGstPatchDto,
  ApplicationAdditionalPatchDto,
  invoiceTrancheDto,
  transactionInfoDto,
  appSummaryDto,
  UserApplicationPatchDto,
} from './dto/application.dto';
import {
  DisbursementRequestDto,
  DisbursementResponseDto,
  DisbursementRequestReconDto,
  DisbursementResponseReconDto,
} from './dto/disbursement.dto';

@Controller({
  version: '1.0',
})
@UseGuards(AuthGuard)
export class ApplicationController {
  constructor(private applicationService: ApplicationService) {}

  @Post('')
  async postApplication(@Req() req: any, @Body() body: UserApplicationDto) {
    try {
      const result = await this.applicationService.processApplicationCreation(
        req,
        body,
      );

      return {
        data: result,
        filter: true,
        key: 'application_created',
        event: 'application.created',
        hook: true,
      };
    } catch (error) {
      throw error;
    }
  }

  @Get('')
  async getUserApplication(@Query() query: GetApplicationDto) {
    try {
      const result = await this.applicationService.getApplication(query);
      return {
        data: result,
        filter: true,
        key: 'application_get',
      };
    } catch (error) {
      throw error;
    }
  }

  @Patch('')
  async patchApplicationData(@Body() body: UserApplicationPatchDto) {
    try {
      const data = await this.applicationService.updateApplicationData({
        ...body,
      });

      return {
        data: { id: body.application_id },
        key: 'application_update',
        filter: true,
        event: 'application.updated',
        hook: false,
      };
    } catch (error) {
      throw error;
    }
  }

  @Post('approve-limit')
  @UsePipes(new ValidationPipe({ whitelist: true, forbidNonWhitelisted: true }))
  async createAprovedLimit(
    @Req() req: any,
    @Body() body: ApplicationApprovedLimitDto,
  ) {
    try {
      await this.applicationService.createAprovedLimit(req, {
        ...body,
        backend_user_id: req.user.backend_user_id,
      });

      return {
        data: { id: body.application_id },
        key: 'approve_limit',
        filter: true,
        event: 'application.approve.limit.' + req.user.user_type,
        hook: true,
      };
    } catch (error) {
      throw error;
    }
  }

  @Post('gst')
  async processApplicationGst(
    @Req() req: any,
    @Body() body: applicationBusinessGstDto,
  ) {
    try {
      await this.applicationService.createAnalysis(
        {
          ...body,
          type: 'application_gst',
          backend_user_id: req?.user?.backend_user_id,
        },
        'application_gst',
      );
      await this.applicationService.setApplicationStatusUnderwriting(body);
      return {
        key: 'application_gst',
        data: { id: body.application_id },
        filter: true,
        event: 'application.gst.created',
        hook: true,
      };
    } catch (error) {
      throw error;
    }
  }

  @Patch('gst')
  async patchApplicationGst(@Body() body: applicationBusinessGstPatchDto) {
    try {
      const data = await this.applicationService.patchAnalysis(
        {
          ...body,
        },
        'application_gst',
        'application_gst_patch',
      );

      return {
        data: { ...data, id: body.application_id },
        key: 'application_gst_patch',
        filter: true,
        event: 'application.gst.updated',
        hook: true,
      };
    } catch (error) {
      throw error;
    }
  }

  @Post('additional')
  async saveApplicationAdditionalData(
    @Req() req: any,
    @Body() body: ApplicationAdditionalDto,
  ) {
    try {
      await this.applicationService.createAnalysis(
        {
          ...body,
          type: 'application_additional',
          backend_user_id: req?.user?.backend_user_id,
        },
        'application_additional',
      );
      return {
        data: { id: body.application_id },
        key: 'application_additional',
        filter: true,
        event: 'application.additional.created',
        hook: true,
      };
    } catch (error) {
      throw error;
    }
  }

  @Patch('additional')
  async patchApplicationAdditionalData(
    @Body() body: ApplicationAdditionalPatchDto,
  ) {
    try {
      const data = await this.applicationService.patchAnalysis(
        {
          ...body,
        },
        'application_additional',
        'application_additional_patch',
      );

      return {
        data: { ...data, id: body.application_id },
        key: 'application_additional_patch',
        filter: true,
        event: 'application.additional.updated',
        hook: true,
      };
    } catch (error) {
      throw error;
    }
  }

  @Post('disbursement/request')
  async disbursementRequest(
    @Req() req: any,
    @Body() body: DisbursementRequestDto,
  ) {
    try {
      await this.applicationService.implementDisbursementRequestValidations(req,
        body,
      );
      await this.applicationService.setInitialsInDisbursementRequest(
        body,
      );
      const data = await this.applicationService.createAnalysis(
        {
          ...body,
          type: 'disbursement_request',
          backend_user_id: req?.user?.backend_user_id,
        },
        'disbursement_request',
      );

      return {
        data,
        key: 'disbursement_request',
        filter: true,
        event: 'disbursement.request',
        hook: true,
      };
    } catch (error) {
      throw error;
    }
  }

  @Post('disbursement/response')
  async disbursementResponse(
    @Req() req: any,
    @Body() body: DisbursementResponseDto,
  ) {
    try {
      await this.applicationService.implementDisbursementResponseValidations(
        body,
      );
      body = await this.applicationService.computeFinalDisbursementStatus(body);
      const data = await this.applicationService.createAnalysis(
        {
          ...body,
          type: 'disbursement_response',
          backend_user_id: req?.user?.backend_user_id,
        },
        'disbursement_response',
      );
      await this.applicationService.updateDisbursementRequest(
        body,
        'disbursement_request_patch',
      );
      return {
        data,
        key: 'disbursement_response',
        filter: true,
        event: 'disbursement.response',
        hook: true,
      };
    } catch (error) {
      throw error;
    }
  }

  @Post('disbursement/request/reconciliation')
  async disbursementRequestReconciliation(
    @Req() req: any,
    @Body() body: DisbursementRequestReconDto,
  ) {
    try {
      const data = await this.applicationService.createAnalysis(
        {
          ...body,
          type: 'disbursement_request_reconciliation',
          backend_user_id: req?.user?.backend_user_id,
        },
        'disbursement_request_reconciliation',
      );

      return {
        data,
        key: 'disbursement_request_reconciliation',
        filter: true,
        event: 'disbursement.request.reconciliation',
        hook: false,
      };
    } catch (error) {
      throw error;
    }
  }

  @Post('disbursement/response/reconciliation')
  async disbursementResponseReconciliation(
    @Req() req: any,
    @Body() body: DisbursementResponseReconDto,
  ) {
    try {
      const data = await this.applicationService.createAnalysis(
        {
          ...body,
          type: 'disbursement_response_reconciliation',
          backend_user_id: req?.user?.backend_user_id,
        },
        'disbursement_response_reconciliation',
      );

      return {
        data,
        key: 'disbursement_response_reconciliation',
        filter: true,
        event: 'disbursement.response.reconciliation',
        hook: true,
      };
    } catch (error) {
      throw error;
    }
  }

  @Post('document')
  async uploadDocument(@File() file: any, @Req() req: any) {
    try {
      const { backend_user_id } = req.user;
      const application_id = Number(file?.fields?.application_id?.value);
      await this.applicationService.uploadDocument(
        file,
        application_id,
        file?.fields.doc_type?.value,
        backend_user_id,
      );
      return {
        data: { id: application_id },
        key: 'document_upload',
        filter: true,
        event: 'application.document.upload',
        hook: true,
      };
    } catch (error) {
      throw error;
    }
  }

  @Get('document/metadata')
  async getDocumentMetadata() {
    try {
      const data = await this.applicationService.getDocumentMetadata();

      return { data, key: 'document_metadata', filter: true };
    } catch (error) {
      throw error;
    }
  }

  @Get('summary/:application_id')
  async getProfile(@Param() params: appSummaryDto) {
    try {
      const data = await this.applicationService.getAppSummary(params);
      return {
        data,
        filter: true,
        key: 'app_summary',
      };
    } catch (error) {
      throw error;
    }
  }

  @Get('invoice/tranche')
  async getInvoiceTrancheSummary(@Query() body: invoiceTrancheDto) {
    try {
      const data = await this.applicationService.getInvoiceTrancheSummary(body);
      return {
        data,
        filter: true,
        key: 'invoice_summary',
      };
    } catch (error) {
      throw error;
    }
  }

  @Get('transaction_info/:id')
  async getTransactionInfo(@Param() params: transactionInfoDto) {
    try {
      const data = await this.applicationService.getApplicationTransactionInfo(
        params,
      );
      return {
        data,
        filter: true,
        key: 'transaction_info',
      };
    } catch (error) {
      throw error;
    }
  }
}
