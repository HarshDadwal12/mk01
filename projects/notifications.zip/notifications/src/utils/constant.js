module.exports = {
  CASE_API: process.env.CASE_API,
  USER_API: process.env.USER_API,
  DOCUMENT_API: process.env.DOCUMENT_API,
  ECOSYSTEM_API: process.env.ECOSYSTEM_API,
  ORCH_API: process.env.ORCH_API,
  ACCESS_KEY: process.env.ACCESS_KEY,
  QUEUE_BULK_UPLOAD_URL:process.env.QUEUE_BULK_UPLOAD_URL,
  CHUNK_SIZE : 500,
  GET_DOCUMENT: '/api/v3/doc/downloadJson/',
  CREATE_LEAD: '/api/leads',
  UPDATE_LEAD: '/api/leads/status',
  CREATE_APPLICATION: '/api/application',
  CREATE_OWNER: '/api/application/owners',
  CREATE_ADDITIONAL: '/api/application/additional',
  CREATE_GST: '/api/application/gst',
  CREATE_APPROVE_LIMIT: '/api/application/approve-limit',
  CREATE_DISBURSEMENT_REQUEST: '/api/application/disbursement/request',
  CREATE_REPAYMENT_REQUEST: '/api/application/repayment/request',
  CREATE_REPAYMENT_RESPONSE: '/api/application/repayment/response',
  CREATE_REPAYMENT_REQUEST_RECONCILIATION:
    '/api/application/repayment/request/reconciliation',
  CREATE_DISBURSEMENT_REQUEST_RECONCILIATION:
    '/api/application/disbursement/request/reconciliation',
  CREATE_DISBURSEMENT_RESPONSE_RECONCILIATION:
    '/api/application/disbursement/response/reconciliation',
  CREATE_DISBURSEMENT_RESPONSE: '/api/application/disbursement/response',
  GET_LEAD: '/api/v1/users',
  LENDER_CONFIG: '/api/user',
  GET_APPLICATION: '/api/v1/application',
  GET_ANALYSIS: '/api/v1/analysis',
  STAGE_APPLICATION: {
    CREATE: 'creation',
    APPROVE_LIMIT: 'approve_limit',
    APPROVE_LIMIT_RESPONSE: 'approve_limit_response',
    SANCTIONED_LIMIT: 'sanctioned_limit',
    NEW:'new',
    UPDATE:'update'
  },
  STAGE_LEAD:{
    LEAD_CREATE:'lead_create',
    LEAD_STATUS:'lead_status'
  },
  STAGE_DISBURSEMENT:{
    DISBURSEMENT_REQUEST:'disbursement_request',
    DISBURSEMENT_RESPONSE:'disbursement_response',
    REQUEST_RECONCILIATION:'request_reconciliation',
    RESPONSE_RECONCILIATION:'response_reconciliation'
  },
  STAGE_REPAYMENT:{
    REPAYMENT_REQUEST:'repayment_request',
    REPAYMENT_RESPONSE:'repayment_response',
    REPAYMENT_CATEGORY:"TRANCHE"
  },
  USER_ID_CONFIG_MAPPING:{
    application: {
      creation: 'aggregator_user_id',
      approve_limit: 'lender_user_id',
      approve_limit_response: 'aggregator_user_id',
      sanctioned_limit: 'lender_user_id',
    },
    lead:{
      lead_create:'aggregator_user_id',
      lead_status:'lender_user_id'
    },
    disbursement:{
      disbursement_request:'aggregator_user_id',
      disbursement_response:'lender_user_id',
      request_reconciliation:'aggregator_user_id',
      response_reconciliation:'lender_user_id'
    },
    repayment:{
      repayment_request:'aggregator_user_id',
      repayment_response:'lender_user_id'
    },
    UNDEFINED:'undefined'
  }
};
