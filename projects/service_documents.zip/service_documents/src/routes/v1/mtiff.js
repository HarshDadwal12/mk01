/** @format */

const express = require('express');
const multerConfig = require("../../config/multer.config");
const upload = new multerConfig().upload;
const { pdfValidator } = require('../../validators/mtiff.validator');
const mtiffController = require('../../controllers/v1/mtiffController');
const {
	pdfToTiffValidator,
	uploadTiffValidator,
} = require('../../validators/mtiff.validator');

const routes = express.Router();

routes.post(
	'/pdf_to_tiff',
	upload.single('file'),
	pdfToTiffValidator,
	mtiffController.doPdfToTiff
);

routes.post(
	'/upload_tiff',
	upload.single('file'),
	uploadTiffValidator,
	mtiffController.doUploadTiff
);

module.exports = routes;
