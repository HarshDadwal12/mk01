const helper = require("../../helpers/helper");
const s3 = require("../../config/s3.config.js");
const fileValidations = require("../../config/files.config");
const uuidv4 = require("uuid/v4");
const config = require("../../../config/config");
const docUtils = require("../../utils/docUtils");
// const Jimp = require('jimp');

module.exports = {

    // async imageUpload(req, allResolutions, fileName, fileNameExt, result) {
    //     if(!allResolutions.length) {
    //         return [];
    //     }

    //     const resolution = allResolutions.pop();
    //     const splitted = resolution.split(/[:x]/); //['small', '100', '100']
    //     const data = {
    //         size: splitted[0],
    //         height: splitted[1] ? +splitted[1]: Jimp.AUTO,
    //         width: splitted[2] ? +splitted[2]: Jimp.AUTO,
    //     };
    //     let imageName = `${uuidv4()}-${fileName}-${data.height.toString().replace('-', '')}x${data.width.toString().replace('-', '')}.${fileNameExt}`;
    //     data.image = keySuffix ? `${keySuffix}/${imageName}`: imageName;
    //     data.imgBuffer = await Jimp.read(buffer).then((image) => {
    //         return image.resize(data.width, data.height).getBufferAsync(Jimp.AUTO);
    //     });

    //     const params = {
    //         ...s3.uploadParams(req.headers["x-tenant-id"]),
    //         Key: data.image,
    //         Body: data.imgBuffer,
    //     };

    //     const uploaded = await docUtils.UploadToS3(req, params);

    //     result.push(data);

    //     return this.imageUpload(req, allResolutions, fileName, fileNameExt);
    // },
	/**
	 * @description Upload image file on s3 bucket
	 *
	 * @author Amit Kishore<amit.kishore@biz2credit.com>
	 *
	 * @param req
	 * @param res
	 *
	 * @returns string
	 */
	async doImageUpload(req, res) {
		try {
			const { doc_type_id, doc_type_key, updated_file_name, resolutions, quality=0.5, data, filename } = req.body;
            
            const buffer = req.file.buffer;
            // const buffer = Buffer.from(data, "base64");
            const originalName = req.file.originalname;
            const fileNameData = originalName.split('.');
            const fileNameExt= fileNameData.pop();
            const fileName = fileNameData.join('.');

            const keySuffix = req.body.base_folder
				? req.body.base_folder
				: config.BUCKET_BASEFOLDER
				? config.BUCKET_BASEFOLDER
				: null;

            let images = {};
            let docKey = '';

            // resolutions = small:100x100,medium:200:200,key:heightxwidth
            if(resolutions && typeof resolutions === 'string') {

                const allResolutions = resolutions.split(','); //['small:100x100', 'medium:200:200']

                const fileData = { fileName, fileNameExt, buffer, keySuffix };

                const output = await docUtils.imageUpload(req,  allResolutions, fileData, []) || [];
                output.forEach((o) => {
                    images[o.size] = o.image;
                    docKey = o.image;
                });
            } else {
                const data = {
                    image: keySuffix ? `${keySuffix}/${uuidv4()}-${fileName}-original.${fileNameExt}`: `${uuidv4()}-${fileName}-original.${fileNameExt}`,
                    size: 'original'
                }

                const params = {
                	...s3.uploadParams(req.headers["x-tenant-id"]),
                	Key: data.image,
                	Body: buffer,
                };

                const uploaded = await docUtils.UploadToS3(req, params);
                images[data.size] = data.image;
                docKey = data.image;
            }

            let body = {
                doc_type_id,
                doc_type_key,
                updated_file_name,
                is_deleted: fileValidations.is_deleted_false,
                images
            };

            const doc = await docUtils.saveDoc(req, {Key: docKey}, body);

            return helper.getSuccessResponse(req, res, doc);

		} catch (err) {
			console.log("error:::", err);
			return res.status(400).send(err);
			// return helper.getErrorResponse(req, res);
		}
	},
}
