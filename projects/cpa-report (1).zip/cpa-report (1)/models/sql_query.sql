select 
LeadId,
CaseId,
`Business Name` "Business Name",
paycheck_case,
`Yodlee Bank Name`"Yodlee Bank Name",
`Yodlee_Account_number`"Yodlee_Account_number",
`Yodlee_Routing_number`"Yodlee_Routing_number",
`Yodlee Creation date`"Yodlee Creation date",
`Yodlee Updation date`"Yodlee Updation date",
`ManualACHdetail BankName`"ManualACHdetail BankName", 
`ManualACHdetail RountingNo`"ManualACHdetail RountingNo", 
`ManualACHdetail AccountingNo`"ManualACHdetail AccountingNo", 
`SBALoanNo`"SBALoanNo", 
`SBA Approved Amount` "SBA Approved Amount"
from 
    (select jf.userid as LeadId,
    jf.fid as CaseId,
    jf.orgname as "Business Name",
    jf.email,
    jf.paycheck_case,
    jfb.bank_name"Yodlee Bank Name",
    jfub.fullAccNumber "Yodlee_Account_number",
    bankTransferCode "Yodlee_Routing_number",
    jfub.creationDate"Yodlee Creation date",
    jfub.updationDate "Yodlee Updation date",
    case when (jfub.fullAccNumber is not null or bankTransferCode is not null) then "Yes" 
         when jfl.bank_routing_no <> ' ' then "Yes" else "no" end as  flag,
    jfl.bankname "ManualACHdetail BankName", 
    jfl.bank_routing_no "ManualACHdetail RountingNo", 
    jfl.bank_account_no "ManualACHdetail AccountingNo", 
    jf.sba_loan_no "SBALoanNo", 
    jf.sba_approve_amt "SBA Approved Amount",
    cm2.cm_status "Case Status"
    from jos_users ju
    inner join jos_financial jf on ju.id=jf.userid
    inner JOIN (select distinct cm_app_id 
           from jos_cm_status a
           inner join jos_financial b on a.cm_app_id=b.fid
           where a.cm_status in ( "Approved - SBA PPP","Loan Closing - SBA PPP","Loan Closing – SBA PPP")
           and b.paycheck_case=1 )asba on jf.fid=asba.cm_app_id
           
    left join jos_financedata_users_bank jfub on jf.userid=jfub.uid and updationDate > "2020-05-01 00:00:00"
                                              -- and (jfub.fullAccNumber is not null or bankTransferCode is not null)
    left join jos_financedata_banks jfb on jfub.bankid=jfb.id
    
    left join jos_financial jfl on jf.fid=jfl.fid and jfl.paycheck_case=1 -- and jfl.bank_routing_no <> ' ' 
    
    Left join (select cm_user_id,cm_app_id, cm_status 
               from jos_cm_status 
               where cm_status_id in (select max(cm_status_id) 
                                      from jos_cm_status
                                      group by cm_app_id)) cm2 on jf.fid=cm2.cm_app_id 
                                      
    where jf.paycheck_case=1
    and ju.userlevel=1
    and ju.name not like '%test%'
    and ju.name not like '%login%'
    and ju.name not like '%aaa%'
    and ju.name not like '%abcd%'
    and ju.name not like '%asdf%'
    and ju.lname not like '%test%'
    and ju.lname not like '%login%'
    and ju.lname not like '%aaa%'
    and ju.lname not like '%abcd%'
    and ju.lname not like '%asdf%'
    and ju.email not like '%sakshay%'
    and ju.email not like '%b2cdev%'
    and ju.id not in (12516,20862,41174,57101,84596,83372,79290,73756,9258,154292,14277)
    order by 1,2,7 desc,10 desc)ty
where flag="Yes"
group by 1,2,6
order by LeadId,CaseId;

