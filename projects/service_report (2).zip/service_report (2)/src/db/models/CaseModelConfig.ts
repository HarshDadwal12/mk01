import DB from '../db';

export class CaseModelConfig {
    conn: any;
    request_collection_name: string;

    constructor(collectionName: string) {
        this.request_collection_name = collectionName;

        this.conn = DB.createConnection(
            process.env.MONGO_CASE_DB_URL,
            this.request_collection_name,
            "./schemas/applicationSchema"
        );
    }

    async find(conditions = {}) {
        try {
            let Collection = this.conn.model(this.request_collection_name);
            return await Collection.find(conditions);
        } catch (error) {
            return error;
        }
    }

    async aggregate(pipeline : any[]) {
        try {
            let Collection = this.conn.model(this.request_collection_name);
            return await Collection.aggregate(pipeline);
        } catch (error) {
            return error;
        }
    }
}


