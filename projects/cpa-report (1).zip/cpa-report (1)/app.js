const express = require('express')
const app = express();
const {ppp_application_report, 
  ppp_aicpa_cpa_report, 
  get_PPP_Business_Report, 
  get_PPP_AICPA_FIRM_Report, 
  cpaFirmReport, 
  ppp_consolidated_cpa_user_report,
  ppp_consolidated_user_report,
  urgent_firm_report,
  case_linkup_report,
  forgiveness_consume_count,
  getCoverPeriodReport,
  bulk_app_assignment,
  app_assignment_by_caseId,
  covered_period_end_date,
  get_CPA_App_Report} = require('./index');
  
 
app.get('/app-report', async (req, res) => {
  const result = await ppp_application_report();

  return res.send(result);
})

app.get('/aicpa-report', async (req, res) => {
  console.log('callled',';;;');
  req.setTimeout(500000);
  const result = await ppp_aicpa_cpa_report(req);

  return res.send(result);
})

app.get('/aicpa-firm-report', async (req, res) => {
  console.log('callled',';;;');
  req.setTimeout(500000);
  const result = await get_PPP_AICPA_FIRM_Report(req);

  return res.send(result);
})
 

app.get('/business-report', async (req, res) => {
  console.log('callled',';;;');
  const result = await get_PPP_Business_Report(req);

  return res.send(result);
})

app.get('/ppp-commission-report', async (req, res) => {
  console.log('callled',';;;');
  const result = await cpaFirmReport(req);

  return res.send(result);
})
 
app.get('/get-ppp-consolidated-cpa-user-report', async (req, res) => {
  const result = await ppp_consolidated_cpa_user_report(req);

  return res.send(result);
})

app.get('/get-ppp-consolidated-user-report', async (req, res) => {
  const result = await ppp_consolidated_user_report(req);

  return res.send(result);
})

app.get('/urgent_firm_report', async (req, res) => {
  const result = await urgent_firm_report(req);

  return res.send(result);
})

app.get('/case_linkup_report', async (req, res) => {
  const result = await case_linkup_report(req);

  return res.send(result);
})
app.get('/forgiveness_consume_count', async (req, res) => {
  const result = await forgiveness_consume_count(req);

  return res.send(result);
})
app.get('/getCoverPeriodReport', async (req, res) => {
  const result = await getCoverPeriodReport(req);

  return res.send(result);
})
app.get('/bulk_app_assignment', async (req, res) => {
  const result = await bulk_app_assignment(req);

  return res.send(result);
})
app.get('/app_assignment_by_caseid', async (req, res) => {
  const result = await app_assignment_by_caseId(req);

  return res.send(result);
})
app.get('/covered_period_end_date', async (req, res) => {
  const result = await covered_period_end_date(req);

  return res.send(result);
})
app.get('/get_CPA_App_Report', async (req, res) => {
  const result = await get_CPA_App_Report(req);

  return res.send(result);
})
 
let server = app.listen(3000);
// server.timeout = 100000