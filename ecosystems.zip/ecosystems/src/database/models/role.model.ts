import { model, Schema } from 'mongoose';
import { BASE_SCHEMA } from './base.model';

const rolesSchema = new Schema(
  {
    user_id: { type: Schema.Types.ObjectId, required: true },
    path: { type: String, required: true },
    method: {
      type: [String],
      enum: ['GET', 'POST', 'DELETE', 'PATCH', 'PUT'],
      required: true,
    },
  },
  { versionKey: false },
).add(BASE_SCHEMA);

rolesSchema.index({ user_id: 1, path: 1 }, { unique: true, background: true });

// rolesSchema.methods = {
//   toJSON() {
//     const t = this.toObject();
//     const result: any = {
//       ...t,
//       id: this._id,
//     };
//     delete result._id;
//     return result;
//   }
// };
export default model('Role', rolesSchema, 'roles');
