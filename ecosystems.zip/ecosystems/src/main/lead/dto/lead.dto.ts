import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import {
  IsAlphanumeric,
  IsDefined,
  IsEmail,
  IsIn,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  Matches,
  MaxLength,
  MinLength,
  IsPositive,
  IsObject,
  ValidateIf,
  IsNotEmptyObject,
  ValidateNested,
} from 'class-validator';

import { Type } from 'class-transformer';

class LeadAdditionalDto {
  @IsDefined()
  @IsString()
  @ApiProperty()
  'address_of_the_shop': string;

  @IsDefined()
  @IsAlphanumeric()
  @ApiProperty()
  'retailer_name': string;

  @IsDefined()
  @IsAlphanumeric()
  @ApiProperty()
  'business_name': string;

  @IsDefined()
  @Transform(({ value }) => value.toString())
  @MaxLength(6)
  @Matches(/\d{6}/, { message: 'business_pincode must be 6 character' })
  @ApiProperty()
  'business_pincode': string;

  @IsDefined()
  @IsString()
  @ApiProperty()
  'business_state': string;

  @IsDefined()
  @MaxLength(10)
  @Matches(/[a-zA-z0-9]{10}/, { message: 'business_pan must be 10 character' })
  @ApiProperty()
  'business_pan': string;

  @IsDefined()
  @IsString()
  @ApiProperty()
  'retailer_id': string;

  @IsDefined()
  @IsString()
  @IsIn(['PARTNERSHIP', 'PROPRIETERSHIP', 'PRIVATE LABEL'])
  @ApiProperty()
  'entity_type': string;

  @IsDefined()
  @IsAlphanumeric()
  @ApiProperty()
  'drug_license_number': string;

  @IsOptional()
  @IsNumber()
  @ApiProperty()
  'gst': number;

  @IsOptional()
  @IsNumber()
  @ApiProperty()
  'montly_total_sale': number;

  @IsOptional()
  @IsNumber()
  @ApiProperty()
  'montly_payout_1': number;

  @IsOptional()
  @IsNumber()
  @ApiProperty()
  'montly_payout_2': number;

  @IsOptional()
  @IsNumber()
  @ApiProperty()
  'montly_payout_3': number;

  @IsOptional()
  @IsNumber()
  @ApiProperty()
  'montly_payout_4': number;

  @IsOptional()
  @IsNumber()
  @ApiProperty()
  'montly_payout_5': number;

  @IsOptional()
  @IsNumber()
  @ApiProperty()
  'montly_payout_6': number;

  @IsOptional()
  @IsNumber()
  @ApiProperty()
  'montly_payout_7': number;

  @IsOptional()
  @IsNumber()
  @ApiProperty()
  'montly_payout_8': number;

  @IsOptional()
  @IsNumber()
  @ApiProperty()
  'comulative_12_months_total_number_of_invoices': number;

  @IsOptional()
  @IsNumber()
  @ApiProperty()
  'volumes_of_invoicing': number;

  @IsOptional()
  @IsNumber()
  @ApiProperty()
  'os_as_on_last_date_of_month': number;

  @IsOptional()
  @Matches(/^([0-2][0-9]|(3)[0-1])-(((0)[1-9])|((1)[0-2]))-\d{4}$/i, {
    message: 'date_of_first_transaction must be in DD-MM-YYYY format',
  })
  @ApiProperty()
  'date_of_first_transaction': string;

  @IsOptional()
  @IsAlphanumeric()
  @ApiProperty()
  'distributor_codes': string;

  @IsOptional()
  @Matches(/^([0-2][0-9]|(3)[0-1])-(((0)[1-9])|((1)[0-2]))-\d{4}$/i, {
    message: 'date_of_first_invoice must be in DD-MM-YYYY format',
  })
  @ApiProperty()
  'date_of_first_invoice': string;

  @IsOptional()
  @Matches(/^([0-2][0-9]|(3)[0-1])-(((0)[1-9])|((1)[0-2]))-\d{4}$/i, {
    message: 'date_of_first_order must be in DD-MM-YYYY format',
  })
  @ApiProperty()
  'date_of_first_order': string;

  @IsOptional()
  @IsNumber()
  @ApiProperty()
  'outstanding_amount_past_12_months': number;

  @IsOptional()
  @IsNumber()
  @ApiProperty()
  'outstanding_amount_past_24_months': number;

  @IsOptional()
  @IsNumber()
  @ApiProperty()
  'invoice_amount_past_12_months': number;

  @IsOptional()
  @IsNumber()
  @ApiProperty()
  'invoice_amount_past_24_months': number;

  @IsOptional()
  @IsNumber()
  @ApiProperty()
  'order_amount_past_12_months': number;

  @IsOptional()
  @IsNumber()
  @ApiProperty()
  'order_amount_past_24_months': number;

  @IsOptional()
  @Transform(({ value }) => value.toString())
  @Matches(/^\d+((.)|(.\d{2})?)$/i, {
    message: 'requested_amount should be two digit precision',
  })
  @ApiProperty()
  'requested_amount': number;

  @IsOptional()
  @IsNumber()
  @ApiProperty()
  'requested_tenure': number;

  @IsOptional()
  @IsString()
  @IsIn(['DAY', 'MONTH', 'YEAR'])
  @ApiProperty()
  'requested_tenure_unit': string;

  @IsOptional()
  @IsAlphanumeric()
  @ApiProperty()
  'partner_ref_no': string;
}

export class LeadDto {
  @IsDefined()
  @IsNotEmpty()
  @Matches(/^[a-z ]+$/i)
  @ApiProperty()
  'borrower_first_name': string;

  @IsOptional()
  @Matches(/^[a-z ]+$/i)
  @ApiProperty()
  'borrower_last_name': string;

  @IsDefined()
  @IsNotEmpty()
  @Transform(({ value }) => value.toString())
  @Matches(/(6|7|8|9)\d{9}/)
  @MaxLength(10)
  @ApiProperty()
  'primary_phone_number': number;

  @IsNotEmpty()
  @IsEmail()
  @MinLength(3)
  @MaxLength(50)
  @ApiProperty()
  'primary_email_id': string;

  @IsDefined()
  @IsNotEmpty()
  @IsAlphanumeric()
  @ApiProperty()
  'product_opportunity_id': string;

  @IsOptional()
  @Transform(({ value }) => value.toString())
  @MaxLength(12)
  @Matches(/\d{12}/)
  @ApiProperty()
  'aadhar_id': number;

  @IsOptional()
  @IsEmail()
  @MinLength(3)
  @MaxLength(50)
  @ApiProperty()
  'additional_email_id': string;

  @IsOptional()
  @IsString()
  @IsIn(['ORGANIZATION', 'INDIVIDUAL'])
  @ApiProperty()
  'borrower_type': string;

  @IsOptional()
  @Transform(({ value }) => value.toString())
  @Matches(/(6|7|8|9)\d{9}/)
  @MaxLength(10)
  @ApiProperty()
  'additional_phone_number': number;

  @IsOptional()
  @Matches(/^([0-2][0-9]|(3)[0-1])-(((0)[1-9])|((1)[0-2]))-\d{4}$/i, {
    message: 'date_of_birth must be in DD-MM-YYYY formate',
  })
  @ApiProperty()
  'date_of_birth': string;

  @IsOptional()
  @IsIn(['MALE', 'FEMALE', 'TRANSGENDER', 'OTHERS'])
  @ApiProperty()
  'gender': string;

  @IsOptional()
  @IsString()
  @ApiProperty()
  'preferred_language': string;

  @IsOptional()
  @IsIn(['NEW', 'WHITELISTED', 'REJECTED'])
  @ApiProperty()
  'lead_status': string;

  @ValidateIf((o) => o.additional !== false)
  @IsDefined()
  @IsObject()
  @IsNotEmptyObject()
  @ValidateNested()
  @Type(() => LeadAdditionalDto)
  @ApiProperty()
  additional: LeadAdditionalDto;
}

export class GetLeadDto {
  @IsOptional()
  @IsNumber()
  @ApiProperty()
  'borrower_first_name': number;
}

export class leadStatusDto {
  @IsDefined()
  @IsNotEmpty()
  @IsAlphanumeric()
  @ApiProperty()
  'borrower_last_name': string;

  @IsDefined()
  @IsNotEmpty()
  @IsAlphanumeric()
  @ApiProperty()
  'borrower_first_name': string;

  @IsOptional()
  @IsNumber()
  @IsPositive()
  @ApiProperty()
  'proposed_limit': number;

  @IsOptional()
  @IsNotEmpty()
  @IsAlphanumeric()
  @ApiProperty()
  'product_opportunity_id': string;

  @IsOptional()
  @IsNotEmpty()
  @IsString()
  @IsIn(['NEW', 'WHITELISTED', 'REJECTED'])
  @ApiProperty()
  'lead_status': string;
}
export class GetProfileDto {
  @IsDefined()
  @IsString()
  @ApiProperty()
  'lead_id': string;
}
