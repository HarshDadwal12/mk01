'use strict';
const XLSX = require('xlsx');
const _ = require('lodash');
const constant = require('../utils/constant');
const { fileRecord, formatDataAndUrl } = require('../utils/helper');
const AWS = require('aws-sdk');
const { v4: uuidv4 } = require('uuid');
const sqs = new AWS.SQS({ region: 'us-east-1' });

function getDataRange(data) {
  const dataWithValues = _.pickBy(data, (value, key) => !!value.v);
  const cellNamesWithValues = _.keys(dataWithValues);
  const cellsWithValues = cellNamesWithValues.map((cell) =>
    XLSX.utils.decode_cell(cell),
  );
  const maxRow = _.max(cellsWithValues.map((cell) => cell.r));
  const maxColumn = _.max(cellsWithValues.map((cell) => cell.c));
  const lastCellName = XLSX.utils.encode_cell({ c: maxColumn, r: maxRow });
  return `A1:${lastCellName}`;
}

const xlsxRead = async function (data) {
  const workbook = XLSX.read(data, { type: 'base64', cellDates: true });
  const sheetSelect = workbook.Sheets[workbook.SheetNames[0]];
  sheetSelect['!ref'] = getDataRange(sheetSelect);
  return XLSX.utils.sheet_to_json(sheetSelect);
};

async function insertRecordInDb(sheetJsonData, body, start) {
  try {
    const { doc_id } = body;
    const doc = {
      doc_id,
      start,
      data: sheetJsonData,
    };
    await fileRecord(doc);
  } catch (error) {
    throw error;
  }
}

const pushDataQueue = async (body, totalRecords) => {
  const params = {
    QueueUrl: constant.QUEUE_BULK_UPLOAD_URL,
    MessageBody: JSON.stringify({
      ...body,
      totalRecords,
      records_in_db: true,
    }),
    MessageGroupId: uuidv4(),
  };
  const data = await sqs.sendMessage(params).promise();
  console.log('SQS MessageId ----> ', data.MessageId, params);
  return data;
};

exports.xlsxParse = async function (fileData, body) {
  try {
    let { type, lender_id } = body;
    let staticData = { lender_id };
    let totalRecords = 0;
    const sheetJsonData = await xlsxRead(fileData);
    const { formatedData } = formatDataAndUrl(type, sheetJsonData, staticData);
    totalRecords =
      formatedData && formatedData.length ? formatedData.length : 0;
    const sheetJsonDataInChunks =
      formatedData && formatedData.length
        ? _.chunk(formatedData, constant.CHUNK_SIZE)
        : [];
    if (sheetJsonDataInChunks.length) {
      let i = 0;
      while (i < sheetJsonDataInChunks.length) {
        let start = i * constant.CHUNK_SIZE;
        await insertRecordInDb(sheetJsonDataInChunks[i], body, start);
        if (i == sheetJsonDataInChunks.length - 1) {
          await pushDataQueue(body, totalRecords);
        }
        i++;
      }
    }
  } catch (error) {
    throw error;
  }
};
