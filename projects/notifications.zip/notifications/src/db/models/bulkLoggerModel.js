'use strict';

const db = require('..');
const document_collection_name = 'bulk_data_logs';
const conn = new db.connectionFactory(
  process.env.MONGO_DB_URL,
  document_collection_name,
  './schemas/bulkSchema'
);

module.exports = {
  find: async function (condition, limit = 20, skip = 0) {
    const Collection = conn.model(document_collection_name);
    return Collection.find(condition).sort({ createdAt: -1 }).skip(skip).limit(limit);
  },

  create: async function (data) {
    const Collection = conn.model(document_collection_name);
    return await Collection.create(data);
  },
};
