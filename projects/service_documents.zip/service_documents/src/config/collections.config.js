
// Collections created and used in the service

const collections = {
    document_log        : 'document_log',
    request_response_log: 'req_res_log',
    document_visibility: 'document_visibility', 
    file_log: 'file_log', 
};

module.exports = collections;