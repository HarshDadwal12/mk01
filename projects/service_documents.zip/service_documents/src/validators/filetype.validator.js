const path = require('path');
const file_validations = require('../config/files.config');
const helper = require('../helpers/helper');
const messages = require('../lang/en/messages');

module.exports = {
    /**
     * @description Validate pdf file before uploading 
     * 
     * @author Tanuj Chawla <tanuj.chawla@biz2credit.com>
     * 
     * @param req
     * @param res
     * @param {callback function} next
     * 
     * @returns string
     */
    pdfValidator(req, res, next) {
        if (req.file.size > file_validations.max_allowed_file_size.pdf) {
            return helper.getErrorResponse(req, res, [messages.keys.file_size], messages.codes.bad_request);
        }
        const filetypes = req.body.filetypes;
        // filetypes.push('zip')
        const ext = (path.extname(req.file.originalname).toLowerCase()).replace(/\./g, "");
        const extname = filetypes.includes(ext);
        if (!extname) {
            return helper.getErrorResponse(req, res, [messages.keys.file_type], messages.codes.bad_request);
        }

        const mimetype = req.file.mimetype;
        const mimetypeExists = messages.allowed_mime_types[ext].includes(mimetype);

        if (!mimetypeExists) {
            return helper.getErrorResponse(req, res, [messages.keys.file_type], messages.codes.bad_request);
        }
        next();
    },
    async docTypeValidator(req,res,next){
        const filetypes = req.body.filetypes;
        const ext = (path.extname(req.body.filename).toLowerCase()).replace(/\./g, "");
        const extname = filetypes.includes(ext);
        if (!extname) {
            return helper.getErrorResponse(req, res, [messages.keys.file_type], messages.codes.bad_request);
        }
        next()
    }
};

