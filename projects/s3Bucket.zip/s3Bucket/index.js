const aws = require("aws-sdk");
const Archiver = require("archiver");
const Stream = require("stream");
// const config=require("./config.json");

const fs = require("fs");
const output = fs.createWriteStream(__dirname + "/example.zip");

aws.config.update({
	accessKeyId: "AKIAJWHJDCEGUH7RXUXQ",
	secretAccessKey: "iXY/ymQVXHsS7FuUOM0lNEH5cqFYJ8vTEv1uLlgo",
	region: "us-east-1",
});

let arr = [
	"bulk/bulk_2022518T144435967_gstc_April 30, 2020 (4) (1).pdf",
	"bulk/bulk_202245T154159318_lead_12Dec 2020 #8159.pdf",
];

(async function () {
	try {
		const s3 = new aws.S3();
		const response = await s3
			.listObjectsV2({
				Bucket: "tmypracticeawsbucketc",
				Prefix: "bulk",
			})
			.promise();

		response.zippedFileKey = "zip/zippedFile.zip";
		console.log(response.Contents.length, response.zippedFileKey);
		//fs.writeFileSync("test01.json", JSON.stringify(response));

		// const s3FileDwnldStreams = response.Contents.map((item) => {
		//   // if(!arr.includes(item.Key)){
		//   const stream = s3
		//     .getObject({ Bucket: "tmypracticeawsbucketc", Key: item.Key })
		//     .createReadStream();
		//   return {
		//     stream,
		//     fileName: item.Key,
		//   };
		// // }
		// });

		const s3FileDwnldStreams = response.Contents.map((item) => {
			if (!arr.includes(item.Key)) {
				const stream = s3
					.getObject({ Bucket: "tmypracticeawsbucketc", Key: item.Key })
					.createReadStream();
				return {
					stream,
					fileName: item.Key,
				};
			}
		}).filter((notUndefined) => notUndefined !== undefined);

		// console.log(s3FileDwnldStreams)
		//fs.writeFileSync("test01.json", JSON.stringify(s3FileDwnldStreams));

		const streamPassThrough = new Stream.PassThrough();

		const uploadParams = {
			// ACL: "public-read", //change to private as per requirement
			Body: streamPassThrough,
			ContentType: "application/zip",
			Key: response.zippedFileKey,
			Bucket: "tmypracticeawsbucketc",
			StorageClass: "STANDARD",
		};

		const s3Upload = s3.upload(uploadParams, (err, data) => {
			console.log("in s3upload");
			if (err) console.log("upload error", err);
			else console.log("upload done", data);
		});

		const archive = Archiver("zip", {
			zlib: { level: 9 },
		});

		archive.on("error", (error) => {
			throw new Error(
				`${error.name} ${error.code} ${error.message} ${error.path}  ${error.stack}`
			);
		});

		archive.on("warning", function (err) {
			if (err.code === "ENOENT") {
				console.log("warning");
			} else {
				// throw error
				throw err;
			}
		});

		s3Upload.on("httpUploadProgress", (progress) => {
			console.log("in http Upload progress");
			console.log(progress);
			console.log("after progress");
		});

		await new Promise((resolve, reject) => {
			s3Upload.on("close", resolve());
			s3Upload.on("end", reject());
			s3Upload.on("error", reject());

			archive.pipe(streamPassThrough);
			//archive.pipe(output);
			s3FileDwnldStreams.forEach((s3FileDwnldStream) => {
				archive.append(s3FileDwnldStream.stream, {
					name: s3FileDwnldStream.fileName,
				});
			});
			archive.finalize();
			console.log("in 92");
		})
			.then(() => {
				console.log("ok");
			})
			.catch((error) => {
				throw new Error(`${error.code} ${error.message} ${error.data}`);
			});

		await s3Upload
			.promise()
			.then((data) => {
				console.log("Upload done :", data);
			})
			.catch((err) => {
				console.log("error ", err);
			});
	} catch (e) {
		console.log("error----", e);
	}

	//   await s3Upload.promise();
})();
