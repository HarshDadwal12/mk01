'use strict';

const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const commonSchema = new Schema(
  {
    type: {
      type: String,
      index: true,
    },
    uploaded_by: { type: String, index: true },
  },
  { strict: false, timestamps: true }
);

module.exports = commonSchema;
