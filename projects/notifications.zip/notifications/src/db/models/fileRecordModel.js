'use strict';

const db = require('..');
const document_collection_name = 'File_Record';
const conn = new db.connectionFactory(
  process.env.MONGO_DB_URL,
  document_collection_name,
  './schemas/fileRecordsSchema'
);

module.exports = {
  find: async function (condition) {
    const Collection = conn.model(document_collection_name);
    return Collection.findOne(condition).lean();
  },

  create: async function (data) {
    const Collection = conn.model(document_collection_name);
    return await Collection.create(data);
  },

  deleteFileRecords: async function (condition) {
    const Collection = conn.model(document_collection_name);
    return await Collection.deleteMany(condition);
  },
};
