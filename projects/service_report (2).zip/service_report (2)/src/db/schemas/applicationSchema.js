"use strict";

// Import mongoose module
const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const schema = new Schema({}, { strict: false });
module.exports = schema;
