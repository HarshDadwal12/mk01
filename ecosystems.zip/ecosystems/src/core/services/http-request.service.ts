import { HttpService } from '@nestjs/axios';
import { Injectable } from '@nestjs/common';
import * as _ from 'lodash';
import { firstValueFrom } from 'rxjs';
import { config } from 'src/config/constant.config';

@Injectable()
export class HttpRequestService {
  constructor(private readonly httpService: HttpService) {}

  parseParams({ req, urlConfig }: { req: any; urlConfig: any }) {
    const allParams: any = {};
    urlConfig.forEach((element: any) => {
      const {
        send_param_in: sendParamIn,
        data_from: dataFrom,
        request_key: requestKey,
        request_value: reqValue,
      } = element;

      if (!sendParamIn) {
        return {};
      }

      if (!allParams[sendParamIn]) {
        allParams[sendParamIn] = {};
      }

      if (dataFrom.trim() === 'formdata') {
        if (Array.isArray(req.body)) {
          allParams[sendParamIn] = req.body;
        } else {
          allParams[sendParamIn] = {
            ...allParams[sendParamIn],
            ...req.body,
          };
        }
      } else if (dataFrom.trim() === 'static') {
        allParams[sendParamIn][requestKey] = reqValue;
      } else if (dataFrom.trim() === 'eval') {
        allParams[sendParamIn][requestKey] = eval(reqValue);
      } else if (dataFrom === 'headers' || dataFrom === 'query') {
        allParams[sendParamIn][requestKey] = req[dataFrom][reqValue];
      } else if (dataFrom === 'body') {
        allParams[sendParamIn][requestKey] = req[dataFrom][reqValue];
      } else if (dataFrom === 'merge_request_data') {
        allParams[sendParamIn][requestKey] = reqValue.map(
          (reqKey: any) => allParams[element.merge_from][reqKey],
        );
      }
    });

    if (req && req.headers && req.headers['entity-id']) {
      if (!allParams.headers) {
        // case no headers
        allParams.headers = {
          'entity-id': req.headers['entity-id'],
        };
      } else if (allParams.headers && !allParams.headers['entity-id']) {
        // headers but not exist key entity-id
        allParams.headers['entity-id'] = req.headers['entity-id'];
      }
    }
    return allParams;
  }

  makeConfig(requestParams: any) {
    if (!requestParams) {
      return {};
    }

    const { headers, body, query } = requestParams;
    const config = {
      headers,
      body,
      params: query,
    };

    return config;
  }

  get({ req, data }: { req: any; data: any }) {
    const requestParams = this.parseParams({
      req,
      urlConfig: data.data,
    });
    const config = this.makeConfig(requestParams);
    const pathParams =
      requestParams.path && requestParams.path != null
        ? `/${Object.values(requestParams.path)}`
        : '';
    console.log('get api -- ', data.url + pathParams, 'config - ', config);

    const request = this.httpService.get(data.url + pathParams.trim(), config);
    return firstValueFrom(request)
      .then((response: any) => {
        return response;
      })
      .catch((error: any) => {
        throw error;
      });
  }

  post({ req, data }: { req: any; data: any }) {
    const requestParams = this.parseParams({
      req,
      urlConfig: data.data,
    });
    const config: any = this.makeConfig(requestParams);
    const pathParams =
      requestParams.path && requestParams.path != null
        ? `/${Object.values(requestParams.path)}`
        : '';
    delete config.body;
    console.log(
      'post api -- ',
      data.url + pathParams,
      ' body - ',
      requestParams.body,
      'config - ',
      config,
    );

    const request = this.httpService.post(
      data.url + pathParams,
      requestParams.body,
      config,
    );
    return firstValueFrom(request)
      .then((response: any) => {
        return response;
      })
      .catch((error: any) => {
        throw error;
      });
  }

  deleteFunction({ req, data }: { req: any; data: any }) {
    const requestParams = this.parseParams({
      req,
      urlConfig: data.data,
    });
    const config: any = this.makeConfig(requestParams);
    const pathParams =
      requestParams.path && requestParams.path != null
        ? `/${Object.values(requestParams.path)}`
        : '';
    delete config.body;
    console.log('delete api -- ', data.url + pathParams, 'config - ', config);

    const request = this.httpService.delete(data.url + pathParams, config);
    return firstValueFrom(request)
      .then((response: any) => {
        return response;
      })
      .catch((error: any) => {
        throw error;
      });
  }

  put({ req, data }: { req: any; data: any }) {
    const requestParams: any = this.parseParams({
      req,
      urlConfig: data.data,
    });
    const config = this.makeConfig(requestParams);
    const pathParams =
      requestParams.path && requestParams.path != null
        ? `/${Object.values(requestParams.path)}`
        : '';
    console.log(
      'put api -- ',
      data.url + pathParams,
      ' body - ',
      requestParams.body,
      'config - ',
      config,
    );

    const request = this.httpService.put(
      data.url + pathParams,
      requestParams.body,
      config,
    );
    return firstValueFrom(request)
      .then((response: any) => {
        return response;
      })
      .catch((error: any) => {
        throw error;
      });
  }

  patch({ req, data }: { req: any; data: any }) {
    const requestParams: any = this.parseParams({
      req,
      urlConfig: data.data,
    });
    const config = this.makeConfig(requestParams);
    const pathParams =
      requestParams.path && requestParams.path != null
        ? `/${Object.values(requestParams.path)}`
        : '';
    console.log(
      'path api -- ',
      data.url + pathParams,
      ' body - ',
      requestParams.body,
      'config - ',
      config,
    );

    const request = this.httpService.patch(
      data.url + pathParams,
      requestParams.body,
      config,
    );
    return firstValueFrom(request)
      .then((response: any) => {
        return response;
      })
      .catch((error: any) => {
        throw error;
      });
  }

  getMasterData(endpoint) {
    const url = config.MASTER_API + '/' + endpoint;
    console.log({ url, method: 'get' });
    return firstValueFrom(this.httpService.get(url));
  }

  getUserData(endpoint) {
    const url = config.USER_API + '/' + endpoint;
    console.log({ url, method: 'get' });
    return firstValueFrom(this.httpService.get(url));
  }

  getCaseData(endPoint: string) {
    const url = `${config.CASE_API}/${endPoint}`;
    console.log({ url });
    return firstValueFrom(this.httpService.get(url));
  }

  getOfferData(endPoint: string) {
    const url = `${config.OFFER_API}/${endPoint}`;
    console.log({ url });
    return firstValueFrom(this.httpService.get(url));
  }
}
