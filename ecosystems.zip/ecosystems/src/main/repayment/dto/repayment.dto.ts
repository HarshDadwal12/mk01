import { ApiProperty } from '@nestjs/swagger';
import {
  IsAlphanumeric,
  IsDefined,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsIn,
  IsString,
  Matches,
  ArrayNotEmpty,
  ArrayMinSize,
  IsArray,
  ValidateNested,
  ValidateIf,
} from 'class-validator';
import { Type } from 'class-transformer';

class InvoiceReq {
  @IsOptional()
  @IsAlphanumeric()
  @IsNotEmpty()
  @ApiProperty()
  invoice_no: string;

  @IsOptional()
  @IsString()
  @IsNotEmpty()
  @Matches(
    /^(3[01]|[12][0-9]|0[1-9])-(1[0-2]|0[1-9])-[0-9]{4} (2[0-3]|[01]?[0-9]):([0-5]?[0-9]):([0-5]?[0-9])$/,
    {
      message: 'invoice_timestamp should be in DD-MM-YYYY HH:mm:ss',
    },
  )
  @ApiProperty()
  'invoice_timestamp': string;
}
export class RepaymentRequestDto {
  @IsDefined()
  @IsNotEmpty()
  @IsNumber()
  @ApiProperty()
  application_id: number;

  @IsDefined()
  @IsNumber()
  @ApiProperty()
  repayment_unique_id: number;

  @IsDefined()
  @IsString()
  @IsNotEmpty()
  @Matches(
    /^(3[01]|[12][0-9]|0[1-9])-(1[0-2]|0[1-9])-[0-9]{4} (2[0-3]|[01]?[0-9]):([0-5]?[0-9]):([0-5]?[0-9])$/,
    {
      message: 'repayment_timestamp should be in DD-MM-YYYY HH:mm:ss',
    },
  )
  @ApiProperty()
  repayment_timestamp: string;

  @IsDefined()
  @IsString()
  @IsNotEmpty()
  @ApiProperty()
  retailer_name: string;

  @IsDefined()
  @IsAlphanumeric()
  @IsNotEmpty()
  @ApiProperty()
  loan_account_number: string;

  @IsDefined()
  @IsAlphanumeric()
  @IsIn(['INVOICE', 'TRANCHE'])
  @IsNotEmpty()
  @ApiProperty()
  repayment_category: string;

  @IsDefined()
  @IsAlphanumeric()
  @IsIn(['FULL', 'PARTIAL'])
  @IsNotEmpty()
  @ApiProperty()
  repayment_type: string;

  @IsDefined()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  repayment_amount: number;

  @ValidateIf((o: RepaymentRequestDto) => o.repayment_category === 'TRANCHE')
  @IsDefined()
  @IsString()
  @IsNotEmpty()
  @ApiProperty()
  disbursement_unique_id: string;

  @ValidateIf((o: RepaymentRequestDto) => o.repayment_category === 'INVOICE')
  @IsDefined()
  @IsArray()
  @ArrayNotEmpty()
  @ArrayMinSize(1)
  @ValidateNested({ each: true })
  @Type(() => InvoiceReq)
  @ApiProperty()
  invoices: InvoiceReq[];
}

export class RepaymentRequestReconDto {
  @IsNotEmpty()
  @IsNumber()
  @ApiProperty()
  application_id: string;

  @IsNotEmpty()
  @IsNumber()
  @ApiProperty()
  repayment_unique_id: number;

  @IsDefined()
  @IsNotEmpty()
  @IsString()
  @Matches(
    /^(3[01]|[12][0-9]|0[1-9])-(1[0-2]|0[1-9])-[0-9]{4} (2[0-3]|[01]?[0-9]):([0-5]?[0-9]):([0-5]?[0-9])$/,
    {
      message: 'repayment_timestamp should be in DD-MM-YYYY HH:mm:ss',
    },
  )
  @ApiProperty()
  'repayment_timestamp': string;

  @IsNotEmpty()
  @IsString()
  @ApiProperty()
  'retailer_name': string;

  @IsNotEmpty()
  @IsAlphanumeric()
  @ApiProperty()
  'loan_account_number': string;

  @IsDefined()
  @IsNotEmpty()
  @IsNumber()
  @ApiProperty()
  'total_repayment_received': number;

  @IsDefined()
  @IsNotEmpty()
  @IsString()
  @IsIn(['RECEIVED', 'ON_HOLD', 'PARTIAL'])
  @ApiProperty()
  'payment_status': number;

  @IsNotEmpty()
  @IsNumber()
  @ApiProperty()
  'pending_repayment_amount': number;

  @IsNotEmpty()
  @IsNumber()
  @ApiProperty()
  'available_credit_limit': number;

  @IsNotEmpty()
  @IsNumber()
  @ApiProperty()
  'updated_credit_limit': number;

  @IsDefined()
  @IsArray()
  @ArrayNotEmpty()
  @ArrayMinSize(1)
  @ValidateNested({ each: true })
  @Type(() => InvoiceRecon)
  @ApiProperty()
  invoices: InvoiceRecon[];
}

class InvoiceRecon {
  @IsDefined()
  @IsAlphanumeric()
  @IsNotEmpty()
  @ApiProperty()
  invoice_no: string;

  @IsDefined()
  @IsString()
  @IsIn(['PAID', 'PARTIAL', 'PENDING'])
  @IsNotEmpty()
  @ApiProperty()
  status_of_invoice_repayment: string;

  @IsDefined()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  disbursement_amount: number;

  @IsDefined()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  invoice_principal_deduction: number;

  @IsDefined()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  invoice_interest_deduction: number;

  @IsDefined()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  invoice_penalty_deduction: number;

  @IsDefined()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  total_invoice_deduction: number;

  @IsDefined()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  principal_os: number;

  @IsDefined()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  interest_os: number;

  @IsDefined()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  penalty_os: number;

  @IsDefined()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  total_invoice_outstanding: number;
}

class InvoiceRes {
  @IsDefined()
  @IsAlphanumeric()
  @IsNotEmpty()
  @ApiProperty()
  invoice_no: string;

  @IsDefined()
  @IsString()
  @IsIn(['PAID', 'PARTIAL', 'PENDING'])
  @IsNotEmpty()
  @ApiProperty()
  status_of_invoice_repayment: string;

  @IsDefined()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  disbursement_amount: number;

  @IsDefined()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  invoice_principal_deduction: number;

  @IsDefined()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  invoice_interest_deduction: number;

  @IsDefined()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  invoice_penalty_deduction: number;

  @IsDefined()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  total_invoice_deduction: number;

  @IsDefined()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  principal_os: number;

  @IsDefined()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  interest_os: number;

  @IsDefined()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  penalty_os: number;

  @IsDefined()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  total_invoice_outstanding: number;
}
export class RepaymentResponseDto {
  @IsDefined()
  @IsNotEmpty()
  @IsNumber()
  @ApiProperty()
  application_id: number;

  @IsDefined()
  @IsNumber()
  @ApiProperty()
  repayment_unique_id: number;

  @IsDefined()
  @IsString()
  @IsNotEmpty()
  @Matches(
    /^(3[01]|[12][0-9]|0[1-9])-(1[0-2]|0[1-9])-[0-9]{4} (2[0-3]|[01]?[0-9]):([0-5]?[0-9]):([0-5]?[0-9])$/,
    {
      message: 'repayment_timestamp should be in DD-MM-YYYY HH:mm:ss',
    },
  )
  @ApiProperty()
  repayment_timestamp: string;

  @IsDefined()
  @IsString()
  @IsNotEmpty()
  @ApiProperty()
  retailer_name: string;

  @IsDefined()
  @IsAlphanumeric()
  @IsNotEmpty()
  @ApiProperty()
  loan_account_number: string;

  @IsDefined()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  total_repayment_received: number;

  @IsDefined()
  @IsString()
  @IsIn(['RECEIVED', 'ON_HOLD'])
  @IsNotEmpty()
  @ApiProperty()
  payment_status: string;

  @IsDefined()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  pending_repayment_amount: number;

  @IsDefined()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  available_credit_limit: number;

  @IsDefined()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  updated_credit_limit: number;

  @IsOptional()
  @IsString()
  @IsNotEmpty()
  @ApiProperty()
  disbursement_unique_id: string;

  @IsOptional()
  @IsString()
  @IsAlphanumeric()
  @IsNotEmpty()
  @IsIn(['PAID', 'PARTIAL', 'PENDING'])
  @ApiProperty()
  status_of_tranche_repayment: number;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  total_payment_requested: number;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  total_principal_deduction: number;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  total_interest_deduction: number;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  total_penalty_deduction: number;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  total_invoice_deduction: number;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  tranche_principal_os: number;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  tranche_interest_os: number;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  tranche_penalty_os: number;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  total_tranche_outstanding: number;

  @IsOptional()
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  total_tranche_deduction: number;

  @IsOptional()
  @IsArray()
  @ArrayNotEmpty()
  @ArrayMinSize(1)
  @ValidateNested({ each: true })
  @Type(() => InvoiceRes)
  @ApiProperty()
  invoices: InvoiceRes[];
}
