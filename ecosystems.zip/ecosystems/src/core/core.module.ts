import { Module } from '@nestjs/common';
import { APP_FILTER, APP_INTERCEPTOR } from '@nestjs/core';
import { JwtModule } from '@nestjs/jwt';
import { EventEmitterModule } from '@nestjs/event-emitter';

import { HttpExceptionFilter } from './filters/http-exceptions.filter';
import { HttpModule } from './http.module';
import { TransformInterceptor } from './interceptors/transform.interceptor';
import { CommonService } from './services/common.service';
import { CryptoService } from './services/cypto.service';
import { HttpRequestService } from './services/http-request.service';
import { JwtService } from './services/jwt.service';
import { QueryService } from './services/query.service';
import { RequestLogListener } from './listeners/request-log.listener';
import { WebHookListener } from './listeners/web-hook.listener';
import { Queue } from './clients/queue';
import { QueueService } from './services/queue.service';

@Module({
  imports: [JwtModule.register({}), HttpModule, EventEmitterModule.forRoot()],
  exports: [
    JwtService,
    CryptoService,
    QueryService,
    CommonService,
    HttpRequestService,
  ],
  controllers: [],
  providers: [
    JwtService,
    CryptoService,
    QueryService,
    QueueService,
    CommonService,
    HttpRequestService,
    RequestLogListener,
    WebHookListener,
    {
      provide: APP_FILTER,
      useClass: HttpExceptionFilter,
    },
    {
      provide: APP_INTERCEPTOR,
      useClass: TransformInterceptor,
    },
    { provide: 'QUEUE', useClass: Queue },
  ],
})
export class CoreModule {}
