import { ApiProperty } from '@nestjs/swagger';
import {
  IsNotEmpty,
  IsString,
  IsObject,
  IsIn,
  IsBoolean,
  IsOptional,
  IsArray,
  ArrayNotEmpty,
  ArrayMinSize,
  ValidateNested,
  ValidateIf
} from 'class-validator';
import { Type } from 'class-transformer';
import { config } from 'src/config/constant.config'

export class UserMappingDto {

  @ValidateIf((o) => o?.mappings?.length ? false : true)
  @IsNotEmpty()
  @IsString()
  @ApiProperty()
  user_id: string;

  @ValidateIf((o) => o?.mappings?.length ? false : true)
  @IsNotEmpty()
  @IsString()
  @IsIn(config.IDENTIFIER)
  @ApiProperty()
  identifier: string;

  @IsOptional()
  @IsObject()
  @ApiProperty()
  response_keys: Record<any, any>;

  @IsOptional()
  @IsBoolean()
  @ApiProperty()
  hook: Boolean;

  @IsOptional()
  @IsArray()
  @ArrayNotEmpty()
  @ArrayMinSize(1)
  @ValidateNested({ each: true })
  @Type(() => MappingsData)
  @ApiProperty()
  mappings: MappingsData[];
}

class MappingsData {
  @IsNotEmpty()
  @IsString()
  @IsIn(config.IDENTIFIER)
  @ApiProperty()
  identifier: string;

  @IsOptional()
  @IsObject()
  @ApiProperty()
  response_keys: Record<any, any>;

  @IsOptional()
  @IsBoolean()
  @ApiProperty()
  hook: Boolean;
}
export class GetUserMappingDto {
  @IsNotEmpty()
  @IsString()
  @ApiProperty()
  user_id: string;
}

export class routeInfoDto{
  @IsOptional()
  @IsString()
  @IsIn(['lender','aggregator'])
  @ApiProperty()
  type:String;
}