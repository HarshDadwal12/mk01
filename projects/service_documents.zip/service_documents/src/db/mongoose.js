const mongoose = require('mongoose');

// DB Connection Handler

mongoose.Promise = global.Promise;
module.exports = {
  connect: (url) => {
    return mongoose.createConnection(url, { useNewUrlParser: true, useCreateIndex:true });
  },
  disconnect: () => {
    return mongoose.disconnect();
  },
};
