const express = require("express");
'use strict';

const excelToJson = require("convert-xls-files-to-json");

const app = express();
const port = 5000;

app.use(express.json());


const result = excelToJson({
    sourceFile: 'Application Creation2.xlsx',
    columnToKey: {
        '*': '{{columnHeader}}'
    }
});

const rows = result['sheet 1']
//console.log(rows)

//// -----real excel read...

app.get("/data", (req, res) => {
    let response = [];
   
    for (let i = 1; i < rows.length; i++) {
        
        let entries = Object.keys(rows[i]);
       
        let owner = {}
        let unique = []
        let obj = {};
        let flag = false

        for (let j = 0; j < entries.length; j++) {
            let start = entries[j].split('_')[0];
            if (!unique.includes(start)) {
                unique.push(start)
            }

            if (entries[j].startsWith("owners")) {
                if (Object.keys(obj).length === 0 && obj.constructor === Object) flag = true

                if (flag) {
                    owner[entries[j].slice(7)] = rows[i][`${entries[j]}`];
                    if (j == entries.length - 1) {
                    
                        response[response.length - 1].owners.push(owner)
                    }
                } else {
                    if (!obj.owners) {
                        obj.owners = [];
                        owner[entries[j].slice(7)] = rows[i][`${entries[j]}`];
                    } else if (j == entries.length - 1) {
                        owner[entries[j].slice(7)] = rows[i][`${entries[j]}`];
                
                        obj.owners.push(owner);
                    } else {
                        owner[entries[j].slice(7)] = rows[i][`${entries[j]}`];
                    }
                }
            }

            let head = unique[unique.length - 1]
            if (entries[j].startsWith(unique[unique.length - 1])) {
                if (obj[unique[unique.length - 1]]) {
                    obj[unique[unique.length - 1]][entries[j].slice(head.length + 1)] = rows[i][`${entries[j]}`];
                } else {
                    obj[unique[unique.length - 1]] = {};
                    obj[unique[unique.length - 1]][entries[j].slice(head.length + 1)] = rows[i][`${entries[j]}`];
                }
               
            }

        }
        if (!flag) {
            response.push(obj);
        }
    }
   
    res.json(response);
});


app.listen(port, () => {
    console.log("app running at 5000...");
});
