/** @format */

const express = require("express");
const healthController = require("../../controllers/v1/HealthController");


const routes = express.Router();

// Document Service Provided Endpoints


routes.get("/", healthController.checkHealth);

module.exports = routes;
