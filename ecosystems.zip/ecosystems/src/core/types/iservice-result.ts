export interface IServiceResult<T = any> {
  total: number;
  filter?: boolean;
  hook?: boolean;
  key?: string;
  event?: string;
  data: T;
}
