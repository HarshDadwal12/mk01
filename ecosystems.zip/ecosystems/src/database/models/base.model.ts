import { Schema } from 'mongoose';
import { getDateUnixTimestamp } from 'src/config/datetime.config';

export const BASE_SCHEMA = new Schema(
  {
    is_active: { type: Boolean, default: true },
    created_at: { type: Schema.Types.Mixed, index: true },
    updated_at: { type: Schema.Types.Mixed }
  },
  {
    timestamps: {
      createdAt: 'created_at',
      updatedAt: 'updated_at',
      currentTime: () => getDateUnixTimestamp(),
    },
  },
);
