'use strict';

const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const commonSchema = new Schema(
  {
    doc_id: {
      type: String,
    },
    start: {
      type: Number,
      default: 0
    }
  },
  { strict: false, timestamps: true }
);
commonSchema.set('collection', 'file_record');
commonSchema.index({ doc_id: 1, start: 1 });

module.exports = commonSchema;
