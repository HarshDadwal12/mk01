import {
  Injectable,
  BadRequestException,
  ForbiddenException,
} from '@nestjs/common';
import { HttpRequestService } from 'src/core/services/http-request.service';
import { CommonService } from 'src/core/services/common.service';
import { config } from 'src/config/constant.config';
import * as moment from 'moment';
import * as _ from 'lodash';

@Injectable()
export class ApplicationService {
  constructor(
    private commonService: CommonService,
    private httpRequestService: HttpRequestService,
  ) {}

  async processApplicationCreation(req: any, body: any) {
    try {
      const { backend_user_id } = req.user;
      const userEndPoint = `api/v1/users?record_id=${body.lead_id}`;
      const user = await this.commonService.getFrontendUser(userEndPoint);
      if (!user?.id) throw new BadRequestException('invalid lead_id');
      if (user?.lead_status == '61c34567f2e5ff26343060d9')
        throw new BadRequestException('lead has been rejected');

      const applicationData = await this.createUserApplication({
        user_id: user?.id,
        lender_id: user?.lender_id,
        product_type: user?.product_opportunity_id,
        backend_user_id,
      });

      const business = await this.createUserBusinessAppData({
        user_id: user?.id,
        app_id: applicationData._id,
        ...body,
      });

      const owners = await this.createUserOwnerData({
        user_id: user?.id,
        app_id: applicationData._id,
        ...body,
      });

      return { ...applicationData, business, owners };
    } catch (error) {
      throw error;
    }
  }

  async updateApplicationData(data) {
    try {
      const appUrl = `api/v1/application?auto_id=${data.application_id}&child_ref=business,owners`;
      const appData: any = await this.commonService.getApplication(appUrl);
      const app_id = appData?.[0]?._id;
      if (!app_id) throw new BadRequestException('invalid application id');
      const businessId = appData?.[0]?.business?.[0]?._id;
      if (!businessId)
        throw new BadRequestException('Application business details not found');
      const business_res = await this.commonService.callApiByName(
        'business_update',
        {
          body: { businessId, ...data },
        },
      );
      if (data?.owners?.length) {
        await this.processOwnerUpdateOrCreate(
          data?.owners,
          appData?.[0]?.owners,
          appData,
          app_id,
        );
      }
      return business_res;
    } catch (err) {
      throw new BadRequestException(err);
    }
  }

  async setApplicationStatusUnderwriting(data) {
    try {
      const appData = await this.commonService.getAppWithBusiness(
        data.application_id,
      );
      const app_id = appData?.[0]?._id;
      if (!app_id) throw new BadRequestException('invalid application id');
      const analysisEndPoint = `api/v1/analysis?app_id=${app_id}`;
      const analysisData: any = await this.httpRequestService.getCaseData(
        analysisEndPoint,
      );
      const app_gst_data = _.find(analysisData, { type: 'application_gst' });
      if (app_gst_data) {
        const app_status_required = await this.commonService.getAppStatus(
          'UNDERWRITING',
        );
        await this.commonService.callApiByName('application_status_update', {
          body: {
            id: app_id,
            status_id: app_status_required?.id,
          },
        });
      }
    } catch (err) {
      throw new BadRequestException(err);
    }
  }

  async processOwnerUpdateOrCreate(owners, appWithOwners, appData?, app_id?) {
    try {
      if (!appWithOwners?.length) {
        const owner_create_res = await this.createUserOwnerData({
          user_id: appData?.[0]?.user_id,
          app_id: app_id,
          owners,
        });
        return owner_create_res;
      }
      for (const owner of owners) {
        const existing_app_owner = _.find(appWithOwners, [
          'owner_pan',
          owner?.owner_pan,
        ]);
        if (!existing_app_owner) {
          const owner_create_res = await this.createUserOwnerData({
            user_id: appData?.[0]?.user_id,
            app_id: app_id,
            owners: [owner, ...appWithOwners],
          });
          continue;
        }
        const owner_update_res = await this.commonService.callApiByName(
          'owner_update',
          {
            body: {
              user_id: appData?.[0]?.user_id,
              app_id: app_id,
              owner_id: existing_app_owner._id,
              ...owner,
            },
          },
        );
        continue;
      }
    } catch (error) {
      throw new BadRequestException(error);
    }
  }

  async createUserApplication(body: any) {
    try {
      const res = await this.commonService.callApiByName('application', {
        body,
      });
      return res;
    } catch (error) {
      throw new BadRequestException(error);
    }
  }

  async createUserBusinessAppData(body: any) {
    try {
      const res = await this.commonService.callApiByName('business', {
        body,
      });
      return res;
    } catch (error) {
      throw new BadRequestException(error);
    }
  }

  async createUserOwnerData(data: any) {
    try {
      const body = {
        user_id: data?.user_id,
        app_id: data?.app_id,
        owners: data?.owners,
      };
      const res = await this.commonService.callApiByName('owner', {
        body,
      });
      return res;
    } catch (error) {
      throw new BadRequestException(error);
    }
  }

  async getApplication(query) {
    try {
      let [appResult] = await this.commonService.callApiByName(
        'application_get',
        {
          query,
        },
      );
      const app_id = appResult?._id;
      if (!app_id) throw new BadRequestException('invalid application id');
      if (appResult?.owners) {
        appResult.owners = await this.filterArrayfields(
          appResult.owners,
          'owner_get',
        );
      }
      if (appResult?.analysis) {
        appResult.analysis = await this.filterArrayfields(
          appResult.analysis,
          'analysis_get',
        );
        _.forEach(config.RESPONSE_KEYS_ADDITION.application_get, (key) => {
          const data = _.findLast(appResult.analysis, ['type', key]);
          if (data) {
            appResult[key] = data;
          }
        });
      }
      const limit_data: any = await this.getOfferLimit(appResult?._id);
      if (limit_data?.length) {
        const endPoint = `v1/limit_status`;
        const master_limit_data = await this.httpRequestService.getMasterData(
          endPoint,
        );
        _.forEach(limit_data, (data) => {
          data.limit_status = _.find(master_limit_data, [
            'id',
            data.limit_status,
          ])?.type
            ? _.find(master_limit_data, ['id', data.limit_status])?.type
            : '';
        });
        appResult.limit_data = await this.filterArrayfields(
          limit_data,
          'limit_get',
        );
      }
      if (appResult?.business?.length) {
        const businessData = appResult.business[0];
        delete appResult.business;
        appResult = { ...businessData, ...appResult };
      }
      return appResult;
    } catch (error) {
      throw new BadRequestException(error);
    }
  }

  async getOfferLimit(app_id: string) {
    try {
      const url = `api/v1/offers/all?app_id=${app_id}`;
      return this.httpRequestService.getOfferData(url);
    } catch (error) {
      throw new BadRequestException(error);
    }
  }

  async uploadDocument(
    file?: any,
    application_id?: number,
    doc_type?: string,
    backend_user_id?: string,
  ) {
    try {
      if (!file || !application_id || !doc_type)
        throw new BadRequestException('Fields required !!');
      if (file?.fieldname !== 'file')
        throw new BadRequestException('File key is required !!');
      if (file.fields?.file?.length)
        throw new BadRequestException('Multiple files are not allowed !!');
      const appData = await this.commonService.getAppWithBusiness(
        application_id,
      );
      const app_id = appData?.[0]?._id;
      const user_id = appData?.[0]?.user_id;
      if (!app_id) throw new BadRequestException('invalid application id');
      await this.commonService.checkAppStatus(appData?.[0]?.status_id);
      const docsMetaData = await this.getDocumentMetadata();
      const requiredDoc = _.find(docsMetaData, ['key', doc_type]);
      if (!requiredDoc) throw new BadRequestException('invalid doc type');
      const currentFileType = file?.filename?.split('.').pop();
      if (!currentFileType) throw new BadRequestException('invalid file');
      const isFileAllowed = requiredDoc?.allowed_file_type
        ?.split(', ')
        .includes(currentFileType);
      if (!isFileAllowed)
        throw new BadRequestException('file type is not allowed');
      const fileBufferData = await file.toBuffer();
      const body = {
        doc_type_id: requiredDoc.id,
        ref_id: app_id,
        filename: file.filename,
        data: fileBufferData.toString('base64'),
      };
      const uploadDataRes = await this.commonService.callApiByName(
        'upload_doc',
        {
          body,
        },
      );
      const businessReferenceData = {
        ref_id: uploadDataRes.doc_id,
        user_id,
        app_id,
        backend_user_id,
        response: uploadDataRes,
      };
      const businessRefRes = await this.commonService.callApiByName(
        'save_business_ref',
        {
          body: businessReferenceData,
        },
      );
    } catch (error) {
      throw new BadRequestException(error);
    }
  }

  async filterArrayfields(list: any[], key: string) {
    try {
      list = _.map(list, function (obj) {
        return _.omit(obj, config.HIDE_DATA[key]);
      });
      return list;
    } catch (error) {
      throw new BadRequestException(error);
    }
  }

  async createAprovedLimit(req, data) {
    // get app data
    if (data?.lender_interest_rate && data.limit_status != 'SANCTIONED') {
      throw new BadRequestException('lender_interest_rate should not exist');
    }
    if (data.lead_status == 'REJECTED' && data.limit_status !== 'PENDING') {
      throw new BadRequestException(
        'limit_status must be pending in case lead is rejected',
      );
    }
    const appData = await this.commonService.getAppWithBusiness(
      data.application_id,
    );
    const app_id = appData?.[0]?._id;
    const user_id = appData?.[0]?.user_id;
    if (!app_id) throw new BadRequestException('invalid application id');
    await this.commonService.checkAppStatus(appData?.[0]?.status_id);
    const userEndPoint = `api/v1/users/${user_id}`;
    const user = await this.commonService.getFrontendUser(userEndPoint);
    // Get Limit and lead status from master

    const leadLimitStatus: any = await Promise.all([
      this.commonService.getLeadStatus(data?.lead_status),
      this.commonService.getLimitStatus(data?.limit_status),
    ]);

    const lead_status = leadLimitStatus?.[0];
    const limit_status = leadLimitStatus?.[1];

    if (!lead_status) throw new BadRequestException('invalid lead status');
    if (!limit_status) throw new BadRequestException('invalid limit status');
    if (!limit_status?.can_update?.includes(req?.user?.user_type))
      throw new ForbiddenException('Forbidden status');
    await this.commonService.callApiByName('update_lead', {
      body: {
        id: user_id,
        lead_status: lead_status?.id,
      },
    });
    if (user.lead_status !== lead_status?.id) {
      await this.commonService.callApiByName('create_user_activity', {
        body: {
          user_id,
          action: 'update',
          lead_status: {
            current_status: lead_status?.id,
            previous_status: user.lead_status,
          },
        },
      });
    }

    if (
      data?.lead_status == 'REJECTED' ||
      data?.limit_status == 'APPROVED' ||
      data?.limit_status == 'REJECTED' ||
      data?.limit_status == 'SANCTIONED'
    ) {
      data.app_status = data.limit_status;
      if (data?.limit_status == 'SANCTIONED') {
        data.app_status = 'LIMIT_SANCTIONED';
      }
      if (data?.lead_status == 'REJECTED') {
        data.app_status = 'REJECTED';
      }
      // Application status get and Update
      const app_status = await this.commonService.getAppStatus(
        data?.app_status,
      );
      await this.commonService.callApiByName('application_status_update', {
        body: {
          id: app_id,
          status_id: app_status?.id,
        },
      });
    }

    await this.commonService.callApiByName('approve_limit', {
      body: {
        ...data,
        amount: data?.sanctioned_limit || data?.approved_limit,
        app_id,
        limit_status: limit_status?.id,
      },
    });
    return;
  }

  async implementDisbursementResponseValidations(body) {
    try {
      let [appResult]: any = await this.commonService.getAppWithBusiness(
        body.application_id,
      );
      const app_id = appResult?._id;
      if (!app_id) throw new BadRequestException('invalid application id');
      let offerData: any, analysisData: any;
      const offerEndPoint = `api/v1/offers/all?app_id=${app_id}`;
      offerData = await this.httpRequestService.getOfferData(offerEndPoint);
      const analysisEndPoint = `api/v1/analysis?app_id=${app_id}&limit=-1`;
      analysisData = await this.httpRequestService.getCaseData(
        analysisEndPoint,
      );
      if (analysisData?.length) {
        await this.implementInvoiceValidations(body, analysisData);
        const current_limit = await this.getCurrentLimit(
          analysisData,
          offerData,
        );
        if (current_limit <= 0) {
          throw new BadRequestException('Your Client current limit is zero');
        }
        if (parseInt(body.total_disbursement_amount) > current_limit) {
          throw new BadRequestException(
            'You are Sending More than Your Client Current Limit',
          );
        }
      }
    } catch (error) {
      throw new BadRequestException(error);
    }
  }

  async implementInvoiceValidations(body, analysisData) {
    try {
      const disbursement_request_data = _.findLast(analysisData, {
        type: 'disbursement_request',
        disbursement_unique_id: body.disbursement_unique_id,
      });
      const disbursement_response_previous_data = _.findLast(analysisData, {
        type: 'disbursement_response',
        disbursement_unique_id: body.disbursement_unique_id,
      });
      const transanction_id_data = _.findLast(analysisData, {
        type: 'disbursement_response',
        transanction_id: body.transanction_id,
      });

      const total_disbursement_amount = body.invoices.reduce(function (
        previous_value,
        current_value,
      ) {
        return current_value.disbursement_status !== 'PENDING' &&
          current_value.disbursement_status !== 'FAILED'
          ? previous_value + current_value?.disbursement_amount
          : previous_value;
      },
      0);
      const common_invoice_data = _.intersectionBy(
        disbursement_request_data?.invoices,
        body?.invoices,
        'invoice_no',
      );
      const missing_invoices = _.differenceBy(
        disbursement_request_data?.invoices,
        body?.invoices,
        'invoice_no',
      );
      if (!disbursement_request_data)
        throw new BadRequestException(
          'disbursement request records not found on server',
        );
      else if (
        disbursement_response_previous_data?.disbursement_status === 'DISBURSED'
      ) {
        throw new BadRequestException(
          'Payment has been fully disbursed for provided disbursement_unique_id',
        );
      } else if (transanction_id_data) {
        throw new BadRequestException('transanction_id must be unique');
      } else if (
        disbursement_request_data?.invoices?.length !== body.invoices.length
      ) {
        if (missing_invoices?.length) {
          const missed_invoices = await this.getInvoiceNosFromData(
            missing_invoices,
          );
          throw new BadRequestException(
            `Invoices with invoice_no(${missed_invoices}) are missing`,
          );
        } else {
          const extra_invoices = _.differenceBy(
            body?.invoices,
            disbursement_request_data?.invoices,
            'invoice_no',
          );
          const additional_invoices: any = await this.getInvoiceNosFromData(
            extra_invoices,
          );
          if (additional_invoices?.length)
            throw new BadRequestException(
              `Invoices with invoice_no(${additional_invoices}) are provided additionally`,
            );
          else
            throw new BadRequestException(
              `Invoices with duplicate invoice_no are not allowed`,
            );
        }
      } else if (
        common_invoice_data?.length !=
        disbursement_request_data?.invoices?.length
      ) {
        if (missing_invoices?.length) {
          const missed_invoices = await this.getInvoiceNosFromData(
            missing_invoices,
          );
          throw new BadRequestException(
            `Invoices with invoice_no(${missed_invoices}) are missing`,
          );
        } else
          throw new BadRequestException(
            'invoice_no not found against provided disbursement_unique_id',
          );
      }
      disbursement_request_data?.invoices.forEach((invoice) => {
        const dis_res_invoice_data = _.find(body?.invoices, [
          'invoice_no',
          invoice.invoice_no,
        ]);
        if (
          dis_res_invoice_data.disbursement_amount > invoice?.payment_requested
        ) {
          throw new BadRequestException(
            `disbursement_amount is greater than requested amount for invoice_no (${invoice.invoice_no})`,
          );
        } else if (
          (dis_res_invoice_data.disbursement_status == 'PENDING' ||
            dis_res_invoice_data.disbursement_status == 'FAILED') &&
          dis_res_invoice_data.disbursement_amount !== 0
        ) {
          throw new BadRequestException(
            `For invoice_no (${invoice.invoice_no}) it's disbursement_status is 'PENDING' or 'FAILED'.So it's disbursement_amount should be 0`,
          );
        } else if (
          dis_res_invoice_data.disbursement_amount > 0 &&
          dis_res_invoice_data.disbursement_amount <
            invoice?.payment_requested &&
          dis_res_invoice_data.disbursement_status !== 'PARTIALLY_DISBURSED'
        ) {
          throw new BadRequestException(
            `disbursement_amount for invoice_no (${invoice.invoice_no}) is less than payment_requested. so disbursement_status should be 'PARTIALLY_DISBURSED'`,
          );
        } else if (
          dis_res_invoice_data.disbursement_amount == 0 &&
          dis_res_invoice_data.disbursement_status == 'PARTIALLY_DISBURSED'
        ) {
          throw new BadRequestException(
            `disbursement_amount for invoice_no (${invoice.invoice_no}) is 0. so disbursement_status cannot be 'PARTIALLY_DISBURSED'`,
          );
        } else if (
          dis_res_invoice_data.disbursement_amount ==
            invoice?.payment_requested &&
          dis_res_invoice_data.disbursement_status !== 'DISBURSED'
        ) {
          throw new BadRequestException(
            `disbursement_status for invoice_no (${invoice.invoice_no}) should be 'DISBURSED'`,
          );
        } else if (
          dis_res_invoice_data.disbursement_amount !=
            invoice?.payment_requested &&
          dis_res_invoice_data.disbursement_amount == 0 &&
          dis_res_invoice_data.disbursement_status == 'DISBURSED'
        ) {
          throw new BadRequestException(
            `disbursement_amount for invoice_no (${invoice.invoice_no}) is not equal to payment_requested. So it's disbursement_status cannot be 'DISBURSED'`,
          );
        }
      });
      if (total_disbursement_amount !== body.total_disbursement_amount)
        throw new BadRequestException('total_disbursement_amount is invalid');
    } catch (error) {
      throw new BadRequestException(error);
    }
  }

  async getInvoiceNosFromData(data: any) {
    const invoices: object = [];
    if (data?.length) {
      data.forEach((invoice, index) => {
        invoices[index] = invoice?.invoice_no;
      });
    }
    return invoices;
  }

  async implementDisbursementRequestValidations(req: any, body: any) {
    try {
      const date = Date.now();
      let [appResult]: any = await this.commonService.getAppWithBusiness(
        body.application_id,
      );
      const app_id = appResult?._id;
      if (!app_id) throw new BadRequestException('invalid application id');
      let offerData: any, analysisData: any;
      const offerEndPoint = `api/v1/offers/all?app_id=${app_id}`;
      offerData = await this.httpRequestService.getOfferData(offerEndPoint);
      const analysisEndPoint = `api/v1/analysis?app_id=${app_id}`;
      analysisData = await this.httpRequestService.getCaseData(
        analysisEndPoint,
      );
      const total_payment_requested = body.invoices.reduce(
        (previous_value, current_value) =>
          previous_value + current_value?.payment_requested,
        0,
      );
      const total_invoice_amount = body.invoices.reduce(
        (previous_value, current_value) =>
          previous_value + current_value?.invoice_amount,
        0,
      );
      const unique_invoices = _.uniqBy(body?.invoices, 'invoice_no');
      if (total_payment_requested !== body.total_payment_requested)
        throw new BadRequestException('total_payment_requested is invalid');
      else if (total_invoice_amount !== body.total_invoice_amount)
        throw new BadRequestException('total_invoice_amount is invalid');
      else if (body?.total_invoices !== body?.invoices.length)
        throw new BadRequestException('total_invoices is invalid');
      else if (unique_invoices?.length !== body?.invoices?.length)
        throw new BadRequestException(
          'invoice_no must be unique for all invoices',
        );
      if (analysisData?.length) {
        const current_limit = await this.getCurrentLimit(
          analysisData,
          offerData,
        );
        if (current_limit <= 0) {
          throw new BadRequestException('Your current limit is zero');
        }
        if (parseInt(body.total_payment_requested) > current_limit) {
          throw new BadRequestException(
            'You are Requested More than Your Current Limit',
          );
        }
      }
      const limit_data: any = await this.getOfferLimit(appResult?._id);
      if (limit_data.length) {
        const limitLastElem = limit_data[limit_data.length - 1];
        if (limitLastElem) {
          if (
            limitLastElem.limit_status === '6225c4943857e83141ff0108' ||
            limitLastElem.limit_status === '6225c6aa278ec6391ebc4628'
          )
            throw new BadRequestException('limit has been blocked');
          if (
            (limitLastElem.limit_status === '6231e7b1f6b8346b07e5c693' ||
              limitLastElem.limit_status === '6225c3eeda9f5b9367369235') &&
            limitLastElem.amount < body.total_payment_requested
          )
            throw new BadRequestException(
              'requested amount is greater than available limit',
            );
        }
        limit_data.forEach((element) => {
          let exprireDateActual = element.limit_expiry_date
            .split('-')
            .reverse()
            .join('-');
          const actualDate = Date.parse(`${exprireDateActual}`);
          const expireDateUpdated = new Date(actualDate);
          expireDateUpdated.setHours(23, 59, 59, 999);
          if (
            element.limit_status === '6231e7b1f6b8346b07e5c693' &&
            Date.parse(`${expireDateUpdated}`) < date
          ) {
            throw new BadRequestException('limit has been expired');
          }
        });
        for (const invoice of body?.invoices) {
          const analysisEndPoint = `api/v1/analysis?invoices.invoice_no=${invoice?.invoice_no}&type=disbursement_request&backend_user_id=${req?.user?.backend_user_id}`;
          analysisData = await this.httpRequestService.getCaseData(
            analysisEndPoint,
          );
          if (analysisData?.length) {
            throw new BadRequestException(
              `disbursement request has been already initiated for invoice_no ${invoice?.invoice_no}.`,
            );
          }
        }
      }
    } catch (error) {
      throw new BadRequestException(error);
    }
  }

  async setInitialsInDisbursementRequest(data) {
    data['disbursement_status'] = 'PENDING';
    return data;
  }

  async createAnalysis(data, api) {
    const appData = await this.commonService.getAppWithBusiness(
      data.application_id,
    );
    const app_id = appData?.[0]?._id;
    if (
      api == 'disbursement_request' ||
      api == 'disbursement_request_reconciliation' ||
      api == 'disbursement_response_reconciliation'
    ) {
      await this.implementDisbursementIdValidation(
        app_id,
        data.type,
        data.disbursement_unique_id,
        api,
      );
    }
    if (!app_id) throw new BadRequestException('invalid application id');
    await this.commonService.checkAppStatus(appData?.[0]?.status_id);
    const body: any = {
      app_id,
      lender_id: appData?.[0]?.lender_id,
      ...data,
    };
    return this.commonService.callApiByName(api, { body });
  }

  async implementDisbursementIdValidation(
    app_id: string,
    type: string,
    disbursement_unique_id: string,
    api: string,
  ) {
    let analysisEndPoint: string = `api/v1/analysis?app_id=${app_id}&start=0&limit=1&sort_by=-created_at&type=${type}&disbursement_unique_id=${disbursement_unique_id}`;
    let disbursementData: any = await this.httpRequestService.getCaseData(
      analysisEndPoint,
    );
    if (disbursementData?.length) {
      throw new BadRequestException('disbursement_unique_id must be unique');
    }
  }

  async patchAnalysis(data, type, api) {
    const appData = await this.commonService.getAppWithBusiness(
      data.application_id,
    );
    const app_id = appData?.[0]?._id;
    if (!app_id) throw new BadRequestException('invalid application id');
    await this.commonService.checkAppStatus(appData?.[0]?.status_id);
    const analysisId = await this.getAnalysisData(app_id, type);
    if (!analysisId) throw new BadRequestException('invalid application id');
    const body = _.omit(data, 'application_id');
    body['analysisId'] = analysisId;
    return this.commonService.callApiByName(api, { body });
  }

  async getAnalysisData(app_id: string, type: string) {
    try {
      const endPoint = `api/v1/analysis?type=${type}&app_id=${app_id}`;
      const analysisData: any = await this.httpRequestService.getCaseData(
        endPoint,
      );
      return analysisData?.[0]?._id;
    } catch (error) {
      throw new BadRequestException(error);
    }
  }

  async updateDisbursementRequest(data, api) {
    const appData = await this.commonService.getAppWithBusiness(
      data.application_id,
    );
    const app_id = appData?.[0]?._id;
    if (!app_id) throw new BadRequestException('invalid application id');
    const analysisEndPoint = `api/v1/analysis?app_id=${app_id}&type=disbursement_request&disbursement_unique_id=${data?.disbursement_unique_id}`;
    const analysisData: any = await this.httpRequestService.getCaseData(
      analysisEndPoint,
    );
    console.log('here analysis data', analysisData);
    if (analysisData?.length) {
      const body: any = {};
      body['analysisId'] = analysisData?.[0]?._id;
      body['disbursement_status'] = data?.disbursement_status;
      _.forEach(analysisData?.[0]?.invoices, function (invoice) {
        const dis_res_invoice_data = _.find(data?.invoices, [
          'invoice_no',
          invoice.invoice_no,
        ]);
        if (dis_res_invoice_data) {
          invoice['disbursement_status'] =
            dis_res_invoice_data?.disbursement_status;
        }
      });
      body['invoices'] = analysisData?.[0]?.invoices;
      return this.commonService.callApiByName(api, { body });
    }
  }

  async getDocumentMetadata() {
    const url = `v1/document_type?is_public=0`;
    return this.httpRequestService.getMasterData(url);
  }

  async getInvoiceTrancheSummary(body: any) {
    try {
      let final_res: any = {},
        backendUserLenderEndPoint: any,
        backendUserLenderData: any,
        analysisData: any;
      const [appData]: any = await this.commonService.getAppWithBusiness(
        body.application_id,
      );
      const app_id = appData?._id;
      if (!app_id) throw new BadRequestException('invalid application id');
      const BackendUserAnchorEndPoint = `api/backend/v1/users?_id=${appData.backend_user_id}`;
      const backendUserAnchorData = await this.commonService.getFrontendUser(
        BackendUserAnchorEndPoint,
      );
      const userEndPoint = `api/v1/users/${appData.user_id}`;
      const user = await this.commonService.getFrontendUser(userEndPoint);
      if (user && user.lender_id) {
        backendUserLenderEndPoint = `api/backend/v1/users?_id=${user.lender_id}`;
        backendUserLenderData = await this.commonService.getFrontendUser(
          backendUserLenderEndPoint,
        );
      }
      const analysisEndPoint = `api/v1/analysis?app_id=${app_id}&start=0&limit=500`;
      analysisData = await this.httpRequestService.getCaseData(
        analysisEndPoint,
      );
      final_res['application_id'] = Number(body.application_id)
        ? Number(body.application_id)
        : null;
      final_res['anchor_id'] =
        backendUserAnchorData && backendUserAnchorData.record_id
          ? backendUserAnchorData.record_id
          : null;
      final_res['lender_id'] = backendUserLenderData?.record_id ?? null;
      final_res['lead_id'] = user?.record_id ?? null;
      switch (body.type) {
        case 'INVOICE':
          const invoice_data = await this.getInvoiceSummary(
            body.invoice_no,
            analysisData,
          );
          return { ...final_res, ...invoice_data };
        case 'DISBURSEMENT':
          const data_with_disbursement: any =
            await this.getDataWithDisbursementId(
              body.disbursement_unique_id,
              analysisData,
            );
          return { ...final_res, ...data_with_disbursement };
        case 'REPAYMENT':
          const data_with_repayment: any = await this.getDataWithRepaymentId(
            body.repayment_unique_id,
            analysisData,
          );
          return { ...final_res, ...data_with_repayment };
        default:
          return { ...final_res };
      }
    } catch (error) {
      throw new BadRequestException(error);
    }
  }

  async getDataWithRepaymentId(repayment_unique_id: any, analysisData: any) {
    try {
      let data_with_repayment_id: any = {},
        disbursementResponseData: any,
        disbursementRequestData: Object,
        repaymentResponseData: any;
      if (analysisData && analysisData?.length) {
        repaymentResponseData =
          _.findLast(analysisData, {
            type: 'repayment_response',
            repayment_unique_id: +repayment_unique_id,
          }) ?? null;
      }
      if (repaymentResponseData) {
        if (repaymentResponseData.disbursement_unique_id) {
          disbursementResponseData =
            _.findLast(analysisData, {
              type: 'disbursement_response',
              disbursement_unique_id:
                repaymentResponseData.disbursement_unique_id,
            }) ?? null;
          disbursementRequestData =
            _.findLast(analysisData, {
              type: 'disbursement_request',
              disbursement_unique_id:
                repaymentResponseData.disbursement_unique_id,
            }) ?? null;
          if (disbursementResponseData && disbursementRequestData) {
            data_with_repayment_id = _.pick(
              disbursementResponseData,
              config.RESPONSE_KEYS_ADDITION
                .invoice_tranche_dis_res_common_fields_topick,
            );
            data_with_repayment_id['invoices'].forEach((elem) => {
              let req_inv = _.find(disbursementRequestData['invoices'], {
                invoice_no: elem.invoice_no,
              });
              if (req_inv) {
                elem['payment_requested'] = req_inv
                  ? req_inv['payment_requested']
                  : 0;
              }
            });
          }
          const tranche_res_with_repayment_id = _.pick(
            repaymentResponseData,
            config.RESPONSE_KEYS_ADDITION.repayment_res_disbursement_id,
          );
          data_with_repayment_id = {
            ...data_with_repayment_id,
            ...tranche_res_with_repayment_id,
          };
          data_with_repayment_id['maadhyam_tranche_date'] =
            repaymentResponseData?.maadhyam_tranche_date ?? null;
          data_with_repayment_id['maadhyam_tranche_disbursement_date'] =
            repaymentResponseData?.maadhyam_tranche_disbursement_date ?? null;
          data_with_repayment_id['maadhyam_tranche_due_date'] =
            repaymentResponseData?.maadhyam_tranche_due_date ?? null;
          data_with_repayment_id['maadhyam_tranche_repayment_date'] =
            repaymentResponseData?.maadhyam_tranche_repayment_date ?? null;
          data_with_repayment_id['maadhyam_tranche_borrower_repayment_amount'] =
            repaymentResponseData?.maadhyam_tranche_borrower_repayment_amount ??
            null;
          data_with_repayment_id[
            'maadhyam_tranche_borrower_repayment_principal'
          ] =
            repaymentResponseData?.maadhyam_tranche_borrower_repayment_principal ??
            null;
          data_with_repayment_id[
            'maadhyam_tranche_borrower_repayment_interest'
          ] =
            repaymentResponseData?.maadhyam_tranche_borrower_repayment_interest ??
            null;
          data_with_repayment_id[
            'maadhyam_tranche_borrower_repayment_charges'
          ] =
            repaymentResponseData?.maadhyam_tranche_borrower_repayment_charges ??
            null;
          data_with_repayment_id[
            'maadhyam_tranche_borrower_os_repayment_amount'
          ] =
            repaymentResponseData?.maadhyam_tranche_borrower_os_repayment_amount ??
            null;
          data_with_repayment_id['maadhyam_tranche_borrower_os_principal'] =
            repaymentResponseData?.maadhyam_tranche_borrower_os_principal ??
            null;
          data_with_repayment_id['maadhyam_tranche_borrower_os_interest'] =
            repaymentResponseData?.maadhyam_tranche_borrower_os_interest ??
            null;
          data_with_repayment_id['maadhyam_tranche_borrower_os_charges'] =
            repaymentResponseData?.maadhyam_tranche_borrower_os_charges ?? null;
          data_with_repayment_id['maadhyam_tranche_repayment_date'] =
            repaymentResponseData?.maadhyam_tranche_repayment_date ?? null;
          data_with_repayment_id[
            'maadhyam_tranche_aggregator_repayment_amount'
          ] =
            repaymentResponseData?.maadhyam_tranche_aggregator_repayment_amount ??
            null;
          data_with_repayment_id[
            'maadhyam_tranche_aggregator_repayment_principal'
          ] =
            repaymentResponseData?.maadhyam_tranche_aggregator_repayment_principal ??
            null;
          data_with_repayment_id[
            'maadhyam_tranche_aggregator_repayment_interest'
          ] =
            repaymentResponseData?.maadhyam_tranche_aggregator_repayment_interest ??
            null;
          data_with_repayment_id[
            'maadhyam_tranche_aggregator_repayment_charges'
          ] =
            repaymentResponseData?.maadhyam_tranche_aggregator_repayment_charges ??
            null;
          return data_with_repayment_id;
        }
        data_with_repayment_id['invoices'] =
          repaymentResponseData?.invoices ?? null;
      }
      return data_with_repayment_id;
    } catch (error) {
      throw new BadRequestException(error);
    }
  }

  async getDataWithDisbursementId(
    disbursement_unique_id: any,
    analysisData: any,
  ) {
    try {
      let data_with_disbursement_id: any = {},
        disbursementResponseData: any,
        repaymentResponseData: any,
        disbursementRequestData: Object;
      if (analysisData && analysisData?.length) {
        disbursementResponseData =
          _.findLast(analysisData, {
            type: 'disbursement_response',
            disbursement_unique_id: disbursement_unique_id,
          }) ?? null;
        disbursementRequestData =
          _.findLast(analysisData, {
            type: 'disbursement_request',
            disbursement_unique_id: disbursement_unique_id,
          }) ?? null;
        repaymentResponseData =
          _.findLast(analysisData, {
            type: 'repayment_response',
            disbursement_unique_id: disbursement_unique_id,
          }) ?? null;
      }
      if (disbursementResponseData && disbursementRequestData) {
        data_with_disbursement_id = _.pick(
          disbursementResponseData,
          config.RESPONSE_KEYS_ADDITION
            .invoice_tranche_dis_res_common_fields_topick,
        );
        data_with_disbursement_id['invoices'].forEach((elem) => {
          let req_inv = _.find(disbursementRequestData['invoices'], {
            invoice_no: elem.invoice_no,
          });
          if (req_inv) {
            elem['payment_requested'] = req_inv
              ? req_inv['payment_requested']
              : 0;
          }
        });
      }
      if (repaymentResponseData) {
        const tranche_res_with_disbursement_id = _.pick(
          repaymentResponseData,
          config.RESPONSE_KEYS_ADDITION.repayment_res_disbursement_id,
        );
        data_with_disbursement_id = {
          ...data_with_disbursement_id,
          ...tranche_res_with_disbursement_id,
        };
        data_with_disbursement_id['maadhyam_tranche_date'] =
          repaymentResponseData?.maadhyam_tranche_date ?? null;
        data_with_disbursement_id['maadhyam_tranche_disbursement_date'] =
          repaymentResponseData?.maadhyam_tranche_disbursement_date ?? null;
        data_with_disbursement_id['maadhyam_tranche_due_date'] =
          repaymentResponseData?.maadhyam_tranche_due_date ?? null;
        data_with_disbursement_id['maadhyam_tranche_repayment_date'] =
          repaymentResponseData?.maadhyam_tranche_repayment_date ?? null;
        data_with_disbursement_id[
          'maadhyam_tranche_borrower_repayment_amount'
        ] =
          repaymentResponseData?.maadhyam_tranche_borrower_repayment_amount ??
          null;
        data_with_disbursement_id[
          'maadhyam_tranche_borrower_repayment_principal'
        ] =
          repaymentResponseData?.maadhyam_tranche_borrower_repayment_principal ??
          null;
        data_with_disbursement_id[
          'maadhyam_tranche_borrower_repayment_interest'
        ] =
          repaymentResponseData?.maadhyam_tranche_borrower_repayment_interest ??
          null;
        data_with_disbursement_id[
          'maadhyam_tranche_borrower_repayment_charges'
        ] =
          repaymentResponseData?.maadhyam_tranche_borrower_repayment_charges ??
          null;
        data_with_disbursement_id[
          'maadhyam_tranche_borrower_os_repayment_amount'
        ] =
          repaymentResponseData?.maadhyam_tranche_borrower_os_repayment_amount ??
          null;
        data_with_disbursement_id['maadhyam_tranche_borrower_os_principal'] =
          repaymentResponseData?.maadhyam_tranche_borrower_os_principal ?? null;
        data_with_disbursement_id['maadhyam_tranche_borrower_os_interest'] =
          repaymentResponseData?.maadhyam_tranche_borrower_os_interest ?? null;
        data_with_disbursement_id['maadhyam_tranche_borrower_os_charges'] =
          repaymentResponseData?.maadhyam_tranche_borrower_os_charges ?? null;
        data_with_disbursement_id['maadhyam_tranche_repayment_date'] =
          repaymentResponseData?.maadhyam_tranche_repayment_date ?? null;
        data_with_disbursement_id[
          'maadhyam_tranche_aggregator_repayment_amount'
        ] =
          repaymentResponseData?.maadhyam_tranche_aggregator_repayment_amount ??
          null;
        data_with_disbursement_id[
          'maadhyam_tranche_aggregator_repayment_principal'
        ] =
          repaymentResponseData?.maadhyam_tranche_aggregator_repayment_principal ??
          null;
        data_with_disbursement_id[
          'maadhyam_tranche_aggregator_repayment_interest'
        ] =
          repaymentResponseData?.maadhyam_tranche_aggregator_repayment_interest ??
          null;
        data_with_disbursement_id[
          'maadhyam_tranche_aggregator_repayment_charges'
        ] =
          repaymentResponseData?.maadhyam_tranche_aggregator_repayment_charges ??
          null;
      }
      return data_with_disbursement_id;
    } catch (error) {
      throw new BadRequestException(error);
    }
  }

  async computeFinalDisbursementStatus(body: any) {
    try {
      const disbursement_status_obj = _.groupBy(
        body['invoices'],
        'disbursement_status',
      );
      const disbursement_status_array = _.keys(disbursement_status_obj);
      if (disbursement_status_array?.length) {
        switch (disbursement_status_array?.length) {
          case 1:
            body['disbursement_status'] = disbursement_status_array[0];
            return body;
          case 2:
            if (
              disbursement_status_array.includes('PENDING') &&
              disbursement_status_array.includes('FAILED')
            ) {
              body['disbursement_status'] = 'PENDING';
              return body;
            }
            body['disbursement_status'] = 'PARTIALLY_DISBURSED';
            return body;
          default:
            body['disbursement_status'] = 'PARTIALLY_DISBURSED';
            return body;
        }
      }
    } catch (error) {
      throw new BadRequestException(error);
    }
  }

  async getInvoiceSummary(invoice_no: any, analysisData: any) {
    try {
      let invoice_details: any = {},
        disbursementRequestData: any,
        disbursementResponseData: any,
        repaymentResponseData: any,
        repaymentRequestData: any;
      if (analysisData && analysisData?.length) {
        disbursementRequestData =
          _.findLast(analysisData, ['type', 'disbursement_request']) ?? null;
        disbursementResponseData =
          _.findLast(analysisData, ['type', 'disbursement_response']) ?? null;
        repaymentRequestData =
          _.findLast(analysisData, ['type', 'repayment_request']) ?? null;
        repaymentResponseData =
          _.findLast(analysisData, ['type', 'repayment_response']) ?? null;
      }
      invoice_details['invoice_no'] = invoice_no ?? null;
      if (disbursementRequestData) {
        const disbursement_req_invoice_data = _.find(
          disbursementRequestData.invoices,
          ['invoice_no', invoice_no],
        );
        invoice_details['distributor_unique_code'] =
          disbursement_req_invoice_data?.distributor_unique_code ?? null;
        invoice_details['payee_account_number'] =
          disbursement_req_invoice_data?.payee_account_number ?? null;
        invoice_details['payment_requested'] =
          disbursement_req_invoice_data?.payment_requested ?? null;
      }
      if (disbursementResponseData) {
        const disbursement_res_invoice_data = _.find(
          disbursementResponseData.invoices,
          ['invoice_no', invoice_no],
        );
        if (disbursement_res_invoice_data) {
          const invoice_data_disbursement = _.pick(
            disbursement_res_invoice_data,
            config.RESPONSE_KEYS_ADDITION
              .invoice_tranche_disbursement_invoice_res,
          );
          invoice_details = {
            ...invoice_details,
            ...invoice_data_disbursement,
          };
        }
        const invoice_res_disbursement = _.pick(
          disbursementResponseData,
          config.RESPONSE_KEYS_ADDITION.invoice_tranche_disbursement_res,
        );
        invoice_details = { ...invoice_details, ...invoice_res_disbursement };
      }
      if (repaymentRequestData) {
        invoice_details['repayment_date'] =
          repaymentRequestData?.repayment_timestamp ?? null;
        const repayment_req_invoice_data = _.find(
          repaymentRequestData?.invoices,
          ['invoice_no', invoice_no],
        );
        if (repayment_req_invoice_data) {
          invoice_details['aggregator_due_date'] =
            repayment_req_invoice_data?.invoice_timestamp
              ? moment(
                  repayment_req_invoice_data.invoice_timestamp,
                  'DD-MM-YYYY hh:mm:ss',
                )
                  .add(45, 'd')
                  .format('DD-MM-YYYY hh:mm:ss')
              : null;
        }
      }
      if (repaymentResponseData) {
        const repayment_res_invoice_data = _.find(
          repaymentResponseData?.invoices,
          ['invoice_no', invoice_no],
        );
        if (repayment_res_invoice_data) {
          const invoice_res_repayment = _.pick(
            repayment_res_invoice_data,
            config.RESPONSE_KEYS_ADDITION.respayment_response_invoice,
          );
          invoice_details = { ...invoice_details, ...invoice_res_repayment };
          invoice_details['maadhyam_invoice_due_date'] =
            repayment_res_invoice_data?.maadhyam_invoice_fination_due_date;
        }
        if (
          repaymentResponseData?.disbursement_unique_id &&
          repaymentRequestData?.disbursement_unique_id &&
          repaymentResponseData?.disbursement_unique_id ===
            repaymentRequestData?.disbursement_unique_id
        ) {
          const invoice_res_with_disbursement_id = _.pick(
            repaymentResponseData,
            config.RESPONSE_KEYS_ADDITION.repayment_res_disbursement_id,
          );
          invoice_details = {
            ...invoice_details,
            ...invoice_res_with_disbursement_id,
          };
          invoice_details['maadhyam_tranche_date'] =
            repaymentResponseData?.maadhyam_tranche_date ?? null;
          invoice_details['maadhyam_tranche_disbursement_date'] =
            repaymentResponseData?.maadhyam_tranche_disbursement_date ?? null;
          invoice_details['maadhyam_tranche_due_date'] =
            repaymentResponseData?.maadhyam_tranche_due_date ?? null;
          invoice_details['maadhyam_tranche_repayment_date'] =
            repaymentResponseData?.maadhyam_tranche_repayment_date ?? null;
          invoice_details['maadhyam_tranche_borrower_repayment_amount'] =
            repaymentResponseData?.maadhyam_tranche_borrower_repayment_amount ??
            null;
          invoice_details['maadhyam_tranche_borrower_repayment_principal'] =
            repaymentResponseData?.maadhyam_tranche_borrower_repayment_principal ??
            null;
          invoice_details['maadhyam_tranche_borrower_repayment_interest'] =
            repaymentResponseData?.maadhyam_tranche_borrower_repayment_interest ??
            null;
          invoice_details['maadhyam_tranche_borrower_repayment_charges'] =
            repaymentResponseData?.maadhyam_tranche_borrower_repayment_charges ??
            null;
          invoice_details['maadhyam_tranche_borrower_os_repayment_amount'] =
            repaymentResponseData?.maadhyam_tranche_borrower_os_repayment_amount ??
            null;
          invoice_details['maadhyam_tranche_borrower_os_principal'] =
            repaymentResponseData?.maadhyam_tranche_borrower_os_principal ??
            null;
          invoice_details['maadhyam_tranche_borrower_os_interest'] =
            repaymentResponseData?.maadhyam_tranche_borrower_os_interest ??
            null;
          invoice_details['maadhyam_tranche_borrower_os_charges'] =
            repaymentResponseData?.maadhyam_tranche_borrower_os_charges ?? null;
          invoice_details['maadhyam_tranche_repayment_date'] =
            repaymentResponseData?.maadhyam_tranche_repayment_date ?? null;
          invoice_details['maadhyam_tranche_aggregator_repayment_amount'] =
            repaymentResponseData?.maadhyam_tranche_aggregator_repayment_amount ??
            null;
          invoice_details['maadhyam_tranche_aggregator_repayment_principal'] =
            repaymentResponseData?.maadhyam_tranche_aggregator_repayment_principal ??
            null;
          invoice_details['maadhyam_tranche_aggregator_repayment_interest'] =
            repaymentResponseData?.maadhyam_tranche_aggregator_repayment_interest ??
            null;
          invoice_details['maadhyam_tranche_aggregator_repayment_charges'] =
            repaymentResponseData?.maadhyam_tranche_aggregator_repayment_charges ??
            null;
        }
      }

      return invoice_details;
    } catch (error) {
      throw new BadRequestException(error);
    }
  }

  async getApplicationTransactionInfo({ id }: any) {
    try {
      const endPoint = `api/v1/analysis?auto_id=${id}`;
      const analysisData: any = await this.httpRequestService.getCaseData(
        endPoint,
      );
      if (!analysisData.length)
        throw new BadRequestException('invalid transaction id');
      return analysisData;
    } catch (error) {
      throw new BadRequestException(error);
    }
  }

  async getAppSummary(params) {
    try {
      let offerData: any, analysisData: any, user_data: Object;
      const [appData]: any = await this.commonService.getAppWithBusiness(
        params?.application_id,
      );
      if (!appData) throw new BadRequestException('invalid application_id');

      const masterEndPoint = `v1/multiple?model=app_status,limit_status,lead_status`;
      const masterData = await this.httpRequestService.getMasterData(
        masterEndPoint,
      );
      if (appData?._id) {
        const offerEndPoint = `api/v1/offers/all?app_id=${appData._id}`;
        offerData = await this.httpRequestService.getOfferData(offerEndPoint);

        const analysisEndPoint = `api/v1/analysis?app_id=${appData._id}&limit=-1`;
        analysisData = await this.httpRequestService.getCaseData(
          analysisEndPoint,
        );
        const userEndPoint = `api/v1/users/${appData.user_id}`;
        user_data = await this.httpRequestService.getUserData(userEndPoint);
      }
      const finalRes = await this.prepareAppSummaryRes(
        masterData,
        appData,
        analysisData,
        offerData,
        user_data,
      );
      return finalRes;
    } catch (error) {
      throw new BadRequestException(error);
    }
  }

  async prepareAppSummaryRes(
    masterData: any,
    appData: any,
    analysisData: any,
    offerData: any,
    userData: any,
  ) {
    try {
      let res: any = {};
      let latestOfferData: any = {};
      res.application_id = appData?.auto_id ? appData?.auto_id : null;
      res.lead_id = userData?.record_id ? userData?.record_id : null;
      appData?.business?.[0]?.retailer_interest_rate
        ? (res.retailer_interest_rate =
            appData?.business?.[0].retailer_interest_rate)
        : '';
      if (masterData?.app_status) {
        res.application_status = appData.status_id
          ? _.find(masterData.app_status, ['id', appData.status_id])
            ? _.find(masterData.app_status, ['id', appData.status_id])?.type
            : null
          : null;
      }

      if (offerData?.length) {
        if (masterData.limit_status) {
          res.approved_limit = _.find(masterData.limit_status, [
            'value',
            'Approved',
          ])
            ? _.find(offerData, [
                'limit_status',
                _.find(masterData.limit_status, ['value', 'Approved']).id,
              ])
              ? _.find(offerData, [
                  'limit_status',
                  _.find(masterData.limit_status, ['value', 'Approved']).id,
                ]).amount
              : null
            : null;
          res.sanctioned_limit = _.find(masterData.limit_status, [
            'value',
            'Sanctioned',
          ])
            ? _.find(offerData, [
                'limit_status',
                _.find(masterData.limit_status, ['value', 'Sanctioned']).id,
              ])
              ? _.find(offerData, [
                  'limit_status',
                  _.find(masterData.limit_status, ['value', 'Sanctioned']).id,
                ]).amount
              : null
            : null;
          res.allocated_limit = _.find(masterData.limit_status, [
            'value',
            'Allocated',
          ])
            ? _.find(offerData, [
                'limit_status',
                _.find(masterData.limit_status, ['value', 'Allocated']).id,
              ])
              ? _.find(offerData, [
                  'limit_status',
                  _.find(masterData.limit_status, ['value', 'Allocated']).id,
                ]).amount
              : null
            : null;
          let offerIndex: any;
          if (
            _.some(offerData, (offer, index) => {
              if (offer.loan_account_number) {
                offerIndex = index;
                return true;
              }
              return false;
            })
          ) {
            res.loan_account_number = offerData[offerIndex]?.loan_account_number
              ? offerData[offerIndex].loan_account_number
              : null;
          }
          if (analysisData?.length) {
            const current_limit = await this.getCurrentLimit(
              analysisData,
              offerData,
            );
            res.current_limit = current_limit ? current_limit : 0;
          }
          latestOfferData = offerData.pop();
          res.limit_status = latestOfferData.limit_status
            ? _.find(masterData.limit_status, [
                'id',
                latestOfferData.limit_status,
              ])
              ? _.find(masterData.limit_status, [
                  'id',
                  latestOfferData.limit_status,
                ])?.type
              : null
            : null;
          res.limit_expiry_date = latestOfferData.limit_expiry_date
            ? latestOfferData.limit_expiry_date
            : null;
        }
      }
      if (analysisData?.length) {
        const analysisCountData = _.countBy(analysisData, 'type');
        if (analysisCountData['disbursement_response']) {
          res.total_disbursement_count = 0;

          _.forEach(analysisData, (analysis) => {
            if (analysis?.type == 'disbursement_response') {
              if (analysis?.invoices?.length) {
                const invoiceCountData = _.countBy(
                  analysis.invoices,
                  'disbursement_status',
                );
                res.total_disbursement_count = invoiceCountData['DISBURSED']
                  ? res.total_disbursement_count + invoiceCountData['DISBURSED']
                  : res.total_disbursement_count;
              }
            }
          });
        }
        const disbursementResData = _.findLast(analysisData, [
          'type',
          'disbursement_response',
        ]);
        if (disbursementResData) {
          res.last_disbursement_date = disbursementResData?.invoices?.length
            ? disbursementResData?.invoices[
                disbursementResData?.invoices?.length - 1
              ]?.disbursed_date
            : null;
          res.last_disbursement_amount =
            disbursementResData?.total_disbursement_amount
              ? disbursementResData.total_disbursement_amount
              : null;
        }
        const repaymentResData = _.findLast(analysisData, [
          'type',
          'repayment_response',
        ]);
        if (repaymentResData) {
          res.last_repayment_date = repaymentResData?.repayment_timestamp
            ? repaymentResData.repayment_timestamp
            : '';
          res.last_repayment_amount = repaymentResData?.total_repayment_received
            ? repaymentResData.total_repayment_received
            : null;
          res.pending_repayment_amount =
            repaymentResData?.pending_repayment_amount
              ? repaymentResData.pending_repayment_amount
              : 0;
          if (analysisCountData['repayment_response']) {
            res.total_repayment_count = 0;

            _.forEach(analysisData, (analysis) => {
              if (analysis?.type == 'repayment_response') {
                if (analysis?.invoices?.length) {
                  const invoiceCountData = _.countBy(
                    analysis.invoices,
                    'status_of_invoice_repayment',
                  );
                  res.total_repayment_count = invoiceCountData['PAID']
                    ? res.total_repayment_count + invoiceCountData['PAID']
                    : res.total_repayment_count;
                }
                if (
                  analysis?.disbursement_unique_id &&
                  analysis?.status_of_tranche_repayment === 'PAID'
                ) {
                  res.total_repayment_count += 1;
                }
              }
            });
          }
        }
      }
      return res;
    } catch (error) {
      throw new BadRequestException(error);
    }
  }

  async filterLatestTranscResponseRecords(analysis_history) {
    let disidtypeRecMap = {};
    return analysis_history.filter((rec) => {
      let hash = rec.disbursement_unique_id + '#' + rec.type;
      if (!disidtypeRecMap[hash]) {
        disidtypeRecMap[hash] = true;
        return true;
      }
      return false;
    });
  }
  async calculateCurrentLimit(sanctioned_amount: any, analysisData: any) {
    try {
      let totalLimitAmount = sanctioned_amount;
      let subtractAmount = 0;
      let total_invoice_principal_deduction = 0;
      if (analysisData?.length) {
        let disubrsement_list = analysisData
          .filter(
            (data) =>
              data.disbursement_unique_id &&
              data.type == config.RESPONSE_TYPE.DISBURSEMENT_TYPE.response,
          )
          .sort(
            (comp1, comp2) =>
              new Date(comp2.created_at).getTime() -
              new Date(comp1.created_at).getTime(),
          );
        disubrsement_list = await this.filterLatestTranscResponseRecords(
          disubrsement_list,
        );
        let repayment_list = analysisData.filter(
          (data) =>
            data.repayment_unique_id &&
            data.type == config.RESPONSE_TYPE.REPAYMENT_TYPE.response,
        );
        for (let data of disubrsement_list) {
          subtractAmount += +data.total_disbursement_amount;
        }
        for (let data of repayment_list) {
          if (data?.invoices?.length) {
            for (let invoice of data.invoices) {
              total_invoice_principal_deduction +=
                +invoice.invoice_principal_deduction || 0;
            }
          } else if (data?.status_of_tranche_repayment == 'PARTIAL') {
            total_invoice_principal_deduction +=
              +data.total_principal_deduction || 0;
          } else {
            total_invoice_principal_deduction +=
              +data.total_principal_deduction || 0;
          }
        }
        totalLimitAmount -= subtractAmount;
        totalLimitAmount += total_invoice_principal_deduction;
      }
      return totalLimitAmount;
    } catch (error) {
      throw new BadRequestException(error);
    }
  }

  async getCurrentLimit(analysisData: any, offerData: any) {
    try {
      let sanctiondOffer = await this.getSanctionedOffer(offerData);
      if (sanctiondOffer) {
        return await this.calculateCurrentLimit(
          +sanctiondOffer.amount,
          analysisData,
        );
      }
      return null;
    } catch (error) {
      throw new BadRequestException(error);
    }
  }

  async getSanctionedOffer(offerData: any) {
    try {
      let offer_data = null;
      for (let offer of offerData) {
        if (
          [
            config.LIMIT_STATUS.sanctioned,
            config.LIMIT_STATUS.allocated,
          ].includes(offer.limit_status)
        ) {
          offer_data = offer;
        }
      }
      return offer_data ? offer_data : null;
    } catch (error) {
      throw new BadRequestException(error);
    }
  }
}
