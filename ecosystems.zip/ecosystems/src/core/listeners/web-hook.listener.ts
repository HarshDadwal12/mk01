import { Injectable } from '@nestjs/common';
import { OnEvent } from '@nestjs/event-emitter';

import { WebHookEvent } from '../events/web-hook.event';
import { QueueService } from '../services/queue.service';

@Injectable()
export class WebHookListener {
  constructor(private readonly queueService: QueueService) {}
  @OnEvent('web.hook')
  async handleRequestLogEvent(event: WebHookEvent) {
    try {
      console.log(JSON.stringify(event.resData));

      // if (process.env.NODE_ENV === 'production') {
        const data = await this.queueService.sendMessage(event.resData);
        console.log(data);
      // }
    } catch (error) {
      console.log('web hook error', error);
    }
  }
}
