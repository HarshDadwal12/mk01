const pdfConfig = (req) => {
    let margin = {
        top: '30px',
        bottom: '30px',
        left: '50px',
        right: '50px'
    };
    let config = {
        format: 'Letter',
        displayHeaderFooter:false,
        margin: margin
    };


    if(req.body.header_template || req.body.footer_template || req.body.page_number){
        config.displayHeaderFooter = true;
       
        if(req.body.header_template){
            config.margin.top = '120px';
            config.headerTemplate = req.body.header_template;
        }else{
            config.headerTemplate = ' ';
        }

        if(req.body.page_number) {
            config.footerTemplate =  `
            <div id="footer-template" style="font-size:10px  !important; content-align: right; width: 100%; color:#808080; padding-left:10px">
                <span style="float: right; padding-right: 60px; padding-bottom:10px;">
                    <span class="pageNumber"></span>/<span class="totalPages"></span>
                </span>
            </div>`;
            config.margin.bottom = '100px';
        } else if(req.body.footer_template){
            config.footerTemplate = req.body.footer_template;
            config.margin.bottom = '100px';
        }else{
            config.footerTemplate = ' ';
        }
    }

    if(req.body.print_background) {
        config.printBackground = true;
    }

    return {...config};
};

exports.pdfConfig = pdfConfig;