import { model, Schema } from 'mongoose';

import { BASE_SCHEMA } from './base.model';

const UserSchema = new Schema(
  {
    name: { type: String, required: true },
    user_type: { type: String, enum: ['aggregator', 'lender'], required: true },
    address: { type: String },
    username: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    customer_key: { type: String, required: true, unique: true },
    backend_user_id: { type: String, required: true, unique: true },
    customer_secret: { type: String, required: true, unique: true },
    products: [{ type: String }],
    hook_config: {
      url: { type: String },
      encryption_key: { type: String },
      headers: {},
    },
  },
  { versionKey: false },
).add(BASE_SCHEMA);

UserSchema.methods = {
  toJSON() {
      let result: any = this.toObject();
      delete result?.password
      delete result?.customer_key


      return result; 
  }
}
export default model('User', UserSchema, 'users');
