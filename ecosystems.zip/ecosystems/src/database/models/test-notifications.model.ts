import { model, Schema } from 'mongoose';
import { getDateUnixTimestamp } from 'src/config/datetime.config';


const TestNotificationsSchema = new Schema(
  {
    type : { type : String , required : true},
    data : {type : Object,required : true},
    created_at: { type: Schema.Types.Mixed, index: true },
    updated_at: { type: Schema.Types.Mixed }
  },
  {
    strict: false, versionKey: false,
    timestamps: {
      createdAt: 'created_at',
      updatedAt: 'updated_at',
      currentTime: () => getDateUnixTimestamp(),
    },
  },
);

export default model('TestNotifications', TestNotificationsSchema, 'testNotifications');
