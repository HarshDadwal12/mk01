import { BadRequestException, Injectable } from '@nestjs/common';
import { JwtService } from 'src/core/services/jwt.service';
import * as bcrypt from 'bcrypt';

import { config } from 'src/config/constant.config';
import { CryptoService } from 'src/core/services/cypto.service';
import { QueryService } from 'src/core/services/query.service';
import CustomerInfo from '../../database/models/user.model';

@Injectable()
export class AuthService {
  constructor(
    private jwtService: JwtService,
    private queryService: QueryService,
    private cryptoService: CryptoService,
  ) {}
  /**
   *
   * @param param0
   * @returns
   */
  async checkUser({
    username,
    password,
  }: {
    username: string;
    password: string;
  }) {
    const customer = await this.queryService.findOne({
      modelName: CustomerInfo,
      condition: { username, is_active: true },
    });

    if (!customer) throw new BadRequestException(['invalid_client']);
    const passwordStr = Buffer.from(this.cryptoService.decrypt(customer.password), 'base64').toString('ascii');
    if (passwordStr !== password) throw new BadRequestException(['invalid_client']);
    return customer;
  }

  /**
   *
   * @param customer_key
   * @param customer_secret
   * @param customer
   * @returns
   */
  async generateToken(
    customer_key: string,
    customer_secret: string,
    customer: any,
  ) {
    if (
      customer.customer_key !== customer_key ||
      customer.customer_secret !== customer_secret
    ) {
      throw new BadRequestException(['invalid_client']);
    }

    const token = await this.jwtService.getTokens(customer._id);
    const access_token = this.cryptoService.encrypt(token.access_token);

    return {
      access_token,
      token_type: 'Bearer',
      expires_in: config.ACCESS_TOKEN_EXPIRY_TIME,
    };
  }

  parseToken(token: string): string[] {
    return Buffer.from(token.split(' ')[1], 'base64').toString().split(':');
  }
}
