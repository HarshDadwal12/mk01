const aws = require('aws-sdk');
const Archiver = require('archiver');
const s3 = new aws.S3();

const s3_Config = {
  preSignedUrl: () => {
    return s3.getSignedUrl('getObject', {
      Bucket: process.env.BUCKET_NAME,
      Key: 'zip/zippedFile.zip',
      Expires: 30 * 60,
    });
  },
  getS3Object: async (app_id) => {
    const s3Object = await s3
      .listObjectsV2({
        Bucket: process.env.BUCKET_NAME,
        Prefix: app_id,
      })
      .promise();
    return s3Object;
  },
  getS3CreateReadstream: (Key) => {
    return s3
      .getObject({ Bucket: process.env.BUCKET_NAME, Key })
      .createReadStream();
  },
  s3UploadParams: (Key, stream) => {
    return {
      Body: stream,
      ContentType: 'application/zip',
      Key,
      Bucket: process.env.BUCKET_NAME,
      StorageClass: 'STANDARD',
    };
  },
  s3UploadData: (params) => {
    const s3Upload = s3.upload(params, (err, data) => {
      if (err) {
        console.error('upload error', err);
      } else {
        console.log('upload done', data);
      }
    });
    return s3Upload;
  },
};

const Archive = {
  archiver: () => {
    return Archiver('zip', {
      zlib: { level: 9 },
    });
  },
};

module.exports = { s3_Config, Archive };
