import { SQSClient } from '@aws-sdk/client-sqs';
export interface QueueInterface {
  client?: SQSClient;
}
