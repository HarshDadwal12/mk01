"use strict";

// Import module for mongo-db conection
const db = require("../db");
const conn = new db.connectionFactory(
  process.env.MONGO_USER_DB_URL,
  "user_trackings",
  "./schemas/userTrackingSchema"
);
var ObjectId = require("mongoose").Types.ObjectId;
// Define log-collection name
const request_collection_name = "user_trackings";

module.exports = {
  findByUserId: async function (user_id) {
    return new Promise(async function (resolve, reject) {
      try {
        let Collection = conn.model(request_collection_name);

        await Collection.findOne({ user_id: new ObjectId(user_id) }, function (
          err,
          data
        ) {
          // return document data
          if (!err) return resolve(data);
          // return error
          else return reject(err);
        });
      } catch (error) {
        return reject(error);
      }
    });
  },
  find: async function (query, project = null) {
    return new Promise(async function (resolve, reject) {
      try {
        let Collection = conn.model(request_collection_name);

        await Collection.find(query, project, function (
          err,
          data
        ) {
          // return document data
          if (!err) return resolve(data);
          // return error
          else return reject(err);
        });
      } catch (error) {
        return reject(error);
      }
    });
  },
  getAggregate: async function (json_data) {
    return new Promise(async function (resolve, reject) {
      try {
        let Collection = conn.model(request_collection_name);

        await Collection.aggregate(json_data, function (err, data) {
          // return document data
          if (!err) return resolve(data);
          // return error
          else return reject(err);
        });
      } catch (error) {
        return reject(error);
      }
    });
  },
};
