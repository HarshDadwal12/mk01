args=("$@")
function install {
  (
    echo "Installing node project ... "
    echo $1
    cd $1;\
    echo ${args[0]}
    npm install
    # npm install --prefix "service_document/" "service_document/"."${args[0]}";\
  )
}
install $1