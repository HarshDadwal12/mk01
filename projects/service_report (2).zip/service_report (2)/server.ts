import cors from 'cors';
import compression from 'compression';
import CONSTANT from './src/config/constants';
import express, { Application } from 'express';
import bodyParser from 'body-parser';
import ReportRouter from './src/routes/ReportRouters';


export class Server {
  private _app: Application = express();
  private _port: string | number = CONSTANT.PORT;
  public router: express.Router = express.Router();

  constructor() {
    this.setConfiguration();
    this.setRoutes();
  }
  get app() {
    return this._app;
  }
  get port() {
    return this._port;
  }
  setConfiguration() {
    this._app.use(express.urlencoded({ extended: true }));
    this._app.use(express.json());
    this._app.use(compression());

    this._app.use(
      cors({
        origin: CONSTANT.ACCESS_DOMAIN,
        methods: ['GET', 'PUT', 'PATCH', 'POST', 'DELETE', 'OPTIONS'],
      })
    );
  }

  configureBodyParser() {
    this.app.use(bodyParser.urlencoded({ limit: '50mb', extended: true }));
    this.app.use(bodyParser.json({ limit: '50mb' }));
}

setRoutes() {
  console.log('inside');

  this.app.use('/api/v1', new ReportRouter(this.router).router);
}
}
