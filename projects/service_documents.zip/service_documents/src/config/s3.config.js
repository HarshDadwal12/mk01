const AWS = require("aws-sdk");

// S3 Client

const s3 = {};
s3.getS3Client = (tenant) => {
	return new AWS.S3({
		accessKeyId: global[tenant]["envConfig"].AWS_ACCESS_KEY,
		secretAccessKey: global[tenant]["envConfig"].AWS_SECRET_ACCESS_KEY,
		region: global[tenant]["envConfig"].REGION,
	});
};
s3.uploadParams = (tenant) => {
	return {
		Bucket: global[tenant]["envConfig"].BUCKET,
		Key: "",
		Body: null,
	};
};
s3.downloadParams = (tenant) => {
	return {
		Bucket: global[tenant]["envConfig"].BUCKET,
		Key: "",
	};
};

s3.copyParams = (tenant, messages, doc) => {
	const bucket = global[tenant]["envConfig"].BUCKET;
	return {
		Bucket: bucket,
		Key: `${messages.deleted}/${doc.doc_key}`,
		CopySource: `${bucket}/${doc.doc_key}`,
	};
};

module.exports = s3;
