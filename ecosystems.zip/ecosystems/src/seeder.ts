import { connect, connection, Connection } from 'mongoose';
import * as path from 'path';

import * as fs from 'fs';
import * as Glob from 'glob';
import * as util from 'util';
import { config } from './config/constant.config';
const lstat = util.promisify(fs.lstat);

export class Seeder {
  private _db: Connection;
  seederCount = 0;
  totalFilesRead = 0;

  public constructor() {
    this.connectDb();
  }

  private async connectDb() {
    await connect(config.MONGO_URL);
    this._db = connection;
    this._db.on('open', this.connected);
    this._db.on('error', this.error);
    this.getAllFiles();
  }

  private error(error) {
    console.log('Mongoose has errored', error);
  }

  private async getAllFiles() {
    const files = await Glob.sync(`src/assets/*`);
    this.processFiles(files);
  }

  private async truncateAndInset(file) {
    let fileName = path.basename(file, '.js');
    const fileData = await import(path.join('../', file));
    await this.truncateTable(fileName);
    await this.insertData(fileName, fileData);
  }

  private async processFiles(files) {
    try {
      for await (const file of files) {
        const stat = await lstat(file);
        if (`${file}`.indexOf('.js') !== -1) {
          console.log('Seeding...', file);
          await this.truncateAndInset(file);
          this.seederCount++;
        }
      }
      if (
        this.seederCount === files.length ||
        this.totalFilesRead === this.seederCount
      ) {
        process.exit(0);
      }
    } catch (error) {
      console.log(error);
    }
  }

  private async insertData(fileName, fileData) {
    try {
      if (fileName == 'apis') {
        let fieldId = 'name';
        fileData = await fileData.map((elem) => ({
          ...elem,
          _id: elem[fieldId],
        }));
      }

      let isInserted = await this._db
        .collection(fileName)
        .insertMany(fileData, {
          ordered: false,
        });
      return isInserted;
    } catch (error) {
      console.log(error);
      return error.message;
    }
  }

  private async truncateTable(fileName) {
    try {
      fileName = fileName.toLowerCase();

      const isTruncated = await this._db.dropCollection(fileName);

      return isTruncated;
    } catch (error) {
      return error.message;
    }
  }

  connected() {
    console.log('Mongoose has connected ');
  }
}
new Seeder();
