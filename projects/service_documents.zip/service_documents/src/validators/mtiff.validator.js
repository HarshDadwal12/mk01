const axios = require('axios');
const helper = require('../helpers/helper');
const config = require('../../config/config');
const messages = require('../lang/en/messages');

module.exports = {

    // Various methods to validate the incoming request
    
    /**
     * @description Check is file is selected or not
     * 
     * @author Sujendra Kumar <sujendra.kumar@biz2credit.com>
     * 
     * @param req
     * @param res
     * @param {callback function} next
     * 
     * @returns string
     */
    pdfToTiffValidator (req, res, next) { 
        if(!req.file){ 
            return helper.getErrorResponse(req, res, [ messages.keys.file_required], messages.codes.bad_request);
        }
        
        next();
    },

    /**
     * @description Check is file is selected or not
     * 
     * @author Sujendra Kumar <sujendra.kumar@biz2credit.com>
     * 
     * @param req
     * @param res
     * @param {callback function} next
     * 
     * @returns string
     */
    uploadTiffValidator (req, res, next) { 
        if(!req.file && !req.body.doc_type_id){ 
            return helper.getErrorResponse(req, res, [ messages.keys.file_required , messages.keys.doc_type_required ], messages.codes.bad_request);
        }

        if(!req.file) {
            return helper.getErrorResponse(req, res, [messages.keys.file_required], messages.codes.bad_request);
        }

        if(!req.body.doc_type_id) {
            return helper.getErrorResponse(req, res, [messages.keys.doc_type_required] , messages.codes.bad_request);
        }
        
        next();
    },
};
