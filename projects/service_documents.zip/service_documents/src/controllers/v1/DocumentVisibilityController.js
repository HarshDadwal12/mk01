const helper = require("../../helpers/helper");
const DocumentVisibility = require("../../models/DocumentVisibility");

module.exports = {
	/**
	 * @description create Document visibility for Applications
	 *
	 * @author Ravi Pratap Singh <ravi.singh@biz2credit.com>
	 *
	 * @param req
	 * @param res
	 *
	 * @returns string
	 */
	createDocVisibility: async (req, res) => {
		try {
      const body = req.body
			const tenant = req.headers["x-tenant-id"];
      const DocVisibility = global[tenant]['dbModel'][DocumentVisibility.name];
      
      const doc = await (new DocVisibility(body)).save()

      return helper.sendSuccessResponse(req, res, doc);

		} catch (error) {
			console.log("error:::", error);
			return helper.getErrorResponse(req, res);
		}
	},
  /**
	 * @description get Document visibility for Applications
	 *
	 * @author Ravi Pratap Singh <ravi.singh@biz2credit.com>
	 *
	 * @param req
	 * @param res
	 *
	 * @returns string
	 */
	getDocVisibility: async (req, res) => {
		try {
      const _id = req.params.id
			const tenant = req.headers["x-tenant-id"];
      const DocVisibility = global[tenant]['dbModel'][DocumentVisibility.name];
  
      const doc = await DocVisibility.findOne({_id})

      return helper.sendSuccessResponse(req, res, doc || {} );

		} catch (error) {
			console.log("error:::", error);
			return helper.getErrorResponse(req, res);
		}
	},
  /**
	 * @description Update Document visibility for Applications
	 *
	 * @author Ravi Pratap Singh <ravi.singh@biz2credit.com>
	 *
	 * @param req
	 * @param res
	 *
	 * @returns string
	 */
	updateDocVisibility: async (req, res) => {
		try {
      const body = req.body
      const _id = req.params.id
			const tenant = req.headers["x-tenant-id"];
      const DocVisibility = global[tenant]['dbModel'][DocumentVisibility.name];
      
      await DocVisibility.updateOne({ _id }, body);

      return helper.sendSuccessResponse(req, res);

		} catch (error) {
			console.log("error:::", error);
			return helper.getErrorResponse(req, res);
		}
	},
};
