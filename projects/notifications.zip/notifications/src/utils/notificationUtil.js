'use strict';

const { post, put, get } = require('../client/httpRequest');
const { create } = require('../db/models/notificationLoggerModel');
const constant = require('./constant');
const { getEcoApiConfig } = require('./helper');

/**
 * @description Get Application
 * @author Ravi Pratap Singh <ravi.singh@biz2credit.com>
 * @param {*} data
 * @param {*} id
 * @returns promise
 */
module.exports.getAnalysis = async function (query) {
  const url = constant.CASE_API + constant.GET_ANALYSIS + '?' + query;
  return (await get({ url }))[0];
};

/**
 * @description Get Application
 * @author Ravi Pratap Singh <ravi.singh@biz2credit.com>
 * @param {*} data
 * @param {*} id
 * @returns promise
 */
module.exports.getApplication = async function (id) {
  const url = constant.CASE_API + constant.GET_APPLICATION + '?auto_id=' + id;
  return (await get({ url }))[0];
};

/**
 * @description Get Application
 * @author Ravi Pratap Singh <ravi.singh@biz2credit.com>
 * @param {*} data
 * @param {*} id
 * @returns promise
 */
module.exports.getApplicationById = async function (id) {
  const url = constant.CASE_API + constant.GET_APPLICATION + '/' + id;
  return (await get({ url }))[0];
};

/**
 * @description Get Lead
 * @author Ravi Pratap Singh <ravi.singh@biz2credit.com>
 * @param {*} data
 * @param {*} id
 * @returns promise
 */
module.exports.getLead = async function (id) {
  const url = constant.USER_API + constant.GET_LEAD + '?record_id=' + id;
  return (await get({ url }))[0];
};

/**
 * @description Get Lead
 * @author Ravi Pratap Singh <ravi.singh@biz2credit.com>
 * @param {*} data
 * @param {*} id
 * @returns promise
 */
module.exports.getLeadById = async function (id) {
  const url = constant.USER_API + constant.GET_LEAD + '/' + id;
  return await get({ url });
};

/**
 * @description Get Lender Config
 * @author Ravi Pratap Singh <ravi.singh@biz2credit.com>
 * @param {*} data
 * @param {*} id
 * @returns promise
 */
module.exports.getClientConfig = async function (query) {
  const url =
    constant.ECOSYSTEM_API +
    constant.LENDER_CONFIG +
    '?expands=user-mappings' +
    query;
  const config = getEcoApiConfig();
  return (await get({ url, config }))[0];
};

/**
 * @description Post data on web hook
 * @author Ravi Pratap Singh <ravi.singh@biz2credit.com>
 * @param {*} data
 * @param {*} id
 * @returns promise
 */
module.exports.webHook = async function (user_mapping, data, userData) {
  if (user_mapping && user_mapping.hook) {
    const { backend_user_id, hook_config } = userData;
    const { headers = {} } = hook_config;
    return post({ url: hook_config.url, data, config: { headers } }).catch(
      async (err) => {
        console.log(err);
        await create({
          response: err,
          backend_user_id,
          data,
          status: 'failed',
        });
      },
    );
  }
};
