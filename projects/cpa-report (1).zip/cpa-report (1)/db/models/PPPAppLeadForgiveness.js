"use strict";

// Import module for mongo-db conection
const db = require("../db");
const conn = new db.connectionFactory(
    process.env.MONGO_SERVICE_SBA_DB_URL,
    "forgiveness_app_lead",
    "./schemas/PPPAppLeadForgivenessSchema"
);
var ObjectId = require("mongoose").Types.ObjectId;
const request_collection_name = "forgiveness_app_lead";

module.exports = {
    find: async function (json_data) {
        return new Promise(async function (resolve, reject) {
            try {
                let Collection = conn.model(request_collection_name);

                await Collection.find(json_data, function (err, data) {
                    // return document data
                    if (!err) return resolve(data);
                    // return error
                    else return reject(err);
                });
            } catch (error) {
                return reject(error);
            }
        });
    },
    getAggregate: async function (json_data) {
        return new Promise(async function (resolve, reject) {
          try {
            let Collection = conn.model(request_collection_name);
    
            await Collection.aggregate(json_data, function (err, data) {
              // return document data
              if (!err) return resolve(data);
              // return error
              else return reject(err);
            });
          } catch (error) {
            return reject(error);
          }
        });
    },
};
