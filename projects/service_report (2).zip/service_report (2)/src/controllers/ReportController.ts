import { Request, Response, NextFunction } from 'express';
import { UserModelConfig } from '../db/models/UserModelConfig';
import { CaseModelConfig } from '../db/models/CaseModelConfig';
import moment from 'moment';

export default class ReportController {

  static async getUptime(req:Request,res:Response,next:NextFunction){
    try {
      let uptimeOfApp;
      //  res.status(200).send([]);
      const upTimeFormat = function format(seconds: any){
        function pad(s: Number){
          return (s < 10 ? '0' : '') + s;
        }
        var hours = Math.floor(seconds / (60*60));
        var minutes = Math.floor(seconds % (60*60) / 60);
        var seconds: any = Math.floor(seconds % 60);
      
        return pad(hours) + ':' + pad(minutes) + ':' + pad(seconds);
      }
      
      var uptime = upTimeFormat(process.uptime());
      res.status(200).send({'Service':'Active', 'Uptime':uptime});
    } catch (error) {
      throw error
    }
  }

  static async getCallingAgentReport(req: Request, res: Response, next: NextFunction) {
    try {
      
    const BackendUserModel = new UserModelConfig('backend_users'); 
    const CaseModel = new CaseModelConfig('cases');
    const AssignmentModel = new CaseModelConfig('assignments');
    const PtpModel = new CaseModelConfig('ptps');
    const PaymentModel = new CaseModelConfig('payments');
    const ExceptionModel = new CaseModelConfig('exceptions');
    const DisputeModel = new CaseModelConfig('disputes');

    const now = moment();
    const start_date = now.startOf('day').valueOf();
    const end_date = now.endOf('day').valueOf();

    const callingAgents = await BackendUserModel.aggregate([
      {
        $match: {
          delete: { $ne: true },
          user_type: 'agent',
          'data.agent_type': '626a68e49b78643044d3237a'
        },
      },
      {
        $project: {
          name: 1,
          record_id:1
        }
      }
      
    ]);

    const finalReportData: any[] = [];

    const agentIdMap: any = {};
    const caseIdMap: any = {};
    const caseIds: any = [];
    const agentIds: string[] = [];
    const agentCasesCount: any = {};
    const agentPtpCount: any = {};
    const agentPaymentCount: any = {};
    const agentDisputeCount: any = {};
    const agentExceptionCount: any = {};

    const caseIdAgentIdMap: any = {};


    callingAgents.forEach((agent: any) => {
      agentIds.push(agent._id.toString());
      agentIdMap[agent._id] = agent;
    });

    const assignments = await AssignmentModel.aggregate([
      {
        $match: {
          assigned_to: { $in: agentIds }
        }
      },
      {
        $group: {
          _id: '$case_id',
          assignments: { $addToSet: { assigned_to: '$assigned_to', case_id: '$case_id', assigned_by: '$assigned_by' } }
        }
      },
      {
        $unwind: '$assignments'
      }
    ]);

    assignments.forEach((assignment: any) => {
      caseIds.push(assignment.assignments.case_id);
      agentCasesCount[assignment.assignments.assigned_to] = (agentCasesCount[assignment.assignments.assigned_to] || 0) + 1;
      caseIdAgentIdMap[assignment.assignments.case_id] =  assignment.assignments.assigned_to;
    });


    const ptps = await PtpModel.aggregate([
      {
        $match: {
          delete: { $ne: true },
          case_id: { $in: caseIds },

          // created_at: { $gte: start_date, $lte: end_date  }
        },
      },
      {
        $group: {
          _id: '$case_id',
          total: { $sum: 1 }
        }
      }
    ]);

    const payments = await PaymentModel.aggregate([
      {
        $match: {
          delete: { $ne: true },
          case_id: { $in: caseIds },

          // created_at: { $gte: start_date, $lte: end_date  }
        },
      },
      {
        $group: {
          _id: '$case_id',
          total: { $sum: 1 }
        }
      }
    ]);

    const exceptions = await ExceptionModel.aggregate([
      {
        $match: {
          delete: { $ne: true },
          case_id: { $in: caseIds },

          // created_at: { $gte: start_date, $lte: end_date  }
        },
      },
      {
        $group: {
          _id: '$case_id',
          total: { $sum: 1 }
        }
      }
    ]);

    const disputes = await DisputeModel.aggregate([
      {
        $match: {
          delete: { $ne: true },
          case_id: { $in: caseIds },

          // created_at: { $gte: start_date, $lte: end_date  }
        },
      },
      {
        $group: {
          _id: '$case_id',
          total: { $sum: 1 }
        }
      }
    ]);

    ptps.forEach((item: any) => {
      agentPtpCount[item._id] = item;
    });
    payments.forEach((item: any) => {
      agentPaymentCount[item._id] = item;
    });
    disputes.forEach((item: any) => {
      agentDisputeCount[item._id] = item;
    });
    exceptions.forEach((item: any) => {
      agentExceptionCount[item._id] = item;
    });

    /* creating report data */
    // loop will run on agent, not on case id
    caseIds.forEach((id: string) => {
      const reportDataRow: any = {};

      const agentId = caseIdAgentIdMap[id];

      const agent = agentIdMap[agentId];

      const agentPTP = agentPtpCount[id];
      const agentPayment = agentPaymentCount[id];
      const agentException = agentExceptionCount[id];
      const agentDispute= agentDisputeCount[id];

      const caseCount  = agentCasesCount[agentId];

      reportDataRow.agent_name = agent.name;
      reportDataRow.agent_id = agent.record_id;
      reportDataRow.case_count = caseCount;
      reportDataRow.ptp_count = agentPTP;
      reportDataRow.payment_count = agentPayment;
      reportDataRow.exception_count = agentException;
      reportDataRow.dispute_count = agentDispute;

      finalReportData.push(reportDataRow);
    });


    return res.send(finalReportData);
    } catch(err) {
      console.log(err);
      return res.send(err)
    }
  }


}
