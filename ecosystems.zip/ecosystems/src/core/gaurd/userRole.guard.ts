import {
  Injectable,
  CanActivate,
  ExecutionContext,
  ForbiddenException,
} from '@nestjs/common';
import { Observable } from 'rxjs';

import { config } from '../../config/constant.config';

@Injectable()
export class UserRoleGuard implements CanActivate {
  constructor() {}

  canActivate(
    context: ExecutionContext,
  ): boolean | Promise<boolean> | Observable<boolean> {
    const request = context.switchToHttp().getRequest();
    return this.validateRequest(request);
  }

  async validateRequest(request: any) {
    try {
      return request.headers['access-key'] === config['ACCESS_KEY']
        ? true
        : false;
    } catch (error) {
      throw new ForbiddenException(error);
    }
  }
}
