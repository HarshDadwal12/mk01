import * as mongoose from 'mongoose';

import { config } from '../config/constant.config';

export const databaseProviders = [
  {
    provide: 'DATABASE_CONNECTION',
    useFactory: async (): Promise<void> => {
      return mongoose
        .connect(config.MONGO_URL)
        .then(() => {
          console.log('Database connect', config.MONGO_URL);
        })
        .catch((error) => {
          throw error;
        });
    },
  },
];
