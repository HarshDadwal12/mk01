require("dotenv").config();
const dbMaster = require('../config/mysql.js');
const fs = require('fs');
const appRoot = require("app-root-path");
const path = require("path");

var b2c = {

    /**
      * Replica connection
      */
    replicaConnection: function () {
        return new Promise(async function (resolve, reject) {
            dbMaster.poolReplica.getConnection(function (err, connection) {
                if (err) {
                    console.log(err);
                    reject(err);
                } else {
                    resolve(connection);
                }
            });
        });
    },
    
    getReportData: async function (title, attribute) {
        return new Promise(async function (resolve, reject) {
            try {
                // connect database
                let con = await b2c.replicaConnection();
                
                let dir = appRoot.resolve("models");
                fileName = 'sql_query.sql';
                let filePath = path.resolve(dir+"/" +fileName);
                let sql_query = fs.readFileSync(filePath).toString();
                let sql = sql_query;
                
                console.log(sql);
                
                con.query(sql, function (err, result) {
                    con.release();
                    if (err) {
                        reject(err);
                    } else {
                        resolve(result);
                    }
                });
            } catch (err) {
                reject(err);
            }
        }).catch(function (err) {
            throw err;
        });
    },

};
module.exports = b2c;