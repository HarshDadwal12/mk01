const mongoose = require("mongoose");
const collections = require("../config/collections.config");
const Schema = mongoose.Schema;

const DocumentVisibilitySchema = new Schema(
	{
		doc_data: [
			{
				doc_type_key: {
					type: String,
					require:true
				},
				value: {
					type: String,
					require:true
				},
				comment: {
					type: String
				},
				due_date: {
					type: Date
				},
				owner_ids: {
					type: Array
				}
			},
		],
	},
	{
		timestamps: true,
	}
);
DocumentVisibilitySchema.methods.toJSON = function (){
    return {
      id:this._id,
      doc_data:this.doc_data,
    }
}

module.exports = {
	schema: DocumentVisibilitySchema,
	name: collections.document_visibility,
};