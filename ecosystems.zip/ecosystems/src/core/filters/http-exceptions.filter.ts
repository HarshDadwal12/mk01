import { ArgumentsHost, Catch } from '@nestjs/common';
import { BaseExceptionFilter } from '@nestjs/core';

import { HttpResponse } from '../../config/http-response';
import { CommonService } from '../services/common.service';
import { IErrorResponse } from '../types';

/**
 * Global exception handler. Catches and transforms error response.
 */
@Catch()
export class HttpExceptionFilter extends BaseExceptionFilter {
  constructor(private readonly commonService: CommonService) {
    super();
  }

  catch(ex: any, host: ArgumentsHost): void {
    console.log(ex);
    console.log('in catch error ----');
    
    
    const ctx = host.switchToHttp();
    const response = ctx.getResponse();
    const request = ctx.getRequest();
    const message = (ex?.response?.message || ex?.message) ?? '';
    const payload: IErrorResponse<any> = {
      ...HttpResponse[ex?.status ?? 500],
      errors: Array.isArray(message) ? message : [message],
    };
    request.response = payload;
    payload.correlation_id = this.commonService.requestLog(request);
    console.log('payload---',payload);
    
    return response.status(payload.code).send(payload);
  }
  
}
