require("dotenv").config();
const datetime = require("node-datetime");
const b2c = require("../models/b2c");
const mailer = require("../lib/mail");
const fastcsv = require("fast-csv");
const fs = require("graceful-fs");
const appRoot = require("app-root-path");
const path = require("path");
const { Parser } = require("json2csv");
const awsS3 = require("../lib/awsS3");

mkdirp = function (directory) {
	if (!path.isAbsolute(directory)) return;
	let parent = path.join(directory, "..");
	if (parent !== path.join("/") && !fs.existsSync(parent)) mkdirp(parent);
	if (!fs.existsSync(directory)) fs.mkdirSync(directory);
};

exports.createReport = async function () {
	return new Promise(async function (resolve, reject) {
		try {
			let data = await b2c.getReportData();
			if (data && data.length > 0) {
				const jsonData = JSON.parse(JSON.stringify(data));
				let dt = datetime.create();
				let cDateTime = dt.format("Y-m-d H:M:S");
				let dir = appRoot.resolve("temp_upload");
				let fileName = "ppp-bank-info-report.csv";

				let filePath = path.resolve("/tmp/" + fileName);

				//mkdirp(dir);

				const ws = fs.createWriteStream(filePath);

				fastcsv
					.write(jsonData, { headers: true })
					.on("finish", function () {})
					.pipe(ws);

				let attachments = [
					{
						filename:
							"ppp-bank-info-report-" +
							cDateTime.replace(/:/g, "_") +
							"-UTC.csv",
						path: filePath,
					},
				];

				let mailData = {
					from_email: process.env.EMAIL_FROM,
					to_email: process.env.EMAIL_TO,
					subject: "PPP Bank Info report created at " + cDateTime + " UTC",
					text: "PFA is the report",
					attachments: attachments,
				};
				if (process.env.CC_EMAIL != undefined && process.env.CC_EMAIL != "") {
					mailData["cc"] = process.env.CC_EMAIL;
				}
				let notification = await mailer.mailSender(mailData);

				fs.unlink(filePath, function (err) {
					if (err) {
						reject(err);
					}
				});

				if (notification) {
					resolve("Mail has been send successfully");
				} else {
					throw new Error("Mail has not been sent");
				}
			} else {
				throw new Error("Data not Found");
			}
		} catch (error) {
			reject(error);
		}
	}).catch(function (error) {
		console.log(error);
		throw error;
	});
};
exports.createACHRejectionReport = async function () {
	return new Promise(async function (resolve, reject) {
		try {
			let mailData = "";
			let filePath = "";
			let finalData = [];

			// Subject date
			let subjectDt = datetime.create();
			subjectDt.offsetInDays(-1);
			let subjectDate = subjectDt.format("Ymd");

			const fields = [
				"Business Name",
				"Email ID",
				"Case ID",
				"Wired / ACH'ed Date",
				"Rejection Reason",
				"Dollar Amount",
				"Bank Name funds sent to",
				"Account number",
				"Routing number",
			];

			const opts = { fields };
			const parser = new Parser(opts);

			let data = await b2c.getACHRejectionReportData();
			for (let item of data) {
				let wired_ach_date = item.wired_ach_date ? item.wired_ach_date : "";

				if (wired_ach_date !== "") {
					wired_ach_date = datetime.create(wired_ach_date);
					wired_ach_date = wired_ach_date.format("Y-m-d");
				}

				let reportData = {
					"Business Name": item.business_name ? item.business_name : "",
					"Email ID": item.email ? item.email : "",
					"Case ID": item.case_id ? item.case_id : "",
					"Wired / ACH'ed Date": wired_ach_date,
					"Rejection Reason": item.rejection_reason
						? item.rejection_reason
						: "",
					"Dollar Amount": item.dollar_amount ? item.dollar_amount : "",
					"Bank Name funds sent to": item.bank_name_funds_sent_to
						? item.bank_name_funds_sent_to
						: "",
					"Account number": item.account_number ? item.account_number : "",
					"Routing number": item.routing_number ? item.routing_number : "",
				};

				finalData.push(reportData);
			}
			if (finalData.length > 0) {
				// Convert json data into csv
				let contents = parser.parse(finalData);

				// Temporary file name
				let attach_fileName = "ach-rejection-report.csv";

				if (process.env.NODE_ENV == "local") {
					filePath = path.resolve(attach_fileName);
				} else {
					filePath = path.resolve("/tmp/" + attach_fileName);
				}

				const writeStream = fs.createWriteStream(filePath);
				writeStream.write(contents);

				writeStream.on("finish", () => {
					console.log("wrote all data to file");
				});

				writeStream.end();

				let prefixDt = datetime.create();
				prefixDt.offsetInDays(-1);
				let prefixDate = prefixDt.format("Ymd");
				let folderData = prefixDt.format("Y-m-d");
				let splitDate = folderData.split("-");
				let prefix =
					"reports/ach-rejection-report/" +
					process.env.NODE_ENV +
					"/" +
					splitDate[0] +
					"/" +
					splitDate[1];
				let fileName = prefixDate + "-ach-rejection-report-data.csv";
				let bucketName = process.env.BUCKET_NAME + "/" + prefix;

				await awsS3.createLogFile(bucketName, fileName, contents);

				let attachments = [
					{
						filename: fileName,
						path: filePath,
					},
				];

				let bodyText = "<p>Hi, PFA is the ACH Rejection Reason Report.</p>";

				mailData = {
					from_email: process.env.USER_INFO_EMAIL_FROM,
					to_email: process.env.ACH_EMAIL_TO,
					subject: "PPP ACH Rejection Report data as on " + subjectDate,
					html: bodyText,
					attachments: attachments,
				};
				if (
					process.env.USER_INFO_CC_EMAIL != undefined &&
					process.env.USER_INFO_CC_EMAIL != ""
				) {
					mailData["cc"] = process.env.USER_INFO_CC_EMAIL;
				}
			} else {
				mailData = {
					from_email: process.env.USER_INFO_EMAIL_FROM,
					to_email: process.env.ACH_EMAIL_TO,
					subject: "PPP ACH Rejection Report data as on " + subjectDate,
					text: "Hi, No data was found",
				};
				if (
					process.env.USER_INFO_CC_EMAIL != undefined &&
					process.env.USER_INFO_CC_EMAIL != ""
				) {
					mailData["cc"] = process.env.USER_INFO_CC_EMAIL;
				}
			}

			let notification = await mailer.mailSender(mailData);

			fs.unlink(filePath, function (err) {
				if (err) {
					reject(err);
				}
			});

			if (notification) {
				resolve(notification);
			} else {
				throw new Error("Mail not sent");
			}
		} catch (error) {
			reject(error);
		}
	}).catch(function (error) {
		throw error;
	});
};
