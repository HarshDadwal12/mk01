'use strict';

const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const zipSchema = new Schema(
  {
    app_id: {
      type: String,
    },
  },
  { strict: false, timestamps: true },
);
module.exports = zipSchema;
