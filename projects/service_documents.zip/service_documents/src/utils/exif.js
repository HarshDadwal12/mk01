const arrayBufferToBuffer = require('arraybuffer-to-buffer');

module.exports = function (data) {
	const pieces = [];
	var arrayBuffer = new Uint8Array(data).buffer;
	const dv = new DataView(arrayBuffer);
	let offset = 0,
		recess = 0;
	let i = 0;
	// jpeg magic bytes 0xffd8
	if (dv.getUint16(offset) == 0xffd8) {
		offset += 2;
		let app1 = dv.getUint16(offset);
		offset += 2;
		while (offset < dv.byteLength) {
			if (app1 == 0xffe1) {
				pieces[i] = { recess: recess, offset: offset - 2 };
				recess = offset + dv.getUint16(offset);
				i++;
			} else if (app1 == 0xffda) {
				break;
			}
			offset += dv.getUint16(offset);
			app1 = dv.getUint16(offset);
			offset += 2;
		}

		if (pieces.length > 0) {
			const newPieces = [];
			pieces.forEach(function (v) {
				newPieces.push(arrayBufferToBuffer(arrayBuffer.slice(v.recess, v.offset)));
			}, this);
			newPieces.push(arrayBufferToBuffer(arrayBuffer.slice(recess)));
			return Buffer.concat(newPieces);
		}
	}
  return data
};