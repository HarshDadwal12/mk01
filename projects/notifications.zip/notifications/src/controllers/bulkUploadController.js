'use strict';

const { bulk_upload_logs } = require('../..');
const { xlsxParse } = require('../client/excelParser');
const { find } = require('../db/models/bulkLoggerModel');
const { getDocument, createData } = require('../utils/bulkUtil');
const { bulkLog } = require('../utils/helper');

module.exports.processData = async function (body) {
  try {
    const { doc_id ,records_in_db = false} = body;
    if(!records_in_db){
      const doc = await getDocument(doc_id).catch(async (error) => {
        console.log('================>', error);
        await bulkLog({
          ...body,
          error,
          type: 'doc',
          docType: body.type,
          status: 'failed',
        });
      });
      await xlsxParse(doc.body,body);
    } else {
      await createData(body);
    }
  } catch (error) {
    throw error;
  }
};

module.exports.getBulkUploadLog = async function (query) {
  const { limit, start, ...condition } = query;
  return find(condition, limit, start);
};
