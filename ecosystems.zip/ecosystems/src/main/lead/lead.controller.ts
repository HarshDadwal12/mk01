import {
  BadRequestException,
  Body,
  Controller,
  Get,
  Param,
  Post,
  Put,
  Req,
  UseGuards,
} from '@nestjs/common';
import { AuthGuard } from '../../core/gaurd/auth.gaurd';
import { LeadDto, GetLeadDto, leadStatusDto,GetProfileDto } from './dto/lead.dto';

import { LeadService } from './lead.service';

@Controller({
  version: '1.0',
})
@UseGuards(AuthGuard)
export class LeadController {
  constructor(private leadService: LeadService) {}

  @Post()
  async postLead(@Req() req: any, @Body() body: LeadDto) {
    try {
      const data = await this.leadService.createLead(req.user, body);
      console.log('lead data----',data);
      
      return {
        data: data,
        filter: true,
        key: 'lead_created',
        hook: true,
        event: 'lead.created',
      };
    } catch (error) {
      throw error;
    }
  }

  @Get(':lead_id')
  async getLead(@Param() params: GetLeadDto) {
    try {
      const data = await this.leadService.getLead(params);
      console.log('in lead get--',data);
      
      return {
        data: data.result,
        filter: true,
        key: 'lead_get',
      };
    } catch (error) {
      throw error;
    }
  }

  @Put('status/:lead_id')
  async changeLeadStatus(
    @Body() body: leadStatusDto,
    @Param('lead_id') lead_id: string,
    @Req() req: any,
  ) {
    try {
      if (body.product_opportunity_id) {
        const isValidProduct = await this.leadService.checkProduct(
          body.product_opportunity_id,
          req.user.products,
        );
        if (!isValidProduct)
          throw new BadRequestException('invalid product_opportunity_id');
      }

      const data = await this.leadService.updateLeadStatus(body, lead_id);
      return {
        data: data,
        filter: true,
        key: 'lead_update',
        hook: true,
        event: 'lead.status.update',
      };
    } catch (error) {
      throw error;
    }
  }

  @Get('summary/:lead_id')
  async getProfile(@Param() params: GetProfileDto) {
    try {
      const data = await this.leadService.getProfile(params);
      return {
        data,
        filter: true,
        key: 'profile_get',
      };
    } catch (error) {
      throw error;
    }
  }
}
