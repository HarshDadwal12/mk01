import {
  BadRequestException,
  Body,
  Controller,
  Post,
  Req,
} from '@nestjs/common';
import { TestNotificationsService } from './test_notifications.service';

@Controller()
export class TestNotificationsController {
  constructor(private testNotificationService: TestNotificationsService) {}

  @Post('aggregator')
  async processAggregatorNotification(@Req() req: any, @Body() body: any) {
    try {
      const result = await this.testNotificationService.createNotifications(
        "aggregator_notification",
        body,
      );

      return {
        data: result,
        success : true,
        message : "Notification Created"
      };
    } catch (error) {
      throw error;
    }
  }

  @Post('lender')
  async processLenderNotification(@Req() req: any, @Body() body: any) {
    try {
      const result = await this.testNotificationService.createNotifications(
        "lender_notification",
        body,
      );

      return {
        data: result,
        success : true,
        message : "Notification Created"
      };
    } catch (error) {
      throw error;
    }
  }
}
