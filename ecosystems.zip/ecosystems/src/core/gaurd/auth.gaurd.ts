import {
  Injectable,
  CanActivate,
  ExecutionContext,
  ForbiddenException,
} from '@nestjs/common';
import { Observable } from 'rxjs';

import { CryptoService } from 'src/core/services/cypto.service';
import { JwtService } from 'src/core/services/jwt.service';
import { QueryService } from 'src/core/services/query.service';
import customerInfoModel from '../../database/models/user.model';
import roleInfoModel from '../../database/models/role.model';
import { config } from '../../config/constant.config';

@Injectable()
export class AuthGuard implements CanActivate {
  constructor(
    private jwtService: JwtService,
    private queryService: QueryService,
    private cryptoService: CryptoService,
  ) {}

  canActivate(
    context: ExecutionContext,
  ): boolean | Promise<boolean> | Observable<boolean> {
    const request = context.switchToHttp().getRequest();
    return this.validateRequest(request);
  }

  async validateRequest(request: any) {
    try {
      let condition: any = { is_active: true };
      // bypass when call from any internal service
      if (request.headers['internal']) {
        if (request.headers['access-key'] !== config['ACCESS_KEY']) {
          return false;
        }
        condition.backend_user_id = request.headers?.['backend-user-id'];
      } else {
        if (!request.headers.authorization) return false;
        const token = request.headers.authorization.split(' ')[1];

        const data = await this.jwtService.verifyToken(
          this.cryptoService.decrypt(token),
        );

        condition._id = data.sub;
      }

      const user = await this.queryService.findOne({
        modelName: customerInfoModel,
        condition,
      });

      if (!user) return false;

      const pathArr = request.routerPath;
      const role = await this.queryService.findOne({
        modelName: roleInfoModel,
        condition: {
          user_id: user._id.toString(),
          path: pathArr,
          method: request.method,
        },
      });

      if (!role) return false;
      request.user = user;
      return true;
    } catch (error) {
      throw new ForbiddenException(error);
    }
  }
}
