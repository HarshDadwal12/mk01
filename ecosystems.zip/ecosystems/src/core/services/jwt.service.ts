import { Injectable } from '@nestjs/common';
import { JwtService as JWT } from '@nestjs/jwt';

import { config } from 'src/config/constant.config';

@Injectable()
export class JwtService {
  constructor(private jwtService: JWT) {}

  async getTokens(userId: string): Promise<{ access_token: string }> {
    const jwtPayload = {
      sub: userId,
    };

    const access_token = await this.jwtService.signAsync(jwtPayload, {
      secret: config.ACCESS_TOKEN_SECRET,
      expiresIn: config.ACCESS_TOKEN_EXPIRY_TIME,
    });
    return { access_token };
  }

  async verifyToken(token: string): Promise<any> {
    try {
      return await this.jwtService.verifyAsync(token, {
        secret: config.ACCESS_TOKEN_SECRET,
      });
    } catch (error) {
      throw error;
    }
  }
}
