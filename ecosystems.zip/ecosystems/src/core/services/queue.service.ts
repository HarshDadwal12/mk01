import { Inject, Injectable } from '@nestjs/common';
import { SendMessageCommand } from '@aws-sdk/client-sqs';
import { nanoid } from 'nanoid';
import { config } from 'src/config/constant.config';
import { QueueInterface } from '../types/queue';

@Injectable()
export class QueueService {
  constructor(@Inject('QUEUE') private queueClient: QueueInterface) {}

  sendMessage(queue_data: Record<string, any>) {
    const params: any = {
      QueueUrl: config.QUEUE_URL,
      MessageBody: JSON.stringify(queue_data),
      MessageGroupId: nanoid(30),
    };
    return this.queueClient.client.send(new SendMessageCommand(params));
  }
}
