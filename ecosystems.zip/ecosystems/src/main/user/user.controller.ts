import {
  Controller,
  Post,
  Body,
  UseGuards,
  Put,
  Param,
  Get,
  Query,
  Patch,
  NotFoundException,
  UsePipes,
  ValidationPipe,
  Delete,
} from '@nestjs/common';
import { RoleDtoUpdate, UserRoleDto } from './dto/role.dto';
import { UserDto, UpdateUserDto} from './dto/user.dto';
import { UserRoleGuard } from '../../core/gaurd/userRole.guard';
import { GetUserMappingDto, routeInfoDto, UserMappingDto } from './dto/user-mapping.dto';
import { UserService } from './user.service';

@Controller({
  version: '1.0',
})
@UseGuards(UserRoleGuard)
export class UserController {
  constructor(private userService: UserService) {}

  @Post('')
  async createUser(@Body() body: UserDto) {
    try {
      const data = await this.userService.createUser(body);
      return { data };
    } catch (error) {
      error.message =
        error.code == 11000
          ? 'User with customer_key or username already exists.'
          : error.message;
      throw error;
    }
  }

  @Get('')
  async getUser(@Query() query: any) {
    try {
      const data = await this.userService.getUser(query);
      return { data };
    } catch (error) {
      throw error;
    }
  }

  @Get('routes')
  async getRoutesInfo(@Query() query:routeInfoDto) {
    try {
      const data=this.userService.getRoutes(query);
      return { data };
    } catch (error) {
      throw error;
    }
  }

  @Patch('/:id')
  async updateUser(@Body() body: UpdateUserDto, @Param('id') id: string) {
    try {
      const data = await this.userService.updateUserPatch(body, id);
      return { data };
    } catch (error) {
      throw error;
    }
  }

  @Post('role')
  async createUserRole(@Body() body: UserRoleDto) {
    try {
      let res = [];
      for (let role of body.roles) {
        const data = await this.userService.createRole(role);
        res.push(data);
      }
      return { data: res };
    } catch (error) {
      throw error;
    }
  }

  @Get('role/:user_id')
  async getUserRole(@Param('user_id') user_id: string) {
    try {
      const data = await this.userService.getRole(user_id);
      return { data };
    } catch (error) {
      throw error;
    }
  }

  @Put('role/:id')
  async updateUserRole(
    @Body() body: RoleDtoUpdate,
    @Param('id') role_id: string,
  ) {
    try {
      const data = await this.userService.updateRole(body, role_id);
      return { data };
    } catch (error) {
      throw error;
    }
  }

  @Delete('role/:id')
  async deleteUserRole(
    @Param('id') role_id: string,
    @Query("multiple") multiple : boolean
  ) {
    try {
      const data = await this.userService.deleteRole(role_id ,multiple);
      return { data };
    } catch (error) {
      throw error;
    }
  }
          
  @Get('user-mapping')
  async getUserMapping(@Query() query: GetUserMappingDto) {
    try {
      const user_id = query.user_id;
      const data = await this.userService.getUserMapping(user_id);
      return { data };
    } catch (error) {
      throw error;
    }
  }

  @Post('user-mapping')
  @UsePipes(new ValidationPipe({ whitelist: true, forbidNonWhitelisted: true }))
  async createUserMapping(@Body() body: UserMappingDto , @Query('user_id') user_id : any) {
    try {
      let data;
      if(user_id) data = await this.userService.saveUserMapping(body,user_id)
      else data = await this.userService.saveUserMapping(body) 
      return { data };
    } catch (error) {
      throw error;
    }
  }

  @Put('user-mapping/:id')
  async updateUserMapping(
    @Body() body: UserMappingDto,
    @Param('id') id: string,
  ) {
    try {
      const data = await this.userService.updateUserMapping(body, id);
      return { data };
    } catch (error) {
      throw error;
    }
  }
}
