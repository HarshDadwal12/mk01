const db = require('../db/models/zip.model');

module.exports.create = async (app_id, upload_data) => {
  const { Key } = upload_data;
  const doc = {
    app_id,
    Key,
  };
  return db.create(doc);
};
