"use strict";

require("dotenv").config();
const datetime = require("node-datetime");
const momentTz = require("moment-timezone");
const mailer = require("../lib/mail");
const helper = require("../lib/helper");
const awsS3 = require("../lib/awsS3");
const { Parser } = require("json2csv");
const fastcsv = require("fast-csv");
const fs = require("graceful-fs");
const appRoot = require("app-root-path");
const path = require("path");
const backendUser = require("../db/models/backendUser");
const application = require("../db/models/application");
const appStatus = require("../db/models/appStatus");
const deviceDetector = require("node-device-detector");
const businessInfo = require("../db/models/businessInfo");

exports.getPPPAICPAReport = async function () {
    return new Promise(async function (resolve, reject) {
        try {
            let mailData = "";
            let filePath = "";

            let cpaUsers = [];
            let cpaApplication = [];
            let finalData = [];
            const detector = new deviceDetector();

            // Set header of the csv
            const fields = [
                "Email",
                "First Name",
                "Last Name",
                "Phone",
                "Register Date",
                "AICPA member number",
                "CPA Firm Name",
                "Number of applications initiated",
                "Number of applications completed",
                "Total amount of completed application"
            ];

            const opts = { fields };
            const parser = new Parser(opts);

            // Get start time
            let pastStartDt = datetime.create();
            pastStartDt.offsetInDays(-7);
            pastStartDt = pastStartDt.format("Y-m-d");
            let startDt = datetime.create(pastStartDt);
            let startTime = startDt.epoch();

            // Get End time
            let pastEndDt = datetime.create();
            pastEndDt = pastEndDt.format("Y-m-d");
            let endDt = datetime.create(pastEndDt);
            //endDt.offsetInDays(-1);
            let endTime = endDt.epoch();

            // Subject date
            let subjectDt = datetime.create();
            subjectDt.offsetInDays(-1);
            let subjectDate = subjectDt.format("Ymd");

            // Fetch record from cpa user data collection according to time

            let cpaUserData = await backendUser.find({
                $and: [
                    { created_at: { $lt: endTime } },
                    { created_at: { $gte: startTime } },
                    { email_address: { $not: /^.*@(b2cdev|biz2credit)\.([a-zA-Z\.]{2,})/ } },
                    { email_address: { $ne: null } }
                ]
            });

            if (cpaUserData.length > 0) {
                cpaUserData = JSON.parse(JSON.stringify(cpaUserData));
                for (var item in cpaUserData) {

                    let registerDate = new Date(cpaUserData[item].created_at * 1000);
                    let registerDt = datetime.create(registerDate);
                    let createdDate = registerDt.format("m/d/Y");

                    let firstName = "";
                    let lastName = "";

                    if (
                        cpaUserData[item].name == undefined ||
                        cpaUserData[item].name == ""
                    ) {
                        firstName = "";
                        lastName = "";
                    } else {
                        var fullname = cpaUserData[item].name.split(" ");

                        if (!fullname || fullname.length <= 1) {
                            //firstName = fullname.slice(0, -1).join(" ");
                            firstName = fullname[0];
                            lastName = "";
                        } else {
                            firstName = fullname.slice(0, -1).join(" ");
                            lastName = fullname.slice(-1).join(" ");
                        }
                    }

                    let data = {
                        lead_id: cpaUserData[item]._id.toString(),
                        email: cpaUserData[item].email_address,
                        'first_name': firstName,
                        'last_name': lastName,
                        created_at: createdDate,

                        registration_code:
                            cpaUserData[item].registration_code == undefined ||
                                cpaUserData[item].registration_code == null ||
                                cpaUserData[item].registration_code == ""
                                ? ""
                                : cpaUserData[item].registration_code,
                        app_id: "",
                        status_id: "",
                    };

                    if (cpaUserData[item].data == undefined
                        || cpaUserData[item].data == null
                        || cpaUserData[item].data == "") {

                        data["cpa_firm_name"] = "";
                    } else {

                        let cpaFirmdata = cpaUserData[item].data;

                        data["cpa_firm_name"] = cpaFirmdata.cpa_firm_name == undefined ||
                            cpaFirmdata.cpa_firm_name == null ||
                            cpaFirmdata.cpa_firm_name == ""
                            ? ""
                            : cpaFirmdata.cpa_firm_name;
                    }

                    if (
                        cpaUserData[item].phone_number == undefined ||
                        isNaN(cpaUserData[item].phone_number)
                    ) {
                        data["phone"] = "";
                    } else {
                        data["phone"] =
                            isNaN(cpaUserData[item].phone_number) ||
                                cpaUserData[item].phone_number == null ||
                                cpaUserData[item].phone_number == ""
                                ? ""
                                : parseInt(cpaUserData[item].phone_number);
                    }


                    cpaUsers.push(data);
                }
            }

            if (cpaUsers.length > 0) {
                for (var item in cpaUsers) {
                    let cpaApp = {}
                    cpaApp['lead_id'] = cpaUsers[item].lead_id;
                    cpaApp['email'] = cpaUsers[item].email;
                    cpaApp['first_name'] = cpaUsers[item].first_name;
                    cpaApp['last_name'] = cpaUsers[item].last_name;
                    cpaApp['phone'] = cpaUsers[item].phone;
                    cpaApp['created_at'] = cpaUsers[item].created_at;
                    cpaApp["cpa_firm_name"] =
                        cpaUsers[item].cpa_firm_name;
                    cpaApp["registration_code"] =
                        cpaUsers[item].registration_code;


                    let appData = await application.find({
                        backend_user_id: cpaUsers[item].lead_id,
                    });

                    let appDataArr = [];

                    if (appData.length > 0) {
                        appData = JSON.parse(JSON.stringify(appData));
                        for (var item in appData) {
                            let cpaData = {}
                            cpaData['app_id'] = appData[item]._id.toString();
                            cpaData['status_id'] = appData[item].status_id;
                            appDataArr.push(cpaData);
                        }
                    }
                    cpaApp['app_data'] = appDataArr;
                    cpaApplication.push(cpaApp);
                }
            }

            if (cpaApplication.length > 0) {

                for (var item in cpaApplication) {

                    let cpaAppData = {
                        Email: cpaApplication[item].email,
                        "First Name": cpaApplication[item].first_name,
                        "Last Name": cpaApplication[item].last_name,
                        "Phone": cpaApplication[item].phone,
                        "Register Date": cpaApplication[item].created_at,
                        "AICPA member number": cpaApplication[item].registration_code,
                        "CPA Firm Name": cpaApplication[item].cpa_firm_name,
                    };
                    let initiated = [];
                    let submitted = [];
                    let sbLoanAmount = [];
                    var app_data = cpaApplication[item].app_data;
                    if (app_data.length > 0) {
                        for (var itm in app_data) {

                            if (app_data[itm].status_id != undefined) {
                                let appStatusData = await appStatus.findByStatusId(app_data[itm].status_id);

                                if (appStatusData != null) {
                                    appStatusData = JSON.parse(JSON.stringify(appStatusData));
                                    if (appStatusData["value"] == "Submitted") {
                                        submitted.push("Submitted");

                                        if (app_data[itm].app_id != undefined) {
                                            let businessData = await businessInfo.findOne({
                                                app_id: app_data[itm].app_id,
                                            });
                                            if (businessData != null) {
                                                businessData = JSON.parse(JSON.stringify(businessData));
                                                if (businessData["sba_ppp_loan_amount"] == undefined
                                                    || businessData["sba_ppp_loan_amount"] == null || businessData["sba_ppp_loan_amount"] == "") {
                                                    sbLoanAmount.push(0.00);
                                                } else {
                                                    sbLoanAmount.push(parseFloat(businessData["sba_ppp_loan_amount"]));
                                                }
                                            }
                                        } else {
                                            sbLoanAmount.push(0.00);
                                        }

                                    } else {
                                        initiated.push("New");
                                    }
                                }
                            } else {
                                initiated.push("New");
                            }


                        }

                    }

                    let sumOfSBAAmt = sbLoanAmount.reduce(function (a, b) {
                        return a + b;
                    }, 0);
                    cpaAppData['Number of applications initiated'] = initiated.length;
                    cpaAppData['Number of applications completed'] = submitted.length;
                    cpaAppData['Total amount of completed application'] = sumOfSBAAmt;
                    finalData.push(cpaAppData);
                }
            }

            if (finalData.length > 0) {
                // Convert json data into csv
                let contents = parser.parse(finalData);

                // Temporary file name
                let attach_fileName = "aicpa-report.csv";

                if (process.env.NODE_ENV == "local") {
                    filePath = path.resolve(attach_fileName);
                } else {
                    filePath = path.resolve("/tmp/" + attach_fileName);
                }

                const writeStream = fs.createWriteStream(filePath);
                writeStream.write(contents);

                writeStream.on("finish", () => {
                    console.log("wrote all data to file");
                });

                writeStream.end();

                let prefixDt = datetime.create();
                prefixDt.offsetInDays(-1);
                let prefixDate = prefixDt.format("Ymd");
                let folderData = prefixDt.format("Y-m-d");
                let splitDate = folderData.split("-");
                let prefix =
                    "reports/aicpa-report/" +
                    process.env.NODE_ENV +
                    "/" +
                    splitDate[0] +
                    "/" +
                    splitDate[1];
                let fileName = prefixDate + "-aicpa-report-cpa-data.csv";
                let bucketName = process.env.BUCKET_NAME + "/" + prefix;

                await awsS3.createLogFile(bucketName, fileName, contents);

                let attachments = [
                    {
                        filename: fileName,
                        path: filePath,
                    },
                ];

                mailData = {
                    from_email: process.env.USER_INFO_EMAIL_FROM,
                    to_email: process.env.USER_INFO_EMAIL_TO,
                    subject:
                        "PPPForgivenessTool - CPA data as on " +
                        subjectDate,
                    text: "Hi, PFA is the report.",
                    attachments: attachments,
                };
                if (
                    process.env.USER_INFO_CC_EMAIL != undefined &&
                    process.env.USER_INFO_CC_EMAIL != ""
                ) {
                    mailData["cc"] = process.env.USER_INFO_CC_EMAIL;
                }
            } else {
                mailData = {
                    from_email: process.env.USER_INFO_EMAIL_FROM,
                    to_email: process.env.USER_INFO_EMAIL_TO,
                    subject:
                        "PPPForgivenessTool - CPA data as on " +
                        subjectDate,
                    text: "Hi, No CPA data was found",
                };
                if (
                    process.env.USER_INFO_CC_EMAIL != undefined &&
                    process.env.USER_INFO_CC_EMAIL != ""
                ) {
                    mailData["cc"] = process.env.USER_INFO_CC_EMAIL;
                }
            }

            let notification = await mailer.mailSender(mailData);

            fs.unlink(filePath, function (err) {
                if (err) {
                    reject(err);
                }
            });

            if (notification) {
                resolve(notification);
            } else {
                throw new Error("Mail not sent");
            }
        } catch (error) {
            reject(error);
        }
    }).catch(function (error) {
        throw error;
    });
};