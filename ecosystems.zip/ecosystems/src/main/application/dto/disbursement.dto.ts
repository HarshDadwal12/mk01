import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  ArrayMinSize,
  IsAlpha,
  IsArray,
  IsDefined,
  IsIn,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  Matches,
  ValidateNested,
  Min,
} from 'class-validator';

export class DisbursementRequestDto {
  @IsNotEmpty()
  @IsNumber()
  @ApiProperty()
  application_id: number;

  @IsNotEmpty()
  @IsString()
  @ApiProperty()
  disbursement_unique_id: string;

  @IsNotEmpty()
  @Matches(
    /^(3[01]|[12][0-9]|0[1-9])-(1[0-2]|0[1-9])-[0-9]{4} (2[0-3]|[01]?[0-9]):([0-5]?[0-9]):([0-5]?[0-9])$/,
    {
      message: 'payment_request_timestamp should be in DD-MM-YYYY HH:mm:ss',
    },
  )
  @ApiProperty()
  'payment_request_timestamp': string;

  @IsNotEmpty()
  @IsString()
  @ApiProperty()
  'retailer_name': string;

  @IsNotEmpty()
  @IsString()
  @ApiProperty()
  'loan_account_number': string;

  @IsOptional()
  @IsNumber()
  @ApiProperty()
  'available_credit_limit': number;

  @IsNotEmpty()
  @IsNumber()
  @ApiProperty()
  'total_invoice_amount': number;

  @IsNotEmpty()
  @IsNumber()
  @ApiProperty()
  'total_payment_requested': number;

  @IsNotEmpty()
  @IsNumber()
  @ApiProperty()
  'total_invoices': number;

  @IsArray()
  @ValidateNested({ each: true })
  @ArrayMinSize(1)
  @Type(() => ReqInvoice)
  invoices: ReqInvoice[];
}

class ReqInvoice {
  @IsNotEmpty()
  @IsString()
  @ApiProperty()
  'invoice_no': string;

  @IsNotEmpty()
  @Matches(
    /^(3[01]|[12][0-9]|0[1-9])-(1[0-2]|0[1-9])-[0-9]{4} (2[0-3]|[01]?[0-9]):([0-5]?[0-9]):([0-5]?[0-9])$/,
    {
      message: 'invoice_timestamp should be in DD-MM-YYYY HH:mm:ss',
    },
  )
  @ApiProperty()
  'invoice_timestamp': string;

  @IsNotEmpty()
  @IsString()
  @ApiProperty()
  'distributor_unique_code': string;

  @IsNotEmpty()
  @IsString()
  @ApiProperty()
  'distributor_name': string;

  @IsNotEmpty()
  @IsNumber()
  @ApiProperty()
  'invoice_amount': number;

  @IsNotEmpty()
  @IsNumber()
  @ApiProperty()
  'payment_requested': number;

  @IsNotEmpty()
  @IsString()
  @ApiProperty()
  'payee_account_number': string;

  @IsNotEmpty()
  @IsAlpha()
  @ApiProperty()
  'payee_bank_name': string;

  @IsNotEmpty()
  @IsString()
  @ApiProperty()
  'payee_bank_ifsc': string;
}

export class DisbursementResponseDto {
  @IsNotEmpty()
  @IsNumber()
  @ApiProperty()
  application_id: number;

  @IsNotEmpty()
  @IsString()
  @ApiProperty()
  disbursement_unique_id: string;

  @IsNotEmpty()
  @Matches(
    /^(3[01]|[12][0-9]|0[1-9])-(1[0-2]|0[1-9])-[0-9]{4} (2[0-3]|[01]?[0-9]):([0-5]?[0-9]):([0-5]?[0-9])$/,
    {
      message:
        'disbursement_response_timestamp should be in DD-MM-YYYY HH:mm:ss',
    },
  )
  @ApiProperty()
  'disbursement_response_timestamp': string;

  @IsNotEmpty()
  @IsString()
  @ApiProperty()
  'retailer_name': string;

  @IsArray()
  @ValidateNested({ each: true })
  @ArrayMinSize(1)
  @Type(() => ResInvoice)
  invoices: ResInvoice[];

  @IsNotEmpty()
  @IsString()
  @ApiProperty()
  'loan_account_number': string;

  @IsNotEmpty()
  @IsNumber()
  @ApiProperty()
  'available_credit_limit': number;

  @IsNotEmpty()
  @IsNumber()
  @ApiProperty()
  'total_disbursement_amount': number;

  @IsNotEmpty()
  @IsNumber()
  @ApiProperty()
  'balance_credit_limit': number;

  // @IsNotEmpty()
  // @IsNumber()
  // @ApiProperty()
  // 'interest_rate': number;

  // @IsOptional()
  // @IsNumber()
  // @ApiProperty()
  // 'aggregator_interest_rate': number;

  @IsNotEmpty()
  @IsString()
  @ApiProperty()
  'transanction_id': string;

  @IsNotEmpty()
  @Matches(/^([0-2][0-9]|(3)[0-1])-(((0)[0-9])|((1)[0-2]))-\d{4}$/i, {
    message: 'due_date_without_grace must be in DD-MM-YYYY formate',
  })
  @ApiProperty()
  'due_date_without_grace': string;

  @IsOptional()
  @Matches(/^([0-2][0-9]|(3)[0-1])-(((0)[0-9])|((1)[0-2]))-\d{4}$/i, {
    message: 'final_due_date_with_grace must be in DD-MM-YYYY formate',
  })
  @ApiProperty()
  'final_due_date_with_grace': string;

  @IsOptional()
  @IsNumber()
  @ApiProperty()
  'without_grace_principal_os_as_on_due_date': number;

  @IsOptional()
  @IsNumber()
  @ApiProperty()
  'without_grace_interest_os_as_on_due_date': number;

  @IsOptional()
  @IsNumber()
  @ApiProperty()
  'without_grace_penalty_os_as_on_due_date': number;

  @IsOptional()
  @IsNumber()
  @ApiProperty()
  'without_grace_total_os_as_on_due_date': number;

  @IsOptional()
  @IsNumber()
  @ApiProperty()
  'with_grace_principal_os_as_on_due_date': number;

  @IsOptional()
  @IsNumber()
  @ApiProperty()
  'with_grace_interest_os_as_on_due_date': number;

  @IsOptional()
  @IsNumber()
  @ApiProperty()
  'with_grace_penalty_os_as_on_due_date': number;

  @IsOptional()
  @IsNumber()
  @ApiProperty()
  'with_grace_total_os_as_on_due_date': number;

  @IsOptional()
  @IsNumber()
  @ApiProperty()
  'dpd': number;
}

class ResInvoice {
  @IsNotEmpty()
  @IsString()
  @ApiProperty()
  'distributor_unique_code': string;

  @IsNotEmpty()
  @IsString()
  @ApiProperty()
  'invoice_no': string;

  @IsNotEmpty()
  @IsNumber()
  @ApiProperty()
  'payment_requested': number;

  @IsNotEmpty()
  @IsString()
  @ApiProperty()
  'payee_account_number': string;

  @IsNotEmpty()
  @Matches(/^([0-2][0-9]|(3)[0-1])-(((0)[0-9])|((1)[0-2]))-\d{4}$/i, {
    message: 'disbursed_date must be in DD-MM-YYYY formate',
  })
  @ApiProperty()
  'disbursed_date': string;

  @IsIn(['DISBURSED', 'PENDING','FAILED','PARTIALLY_DISBURSED'])
  @ApiProperty()
  'disbursement_status': string;

  @IsNotEmpty()
  @IsNumber()
  @Min(0)	
  @ApiProperty()
  'disbursement_amount': number;
}

export class DisbursementRequestReconDto {
  @IsDefined()
  @IsNotEmpty()
  @IsNumber()
  @ApiProperty()
  application_id: number;

  @IsDefined()
  @IsNotEmpty()
  @IsString()
  @ApiProperty()
  disbursement_unique_id: string;

  @IsDefined()
  @IsNotEmpty()
  @IsString()
  @ApiProperty()
  disbursement_id: string;

  @IsDefined()
  @IsNotEmpty()
  @Matches(/^([0-2][0-9]|(3)[0-1])-(((0)[0-9])|((1)[0-2]))-\d{4}$/i, {
    message: 'disbursed_date must be in DD-MM-YYYY formate',
  })
  @ApiProperty()
  disbursed_date: string;

  @IsDefined()
  @IsNotEmpty()
  @IsString()
  @IsIn(['DISBURSED', 'PENDING'])
  @ApiProperty()
  disbursement_status: string;

  @IsDefined()
  @IsNotEmpty()
  @IsNumber()
  @ApiProperty()
  total_payment_requested: number;

  @IsDefined()
  @IsNotEmpty()
  @IsString()
  @IsIn(['YES', 'NO'])
  @ApiProperty()
  subvention: string;
}

export class DisbursementResponseReconDto {
  @IsDefined()
  @IsNotEmpty()
  @IsNumber()
  @ApiProperty()
  application_id: number;

  @IsNotEmpty()
  @IsString()
  @ApiProperty()
  disbursement_unique_id: string;

  @IsDefined()
  @IsNotEmpty()
  @IsString()
  @ApiProperty()
  transanction_id: string;

  @IsDefined()
  @IsNotEmpty()
  @Matches(/^([0-2][0-9]|(3)[0-1])-(((0)[0-9])|((1)[0-2]))-\d{4}$/i, {
    message: 'disbursed_date must be in DD-MM-YYYY formate',
  })
  @ApiProperty()
  disbursed_date: string;

  @IsDefined()
  @IsNotEmpty()
  @IsString()
  @IsIn(['DISBURSED', 'PENDING'])
  @ApiProperty()
  disbursement_status: string;
}
