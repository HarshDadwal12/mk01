export class WebHookEvent {
  resData: any;
  identifier: string;
}
