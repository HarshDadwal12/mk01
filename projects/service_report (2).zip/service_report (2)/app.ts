import { Server } from './server';

class App {
    constructor() {
        this.startServer();
    }

    startServer() {
        try {
            const server = new Server();
            const { app, port } = server;
            app.listen(port, () => console.log(`server is listening on ${port}`));
        } catch (err) {
            console.log(err);
        }
    }
}

new App();