const config = require("../../config/config");

const redis = require("redis");

const Redis = class {
	
    constructor() {
		this.client = redis.createClient(config.REDIS_URL);
		this.isRedisConnect();
	}

	static getInstance() {
		if (!Redis.instance) {
			Redis.instance = new Redis();
		}
		return Redis.instance;
	}

	isRedisConnect() {
		this.client.on("connect", () => {
			this.isConnect = true;
		});
	}
};

module.exports = Redis;
