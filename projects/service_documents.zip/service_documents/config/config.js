require('dotenv').config();

// Environment credentials

module.exports = {
  VERSION: 'v1',
  MASTER_ENDPOINT: 'document_type',
  REDIS_URL:process.env.REDIS_URL,
  configUpdate: function (envConfig) {
    this.REDIS_URL = envConfig.REDIS_URL;
  }
};
