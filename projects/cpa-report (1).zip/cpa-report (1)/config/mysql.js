var mysql = require('mysql');
require("dotenv").config();
var poolMaster = mysql.createPool({
    host: process.env.MYSQL_MASTER_HOST,
    user: process.env.MYSQL_MASTER_USER,
    password: process.env.MYSQL_MASTER_PASSWORD,
    database: process.env.MYSQL_MASTER_DB,
    connectionLimit: 1000,
    supportBigNumbers: true,
    acquireTime: 10000
});
var poolReplica = mysql.createPool({
    host: process.env.MYSQL_REPLICA_HOST,
    user: process.env.MYSQL_REPLICA_USER,
    password: process.env.MYSQL_REPLICA_PASSWORD,
    database: process.env.MYSQL_REPLICA_DB,
    connectionLimit: 1000,
    supportBigNumbers: true,
    acquireTime: 10000
});
module.exports = { poolMaster: poolMaster, poolReplica: poolReplica };