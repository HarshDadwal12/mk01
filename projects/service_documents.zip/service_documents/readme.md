## All Document Service Endpoints:

  `/v1/doc/upload`,
  `/v1/doc/download/:doc_id?`,
  `/v1/doc/view/:doc_id?`,
  `/v1/doc/delete/:doc_id?`,
  `/v1/doc/get/:doc_id?`,
  `/v1/doc/data_upload`

## Upload document to s3

**URL** : `/v1/doc/upload`

**Method** : `POST`

**Header** : None 

**Auth required** : None

**Permissions required** : None

## Request Body

```formdata
{
    file : <uploaded file> (pdf file, maxsize = 20 MB)
	doc_type_id : 5c1cf2e6eb72d4c894b9c475 <mongo_id> (validated from master data, collection : document_types)
}
```

## Success Response

**Code** : `200`

**Response**

```json

{
    "status": "success",
    "code": 200,
    "data": {
        "doc_id": "5c66bc4026b40644a85acdd9",
        "filename": "AnzAf_PDF_885_3835.pdf",
        "doc_type_key": "tax_filing",
        "created_at": "2019-02-15T13:18:56.560Z",
        "updated_at": "2019-02-15T13:18:56.560Z"
    }
}

```

## Download document from s3

**URL** : `/v1/doc/download/:doc_id`

**Method** : `GET`

**Header** : None 

**Auth required** : None

**Permissions required** : None

**ROUTE_PARAMS** : document_id from upload service

## Success Response

Document Downloaded


## View document from s3

**URL** : `/v1/doc/view/:doc_id`

**Method** : `GET`

**Header** : None 

**Auth required** : None

**Permissions required** : None

**ROUTE_PARAMS** : document_id from upload service

## Success Response

Document Viewed


## Delete document from s3

**URL** : `/v1/doc/delete/:doc_id`

**Method** : `DELETE`

**Header** : None 

**Auth required** : None

**Permissions required** : None

**ROUTE_PARAMS** : document_id from upload service

## Success Response

```json
{
    "status": "success",
    "code": 200
}
```

## Get document to s3

**URL** : `/v1/doc/get/:doc:id`

**Method** : `GET`

**Header** : None 

**Auth required** : None

**Permissions required** : None

**ROUTE_PARAMS** : document_id from upload service

## Success Response

**Code** : `200`

**Response**

```json

{
    "status": "success",
    "code": 200,
    "data": {
        "doc_id": "5c52fd31402dab12585ec501",
        "filename": "AnzAf_PDF_885_3835.pdf"
    }
}

```

## Upload document to s3 from base64 data

**URL** : `/v1/doc/data_upload`

**Method** : `POST`

**Header** : None 

**Auth required** : None

**Permissions required** : None

## Request Body

```formdata
{
    data : <base64 encoded data>
	doc_type_id : 5c1cf2e6eb72d4c894b9c475 <mongo_id> (validated from master data, collection : document_types)
}
```

## Success Response

**Code** : `200`

**Response**

```json

{
    "status": "success",
    "code": 200,
    "data": {
        "doc_id": "5c8151a2345a573f4415d5ac",
        "filename": "Offer.pdf",
        "doc_type_key": "offer_doc",
        "created_at": "2019-03-07T17:15:14.054Z",
        "updated_at": "2019-03-07T17:15:14.054Z"
    }
}

```