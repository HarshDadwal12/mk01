import { ApiProperty } from '@nestjs/swagger';
import {
  IsNotEmpty,
  IsString,
  ArrayNotEmpty,
  ArrayMinSize,
  IsMongoId,
  IsOptional,
  IsBoolean,
  IsObject,
} from 'class-validator';

export class UserDto {
  @IsNotEmpty()
  @IsString()
  @ApiProperty()
  name: string;

  @IsNotEmpty()
  @IsString()
  @ApiProperty()
  user_type: string;

  @IsNotEmpty()
  @IsString()
  @ApiProperty()
  address: string;

  @IsNotEmpty()
  @IsString()
  @ApiProperty()
  username: string;

  @IsNotEmpty()
  @IsString()
  @ApiProperty()
  password: string;

  @IsNotEmpty()
  @IsString()
  @ApiProperty()
  customer_key: string;

  @IsNotEmpty()
  @IsString()
  @IsMongoId()
  @ApiProperty()
  backend_user_id: string;

  @IsOptional()
  @ArrayNotEmpty()
  @ArrayMinSize(1)
  @ApiProperty({ type: [String] })
  products: string[];

  @IsOptional()
  @IsObject()
  @ApiProperty()
  hook_config: object;
}

export class UpdateUserDto {
  @IsOptional()
  @IsNotEmpty()
  @IsString()
  @ApiProperty()
  name: string;

  @IsOptional()
  @IsNotEmpty()
  @IsString()
  @ApiProperty()
  user_type: string;

  @IsOptional()
  @IsNotEmpty()
  @IsString()
  @ApiProperty()
  address: string;

  @IsOptional()
  @ArrayNotEmpty()
  @ArrayMinSize(1)
  @ApiProperty({ type: [String] })
  products: string[];

  @IsOptional()
  @IsBoolean()
  @ApiProperty()
  is_active: boolean;
}
