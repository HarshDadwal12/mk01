/** @format */

const express = require("express");
const multerConfig = require("../../config/multer.config");
const upload = new multerConfig().upload;
const { pdfValidator } = require("../../validators/filetype.validator");
const DocController = require("../../controllers/v1/DocumentController");
const DocVisibilityController = require("../../controllers/v1/DocumentVisibilityController");
// const multer = require('multer');
// let storage = multer.memoryStorage();
// let upload = multer({
//     storage: storage
// });
const {
	singleUploadReqValidator,
	docIdValidator,
	singleFileValidator,
	docIdsValidator,
	reqMethodValidator,
	docTypeIdValidator,
	dataReqValidator,
	genPdfValidator,
	preSignedReqValidator,
	docRefsValidator,
	updatedFileNameValidator,
	urlPdfReqValidator,
	docVisibilityValidator,
	cloneValidator,
} = require("../../validators/request.validator");

const routes = express.Router();

// Document Service Provided Endpoints

routes.post(
	"/upload",
	upload.single("file"),
	reqMethodValidator,
	singleUploadReqValidator,
	docTypeIdValidator,
	pdfValidator,
	DocController.doSingleUpload
);

routes.post("/data_upload", reqMethodValidator, dataReqValidator, DocController.doDataUpload);

routes.get("/download/:doc_id?", reqMethodValidator, docIdValidator, DocController.doDownload);
routes.get(
	"/downloadJson/:doc_id?",
	reqMethodValidator,
	docIdValidator,
	DocController.doDownloadJson
);
routes.get("/get/:doc_id?", reqMethodValidator, docIdValidator, DocController.get);
routes.post("/getByIds", reqMethodValidator, docIdsValidator, DocController.getByIds);

routes.get("/view/:doc_id?", reqMethodValidator, docIdValidator, DocController.viewDoc);

routes.delete("/delete/:doc_id?", reqMethodValidator, docIdValidator, DocController.doDelete);

routes.all("/generatePdf", reqMethodValidator, genPdfValidator, DocController.generatePdf);


routes.all(
	"/getPreSignedUrl",
	reqMethodValidator,
	preSignedReqValidator,
	DocController.getPreSignedUrl
);

routes.all("/saveRef", reqMethodValidator, docRefsValidator, DocController.saveDocRef);

routes.all(
	"/update/:doc_id?",
	reqMethodValidator,
	docIdValidator,
	updatedFileNameValidator,
	DocController.updateDocName
);

routes.get("/signed-url/:doc_id?", docIdValidator, DocController.getSignedUrl);

routes.post("/url-pdf-generate", urlPdfReqValidator, DocController.pdfByUrl);

routes.get("/file-status/:identifier", DocController.getFileStatus);
routes.put("/file-status/:identifier", DocController.updateFileStatus);

routes.post(
	"/document-visibility",
	docVisibilityValidator,
	DocVisibilityController.createDocVisibility
);
routes.get("/document-visibility/:id", DocVisibilityController.getDocVisibility);
routes.put("/document-visibility/:id", DocVisibilityController.updateDocVisibility);

routes.get("/download-by-url", DocController.downloadDocByUrl);



routes.post(
	"/clone",
	cloneValidator,
	DocController.cloneDocument
)

module.exports = routes;
