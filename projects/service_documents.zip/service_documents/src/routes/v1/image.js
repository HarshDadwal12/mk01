/** @format */

const express = require("express");
const ImageController = require("../../controllers/v1//ImageController");
const multerConfig = require("../../config/multer.config");
const upload = new multerConfig().upload;
const {
	singleUploadReqValidator,
	reqMethodValidator,
	docTypeIdValidator,
	dataReqValidator
} = require("../../validators/request.validator");

const routes = express.Router();

// Document Service Provided Endpoints

routes.post(
	"/upload",
	upload.single("file"),
	reqMethodValidator,
	singleUploadReqValidator,
	docTypeIdValidator,
	ImageController.doImageUpload
);

module.exports = routes;
