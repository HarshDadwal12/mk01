"use strict";

// Import module for mongo-db conection
const db = require("../db");
const conn = new db.connectionFactory(
    process.env.MONGO_USER_DB_URL,
    "backend_roles",
    "./schemas/backendRoleSchema"
);
var ObjectId = require("mongoose").Types.ObjectId;
// Define log-collection name
const request_collection_name = "backend_roles";

module.exports = {

    find: async function (json_data) {
        return new Promise(async function (resolve, reject) {
            try {
                let Collection = conn.model(request_collection_name);

                await Collection.find(json_data, function (err, data) {
                    // return document data
                    if (!err) return resolve(data);
                    // return error
                    else return reject(err);
                });
            } catch (error) {
                return reject(error);
            }
        });
    },
    
    findById: async function (id) {
        return new Promise(async function (resolve, reject) {
            try {
                let Collection = conn.model(request_collection_name);

                await Collection.findOne({ _id: new ObjectId(id) }, function (err, data) {
                    // return document data
                    if (!err) return resolve(data);
                    // return error
                    else return reject(err);
                });
            } catch (error) {
                return reject(error);
            }
        });
    },
};
