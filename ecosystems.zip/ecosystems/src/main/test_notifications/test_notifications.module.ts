import { Module } from '@nestjs/common';
import { CoreModule } from 'src/core/core.module';

import { TestNotificationsController } from './test_notifications.controller';
import {TestNotificationsService } from './test_notifications.service';

@Module({
  imports: [CoreModule],
  controllers: [TestNotificationsController],
  providers: [TestNotificationsService],
})
export class TestNotificationsModule {}
