const dotenv = require("dotenv");
const fs = require("fs");
const path = require("path");

const helper = require("../helpers/helper");
const Mongo = require("../db/mongoose");
const config = require("../../config/config");
const messages = require("../lang/en/messages");

/**
 * Switch database connection according to tenant id
 *
 * @param req
 * @param res
 * @param next
 *
 * @returns string
 */
module.exports = async (req, res, next) => {
	try {
		let tenant = req.headers["x-tenant-id"];
		const envFile = tenant ? `.env.${tenant}` : `.env`;
		if (!fs.existsSync(envFile)) {
			return res.status(400).send({
				status: "failed",
				code: 400,
				errors: [messages.x_tenant_id_invalid],
			});
		}
		tenant = tenant || "&default&";
		req.headers["x-tenant-id"] = tenant;
		const envConfig = dotenv.parse(fs.readFileSync(`${envFile}`));
		config.configUpdate(envConfig);
		if (!global[tenant] || !(global[tenant] && global[tenant]['db'] && global[tenant]['db'].readyState)) {
			let mongo_url = helper.connectionUrl(envConfig);
			console.log({ mongo_url });
			let db = await Mongo.connect(mongo_url);
			let list = fs.readdirSync(path.join(path.join(__dirname, ".."), "models"));
			let dbModel = {};
			for (let item of list) {
				if (item.search(/.map$/) === -1 && item.search(/.[tj]s$/) !== -1) {
					let data = require(path.join(path.join(__dirname, ".."), "models", item));
					dbModel[data.name] = db.model(data.name, data.schema);
				}
			}

			global[tenant] = { dbModel: dbModel, db: db, envConfig };
			next();
		} else {
			console.log("tenant already set");
			next();
		}
	} catch (error) {
		const error_msg = error.message || error;
		return res.status(400).send({ code: 500, status: messages.failed, errors: [error_msg] });
	}
};
