## **Configuration Service**

[API V1](./src/v1/docs/README.MD)

# Security

### IP Whitelisting

IP whitelisting allows us to create lists of trusted IP addresses or IP ranges from which our users can access our domains. IP whitelist is a security feature often used for limiting and controlling access only to trusted users. So, at the time of configuration, we would white list user public IP on our firewall, so our web-services would be called by the authorized user server only. Similarly, user also would have to white list our public IP to call the web services.

### SSL Data Transport

All data must be transported over the Transport Layer Security (TLS) version 1.2.

# Prerequisites

a) The consumer (or client) is already set up at API Gateway level.
b) The consumer (or client) is already subscribed to API services.
c) The aggregator is already set up at API Gateway level.

# Authentication

The authentication of client(s) requests to API is managed by Biz2x API Gateway using Client Credentials Grant Type.

### The Consumer Key & Consumer Secret and Access Token

As stated, the authorization data (Consumer Key and Consumer Secret) should have been setup in API gateway by Biz2x for integration clients to obtain the authentication
token. If the client is successfully authenticated, an access token will be returned.

#### Step #01

The Consumer Key and Consumer Secret combination will be created for LOS system as illustrated below in the example:

Client: Client
Consumer Key:100
Consumer Secret: 8adb5fa4-3f62-492c-8ef6-772bde9929f4

#### Step #02

Invoke the Token API to generate the access token using the grant type, along with the Consumer Key and Consumer Secret combination in the format of **consumer-key:consumer-secret**, encoded
in base64. The following portal can be used to generate the encoded base64 string:
https://www.base64encode.org/.

**consumer-key:consumer-secret** = 100:8adb5fa4-3f62-492c-8ef6-772bde9929f4

**Encoded String:**
YjBiZTMyYWEtMDhiNi00ZWU4LWE2ZWQtNDI5YjBjMjk1YzJlOjhhZGI1ZmE0LTNmNjIt
NDkyYy04ZWY2LTc3MmJkZTk5MjlmNA==

The authorization server will respond with a JSON object containing; <br/>

- token type with the value Bearer,
- expires in with an integer representing the TTL(Time-To-Live) of the access token and
- access token, a JWT signed with the authorization server’s private key.

**Request:**
**URI:**
Staging: https://api.sandbox.com/token

**Header**
Key: Authorization Basic
Value: YjBiZTMyYWEtMDhiNi00ZWU4LWE2ZWQtNDI5YjBjMjk1YzJlOjhhZGI1ZmE0LTNmNjItNDkyYy04ZWY2LTc3MmJkZTk5MjlmNA==

Note: The above base64 encoded value passed in the authorization header should be replaced by the actual value related to the client application

**Parameters**

| Name       | Data Type    | Validations      | Mandatory | Description                              |
| ---------- | ------------ | ---------------- | --------- | ---------------------------------------- |
| username   | AlphaNumeric |                  | yes       | client username                          |
| password   | AlphaNumeric |                  | yes       | client password                          |
| scope      | String       | enum: openid api | yes       | scope value will be only "openid api"    |
| grant_type | String       | enum: password   | yes       | grant_type value will be only "password" |

**Body** raw

```json
{
  "username": "username",
  "password": "password",
  "scope": "openid api",
  "grant_type": "password"
}
```

**Success Response:**
Access token is obtained in the response.

```json
{
  "code": 200,
  "message": "Success",
  "data": {
    "access_token": "U2FsdGVkX183kBkvv1TxDKo1wzVhrgO8UkB6ouXkhnOEVCQCHYZer6BLxuQq2KMkKVFo/jzJW4PXR0Y7+kIENdqdImzR+9f2hA1Lg52Fw0FJ+Ojx1U2tausPsl7TnS4cR8UThMgGlfL14s8Tj+JeBpkQZHbiAn44x4ubq7HcLhLSaTpBHBEEpwDfxP2MWg0src8lIVjk0ghvST+BxJyLyL1sdzCiGm7wGOCtT2KtHC2220Y+lmNgRq8TsOkw++3M",
    "token_type": "Bearer",
    "expires_in": "7d"
  }
}
```

**Sample Error Response 1**

```json
{
  "code": 400,
  "message": "Bad Request",
  "errors": ["invalid_client"],
  "correlation_id": "d50wRqrLbIqAp3EfuzpD8"
}
```

**Sample Error Response 2**

```json
{
  "code": 400,
  "message": "Bad Request",
  "errors": ["grant_type must be one of the following values: password"],
  "correlation_id": "kDXAF-DZblr8ZVQOM_knx"
}
```

# APIs Exposed in API Gateway

The following APIs have been currently exposed via API Gateway for LOS System to consume:

Staging
| API | URI |
|-------|--------------------------------------|
| Leads | https://api.sandbox.com/api/leads |

The following highlights the steps required to invoke Lead API
Step 1: Generated Access Token should be sent in the HTTP header in the request
Step 2: Aggregator Token and Product Token should be sent in the HTTP header in the request
Step 3: The JSON payload based on the request type will be passed as a parameter.

**Header**
The token generated in section 3.1 should be added in the authorization header of the request.

| Key           | Value                                                                                                       |
| ------------- | ----------------------------------------------------------------------------------------------------------- |
| Authorization | Bearer YjBiZTMyYWEtMDhiNi00ZWU4LWE2ZWQtNDI5YjBjMjk1YzJlOjhhZGI1ZmE0LTNmNjItNDkyYy04ZWY2LTc3MmJkZTk5MjlmNA== |
| Version       | 1.0                                                                                                         |

**Parameters**
| Name | Data Type | Validations | Mandatory | Description |
| --------------------------------------------- | ------------ | ------------------------------------------ | --------- | --------------------------------------------------------------------------- |
| pan | Alphanumeric | | | PAN of the Lead |
| aadhar_id | Numeric | length=12 | | Aadhar ID of the Lead |
| borrower_first_name | Alphanumeric | | Yes | First Name of the lead |
| borrower_last_name | Alphanumeric | | | Last Name of the lead |
| borrower_type | Alphanumeric | enum: [ORGANIZATION, INDIVIDUAL] | | Type of lead- ORGANIZATION, INDIVIDUAL |
| primary_phone_number | Numeric | length=10 | Yes | Primary Phone number of the lead |
| additional_phone_number | Numeric | length=10 | | Additional Phone numbers |
| primary_email_id | Alphanumeric | min length : 3, max length: 50 | | Primary email ID of the lead |
| additional_email_id | Alphanumeric | min length : 3, max length: 50 | | Additional email ID of the lead |
| date_of_birth | String | date: [DD-MM-YYYY] | | Date of birth of lead Date |
| gender | String | enum: [MALE, FEMALE, TRANSGENDER, OTHERS] | | Gender of Lead (MALE, FEMALE, TRANSGENDER, OTHERS) |
| preferred_language | String | | | Preferred language of lead |
| product_opportunity_id | Alphanumeric | | Yes | Product ID of the product the lead is applying for (Unique loan product ID) |
| lead_status | String | enum: [NEW, WHITELISTED, REJECTED] | | Status of the lead -(NEW, WHITELISTED, REJECTED) |
| additional | Object | | | Extra field |

**Additional**
| Name | Data Type | Validations | Mandatory | Description |
| ----------------------- | --------- | ------------------- | --------- | -------------------------------------------------------------------------------------------- |
| address_of_the_shop | String | | Yes | address of retailer |
| retailer_name | String | | Yes | name of the reatiler |
| business_name | String | | Yes | Name of lead's Business |
| business_pincode | String | business_pincode must be 6 character | Yes | pincode of lead's business |
| business_state | String | | Yes | state of lead's business |
| business_pan | String | | Yes | pan of lead's business |
| retailer_id | String | | Yes | Unique ID of the retailer |
| retailer_name | String | | Yes | Name of the retailer |
| entity_type | String | enum:['PARTNERSHIP','PROPRIETERSHIP','PRIVATE LABEL'] | Yes | Entity type of the retailer |
| drug_license_number | String | | Yes | Drug license number of the retailer |
| gst | Number | | | gst of lead's business |
| montly_total_sale | Number | | | Monthly total sales of leads business |
| montly_payout_1 | Number | | | Monthly total payout of leads business (8th Month) |
| montly_payout_2 | Number | | | Monthly total payout of leads business (7th Month) |
| montly_payout_3 | Number | | | Monthly total payout of leads business (6th Month) |
| montly_payout_4 | Number | | | Monthly total payout of leads business (5th Month) |
| montly_payout_5 | Number | | | Monthly total payout of leads business (4th Month) |
| montly_payout_6 | Number | | | Monthly total payout of leads business (3th Month) |
| montly_payout_7 | Number | | | Monthly total payout of leads business (2th Month) |
| montly_payout_8 | Number | | | Monthly total payout of leads business (1th Month) |
| comulative_12_months_total_number_of_invoices | Number | | | Cumulative 12 Months Total Number of Invoices of the lead |
| volumes_of_invoicing | Number | | | Volumes of Invoicing of the lead |
| os_as_on_last_date_of_month | Number | | | O/S as on last date of Month of the lead |
| date_of_first_transaction | Number | date: [DD-MM-YYYY] | | Date of first transanction of the retailer |
| distributor_codes | String | | | Distributor codes associated with the retailer |
| date_of_first_invoice | String | date: [DD-MM-YYYY] | | Date of the first invoice of the lead |
| date_of_first_order | String | date: [DD-MM-YYYY] | | Date of the first order of the lead |
| outstanding_amount_past_12_months | Number | | | Value of Total Outstanding amount from the lead for past 12 months at month end |
| outstanding_amount_past_24_months | Number | | | Value of Total Outstanding amount from the lead for past 24 months at month end |
| invoice_amount_past_12_months | Number | | | Value of Total Invoice amount from the lead for past 12 months |
| invoice_amount_past_24_months | Number | | | Value of Total Invoice amount from the lead for past 24 months |
| order_amount_past_12_months | Number | | | Value of Total order amount from the lead for past 12 months |
| order_amount_past_24_months | Number | | | Value of Total order amount from the lead for past 24 months |
| requested_amount | Number | requested_amount should be two digit precision | | Amount requested |
| requested_tenure | Number | | | Tenure that is requested by borrower |
| requested_tenure_unit | String | | | Requested Tenure unit : DAY | MONTH | YEAR |
| partner_ref_no | String | | | Referance of Partner |

**Body** raw

```json
{
  "borrower_first_name": "SPORTS",
  "borrower_last_name": "LLC",
  "primary_email_id": "sports_llc@b2cdev.com",
  "pan": "ABCTY1234D",
  "aadhar_id": "999999990019",
  "borrower_type": "ORGANIZATION",
  "primary_phone_number": 9876543214,
  "additional_phone_number": 9876543212,
  "additional_email_id": "additionyou@email.com",
  "date_of_birth": "23-06-1987",
  "gender": "MALE",
  "preferred_language": "en",
  "product_opportunity_id": "SKbZDloB",
  "lead_status": "NEW",
  "additional": {
    "partner_ref_no": "65rfc",
    "business_name": "123as",
    "business_pincode": "654321",
    "business_state": "up",
    "business_pan": "ABCTY1234D",
    "outstanding_amount_past_12_months": 1,
    "outstanding_amount_past_24_months": 2,
    "invoice_amount_past_12_months": 3,
    "invoice_amount_past_24_months": 4,
    "order_amount_past_12_months": 5,
    "order_amount_past_24_months": 6,
    "date_of_first_invoice": "10-10-2023",
    "date_of_first_order": "10-01-2023",
    "requested_amount": 21345,
    "requested_tenure": 21,
    "requested_tenure_unit": "DAY",
    "montly_total_sale": 55,
    "monthly_payout_1": 0,
    "monthly_payout_2": 0,
    "monthly_payout_3": 0,
    "monthly_payout_4": 0,
    "monthly_payout_5": 0,
    "monthly_payout_6": 0,
    "monthly_payout_7": 0,
    "monthly_payout_8": 0,
    "retailer_name": "test",
    "address_of_the_shop": "bh-148",
    "entity_type": "PARTNERSHIP",
    "drug_license_number": "8735",
    "date_of_first_transaction": "10-02-2023",
    "distributor_codes": "8735NU",
    "cumulative_12_months_total_number_of_invoices": 0,
    "volumes_of_invoicing": 0,
    "os_as_on_last_date_of_month": 0,
    "retailer_id": "123"
  }
}
```

**Success Response:**

```json
{
  "code": 201,
  "message": "Successfully Created",
  "data": {
    "id": 95762332438
  }
}
```

**Sample Error Response 1**

```json
{
  "code": 403,
  "message": "Forbidden",
  "errors": ["jwt malformed"],
  "correlation_id": "yY7iiiDhWzEKvzusSbk6t"
}
```

**Sample Error Response 3**

```json
{
  "code": 400,
  "message": "Bad Request",
  "errors": [
    "borrower_first_name must contain only letters (a-zA-Z)",
    "borrower_first_name should not be empty",
    "borrower_last_name must contain only letters (a-zA-Z)",
    "borrower_last_name should not be empty",
    "primary_phone_number must be shorter than or equal to 10 characters",
    "primary_phone_number must match /(6|7|8|9)\\d{9}/ regular expression",
    "primary_phone_number should not be empty",
    "primary_email_id must be shorter than or equal to 50 characters",
    "primary_email_id must be longer than or equal to 3 characters",
    "primary_email_id must be an email",
    "primary_email_id should not be empty",
    "product_opportunity_id must contain only letters and numbers",
    "product_opportunity_id should not be empty"
  ],
  "correlation_id": "otgrkVZceGeMx66r4IHRd"
}
```

Staging
| API | URI | Method |
|-------|--------------------------------------| ------ |
| Application | "https://api.sandbox.com/api/application" | POST |

The following highlights the steps required to invoke Lead API
Step 1: Generated Access Token should be sent in the HTTP header in the request
Step 2: Aggregator Token should be sent in the HTTP header in the request
Step 3: The JSON payload based on the request type will be passed as a parameter.

**Header**
The token generated in section 3.1 should be added in the authorization header of the request.

| Key           | Value                                                                                                       |
| ------------- | ----------------------------------------------------------------------------------------------------------- |
| Authorization | Bearer YjBiZTMyYWEtMDhiNi00ZWU4LWE2ZWQtNDI5YjBjMjk1YzJlOjhhZGI1ZmE0LTNmNjItNDkyYy04ZWY2LTc3MmJkZTk5MjlmNA== |
| Version       | 1.0                                                                                                         |

**Parameters**
| Name | Data Type | Validations | Mandatory | Description |
| --------------------------------------------- | ------------ | ------------------------- | --------- | --------------------------- |
| lead_id | Number | | yes | Lead Id of user |
| retailer_interest_rate | Number | | yes | interest to be charge by retailer by aggregator |
| borrower_address_type | String | enum: [PRIMARY, ALTERNATE] | yes | Borrower's addres type |
| building_name | String | | yes | Building name of business |
| street_name | String | | yes | Street name of business |
| street_no | String | | |Street no of business |
| location | String | | yes | location of business |
| door_number | String | | yes | door no of business |
| state | String | | yes | state of business |
| district | String | | yes | district of business |
| city | String | | yes | city of business |
| floor_number | String | | yes | floor no of business |
| pin_code | Number | | yes | pin code of business |
| latitude | Number | | | latitude of business |
| longitude | Number | | | Longitude of business |
| nature_of_business | String | | | Natur of business |
| sub_industry | String | | | sub industry of business |
| business_industry | String | || industry of business |
| cin | Number | | | cin of business |
| pan | String | | yes | pan of business |
| date_of_incorporation | String | DD-MM-YYYY format | yes | Date of incorporation of business |
| owners | Array | Array of Objects | Yes | Array of owner details |

**owners**

| Name                          | Data Type | Validations                                                                                                                                                                                                       | Mandatory | Description                                                                                                                                                                                                            |
| ----------------------------- | --------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------- | --------- | ------------- | ------ |
| owner_pan                     | string    | alphanumeric                                                                                                                                                                                                      | yes       | PAN of the owner                                                                                                                                                                                                       |
| owner_unique_id               | String    | alphanumeric                                                                                                                                                                                                      | yes       | Unique id of the ownwer                                                                                                                                                                                                |
| business_type                 | String    | enum:['PARTNERSHIP','LLP','PUBLIC_LIMITED_COMPANY','PRIVATE_LIMITED_COMPANY','JOINT_VENTURE_COMPANY','PARTNERSHIP_FIRM','ONE_PERSON_COMPANY','SOLE_PROPRIETORSHIP','BRANCH_OFFICE','NON_GOVERNMENT_ORGANIZATION'] | yes       | Type of business - PARTNERSHIP, LLP, Public Limited Company, Private Limited Company, Joint-Venture Company, Partnership Firm, One Person Company, Sole Proprietorship,Branch Office,Non-Government Organization (NGO) |
| owner_role                    | String    | enum:['OWNER', 'PARTNER', 'DIRECTOR', 'GUARANTOR']                                                                                                                                                                | yes       | Role in business - OWNER                                                                                                                                                                                               | PARTNER   | DIRECTOR  |
| owner_first_name              | String    |                                                                                                                                                                                                                   |           | First Name of the owner                                                                                                                                                                                                |
| owner_last_name               | String    |                                                                                                                                                                                                                   | yes       | Last Name of the owner                                                                                                                                                                                                 |
| owner_dob                     | String    | DD-MM-YYYY format                                                                                                                                                                                                 |           | DOB of owner                                                                                                                                                                                                           |
| ownership_percentage          | number    |                                                                                                                                                                                                                   |           | Percentage of Ownership in the business                                                                                                                                                                                |
| owner_aadhar                  | number    |                                                                                                                                                                                                                   | yes       | Aadhar no. of owner                                                                                                                                                                                                    |
| owner_passport_number         | String    |                                                                                                                                                                                                                   |           | passport number of owner                                                                                                                                                                                               |
| owner_mobile_number           | number    |                                                                                                                                                                                                                   | yes       | Mobile number of owner                                                                                                                                                                                                 |
| owner_alternate_mobile_number | Number    |                                                                                                                                                                                                                   |           | Alternate mobile no. of owner                                                                                                                                                                                          |
| owner_gender                  | string    |                                                                                                                                                                                                                   |           | gender of owner                                                                                                                                                                                                        |
| owner_education               | string    | enum: ['PRIMARY', 'SECONDARY', 'GRADUATE', 'POST_GRADUATE', 'PHD']                                                                                                                                                |           | Education qualification of the owner - Primary                                                                                                                                                                         | Secondary | Graduate  | Post Graduate | PhD    |
| owner_marital_status          | string    | enum:['MARRIED', 'UNMARRIED', 'SEPERATED', 'DIVORCED', 'OTHERS']                                                                                                                                                  |           | Marital Status of the owner - Married                                                                                                                                                                                  | Unmarried | Seperated | Divorced      | Others |
| owner_voter_id                | string    | alphanumeric                                                                                                                                                                                                      |           | voter id of owner                                                                                                                                                                                                      |
| owner_driving_license         | string    | alphanumeric                                                                                                                                                                                                      |           | driving licence of owner                                                                                                                                                                                               |
| owner_ownership_status        | string    | enum:['OWNED', 'RENTED']                                                                                                                                                                                          |           | status of the owner                                                                                                                                                                                                    |
| owner_address_type            | string    | enum: ['PRIMARY', 'OTHERS']                                                                                                                                                                                       | yes       | address type of owner                                                                                                                                                                                                  |
| owner_latitude                | Number    |                                                                                                                                                                                                                   |           | latitude of owner                                                                                                                                                                                                      |
| owner_state                   | string    |                                                                                                                                                                                                                   |           | state of owner                                                                                                                                                                                                         |
| owner_longitude               | Number    |                                                                                                                                                                                                                   |           | longitude of owner                                                                                                                                                                                                     |
| owner_pin_code                | Number    |                                                                                                                                                                                                                   |           | pin code of owner                                                                                                                                                                                                      |
| owner_city                    | string    |                                                                                                                                                                                                                   |           | city of owner                                                                                                                                                                                                          |
| owner_residential_address     | string    | alphanumeric                                                                                                                                                                                                      |           | residential address of owner                                                                                                                                                                                           |
| owner_cibil_score             | Number    |                                                                                                                                                                                                                   |           | cibil score of owner                                                                                                                                                                                                   |
| owner_experian_score          | Number    |                                                                                                                                                                                                                   |           | experian score of business                                                                                                                                                                                             |

**Body** raw

```json
{
  "lead_id": 127839062437,
  "retailer_interest_rate":1,
  "borrower_address_type": "PRIMARY",
  "building_name": "ETT",
  "street_name": "Harley st",
  "street_no": "600B",
  "location": "Noida",
  "door_number": "18",
  "state": "Delhi",
  "district": "NewDelhi",
  "city": "Delhi",
  "floor_number": "2nd",
  "pin_code": 110056,
  "latitude": 89,
  "longitude": 120,
  "nature_of_business": "Trading",
  "sub_industry": "vegetable_and_melon_farming",
  "business_industry": "agriculture",
  "cin": 96843,
  "pan": "ABCTY1234D",
  "date_of_incorporation": "10-02-2022"
  "owners": [
    {
      "owner_pan": "ABCTY1234D",
      "owner_unique_id": "ABCTY1234D",
      "business_type": "PARTNERSHIP",
      "owner_role": "OWNER",
      "owner_first_name": "Rakesh",
      "owner_last_name": "kumar",
      "owner_dob": "20-07-1223",
      "ownership_percentage": 100,
      "owner_aadhar": 654323456712,
      "owner_passport_number": "87654w45f",
      "owner_mobile_number": 9898765456,
      "owner_email": "owner@owner.com",
      "owner_alternate_mobile_number": 987654334567,
      "owner_alternate_email": "alt@owner.com",
      "owner_gender": "Male",
      "owner_education": "PRIMARY",
      "owner_marital_status": "MARRIED",
      "owner_voter_id": "a987654456",
      "owner_driving_license": "45678987654",
      "owner_ownership_status": "OWNED",
      "owner_address_type": "PRIMARY",
      "owner_latitude": 85,
      "owner_longitude": 120,
      "owner_state": "delhi",
      "owner_pin_code": 110023,
      "owner_city": "new Delhi",
      "owner_residential_address": "8765434567",
      "owner_cibil_score": 768,
      "owner_experian_score": 556
    }
  ]
}
```

**Success Response:**

```json
{
  "code": 201,
  "message": "Successfully Created",
  "data": {
    "id": 163784712434
  }
}
```

**Sample Error Response 1**

```json
{
  "code": 403,
  "message": "Forbidden",
  "errors": ["Malformed UTF-8 data"],
  "correlation_id": "3viNIdOP9nut7vMAf5mgS"
}
```

**Sample Error Response 2**

```json
{
  "code": 400,
  "message": "Bad Request",
  "errors": [
    "lead_id should not be null or undefined",
    "lead_id must be a string",
    "lead_id should not be empty"
  ],
  "correlation_id": "JxICm5lKoZXxeBh46bWUb"
}
```

Staging
| API | URI | Method |
|-------|--------------------------------------| ------ |
| Application GST | "https://api.sandbox.com/api/application/gst" | POST |

The following highlights the steps required to invoke Lead API
Step 1: Generated Access Token should be sent in the HTTP header in the request
Step 2: Aggregator Token should be sent in the HTTP header in the request
Step 3: The JSON payload based on the request type will be passed as a parameter.

**Header**
The token generated in section 3.1 should be added in the authorization header of the request.

| Key           | Value                                                                                                       |
| ------------- | ----------------------------------------------------------------------------------------------------------- |
| Authorization | Bearer YjBiZTMyYWEtMDhiNi00ZWU4LWE2ZWQtNDI5YjBjMjk1YzJlOjhhZGI1ZmE0LTNmNjItNDkyYy04ZWY2LTc3MmJkZTk5MjlmNA== |
| Version       | 1.0                                                                                                         |

**Parameters**
| Name | Data Type | Validations | Mandatory | Description |
| --------------------------------------------- | ------------ | ------------------------------------------ | --------- | --------------------------------------------------------------------------- |
| application_id | Number | | yes | Application id of lead |
| gstin | Number | | yes | GSTIN of the Tax Payer |
| state_jurisdiction | String | | | State Jurisdiction of business |
| centre_jurisdiction | String | | | Centre Jurisdiction of business |
| taxpayer_type | String | | Yes | Taxpayer type Eg: regular taxpayer, composition taxable persons, e-commerce operators, tds deductor ,etc|
| legal_name_business | String | | yes | Legal Name of Business |
| constitution_of_business | String | | | Constitution of Business as per GST |
| trade_name | String | | | Trade Name of Business |
| nature_of_business_activity | String | | | Nature of Business Activity Eg: trade, commerce, manufacture, profession, vocation, etc|
| date_of_registration | String | DD-MM-YYYY | | Date of Registration of business |
| last_update_date | String | DD-MM-YYYY | | Last Updated Date of GST details |
| gstin_status | String | | | GSTN status |
| business_owner_type | String | enum:[PRIMARY, ADDITIONAL] | | Type of business owner |
| centre_jurisdiction_code | String | | | Centre Jurisdiction Code |
| state_jurisdiction_code | String | | yes | State Jurisdiction Code of business |

**Body** raw

```json
{
  "application_id": 163784712434,
  "gstin": 12345678956000122,
  "state_jurisdiction": "COSSIPUR",
  "centre_jurisdiction": "GZB",
  "taxpayer_type": "Employed",
  "legal_name_business": "ANU PRODUCTS LTD.",
  "constitution_of_business": "Private Limited Company",
  "trade_name": "BIZ 2 CREDIT INFO SERVICES PRIVATE LIMITED",
  "nature_of_business_activity": "Service Provision",
  "date_of_registration": "12-03-2020",
  "last_update_date": "12-03-2020",
  "gstin_status": "NEW",
  "business_owner_type": "primary",
  "centre_jurisdiction_code": "WA0101",
  "state_jurisdiction_code": "WB051"
}
```

**Success Response:**

```json
{
  "code": 201,
  "message": "Successfully Created"
}
```

**Sample Error Response 1**

```json
{
  "code": 403,
  "message": "Forbidden",
  "errors": ["Malformed UTF-8 data"],
  "correlation_id": "3viNIdOP9nut7vMAf5mgS"
}
```

Staging
| API | URI | Method |
|-------|--------------------------------------| ------ |
| Application Additional | "https://api.sandbox.com/api/application/additional" | POST |

The following highlights the steps required to invoke Lead API
Step 1: Generated Access Token should be sent in the HTTP header in the request
Step 2: Aggregator Token should be sent in the HTTP header in the request
Step 3: The JSON payload based on the request type will be passed as a parameter.

**Header**
The token generated in section 3.1 should be added in the authorization header of the request.

| Key           | Value                                                                                                       |
| ------------- | ----------------------------------------------------------------------------------------------------------- |
| Authorization | Bearer YjBiZTMyYWEtMDhiNi00ZWU4LWE2ZWQtNDI5YjBjMjk1YzJlOjhhZGI1ZmE0LTNmNjItNDkyYy04ZWY2LTc3MmJkZTk5MjlmNA== |
| Version       | 1.0                                                                                                         |

**Parameters**
| Name | Data Type | Validations | Mandatory | Description |
| --------------------------------------------- | ------------ | ------------------------------------------ | --------- | --------------------------------------------------------------------------- |
| application_id | Number | | yes | Application id of lead |
| monthly_loan_obligation | Number | | | Any previous loan obligation from borrower - If yes, loan obligation amount |
| udhyam_registration_number | String | | Yes | Udhyam Registration number of the business |
| government_id_type | String | | | Other Government ID Available |
| government_id_number | String | | | Other Government ID Number |
| investment_in_plant_and_machinery | Number | | | Investment in Plant and Machinery (Original cost excluding land and building & the items specified by the Ministry of Small Scale Industries) |
| experian_commercial_score | Number | | | Experian Score |
| onboarding_date | String | DD-MM-YYYY | Yes | Onboarding date on Anchor |
| borrower_rating | Number | | | Borrower Rating on Anchor Platform |
| overall_rating | Number | | | Overall Rating on Anchor Platform |
| reliability_rating | Number | | | Reliability Rating on Anchor Platform |
| incident_rating | Number | | | Incident Rating on Anchor Platform |
| quality_rating | Number | | | Quality Rating on Anchor Platform |
| coverage_rating | Number | | | Coverage Rating on Anchor Platform |
| payment_rating | Number | | | Payment Rating on Anchor Platform |
| time_period | Number | | | Time period for which vintage data is provided (Eg:- "90" - 90 Days) |
| order_placed | Number | | | Total Number of all orders placed on Anchor during mentioned time period |
| order_value_placed | Number | | | Total value of all orders placed on Anchor during mentioned time period |
| order_value_paid | Number | | | Total value of all orders paid on Anchor during mentioned time period |
| orders_delivered | Number | | | Number of orders delivered by borrower on Anchor during mentioned time period |
| order_value_delivered | Number | | | Value of orders delivered by borrower on Anchor during mentioned time period |
| orders_returned | Number | | | Number of orders returned to borrower on Anchor during mentioned time period |
| order_value_returned | Number | | | Value of orders returned to borrower on Anchor during mentioned time period |
| orders_cancelled | Number | | | Number of orders cancelled by borrower on Anchor during mentioned time period |
| order_value_cancelled | Number | | | Value of orders cancelled by borrower on Anchor during mentioned time period |
| business_vintage | Number | | | Different types of vintage periods - Day, Month, Years. Business vintage entry format in years. |
| average_order_placed | Number | | | Average Number of all orders placed on Anchor |
| average_order_value_placed | Number | | | Average value of all orders placed on Anchor |
| average_order_value_paid | Number | | | Average value of all orders paid on Anchor |
| average_orders_delivered | Number | | | Average Number of orders delivered by borrower on Anchor |
| average_order_value_delivered | Number | | | Average Value of orders delivered by borrower on Anchor |
| average_orders_returned | Number | | | Average Number of orders returned to borrower on Anchor |
| average_order_value_returned | Number | | |Average Value of orders returned to borrower on Anchor |
| average_orders_cancelled | Number | | | Average Number of orders cancelled by borrower on Anchor |
| average_order_value_cancelled | Number | | | Average Value of orders cancelled by borrower on Anchor |
| vintage_order_placed | Number | | | Vintage Number of all orders placed on Anchor |
| vintage_order_value_placed | Number | | | Vintage value of all orders placed on Anchor |
| vintage_order_value_paid | Number | | | Vintage value of all orders paid on Anchor |
| vintage_orders_delivered | Number | | | Vintage Number of orders delivered by borrower on Anchor |
| vintage_orders_value_delivered | Number | | | Vintage Value of orders delivered by borrower on Anchor |
| vintage_orders_returns | Number | | | Number of orders returned to borrower on Anchor |
| vintage_order_value_returns | Number | | | Value of orders returned to borrower on Anchor |
| vintage_orders_cancelled | Number | | | Number of orders cancelled on borrower on Anchor |
| vintage_order_value_cancelled | Number | | | Value of orders cancelled on borrower on Anchor |

**Body** raw

```json
{
  "application_id": 163784712434,
  "monthly_loan_obligation": 50000,
  "udhyam_registration_number": "1245FTUIO",
  "government_id_type": "Adhar",
  "government_id_number": "999999990019",
  "investment_in_plant_and_machinery": 50000,
  "experian_commercial_score": 678,
  "onboarding_date": "13-03-2022",
  "borrower_rating": 5,
  "overall_rating": 10,
  "reliability_rating": 7,
  "incident_rating": 8,
  "quality_rating": 9,
  "coverage_rating": 8,
  "payment_rating": 7,
  "time_period": 15,
  "order_placed": 100,
  "order_value_placed": 10000000,
  "order_value_paid": 500000,
  "orders_delivered": 90,
  "order_value_delivered": 560000,
  "orders_returned": 45,
  "order_value_returned": 70000,
  "orders_cancelled": 10,
  "order_value_cancelled": 67896,
  "business_vintage": 5,
  "average_order_placed": 40,
  "average_order_value_placed": 400000,
  "average_order_value_paid": 30000,
  "average_orders_delivered": 30,
  "average_order_value_delivered": 300009,
  "average_orders_returned": 36,
  "average_order_value_returned": 200000,
  "average_orders_cancelled": 10,
  "average_order_value_cancelled": 399998,
  "vintage_order_placed": 45,
  "vintage_order_value_placed": 677778,
  "vintage_order_value_paid": 54436,
  "vintage_orders_delivered": 78,
  "vintage_orders_value_delivered": 78,
  "vintage_orders_returns": 2339,
  "vintage_order_value_returns": 78886,
  "vintage_orders_cancelled": 67,
  "vintage_order_value_cancelled": 566666
}
```

**Success Response:**

```json
{
  "code": 201,
  "message": "Successfully Created"
}
```

**Sample Error Response 1**

```json
{
  "code": 403,
  "message": "Forbidden",
  "errors": ["Malformed UTF-8 data"],
  "correlation_id": "3viNIdOP9nut7vMAf5mgS"
}
```

Staging
| API | URI | METHOD |
|-------|--------------------------------------|---|
| Approve Limit | https://{{webserver}}/api/application/approve-limit | POST |

The following highlights the steps required to invoke Lead API

1. Generated Access Token should be sent in the HTTP header in the request
2. Lender Token and Product Token should be sent in the HTTP header in the request
3. The JSON payload based on the request type will be passed as a parameter.

**Header**
The token generated in section 3.1 should be added in the authorization header of the request.

| Key           | Value                                                                                                       |
| ------------- | ----------------------------------------------------------------------------------------------------------- |
| Authorization | Bearer YjBiZTMyYWEtMDhiNi00ZWU4LWE2ZWQtNDI5YjBjMjk1YzJlOjhhZGI1ZmE0LTNmNjItNDkyYy04ZWY2LTc3MmJkZTk5MjlmNA== |
| Version       | 1.0                                                                                                         |

**Parameters**
| Name | Data Type | Validations | Mandatory | Description |
| --------------------------------------------- | ------------ | ------------------------------------------ | --------- | --------------------------------------------------------------------------- |
| application_id | Numeric | | Yes | Application id of Lead |
| approved_limit | String | | Yes | Limit that has been approved by the Lender |
| limit_expiry_date | String | | Yes | Date on which the limit will expire |
| limit_status | String | enum: [REQUEST_SANCTION, EXTEND] | Yes | Status of Limit |
| lead_status | String | enum: [APPROVED, REJECTED] | Yes | Status of the Lead after underwriting |
| lender_interest_rate | Numeric | | Yes | Interest levied on the retailer by lender (Can be different from the Interest rate) |

**Body** raw

```json
{
  "application_id": 82968821732,
  "limit_expiry_date": "01-12-2012",
  "approved_limit": 2000,
  "lead_status": "APPROVED",
  "limit_status": "SANCTIONED",
  "lender_interest_rate": 1
}
```

**Success Response:**

```json
{
  "code": 201,
  "message": "Successfully Created"
}
```

**Sample Error Response 1**

```json
{
  "code": 403,
  "message": "Forbidden",
  "errors": ["jwt malformed"],
  "correlation_id": "yY7iiiDhWzEKvzusSbk6t"
}
```

Staging
| API | URI | METHOD |
|-------|--------------------------------------|---|
| Disbursement Request | https://{{webserver}}/api/application/disbursement/request | POST |

The following highlights the steps required to invoke Lead API

1. Generated Access Token should be sent in the HTTP header in the request
2. Lender Token and Product Token should be sent in the HTTP header in the request
3. The JSON payload based on the request type will be passed as a parameter.

**Header**
The token generated in section 3.1 should be added in the authorization header of the request.

| Key           | Value                                                                                                       |
| ------------- | ----------------------------------------------------------------------------------------------------------- |
| Authorization | Bearer YjBiZTMyYWEtMDhiNi00ZWU4LWE2ZWQtNDI5YjBjMjk1YzJlOjhhZGI1ZmE0LTNmNjItNDkyYy04ZWY2LTc3MmJkZTk5MjlmNA== |
| Version       | 1.0                                                                                                         |

**Parameters**
| Name | Data Type | Validations | Mandatory | Description |
| --------------------------------------------- | ------------ | ------------------------------------------ | --------- | --------------------------------------------------------------------------- |
| application_id | Number | | Yes | Application id of Lead |
| disbursement_unique_id | string | | Yes | Unique ID of disbursement record |
| payment_request_timestamp | String | DD-MM-YYYY HH:mm:ss | Yes | Date and time of the disbursement request |
| retailer_name | String | | Yes | Name of the Retailer |
| loan_account_number | String | | Yes | Loan Account Number allocated to lead |
| available_credit_limit | Number | | no | Available credit limit of the Retailer |
| total_invoice_amount | Number | | Yes | Available credit limit of the Retailer |
| total_payment_requested | Number | | Yes | Available credit limit of the Retailer |
| total_invoices | Number | | Yes | Available credit limit of the Retailer |
| invoices | Array | | Yes | Invoice histry in array |

**invoices**

| Name                    | Data Type | Validations         | Mandatory | Description                                                                                  |
| ----------------------- | --------- | ------------------- | --------- | -------------------------------------------------------------------------------------------- |
| invoice_no              | String    |                     | Yes       | Invoice Number against which credit is requested                                             |
| invoice_timestamp       | String    | DD-MM-YYYY HH:mm:ss | Yes       | Date and time of Invoice against which credit is requested                                   |
| distributor_unique_code | String    |                     | Yes       | Unique code of the distributor                                                               |
| distributor_name        | String    |                     | Yes       | Name of the distributor to whom the disbursement will be made                                |
| invoice_amount          | Number    |                     | Yes       | Amount of the invoice against the invoice number                                             |
| payment_requested       | Number    |                     | Yes       | Amount which is requested for the invoice against the invoice number and the available limit |
| payee_account_number    | String    |                     | Yes       | Account number of the distributor against which disbursement needs to be made                |
| payee_bank_name         | String    |                     | Yes       | Name of the bank of the distributor wherein the disbursement needs to be done                |
| payee_bank_ifsc         | String    |                     | Yes       | IFSC code of the bank of the distributor wherein the disbursement needs to be done           |

**Body** raw

```json
{
  "application_id": 82968821732,
  "disbursement_unique_id": "987654345",
  "payment_request_timestamp": "01-02-2015 23:04:59",
  "retailer_name": "Retail 1",
  "loan_account_number": "142344",
  "available_credit_limit": 5432,
  "total_invoice_amount": 2345,
  "total_payment_requested": 5343,
  "total_invoices": 5,
  "invoices": [
    {
      "invoice_no": "142344as",
      "invoice_timestamp": "01-02-2015 23:04:59",
      "distributor_unique_code": "142344as",
      "distributor_name": "asdfg",
      "invoice_amount": 5432,
      "payment_requested": 5432,
      "payee_account_number": "98765432345676543",
      "payee_bank_name": "PNB",
      "payee_bank_ifsc": "PUNB000231"
    }
  ]
}
```

**Success Response:**

```json
{
  "code": 201,
  "message": "Successfully Created",
  "data": {
    "id": 7019712432
  }
}
```

**Sample Error Response 1**

```json
{
  "code": 403,
  "message": "Forbidden",
  "errors": ["jwt malformed"],
  "correlation_id": "yY7iiiDhWzEKvzusSbk6t"
}
```

Staging
| API | URI | METHOD |
|-------|--------------------------------------|---|
| Disbursement Request Reonciliation | https://{{webserver}}/api/application/disbursement/request/reconciliation | POST |

The following highlights the steps required to invoke Lead API

1. Generated Access Token should be sent in the HTTP header in the request
2. Lender Token and Product Token should be sent in the HTTP header in the request
3. The JSON payload based on the request type will be passed as a parameter.

**Header**
The token generated in section 3.1 should be added in the authorization header of the request.

| Key           | Value                                                                                                       |
| ------------- | ----------------------------------------------------------------------------------------------------------- |
| Authorization | Bearer YjBiZTMyYWEtMDhiNi00ZWU4LWE2ZWQtNDI5YjBjMjk1YzJlOjhhZGI1ZmE0LTNmNjItNDkyYy04ZWY2LTc3MmJkZTk5MjlmNA== |
| Version       | 1.0                                                                                                         |

**Parameters**
| Name | Data Type | Validations | Mandatory | Description |
| --------------------------------------------- | ------------ | ------------------------------------------ | --------- | --------------------------------------------------------------------------- |
| application_id | Number | | Yes | Application id of Lead |
| disbursement_unique_id | string | | Yes | Unique ID of disbursement record |
| disbursement_id | String | | Yes | Transanction ID of the disbursement |
| disbursed_date | String | DD-MM-YYYY | Yes | Date of Disbursement |
| disbursement_status | String | enum:[DISBURSED , PENDING]| Yes | Disbursement Status |
| total_payment_requested | Number | | Yes | Total disbursement amount requested for all invoices (collated amount of all invoices) |
| subvention | String | enum:[YES , NO]| Yes | Is subvention applicable - yes, no |

**Body** raw

```json
{
  "application_id": 124748541154,
  "disbursement_id": "abd4562",
  "disbursed_date": "16-02-2023",
  "disbursement_status": "DISBURSED",
  "disbursement_unique_id": "123245644",
  "total_payment_requested": 100000,
  "subvention": "YES"
}
```

**Success Response:**

```json
{
  "code": 201,
  "message": "Successfully Created",
  "data": {
    "id": 7019712432
  }
}
```

**Sample Error Response 1**

```json
{
  "code": 403,
  "message": "Forbidden",
  "errors": ["jwt malformed"],
  "correlation_id": "yY7iiiDhWzEKvzusSbk6t"
}
```

Staging
| API | URI | METHOD |
|-------|--------------------------------------|---|
| Repayment Request | https://{{webserver}}/api/application/repayment/request | POST |

The following highlights the steps required to invoke Lead API

1. Generated Access Token should be sent in the HTTP header in the request
2. Lender Token and Product Token should be sent in the HTTP header in the request
3. The JSON payload based on the request type will be passed as a parameter.

**Header**

The token generated in section 3.1 should be added in the authorization header of the request.

| Key           | Value                                                                                                       |
| ------------- | ----------------------------------------------------------------------------------------------------------- |
| Authorization | Bearer YjBiZTMyYWEtMDhiNi00ZWU4LWE2ZWQtNDI5YjBjMjk1YzJlOjhhZGI1ZmE0LTNmNjItNDkyYy04ZWY2LTc3MmJkZTk5MjlmNA== |
| Version       | 1.0                                                                                                         |

**Parameters**

| Name                   | Data Type | Validations                                   | Mandatory | Description                                              |
| ---------------------- | --------- | --------------------------------------------- | --------- | -------------------------------------------------------- |
| application_id         | Number    |                                               | Yes       | Application id of Lead                                   |
| repayment_unique_id    | Number    |                                               | Yes       | Unique ID of repayment record                            |
| retailer_name          | String    |                                               | Yes       | Name of the Retailer                                     |
| loan_account_number    | String    |                                               | Yes       | Loan Account Number allocated to lead                    |
| repayment_timestamp    | String    | DD-MM-YYYY HH:mm:ss                           | Yes       | Date and time of repayment                               |
| repayment_category     | String    | should be one of 'INVOICE' or 'TRANCHE'       | Yes       | category of repayment                                    |
| repayment_type         | String    | should be one of 'FULL' or 'PARTIAL'          | Yes       | type of repayment                                        |
| repayment_amount       | Number    |                                               | Yes       | Amount of repayment                                      |
| disbursement_unique_id | string    | if 'repayment_category' is equal to 'TRANCHE' | No        | Unique ID of disbursement record                         |
| invoices               | Array     | if 'repayment_category' is equal to 'INVOICE' | No        | An Array of objects describing different invoice details |

**invoices**

| Name              | Data Type | Validations         | Mandatory | Description           |
| ----------------- | --------- | ------------------- | --------- | --------------------- |
| invoice_no        | String    | Alphanumeric        | No        | Invoice no.           |
| invoice_timestamp | String    | DD-MM-YYYY HH:mm:ss | No        | Time stamp of invoice |

**Body 1**

```json
{
  "application_id": 121185321431,
  "repayment_unique_id": 4562,
  "repayment_timestamp": "09-08-2022 02:24:45",
  "retailer_name": "ABC",
  "loan_account_number": "1234abcd",
  "repayment_category": "INVOICE",
  "repayment_type": "FULL",
  "repayment_amount": 500000,
  "invoices": [
    {
      "invoice_no": "asT123",
      "invoice_timestamp": "09-08-2022 01:23:45"
    },
    {
      "invoice_no": "asT124",
      "invoice_timestamp": "10-08-2022 01:23:45"
    }
  ]
}
```

**Body 2**

```json
{
  "application_id": 121185321431,
  "repayment_unique_id": 4562,
  "repayment_timestamp": "09-08-2022 02:24:45",
  "retailer_name": "ABC",
  "loan_account_number": "1234abcd",
  "repayment_category": "TRANCHE",
  "repayment_type": "FULL",
  "repayment_amount": 500000,
  "disbursement_unique_id": "12564"
}
```

**Success Response**

```json
{
  "code": 201,
  "message": "Successfully Created",
  "data": {
    "id": 119775793037
  }
}
```

**Sample Error Response 1**

```json
{
  "code": 403,
  "message": "Forbidden",
  "errors": ["jwt malformed"],
  "correlation_id": "yY7iiiDhWzEKvzusSbk6t"
}
```

**Sample Error Response 2**

```json
{
  "code": 400,
  "message": "Bad Request",
  "errors": ["invoices.0.invoice_no must contain only letters and numbers"],
  "correlation_id": "KhRxcLRXGVI8GWrRLzQW1"
}
```

Staging
| API | URI | METHOD |
|-------|--------------------------------------|---|
| Repayment Request Reconciliation | https://{{webserver}}/api/application/repayment/request/reconciliation | POST |

The following highlights the steps required to invoke Lead API

1. Generated Access Token should be sent in the HTTP header in the request
2. Lender Token and Product Token should be sent in the HTTP header in the request
3. The JSON payload based on the request type will be passed as a parameter.

**Header**

The token generated in section 3.1 should be added in the authorization header of the request.

| Key           | Value                                                                                                       |
| ------------- | ----------------------------------------------------------------------------------------------------------- |
| Authorization | Bearer YjBiZTMyYWEtMDhiNi00ZWU4LWE2ZWQtNDI5YjBjMjk1YzJlOjhhZGI1ZmE0LTNmNjItNDkyYy04ZWY2LTc3MmJkZTk5MjlmNA== |
| Version       | 1.0                                                                                                         |

**Parameters**
| Name | Data Type | Validations | Mandatory | Description |
| --------------------------------------------- | ------------ | ------------------------------------------ | --------- | --------------------------------------------------------------------------- |
| application_id | Number | | Yes | Application id of Lead |
| repayment_unique_id | Number | | Yes | Unique ID of repayment record |
| repayment_timestamp | String | DD-MM-YYYY HH:mm:ss | Yes | Date and time of repayment |
| total_repayment_received | Number | | Yes | total repayment received |
| retailer_name | String | | Yes | Name of the Retailer |
| loan_account_number | String |alphanumeric | Yes | Loan Account Number allocated to lead |
| payment_status | String | should be one of 'RECEIVED', 'ON_HOLD' and 'PARTIAL' | Yes | status of payment |
| pending_repayment_amount | Number | | Yes | Amount pending as repayment from retailer |
| updated_credit_limit | Number | | Yes | credit limit post repayment of the Retailer updated on retailio |
| available_credit_limit | Number | | Yes | available credit limit |

**invoices**

| Name                        | Data Type | Validations                                      | Mandatory | Description                                              |
| --------------------------- | --------- | ------------------------------------------------ | --------- | -------------------------------------------------------- |
| invoice_no                  | String    |                                                  | Yes       | Invoice no.                                              |
| status_of_invoice_repayment | String    | should be one of 'PAID', 'PARTIAL' and 'PENDING' | Yes       | Status of invoice repayment                              |
| disbursement_amount         | Number    |                                                  | Yes       | Amount of disbursement                                   |
| invoice_principal_deduction | Number    |                                                  | Yes       | Principal deducted against invoice from repayment amount |
| invoice_interest_deduction  | Number    |                                                  | Yes       | Interest deducted against invoice from repayment amount  |
| invoice_penalty_deduction   | Number    |                                                  | Yes       | Penalty deducted against invoice from repayment amount   |
| total_invoice_deduction     | Number    |                                                  | Yes       | Total deduction against invoice from repayment amount    |
| principal_os                | Number    |                                                  | Yes       | Principal outstanding against invoice                    |
| interest_os                 | Number    |                                                  | Yes       | Interest outstanding against invoice                     |
| penalty_os                  | Number    |                                                  | Yes       | Penalty outstanding against invoice                      |
| total_invoice_outstanding   | Number    |                                                  | Yes       | Total deduction outstanding against invoice              |

**Body** raw

```json
{
  "application_id": 86337121436,
  "repayment_unique_id": 987654345,
  "repayment_timestamp": "09-09-2022 10:02:02",
  "retailer_name": "Retail",
  "loan_account_number": "1487676754464543",
  "total_repayment_received": 50000,
  "payment_status": "PARTIAL",
  "pending_repayment_amount": 876565757,
  "available_credit_limit": 120000,
  "updated_credit_limit": 876557,
  "invoices": [
    {
      "invoice_no": "APBH1234",
      "status_of_invoice_repayment": "PAID",
      "disbursement_amount": 1100000,
      "invoice_principal_deduction": 25000,
      "invoice_interest_deduction": 1500,
      "invoice_penalty_deduction": 2000,
      "total_invoice_deduction": 4000,
      "principal_os": 50000,
      "interest_os": 1000,
      "penalty_os": 2000,
      "total_invoice_outstanding": 20000
    }
  ]
}
```

**Success Response:**

```json
{
  "code": 201,
  "message": "Successfully Created",
  "data": {
    "id": 7019712432
  }
}
```

**Sample Error Response 1**

```json
{
  "code": 403,
  "message": "Forbidden",
  "errors": ["jwt malformed"],
  "correlation_id": "yY7iiiDhWzEKvzusSbk6t"
}
```

Staging

| API                | URI                                                     | METHOD |
| ------------------ | ------------------------------------------------------- | ------ |
| Document Meatadata | https://{{webserver}}/api/application/document/metadata | GET    |

The following highlights the steps required to invoke document API

1. Generated Access Token should be sent in the HTTP header in the request
2. Lender Token and Product Token should be sent in the HTTP header in the request
3. The JSON payload based on the request type will be passed as a parameter.

**Header**

The token generated in section 3.1 should be added in the authorization header of the request.

| Key           | Value                                                                                                       |
| ------------- | ----------------------------------------------------------------------------------------------------------- |
| Authorization | Bearer YjBiZTMyYWEtMDhiNi00ZWU4LWE2ZWQtNDI5YjBjMjk1YzJlOjhhZGI1ZmE0LTNmNjItNDkyYy04ZWY2LTc3MmJkZTk5MjlmNA== |
| Version       | 1.0                                                                                                         |

**Success Response**

```json
{
  "code": 200,
  "message": "Success",
  "data": [
    {
      "value": "Bank Statements",
      "allowed_file_type": "xls, xlsx, txt, doc, docx, ppt, pptx, pdf, jpg, jpeg, gif, png",
      "doc_type": "bank_statements"
    },
    {
      "value": "GSTIN certificate",
      "allowed_file_type": "xls, xlsx, txt, doc, docx, ppt, pptx, pdf, jpg, jpeg, gif, png",
      "doc_type": "gstin_certificate"
    },
    {
      "value": "MSME certificate",
      "allowed_file_type": "xls, xlsx, txt, doc, docx, ppt, pptx, pdf, jpg, jpeg, gif, png",
      "doc_type": "msme_certificatecertificate"
    },
    {
      "value": "Trade License",
      "allowed_file_type": "xls, xlsx, txt, doc, docx, ppt, pptx, pdf, jpg, jpeg, gif, png",
      "doc_type": "trade_license"
    },
    {
      "value": "Memorandum of Article",
      "allowed_file_type": "xls, xlsx, txt, doc, docx, ppt, pptx, pdf, jpg, jpeg, gif, png",
      "doc_type": "memorandum_of_article"
    },
    {
      "value": "Certificate of Incorporation",
      "allowed_file_type": "xls, xlsx, txt, doc, docx, ppt, pptx, pdf, jpg, jpeg, gif, png",
      "doc_type": "certificate_of_incorporation"
    },
    {
      "value": "Udyog aadhar Document",
      "allowed_file_type": "xls, xlsx, txt, doc, docx, ppt, pptx, pdf, jpg, jpeg, gif, png",
      "doc_type": "udyog_aadhar_document"
    },
    {
      "value": "Business PAN document",
      "allowed_file_type": "xls, xlsx, txt, doc, docx, ppt, pptx, pdf, jpg, jpeg, gif, png",
      "doc_type": "business_pan_document"
    },
    {
      "value": "Business Owner PAN document",
      "allowed_file_type": "xls, xlsx, txt, doc, docx, ppt, pptx, pdf, jpg, jpeg, gif, png",
      "doc_type": "business_owner_pan_document"
    },
    {
      "value": "Business Owner Aadhar document",
      "allowed_file_type": "xls, xlsx, txt, doc, docx, ppt, pptx, pdf, jpg, jpeg, gif, png",
      "doc_type": "business_owner_aadhar_document"
    },
    {
      "value": "Business Owner Passport document",
      "allowed_file_type": "xls, xlsx, txt, doc, docx, ppt, pptx, pdf, jpg, jpeg, gif, png",
      "doc_type": "business_owner_passport_document"
    },
    {
      "value": "Business Owner Voter ID document",
      "allowed_file_type": "xls, xlsx, txt, doc, docx, ppt, pptx, pdf, jpg, jpeg, gif, png",
      "doc_type": "business_owner_voter_id_document"
    },
    {
      "value": "Balance Sheet",
      "allowed_file_type": "xls, xlsx, txt, doc, docx, ppt, pptx, pdf, jpg, jpeg, gif, png",
      "doc_type": "balance_sheet"
    },
    {
      "value": "ITR Document",
      "allowed_file_type": "xls, xlsx, txt, doc, docx, ppt, pptx, pdf, jpg, jpeg, gif, png",
      "doc_type": "ITR_document"
    },
    {
      "value": "Net Worth Statements",
      "allowed_file_type": "xls, xlsx, txt, doc, docx, ppt, pptx, pdf, jpg, jpeg, gif, png",
      "doc_type": "net_worth_statements"
    },
    {
      "value": "Collateral Document",
      "allowed_file_type": "xls, xlsx, txt, doc, docx, ppt, pptx, pdf, jpg, jpeg, gif, png",
      "doc_type": "collateral_document"
    },
    {
      "value": "Collateral Ownership Document",
      "allowed_file_type": "xls, xlsx, txt, doc, docx, ppt, pptx, pdf, jpg, jpeg, gif, png",
      "doc_type": "collateral_ownership_document"
    },
    {
      "value": "Power of Attorney Document",
      "allowed_file_type": "xls, xlsx, txt, doc, docx, ppt, pptx, pdf, jpg, jpeg, gif, png",
      "doc_type": "power_of_attorney_document"
    },
    {
      "value": "Collateral Valuation Document",
      "allowed_file_type": "xls, xlsx, txt, doc, docx, ppt, pptx, pdf, jpg, jpeg, gif, png",
      "doc_type": "collateral_valuation_document"
    },
    {
      "value": "Additional Collateral document",
      "allowed_file_type": "xls, xlsx, txt, doc, docx, ppt, pptx, pdf, jpg, jpeg, gif, png",
      "doc_type": "additional_collateral_document"
    }
  ]
}
```

Staging

| API      | URI                                            | METHOD |
| -------- | ---------------------------------------------- | ------ |
| Document | https://{{webserver}}/api/application/document | POST   |

The following highlights the steps required to invoke document API

1. Generated Access Token should be sent in the HTTP header in the request
2. Lender Token and Product Token should be sent in the HTTP header in the request
3. The JSON payload based on the request type will be passed as a parameter.

**Header**

The token generated in section 3.1 should be added in the authorization header of the request.

| Key           | Value                                                                                                       |
| ------------- | ----------------------------------------------------------------------------------------------------------- |
| Authorization | Bearer YjBiZTMyYWEtMDhiNi00ZWU4LWE2ZWQtNDI5YjBjMjk1YzJlOjhhZGI1ZmE0LTNmNjItNDkyYy04ZWY2LTc3MmJkZTk5MjlmNA== |
| Version       | 1.0                                                                                                         |

**form-data**

| Name           | Data Type | Validations | Mandatory | Description                            |
| -------------- | --------- | ----------- | --------- | -------------------------------------- |
| doc_type       | String    |             | Yes       | Document type of document              |
| application_id | String    |             | Yes       | Application Id of the application      |
| file           |           |             | Yes       | File to be uploaded in required format |

**Success Response**

```json
{
  "code": 201,
  "message": "Successfully Created",
  "data": {
    "id": 124707811244
  }
}
```

**Sample Error Response 1**

```json
{
  "code": 400,
  "message": "Bad Request",
  "errors": ["invalid doc type"],
  "correlation_id": "1CKHw532RShVwCDsbn_tx"
}
```

**Sample Error Response 2**

```json
{
  "code": 400,
  "message": "Bad Request",
  "errors": ["invalid application id"],
  "correlation_id": "-VWBhtRgAAv-xf4HqzJQJ"
}
```

**Sample Error Response 3**

```json
{
  "code": 400,
  "message": "Bad Request",
  "errors": ["Fields required !!"],
  "correlation_id": "BfjtgJUtV0gDOOUpS9ouJ"
}
```

Staging
| API | URI | METHOD |
|-------|--------------------------------------|---|
| Lead Summary | https://{{webserver}}/api/leads/summary/:lead_id | GET |

The following highlights the steps required to invoke Lead API

1. Generated Access Token should be sent in the HTTP header in the request
2. Lender Token and Product Token should be sent in the HTTP header in the request
3. The JSON payload based on the request type will be passed as a parameter.

**_Header_**

The token generated in section 3.1 should be added in the authorization header of the request.

| Key           | Value                                                                                                       |
| ------------- | ----------------------------------------------------------------------------------------------------------- |
| Authorization | Bearer YjBiZTMyYWEtMDhiNi00ZWU4LWE2ZWQtNDI5YjBjMjk1YzJlOjhhZGI1ZmE0LTNmNjItNDkyYy04ZWY2LTc3MmJkZTk5MjlmNA== |
| Version       | 1.0                                                                                                         |

**Parameters**

| Name    | Data Type | Validations | Mandatory | Description     |
| ------- | --------- | ----------- | --------- | --------------- |
| lead_id | Number    |             | Yes       | lead_id of lead |

**Success Response**

```json
{
  "code": 200,
  "message": "Success",
  "data": {
    "lead_id": 13622329845,
    "application_id": 12469618849,
    "lead_status": "APPROVED",
    "application_status": "LIMIT_SANCTIONED",
    "approved_limit": 200000,
    "sanctioned_limit": 200000,
    "allocated_limit": null,
    "loan_account_number": 123456789,
    "current_limit": 198000,
    "limit_status": "SANCTIONED",
    "limit_expiry_date": "22-05-2022",
    "total_disbursement_count": 2,
    "last_disbursement_date": "01-04-2022",
    "last_disbursement_amount": 50000,
    "last_repayment_date": "06-04-2022 18:23:45",
    "last_repayment_amount": 50000,
    "pending_repayment_amount": 50000,
    "total_repayment_count": 2
  }
}
```

**Sample Error Response 1**

```json
{
  "code": 403,
  "message": "Forbidden",
  "errors": ["jwt malformed"],
  "correlation_id": "yY7iiiDhWzEKvzusSbk6t"
}
```

**Sample Error Response 2**

```json
{
  "code": 400,
  "message": "Bad Request",
  "errors": ["invalid lead_id"],
  "correlation_id": "JtySMiVvFm9c1Ohg8Iijw"
}
```

Staging
| API | URI | METHOD |
|-------|--------------------------------------|---|
| Invoice Tranche Summary | https://{{webserver}}/api/application/invoice/tranche | GET |

The following highlights the steps required to invoke Lead API

1. Generated Access Token should be sent in the HTTP header in the request
2. Lender Token and Product Token should be sent in the HTTP header in the request
3. The JSON payload based on the request type will be passed as a parameter.

**_Header_**

The token generated in section 3.1 should be added in the authorization header of the request.

| Key           | Value                                                                                                       |
| ------------- | ----------------------------------------------------------------------------------------------------------- |
| Authorization | Bearer YjBiZTMyYWEtMDhiNi00ZWU4LWE2ZWQtNDI5YjBjMjk1YzJlOjhhZGI1ZmE0LTNmNjItNDkyYy04ZWY2LTc3MmJkZTk5MjlmNA== |
| Version       | 1.0                                                                                                         |

**Parameters**

| Name                   | Data Type | Validations                                     | Mandatory | Description                                      |
| ---------------------- | --------- | ----------------------------------------------- | --------- | ------------------------------------------------ |
| application_id         | Number    |                                                 | Yes       | application id                                   |
| type                   | string    | enum : ['INVOICE', 'DISBURSEMENT', 'REPAYMENT'] | Yes       | type on which data to be filtered                |
| invoice_no             | String    | alphanumeric                                    | Yes       | Invoice Number against which credit is requested |
| disbursement_unique_id | string    | if type = 'DISBURSEMENT'                        | Yes       | disbursement unique id                           |
| repayment_unique_id    | Number    | if type = 'REPAYMENT'                           | Yes       | repayment unique id                              |

**Success Response 1 (INVOICE)**

```json
{
  "code": 200,
  "message": "Success",
  "data": {
    "application_id": 124748541154,
    "anchor_id": 14245510330,
    "lender_id": 59736522325,
    "lead_id": 118906811056,
    "invoice_no": "APBH1234",
    "distributor_unique_code": "142344as",
    "payee_account_number": "98765432345676543",
    "disbursed_date": "12-04-2022",
    "disbursement_amount": 50000,
    "disbursement_status": "DISBURSED",
    "interest_rate": 4,
    "aggregator_interest_rate": 10,
    "due_date_without_grace": "13-04-2022",
    "final_due_date_with_grace": "15-04-2022",
    "status_of_invoice_repayment": "PAID",
    "invoice_principal_deduction": 25000,
    "invoice_interest_deduction": 1500,
    "invoice_penalty_deduction": 2000,
    "total_invoice_deduction": 4000,
    "principal_os": 50000,
    "interest_os": 1000,
    "penalty_os": 2000,
    "total_invoice_outstanding": 20000,
    "maadhyam_invoice_date": "20-04-2022 23:04:59",
    "maadhyam_invoice_disbursement_date": "12-04-2022",
    "maadhyam_invoice_due_date": "04-06-2022 11:04:59",
    "maadhyam_invoice_repayment_date": "09-07-2022 09:33:45",
    "maadhyam_borrower_repayment_amount": 4000,
    "maadhyam_borrower_repayment_principal": 25000,
    "maadhyam_borrower_repayment_interest": 1082.191780821918,
    "maadhyam_borrower_repayment_charges": 2000,
    "maadhyam_borrower_os_repayment_amount": 20000,
    "maadhyam_borrower_os_principal": 50000,
    "maadhyam_borrower_os_interest": 1000,
    "maadhyam_borrower_os_charges": 2000,
    "maadhyam_aggregator_repayment_amount": 4000,
    "maadhyam_aggregator_repayment_principal": 25000,
    "maadhyam_aggregator_repayment_interest": 482.19178082191786,
    "maadhyam_aggregator_repayment_charges": 2000,
    "repayment_date": "09-07-2022 09:33:45",
    "aggregator_due_date": "04-06-2022 11:04:59"
  }
}
```

**Success Response 2 (DISBURSEMENT)**

```json
{
  "code": 200,
  "message": "Success",
  "data": {
    "application_id": 124748541154,
    "anchor_id": 14245510330,
    "lender_id": 59736522325,
    "lead_id": 118906811056,
    "invoices": [
      {
        "disbursed_date": "12-04-2022",
        "disbursement_status": "DISBURSED",
        "disbursement_amount": 50000,
        "distributor_unique_code": "DIST002",
        "invoice_no": "APBH1234",
        "payee_account_number": "98765432345676542"
      },
      {
        "disbursed_date": "12-04-2022",
        "disbursement_status": "DISBURSED",
        "disbursement_amount": 50000,
        "distributor_unique_code": "DIST001",
        "invoice_no": "APBH1235",
        "distributor_name": "distone",
        "payee_account_number": "98765432345676541"
      }
    ],
    "repayment_unique_id": 45623,
    "status_of_tranche_repayment": "PAID",
    "total_payment_requested": 50000,
    "total_principal_deduction": 1000,
    "total_interest_deduction": 2000,
    "total_penalty_deduction": 3000,
    "total_invoice_deduction": 2000,
    "tranche_principal_os": 200,
    "tranche_interest_os": 450,
    "tranche_penalty_os": 456,
    "total_tranche_outstanding": 2000,
    "maadhyam_tranche_date": null,
    "maadhyam_tranche_disbursement_date": null,
    "maadhyam_tranche_due_date": null,
    "maadhyam_tranche_repayment_date": null,
    "maadhyam_tranche_borrower_repayment_amount": null,
    "maadhyam_tranche_borrower_repayment_principal": null,
    "maadhyam_tranche_borrower_repayment_interest": null,
    "maadhyam_tranche_borrower_repayment_charges": null,
    "maadhyam_tranche_borrower_os_repayment_amount": null,
    "maadhyam_tranche_borrower_os_principal": null,
    "maadhyam_tranche_borrower_os_interest": null,
    "maadhyam_tranche_borrower_os_charges": null,
    "maadhyam_tranche_aggregator_repayment_amount": null,
    "maadhyam_tranche_aggregator_repayment_principal": null,
    "maadhyam_tranche_aggregator_repayment_interest": null,
    "maadhyam_tranche_aggregator_repayment_charges": null
  }
}
```

**Success Response 3 (REPAYMENT)**

```json
{
  "code": 200,
  "message": "Success",
  "data": {
    "application_id": 124748541154,
    "anchor_id": 14245510330,
    "lender_id": 59736522325,
    "lead_id": 118906811056,
    "repayment_unique_id": 45623,
    "invoices": [
      {
        "disbursed_date": "12-04-2022",
        "disbursement_status": "DISBURSED",
        "disbursement_amount": 50000,
        "distributor_unique_code": "DIST002",
        "invoice_no": "APBH1234",
        "payee_account_number": "98765432345676542"
      },
      {
        "disbursed_date": "12-04-2022",
        "disbursement_status": "DISBURSED",
        "disbursement_amount": 50000,
        "distributor_unique_code": "DIST001",
        "invoice_no": "APBH1235",
        "distributor_name": "distone",
        "payee_account_number": "98765432345676541"
      }
    ],
    "disbursement_unique_id": "12345678910",
    "status_of_tranche_repayment": "PAID",
    "total_payment_requested": 50000,
    "total_principal_deduction": 1000,
    "total_interest_deduction": 2000,
    "total_penalty_deduction": 3000,
    "total_invoice_deduction": 2000,
    "tranche_principal_os": 200,
    "tranche_interest_os": 450,
    "tranche_penalty_os": 456,
    "total_tranche_outstanding": 2000,
    "maadhyam_tranche_date": null,
    "maadhyam_tranche_disbursement_date": null,
    "maadhyam_tranche_due_date": null,
    "maadhyam_tranche_repayment_date": null,
    "maadhyam_tranche_borrower_repayment_amount": null,
    "maadhyam_tranche_borrower_repayment_principal": null,
    "maadhyam_tranche_borrower_repayment_interest": null,
    "maadhyam_tranche_borrower_repayment_charges": null,
    "maadhyam_tranche_borrower_os_repayment_amount": null,
    "maadhyam_tranche_borrower_os_principal": null,
    "maadhyam_tranche_borrower_os_interest": null,
    "maadhyam_tranche_borrower_os_charges": null,
    "maadhyam_tranche_aggregator_repayment_amount": null,
    "maadhyam_tranche_aggregator_repayment_principal": null,
    "maadhyam_tranche_aggregator_repayment_interest": null,
    "maadhyam_tranche_aggregator_repayment_charges": null
  }
}
```

**Sample Error Response 1**

```json
{
  "code": 403,
  "message": "Forbidden",
  "errors": ["jwt malformed"],
  "correlation_id": "yY7iiiDhWzEKvzusSbk6t"
}
```

**Sample Error Response 2**

```json
{
  "code": 400,
  "message": "Bad Request",
  "errors": ["invalid application id"],
  "correlation_id": "uuyM5ktsdPOIk-EOFT5Zg"
}
```

Staging
| API | URI | METHOD |
|-------|--------------------------------------|---|
| Transaction info | https://{{webserver}}/application/transaction_info/:id | GET |

The following highlights the steps required to invoke Lead API

1. Generated Access Token should be sent in the HTTP header in the request
2. Lender Token and Product Token should be sent in the HTTP header in the request
3. The JSON payload based on the request type will be passed as a parameter.

**_Header_**

The token generated in section 3.1 should be added in the authorization header of the request.

| Key           | Value                                                                                                       |
| ------------- | ----------------------------------------------------------------------------------------------------------- |
| Authorization | Bearer YjBiZTMyYWEtMDhiNi00ZWU4LWE2ZWQtNDI5YjBjMjk1YzJlOjhhZGI1ZmE0LTNmNjItNDkyYy04ZWY2LTc3MmJkZTk5MjlmNA== |
| Version       | 1.0                                                                                                         |

**Parameters**

| Name | Data Type | Validations | Mandatory | Description    |
| ---- | --------- | ----------- | --------- | -------------- |
| id   | string    |             | Yes       | transaction id |

**Success Response**

```json
{
  "code": 200,
  "message": "Success",
  "data": [
    {
      "type": "disbursement_request",
      "disbursement_unique_id": "987654345",
      "payment_request_timestamp": "01-02-2015 23:04:59",
      "retailer_name": "Retail 1",
      "loan_account_number": "142344",
      "available_credit_limit": 5432,
      "total_invoice_amount": 2345,
      "total_payment_requested": 5343,
      "total_invoices": 5,
      "invoices": [
        {
          "invoice_no": "APBH1234",
          "invoice_timestamp": "20-04-2022 23:04:59",
          "distributor_unique_code": "142344as",
          "distributor_name": "asdfg",
          "invoice_amount": 5432,
          "payment_requested": 5432,
          "payee_account_number": "98765432345676543",
          "payee_bank_name": "PNB",
          "payee_bank_ifsc": "PUNB000231"
        },
        {
          "invoice_no": "APBH1235",
          "invoice_timestamp": "21-04-2022 23:04:59",
          "distributor_unique_code": "142344as",
          "distributor_name": "asdfg",
          "invoice_amount": 5432,
          "payment_requested": 5432,
          "payee_account_number": "98765432345676543",
          "payee_bank_name": "PNB",
          "payee_bank_ifsc": "PUNB000231"
        }
      ],
      "id": 25658002558
    }
  ]
}
```

**Sample Error Response 1**

```json
{
  "code": 403,
  "message": "Forbidden",
  "errors": ["jwt malformed"],
  "correlation_id": "yY7iiiDhWzEKvzusSbk6t"
}
```

**Sample Error Response 2**

```json
{
  "code": 400,
  "message": "Bad Request",
  "errors": ["invalid transaction id"],
  "correlation_id": "CT-3lVdFUVWSDOKgeSAFi"
}
```

Staging
| API | URI | METHOD |
|-------|--------------------------------------|---|
| Application Summary | https://{{webserver}}/application/summary/:application_id | GET |

The following highlights the steps required to invoke Lead API

1. Generated Access Token should be sent in the HTTP header in the request
2. Lender Token and Product Token should be sent in the HTTP header in the request
3. The JSON payload based on the request type will be passed as a parameter.

**_Header_**

The token generated in section 3.1 should be added in the authorization header of the request.

| Key           | Value                                                                                                       |
| ------------- | ----------------------------------------------------------------------------------------------------------- |
| Authorization | Bearer YjBiZTMyYWEtMDhiNi00ZWU4LWE2ZWQtNDI5YjBjMjk1YzJlOjhhZGI1ZmE0LTNmNjItNDkyYy04ZWY2LTc3MmJkZTk5MjlmNA== |
| Version       | 1.0                                                                                                         |

**Parameters**

| Name           | Data Type | Validations | Mandatory | Description    |
| -------------- | --------- | ----------- | --------- | -------------- |
| application_id | string    |             | Yes       | application id |

**Success Response**

```json
{
  "code": 200,
  "message": "Success",
  "data": {
    "application_id": 12469618849,
    "retailer_interest_rate": 12,
    "application_status": "LIMIT_SANCTIONED",
    "approved_limit": 200000,
    "sanctioned_limit": 200000,
    "allocated_limit": 100000,
    "loan_account_number": 123456789,
    "current_limit": 78000,
    "limit_status": "ALLOCATED",
    "limit_expiry_date": "22-05-2022",
    "last_repayment_date": "06-04-2022 18:23:45",
    "last_repayment_amount": 50000,
    "pending_repayment_amount": 50000,
    "total_repayment_count": 2
  }
}
```

**Sample Error Response 1**

```json
{
  "code": 403,
  "message": "Forbidden",
  "errors": ["jwt malformed"],
  "correlation_id": "yY7iiiDhWzEKvzusSbk6t"
}
```

**Sample Error Response 2**

```json
{
  "code": 400,
  "message": "Bad Request",
  "errors": ["invalid application_id"],
  "correlation_id": "CT-3lVdFUVWSDOKgeSAFi"
}
```

Staging
| API | URI | METHOD |
|-------|--------------------------------------|---|
| Get Application | https://{{webserver}}/api/application | GET |

The following highlights the steps required to invoke Lead API

1. Generated Access Token should be sent in the HTTP header in the request
2. Lender Token and Product Token should be sent in the HTTP header in the request
3. The JSON payload based on the request type will be passed as a parameter.

**_Header_**

The token generated in section 3.1 should be added in the authorization header of the request.

| Key           | Value                                                                                                       |
| ------------- | ----------------------------------------------------------------------------------------------------------- |
| Authorization | Bearer YjBiZTMyYWEtMDhiNi00ZWU4LWE2ZWQtNDI5YjBjMjk1YzJlOjhhZGI1ZmE0LTNmNjItNDkyYy04ZWY2LTc3MmJkZTk5MjlmNA== |
| Version       | 1.0                                                                                                         |

**Parameters**

| Name | Data Type | Validations | Mandatory | Description    |
| ---- | --------- | ----------- | --------- | -------------- |
| id   | string    |             | Yes       | application id |

**Success Response**

```json
{
  "code": 200,
  "message": "Success",
  "data": {
    "building_name": "ggdggdgdggd",
    "street_name": "Harley st",
    "street_no": "600B",
    "location": "Noida",
    "door_number": "18",
    "state": "Delhi",
    "district": "NewDelhi",
    "city": "Delhi",
    "floor_number": "2nd",
    "pin_code": 110056,
    "latitude": 89,
    "longitude": 120,
    "nature_of_business": "Trading",
    "sub_industry": "vegetable_and_melon_farming",
    "business_industry": "agriculture",
    "cin": 96843,
    "pan": "ABCTY1234D",
    "date_of_incorporation": "10-06-2022",
    "borrower_address_type": "PRIMARY",
    "product_type": "SKbZDloB",
    "owners": [
      {
        "owner_unique_id": "ABCTY1234D",
        "owner_pan": "ABCTY1234D",
        "business_type": "ONE_PERSON_COMPANY",
        "owner_role": "OWNER",
        "owner_first_name": "Rakesh",
        "owner_last_name": "kumar",
        "ownership_percentage": 100,
        "owner_ownership_status": "OWNED",
        "owner_email": "rel45@gmail.com",
        "owner_dob": "28-10-2023",
        "owner_aadhar": 3468468463486,
        "owner_mobile_number": 7878676767,
        "owner_latitude": 85,
        "owner_longitude": 120,
        "owner_state": "delhi",
        "owner_pin_code": 110023,
        "owner_city": "new Delhi",
        "owner_cibil_score": 768,
        "owner_experian_score": 556,
        "level": 1
      },
      {
        "owner_unique_id": "ABCTU1234D",
        "owner_pan": "ABCTY1284D",
        "owner_role": "GUARANTOR",
        "owner_first_name": "Rakesh",
        "business_type": "ONE_PERSON_COMPANY",
        "owner_aadhar": 3468468463486,
        "owner_mobile_number": 7878676767,
        "owner_email": "rel45@gmail.com",
        "owner_last_name": "awasthi",
        "ownership_percentage": 100,
        "owner_ownership_status": "OWNED",
        "owner_dob": "28-09-2023",
        "owner_latitude": 85,
        "owner_longitude": 120,
        "owner_state": "delhi",
        "owner_pin_code": 110023,
        "owner_city": "new Delhi",
        "owner_cibil_score": 768,
        "owner_experian_score": 556,
        "level": 1
      }
    ],
    "disbursement_request": {
      "type": "disbursement_request",
      "disbursement_unique_id": "987654345",
      "payment_request_timestamp": "01-02-2015 23:04:59",
      "retailer_name": "Retail 1",
      "loan_account_number": "142344",
      "available_credit_limit": 5432,
      "total_invoice_amount": 2345,
      "total_payment_requested": 5343,
      "total_invoices": 5,
      "invoices": [
        {
          "invoice_no": "APBH1234",
          "invoice_timestamp": "20-04-2022 23:04:59",
          "distributor_unique_code": "142344as",
          "distributor_name": "asdfg",
          "invoice_amount": 5432,
          "payment_requested": 5432,
          "payee_account_number": "98765432345676543",
          "payee_bank_name": "PNB",
          "payee_bank_ifsc": "PUNB000231"
        },
        {
          "invoice_no": "APBH1235",
          "invoice_timestamp": "21-04-2022 23:04:59",
          "distributor_unique_code": "142344as",
          "distributor_name": "asdfg",
          "invoice_amount": 5432,
          "payment_requested": 5432,
          "payee_account_number": "98765432345676543",
          "payee_bank_name": "PNB",
          "payee_bank_ifsc": "PUNB000231"
        }
      ]
    },
    "disbursement_response": {
      "type": "disbursement_response",
      "disbursement_unique_id": "12345678910",
      "disbursement_response_timestamp": "12-04-2022 15:50:50",
      "retailer_name": "Retail6747",
      "invoices": [
        {
          "disbursed_date": "12-04-2022",
          "disbursement_status": "DISBURSED",
          "disbursement_amount": 50000,
          "distributor_unique_code": "DIST002",
          "invoice_no": "APBH1234",
          "payee_account_number": "98765432345676542"
        },
        {
          "disbursed_date": "12-04-2022",
          "disbursement_status": "DISBURSED",
          "disbursement_amount": 50000,
          "distributor_unique_code": "DIST001",
          "invoice_no": "APBH1235",
          "distributor_name": "distone",
          "payee_account_number": "98765432345676541"
        }
      ],
      "loan_account_number": "1487676754464543",
      "available_credit_limit": 100000,
      "total_disbursement_amount": 100000,
      "balance_credit_limit": 0,
      "interest_rate": 4,
      "aggregator_interest_rate": 10,
      "transanction_id": "tran34245344",
      "due_date_without_grace": "13-04-2022",
      "final_due_date_with_grace": "15-04-2022"
    },
    "repayment_request": {
      "type": "repayment_request",
      "repayment_unique_id": 4562,
      "repayment_timestamp": "09-07-2022 09:33:45",
      "retailer_name": "ABC",
      "loan_account_number": "1234abcd",
      "repayment_category": "INVOICE",
      "repayment_type": "FULL",
      "repayment_amount": 500000,
      "invoices": [
        {
          "invoice_no": "asT123",
          "invoice_timestamp": "09-08-2022 01:23:45"
        },
        {
          "invoice_no": "asT124",
          "invoice_timestamp": "10-08-2022 01:23:45"
        }
      ]
    },
    "id": 115271922552
  }
}
```

**Sample Error Response 1**

```json
{
  "code": 403,
  "message": "Forbidden",
  "errors": ["jwt malformed"],
  "correlation_id": "yY7iiiDhWzEKvzusSbk6t"
}
```

**Sample Error Response 2**

```json
{
  "code": 400,
  "message": "Bad Request",
  "errors": ["invalid application_id"],
  "correlation_id": "CT-3lVdFUVWSDOKgeSAFi"
}
```
