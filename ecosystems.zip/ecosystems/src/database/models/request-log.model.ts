import { model, Schema } from 'mongoose';
import { BASE_SCHEMA } from './base.model';

const REQUEST_SCHEMA = new Schema(
  {
    correlation_id: { type: String, index: true },
    request_url: {
      type: String,
      required: true,
    },
    method: {
      type: String,
      required: true,
    },
    request_ip: {
      type: String,
      required: true,
    },
    request_header: {
      type: Object,
      required: true,
    },
    request_body: {
      type: Object,
    },
    response: {
      type: Object,
      required: true,
    },
  },
  { capped: 20971520, versionKey: false },
).add(BASE_SCHEMA);

export default model('RequestLog', REQUEST_SCHEMA, 'request_logs');
