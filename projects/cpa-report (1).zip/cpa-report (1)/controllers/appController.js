"use strict";

require("dotenv").config();
const datetime = require("node-datetime");
const momentTz = require("moment-timezone");
const mailer = require("../lib/mail");
const helper = require("../lib/helper");
const awsS3 = require("../lib/awsS3");
const { Parser } = require("json2csv");
const fastcsv = require("fast-csv");
const fs = require("graceful-fs");
const appRoot = require("app-root-path");
const path = require("path");
const backendUser = require("../db/models/backendUser");
const userModel = require("../db/models/user");
const application = require("../db/models/application");
const appTypeModel = require("../db/models/appType");
const PPPAppLeadModel = require("../db/models/PPPAppLead");
const appStatus = require("../db/models/appStatus");
const deviceDetector = require("node-device-detector");
const businessInfo = require("../db/models/businessInfo");
const serviceBusinessModel = require("../db/models/ServiceBusiness");
const backendRole = require("../db/models/backendRole");
const userPlans = require("../db/models/userPlans");
const plans = require("../db/models/plans");
const { exit } = require("process");
const appRecordsModel = require('../db/models/appRecords');
const sbaForgivenessModel = require('../db/models/sbaForgiveness');
const PPPAppLeadForgivenessModel = require("../db/models/PPPAppLeadForgiveness");
const { time } = require("console");
const mongoose = require('mongoose');
const moment  = require('moment');

function lastFourCardQuery() {
    return [
      {
      $project: {
        customerId :"$incoming_request.customerId",
        cnpToken: "$incoming_response.tokenResponse.cnpToken",
        type: "$incoming_response.tokenResponse.type"
      }
    },
    {
      $match: {customerId: {$exists: true, $ne: null}, cnpToken: {$exists: true, $ne: null}, type: {$exists: true, $ne: null}}
    },
    {
      $project: {
          customerId:1,
          cnpToken:1,
          type: 1,
          lastFour: { $substrCP: [ '$cnpToken', { $subtract: [{ $strLenCP: "$cnpToken" }, 4] }, { $strLenCP: "$cnpToken" } ] }
      }
    },
    {
      $group: {
        _id: "$cnpToken",
        card_details: { $first: { id: '$_id', cnpToken: "$cnpToken", customerId: "$customerId", type: "$type", lastFour: "$lastFour"} }
      }
    },
    {
      $project: {
        _id: 0,
        payment_log_id: "$card_details.id",
        lastFour: "$card_details.lastFour",
        customerId: "$card_details.customerId",
        card_type: "$card_details.type"
      }
    }
  ];
}
exports.getPPPAICPAReport = async function () {
    return new Promise(async function (resolve, reject) {
        try {
            let mailData = "";
            let filePath = "";

            //let cpaUsers = [];
            let cpaApplication = [];
            let finalData = [];
            const detector = new deviceDetector();
            const APP_SUBMITTED = '5c20bf7e27105c78ad7f9280';
            const PPP2 = '5f40fb82b365b23a003e3708';
            const FORGIVENESS = '5cf61ae8a567c9873cbab4d5';
            // Set header of the csv
            const fields = [
                "CPA Firm Name",
                "CPA user First Name",
                "CPA user last name",
                "Plan Selected",
                "Email Address",
                "Phone Number",
                "Registered date and time",
                "Original plan",
                "Current Plan",
                "Current Role",
                "AICPA Member Number",
                "Number of users created under firm",
                "Number of forgiveness applications created",
                "Number of forgiveness applications completed",
                "Number of PPP2 applications created",
                "Number of PPP 2 applications completed"
            ];

            const opts = { fields };
            const parser = new Parser(opts);

            // Get start time

            let pastDate = '2020-07-16';

            let pastStartDt = datetime.create(pastDate);
            pastStartDt = pastStartDt.format("Y-m-d");

            let startDt = datetime.create(pastStartDt);
            let startTime = startDt.epoch();

            // Get End time
            let pastEndDt = datetime.create();
            pastEndDt = pastEndDt.format("Y-m-d");
            let endDt = datetime.create(pastEndDt);
            //endDt.offsetInDays(-1);
            let endTime = endDt.epoch();

            // Subject date
            let subjectDt = datetime.create();
            subjectDt.offsetInDays(-1);
            let subjectDate = subjectDt.format("Ymd");

            let cpaUserData = await backendUser.getAggregate([
                {
                    "$match": {
                        '$and': [
                            { created_at: { $lt: endTime } },
                            { created_at: { $gte: startTime } },
                            { email_address: { '$not': /^.*@(b2cdev|biz2credit)\.([a-zA-Z\.]{2,})/ } },
                            { email_address: { '$ne': null } }
                        ]
                    }
                },
                { "$group": { _id: "$data.cpa_firm_name", "doc": { "$first": "$$ROOT" } } },
                { '$sort': { created_at: -1 } },
                {
                    "$replaceRoot": { "newRoot": { "$mergeObjects": ["$doc"] } }
                },
                {
                    $lookup: {
                        from: 'backend_users',
                        let: { firm_name: '$data.cpa_firm_name' },
                        pipeline: [
                            {
                                $match: {
                                    $expr: {
                                        $eq: ['$data.cpa_firm_name', '$$firm_name']
                                    }
                                }
                            },
                            {
                                $project: { _id: 1 }
                            }
                        ],
                        as: 'cpa_users'
                    }
                },
                {
                    $addFields: { total_users: { $size: "$cpa_users" } }
                },
                {
                    $lookup: {
                        let: { role_id: "$role" },
                        from: "backend_roles",
                        pipeline: [
                            {
                                $match: {
                                    $expr: {
                                        $eq: ["$_id", "$$role_id"]
                                    }
                                }
                            },
                            {
                                $project: { role_name: 1 }
                            }
                        ],
                        as: "user_role"
                    }
                },
                {
                    $project: {
                        name: 1,
                        email_address: 1,
                        phone_number: 1,
                        created_at: 1,
                        'data.cpa_firm_name': 1,
                        registration_code: 1,
                        role: 1,
                        total_users: 1,
                        roles: {
                            $arrayToObject: {
                                $map: {
                                    input: "$user_role",
                                    as: "role",
                                    in: [
                                        "role_name",
                                        "$$role.role_name"
                                    ]
                                }
                            }
                        }
                    }
                },
                {
                    $replaceRoot: {
                        newRoot: {
                            $mergeObjects: ["$$ROOT", "$roles"]
                        }
                    }
                },
                {
                    $project: { roles: 0, role: 0 }
                }
            ]);

            if (cpaUserData.length) {
                const userIds = [];
                const firm_names_regex = [];
                const email_addresses = [];
                cpaUserData.forEach((cpaUser) => {
                    userIds.push(cpaUser._id.toString());
                    firm_names_regex.push(new RegExp(cpaUser.data.cpa_firm_name, 'i'));
                    email_addresses.push(cpaUser.email_address);
                });

                const appData = await application.getAggregate([
                    {
                        $match: {
                            backend_user_id: { $in: userIds }
                        }
                    },
                    {
                        $project: {
                            app_id: "$_id",
                            status_id: 1,
                            product_type: 1,
                            backend_user_id: 1
                        }
                    }
                ]);

                const userAppsMap = {};
                // map appData with each user
                appData.forEach((app) => {
                    if (!userAppsMap[app.backend_user_id]) {
                        userAppsMap[app.backend_user_id] = [];
                    }

                    userAppsMap[app.backend_user_id].push(app);
                });

                // perform query to get active plan under the firm
                let activeUserPlans = await userPlans.getAggregate([
                    {
                        $match: {
                            // $or: [
                            //     { email_address: { $in: email_addresses } },
                            //     { firm_name: { $in: firm_names_regex } }
                            // ],
                            email_address: { $in: email_addresses },
                            is_active: true
                        },
                    },
                    {
                        $lookup: {
                            from: "plans",
                            localField: "plan_id",
                            foreignField: '_id',
                            as: 'plans'
                        }
                    },
                    {
                        $project: {
                            plan_id: 1,
                            firm_name: 1,
                            email_address: 1,
                            plan_price: {
                                $arrayToObject: {
                                    $map: {
                                        input: "$plans",
                                        as: "p",
                                        in: {
                                            k: "plan",
                                            v: "$$p",
                                        }
                                    }
                                }
                            }
                        }
                    },
                    {
                        $replaceRoot: {
                            newRoot: {
                                $mergeObjects: ["$$ROOT", "$plan_price"]
                            }
                        }
                    },
                    {
                        $project: {
                            type: "$plan.type",
                            price: "$plan.price",
                            plan_id: 1,
                            firm_name: 1,
                            email_address: 1,
                        }
                    }
                ]);

                // map plan with email and firm to identify using firm or email address below
                const emailMap = {};
                const firmMap = {};
                activeUserPlans.forEach((plan) => {
                    emailMap[plan.email_address] = plan;
                    if (plan.firm_name) {
                        firmMap[plan.firm_name] = plan;
                    }
                });


                cpaUserData.forEach(user => {
                    // const user = item.toObject();
                    let registerDate = new Date(user.created_at * 1000);
                    let registerDt = datetime.create(registerDate);
                    let createdDate = registerDt.format("m/d/Y");

                    let firstName = "";
                    let lastName = "";
                    if (user.name) {
                        const fullname = user.name.split(" ");
                        firstName = fullname.slice(0, 1).join(" ");
                        lastName = fullname.slice(1).join(" ");
                    }

                    let selectedPlan = firmMap[user.data.cpa_firm_name];
                    selectedPlan = selectedPlan || emailMap[user.email_address];

                    const userApps = userAppsMap[user._id.toString()] || [];
                    const AppCounts = {
                        ppp2: 0,
                        forgiveness: 0,
                        ppp2_submitted: 0,
                        forgiveness_completed: 0,
                    }
                    userApps.forEach((app) => {
                        if (app.product_type === PPP2) {
                            AppCounts.ppp2 += 1;

                            if (app.status_id === APP_SUBMITTED) {
                                AppCounts.ppp2_submitted += 1;
                            }
                        }
                        if (app.product_type === FORGIVENESS) {
                            AppCounts.forgiveness += 1;

                            if (app.status_id === APP_SUBMITTED) {
                                AppCounts.forgiveness_completed += 1;
                            }
                        }
                    });

                    let cpaAppData = {
                        "Email Address": user.email_address,
                        "CPA user First Name": firstName,
                        "CPA user last name": lastName,
                        "Phone Number": !user.phone_number || isNaN(user.phone_number) ? "" : parseInt(user.phone_number),
                        "Registered date and time": createdDate,
                        "AICPA Member Number": user.registration_code ? user.registration_code : "",
                        "CPA Firm Name": user.data.cpa_firm_name ? user.data.cpa_firm_name : "",
                        "Current Role": user.role_name || "",
                        "Current Plan": selectedPlan ? selectedPlan.type : "",
                        "Plan Selected": selectedPlan ? selectedPlan.type : "",
                        "Original plan": selectedPlan ? selectedPlan.type : "",
                        "Number of users created under firm": user.total_users || 0,
                        'Number of forgiveness applications created': AppCounts.forgiveness,
                        'Number of forgiveness applications completed': AppCounts.forgiveness_completed,
                        'Number of PPP2 applications created': AppCounts.ppp2,
                        'Number of PPP 2 applications completed': AppCounts.ppp2_submitted
                    }
                    finalData.push(cpaAppData);
                });
            }

            if (finalData.length > 0) {
                // Convert json data into csv
                let contents = parser.parse(finalData);

                // Temporary file name
                let attach_fileName = "aicpa-report.csv";

                if (process.env.NODE_ENV == "local") {
                    filePath = path.resolve(attach_fileName);
                } else {
                    filePath = path.resolve("/tmp/" + attach_fileName);
                }

                const writeStream = fs.createWriteStream(filePath);
                writeStream.write(contents);

                writeStream.on("finish", () => {
                    console.log("wrote all data to file");
                });

                writeStream.end();

                let prefixDt = datetime.create();
                prefixDt.offsetInDays(-1);
                let prefixDate = prefixDt.format("Ymd");
                let folderData = prefixDt.format("Y-m-d");
                let splitDate = folderData.split("-");
                let prefix =
                    "reports/old-aicpa-report/" +
                    process.env.NODE_ENV +
                    "/" +
                    splitDate[0] +
                    "/" +
                    splitDate[1];
                let fileName = prefixDate + "-aicpa-report-cpa-data.csv";
               
                let bucketName = process.env.BUCKET_NAME + "/" + prefix;
            
                await awsS3.createLogFile(bucketName, fileName, contents);

                let attachments = [
                    {
                        filename: fileName,
                        path: filePath,
                    },
                ];

                mailData = {
                    from_email: process.env.USER_INFO_EMAIL_FROM,
                    to_email: process.env.USER_INFO_EMAIL_TO_CPA,
                    subject:
                        "PPPForgivenessTool - CPA data as on " +
                        subjectDate,
                    text: "Hi, PFA is the report.",
                    attachments: attachments,
                };
                if (
                    process.env.USER_INFO_CC_EMAIL != undefined &&
                    process.env.USER_INFO_CC_EMAIL != ""
                ) {
                    mailData["cc"] = process.env.USER_INFO_CC_EMAIL;
                }
            } else {
                mailData = {
                    from_email: process.env.USER_INFO_EMAIL_FROM,
                    to_email: process.env.USER_INFO_EMAIL_TO_CPA,
                    subject:
                        "PPPForgivenessTool - CPA data as on " +
                        subjectDate,
                    text: "Hi, No CPA data was found",
                };
                if (
                    process.env.USER_INFO_CC_EMAIL != undefined &&
                    process.env.USER_INFO_CC_EMAIL != ""
                ) {
                    mailData["cc"] = process.env.USER_INFO_CC_EMAIL;
                }
            }

            let notification = await mailer.mailSender(mailData);

            fs.unlink(filePath, function (err) {
                if (err) {
                    reject(err);
                }
            });

            if (notification) {
                resolve(notification);
            } else {
                throw new Error("Mail not sent");
            }
            
        } catch (error) {
            reject(error);
        }
    }).catch(function (error) {
        throw error;
    });
};
exports.get_PPP_AICPA_CPA_Report = async function () {
    return new Promise(async function (resolve, reject) {
        try {
            let mailData = "";
            let filePath = "";

            //let cpaUsers = [];
            let cpaApplication = [];
            let finalData = [];
            const detector = new deviceDetector();
            const APP_SUBMITTED = '5c20bf7e27105c78ad7f9280';
            const PPP2 = '5f40fb82b365b23a003e3708';
            const FORGIVENESS = '5cf61ae8a567c9873cbab4d5';
            // Set header of the csv
            const fields = [
                "CPA Firm Name",
                "CPA user First Name",
                "CPA user last name",
                "Plan Selected",
                "Email Address",
                "Phone Number",
                "SSN",
                "Clear Report Result",
                "CPA License Number",
                "CPA License State",
                "Business Address",
                "City",
                "State",
                "Zipcode",
                "Registered date and time",
                "Original plan",
                "Current Plan",
                "Current Role",
                "AICPA Member Number",
                "AICPA Verification Needed",
                "AICPA - Verified",
                "Number of users created under firm",
                "Number of forgiveness applications created",
                "Number of forgiveness applications completed",
                "Number of PPP2 applications created",
                "Number of PPP 2 applications completed",
                "Firm Owner",
                "Subscription Amount Paid",
                "Payment Status",
                "Payment Date"
            ];

            let total_number_paid_enterprice_cpa_firm = 0;
            let total_number_paid_premium_cpa_firm = 0;
            let total_number_paid_custom_cpa_firm = 0;
            let total_number_paid_cpa_firm = 0;

            let total_number_unpaid_enterprice_cpa_firm = 0;
            let total_number_unpaid_premium_cpa_firm = 0;
            let total_number_unpaid_custom_cpa_firm = 0;
            let total_number_unpaid_cpa_firm = 0;

            let total_number_ppp2_created_by_cpa_verified_firm = 0;
            let total_number_ppp2_completed_by_cpa_verified_firm = 0;
            let total_number_ppp2_created_by_all_firm = 0;
            let total_number_ppp2_completed_by_all_firm = 0;

            const opts = { fields };
            const parser = new Parser(opts);

            // Get start time

            let pastDate = '2020-07-16';

            let pastStartDt = datetime.create(pastDate);
            pastStartDt = pastStartDt.format("Y-m-d");

            let startDt = datetime.create(pastStartDt);
            let startTime = startDt.epoch();

            // Get End time
            let pastEndDt = datetime.create();
            pastEndDt = pastEndDt.format("Y-m-d");
            let endDt = datetime.create(pastEndDt);
            //endDt.offsetInDays(-1);
            let endTime = endDt.epoch();

            // Subject date
            let subjectDt = datetime.create();
            subjectDt.offsetInDays(-1);
            let subjectDate = subjectDt.format("Ymd");

            let queryBuild = [
                {
                    "$match": {
                        '$and': [
                            { 'data.cpa_firm_name': { $exists: true } },
                            { delete:{ $ne: true } },
                            { created_at: { $lt: endTime } },
                            { created_at: { $gte: startTime } },
                            { email_address: { '$not': /^.*@(b2cdev|biz2credit)\.([a-zA-Z\.]{2,})/ } },
                            { email_address: { '$ne': null } }
                        ]
                    }
                },
                { "$group": { _id: { $toLower: "$data.cpa_firm_name" }, "doc": { "$first": "$$ROOT" }, backend_ids: { $push: { $toString: "$_id" } } } },
                { $project: {firm_name: '$_id', backend_ids: 1} }
            ];

            let cpaUserFirm = await backendUser.getAggregate(queryBuild);

            const firmNames = [];
            const firmBackendIdMap = {};
            cpaUserFirm.forEach((firm) => {
                firmNames.push(firm.firm_name);
                firmBackendIdMap[firm.firm_name] = firm.backend_ids;
            });

            const cpaUserQuery = [
                { $match: { delete: { $ne: true } } },
                { $addFields: { firm_name: { $toLower: "$data.cpa_firm_name" } } },
                { $match: { "firm_name": { $in: firmNames } } },
            ];

            let queryModel = backendUser.getBackendUserModel(cpaUserQuery);

            let cpaUserData = await backendUser.getAggregate(queryModel);

            if (cpaUserData.length) {
                const userIds = [];
                const firm_names_regex = [];
                const email_addresses = [];
                cpaUserData.forEach((cpaUser) => {
                    // userIds.push(...cpaUser.backend_ids);
                    userIds.push(...firmBackendIdMap[cpaUser.data.cpa_firm_name.toLowerCase()]);
                    firm_names_regex.push(new RegExp(cpaUser.data.cpa_firm_name, 'i'));
                    email_addresses.push(cpaUser.email_address);
                });

                const appData = await application.getAggregate([
                    {
                        $match: {
                            backend_user_id: { $in: userIds }
                        }
                    },
                    {
                        $project: {
                            app_id: "$_id",
                            status_id: 1,
                            product_type: 1,
                            backend_user_id: 1
                        }
                    }
                ]);

                const userAppsMap = {};
                // map appData with each user
                appData.forEach((app) => {
                    if (!userAppsMap[app.backend_user_id]) {
                        userAppsMap[app.backend_user_id] = [];
                    }

                    userAppsMap[app.backend_user_id].push(app);
                });

                // perform query to get active plan under the firm
                let activeUserPlans = await userPlans.getAggregate([
                    {
                        $match: {
                            $or: [
                                { email_address: { $in: email_addresses } },
                                { firm_name: { $in: firm_names_regex } }
                            ],
                            // is_active: true
                        },
                    },

                    { $match: { $or: [{plan_id: ObjectId("5f48d55a00df162a64a8a57a")}, { $and: [{"payment_status" : {$nin:["pending", "fail"]}}, { payment_status:{ $exists: true } }]  }] } },
                    { '$sort': { createdAt: -1 } },
                    { "$group": { _id: "$email_address", "doc": { "$first": "$$ROOT" }, all_plans: { $push: "$$ROOT" } } },
                    {
                        "$replaceRoot": { "newRoot": { "$mergeObjects": ["$doc"] } }
                    },
                    {
                        $lookup: {
                            from: "plans",
                            localField: "plan_id",
                            foreignField: '_id',
                            as: 'plans'
                        }
                    },
                    {
                        $project: {
                            plan_id: 1,
                            firm_name: 1,
                            email_address: 1,
                            payment_status: 1,
                            payment_date: 1,
                            payment_amount: 1,
                            createdAt: 1,
                            plan_price: {
                                $arrayToObject: {
                                    $map: {
                                        input: "$plans",
                                        as: "p",
                                        in: {
                                            k: "plan",
                                            v: "$$p",
                                        }
                                    }
                                }
                            }
                        }
                    },
                    {
                        $replaceRoot: {
                            newRoot: {
                                $mergeObjects: ["$$ROOT", "$plan_price"]
                            }
                        }
                    },
                    {
                        $project: {
                            type: "$plan.type",
                            price: "$plan.price",
                            plan_id: 1,
                            firm_name: 1,
                            email_address: 1,
                            payment_status: 1,
                            payment_date: 1,
                            payment_amount: 1
                        }
                    }
                ]);

                // map plan with email and firm to identify using firm or email address below
                const emailMap = {};
                const firmMap = {};
                activeUserPlans.forEach((plan) => {
                    const firmEmail = plan.email_address;
                    const firmName = plan.firm_name;
                    if(!emailMap[firmEmail]){ 
                        emailMap[firmEmail] = plan;
                    } else if(emailMap[firmEmail] && plan.payment_date) {
                        emailMap[firmEmail] = plan;
                    }
 
                    if (firmName) {
                        const firmSmallCase = firmName.toLowerCase();
                        if(!firmMap[firmSmallCase]) {
                            firmMap[firmSmallCase] = plan;
                        } else if(firmMap[firmSmallCase] && plan.payment_date) {
                            firmMap[firmSmallCase] = plan;
                        }
                    }
                });

                const cpaFirmEmailMap = {};
                cpaUserData.forEach(async (user) => {
                    let selectedPlan = firmMap[user.data.cpa_firm_name.toLowerCase()];
                    selectedPlan = selectedPlan || emailMap[user.email_address];
                    let selectedPlanEmail = selectedPlan ? selectedPlan.email_address : "";
                    if (selectedPlanEmail !== "" && selectedPlanEmail !== user.email_address) {
                        cpaFirmEmailMap[selectedPlanEmail] = selectedPlanEmail;
                    }
                });
                let queryB = [
                    {
                        "$match": { email_address: { '$in': Object.keys(cpaFirmEmailMap) } }
                    },
                ];
                let queryM = backendUser.getBackendUserModel(queryB);
                let actualUser = await backendUser.getAggregate(queryM);
                const cpaFirmActualUserMap = {};
                actualUser.forEach(async (user) => {
                    cpaFirmActualUserMap[user.email_address] = user;
                });

                const reportUserEmailMap = {};
                const firmsWrittenToFile = {};
                
                for (let user of cpaUserData) {

                    let selectedPlan = firmMap[user.data.cpa_firm_name.toLowerCase()];
                    selectedPlan = selectedPlan || emailMap[user.email_address];
                    let selectedPlanEmail = selectedPlan ? selectedPlan.email_address : "";
                    if (selectedPlanEmail !== "" && selectedPlanEmail !== user.email_address) {
                        user = cpaFirmActualUserMap[selectedPlanEmail] ? cpaFirmActualUserMap[selectedPlanEmail] : user;
                    }

                    if (reportUserEmailMap[user.email_address]) { continue; }

                    if(firmsWrittenToFile[user.data.cpa_firm_name.toLowerCase()]) { continue;}
                    
                    firmsWrittenToFile[user.data.cpa_firm_name.toLowerCase()] = true;

                    reportUserEmailMap[user.email_address] = true;

                    let registerDate = new Date(user.created_at * 1000);
                    let registerDt = datetime.create(registerDate);
                    let createdDate = registerDt.format("m/d/Y");

                    let firstName = "";
                    let lastName = "";
                    if (user.name) {
                        const fullname = user.name.split(" ");
                        firstName = fullname.slice(0, 1).join(" ");
                        lastName = fullname.slice(1).join(" ");
                    }

                    selectedPlan = firmMap[user.data.cpa_firm_name];
                    
                    selectedPlan = selectedPlan || emailMap[user.email_address];
                    let selectedPlanType = selectedPlan ? selectedPlan.type : "";
                    let selectedPlanPrice = selectedPlan && selectedPlan.payment_amount !== undefined ? selectedPlan.payment_amount : "";
                    if(selectedPlanPrice === "")
                    {
                        selectedPlanPrice = selectedPlan ? selectedPlan.price : 0;
                    }
                    
                    let firm_owner = "No";
                    if (selectedPlanType === "premium" || selectedPlanType === "enterprise") {
                        firm_owner = "Yes";
                    }
                    else {
                        firm_owner = "No";
                    }

                    let paymentStatus = selectedPlan ? selectedPlan.payment_status : "";
                    let paymentDate = "";
                    let aicpa_verification_needed = "";
                    if (paymentStatus === "success") {

                        if(selectedPlanType === "enterprise")
                        {
                            total_number_paid_enterprice_cpa_firm++;
                        }
                        if(selectedPlanType === "premium")
                        {
                            total_number_paid_premium_cpa_firm++;
                        }
                        if(selectedPlanType === "custom")
                        {
                            total_number_paid_custom_cpa_firm++; 
                        }
                        paymentDate = selectedPlan && selectedPlan.payment_date ? selectedPlan.payment_date : "";
                        if(paymentDate)
                        {
                            paymentDate = datetime.create(paymentDate);
                            paymentDate = paymentDate.format("m/d/Y");
                        }                   
                        aicpa_verification_needed = user.data.cpa_verification_needed ? user.data.cpa_verification_needed : "Y";
                    }
                    else{
                        if(selectedPlanType === "enterprise")
                        {
                            total_number_unpaid_enterprice_cpa_firm++;
                        }
                        if(selectedPlanType === "premium")
                        {
                            total_number_unpaid_premium_cpa_firm++;
                        }
                        if(selectedPlanType === "custom")
                        {
                            total_number_unpaid_custom_cpa_firm++;
                        }
                        aicpa_verification_needed = user.data.cpa_verification_needed ? user.data.cpa_verification_needed : "";
                    }

                    const AppCounts = {
                        ppp2: 0,
                        forgiveness: 0,
                        ppp2_submitted: 0,
                        forgiveness_completed: 0,
                    }

                    const backendUserIds = firmBackendIdMap[user.data.cpa_firm_name.toLowerCase()];

                    for (let index = 0; index < backendUserIds.length; index++) {
                        // const id = user.backend_ids[index];
                        const id = backendUserIds[index];
                        const userApps = userAppsMap[id] || [];
                        userApps.forEach((app) => {
                            if (app.product_type === PPP2) {
                                AppCounts.ppp2 += 1;
    
                                if (app.status_id === APP_SUBMITTED) {
                                    AppCounts.ppp2_submitted += 1;
                                }
                            }
                            if (app.product_type === FORGIVENESS) {
                                AppCounts.forgiveness += 1;
    
                                if (app.status_id === APP_SUBMITTED) {
                                    AppCounts.forgiveness_completed += 1;
                                }
                            }
                        });
                    }
                    if(user.data.cpa_verified === 'Y')
                    {
                        total_number_ppp2_created_by_cpa_verified_firm = total_number_ppp2_created_by_cpa_verified_firm + AppCounts.ppp2;
                        total_number_ppp2_completed_by_cpa_verified_firm = total_number_ppp2_completed_by_cpa_verified_firm + AppCounts.ppp2_submitted;
                    }
                    total_number_ppp2_created_by_all_firm = total_number_ppp2_created_by_all_firm + AppCounts.ppp2;
                    total_number_ppp2_completed_by_all_firm = total_number_ppp2_completed_by_all_firm + AppCounts.ppp2_submitted;

                    let cpaAppData = {
                        "Email Address": user.email_address,
                        "CPA user First Name": firstName,
                        "CPA user last name": lastName,
                        "Phone Number": !user.phone_number || isNaN(user.phone_number) ? "" : parseInt(user.phone_number),
                        "Business Address": user.data.business_address && user.data.business_address.business_address  ? user.data.business_address.business_address : "",
                        "City": user.data.business_address && user.data.business_address.city  ? user.data.business_address.city : "",
                        "State": user.data.business_address && user.data.business_address.state  ? user.data.business_address.state : "",
                        "Zipcode": user.data.business_address && user.data.business_address.zip_code  ? "\t" + user.data.business_address.zip_code : "",
                        "Registered date and time": createdDate,
                        "AICPA Member Number": user.registration_code ? user.registration_code : "",
                        "AICPA Verification Needed": aicpa_verification_needed,
                        "AICPA - Verified": user.data.cpa_verified ? user.data.cpa_verified : "",
                        "CPA Firm Name": user.data.cpa_firm_name ? user.data.cpa_firm_name : "",
                        "SSN": user.data.ssn ? user.data.ssn : "",
                        "Clear Report Result": user.data.clear_report ? "Yes":"No",
                        "CPA License Number":user.data.cpa_licensee_no,
                        "CPA License State":user.data.cpa_licensee_state,
                        "Current Role": user.role_name || "",
                        "Current Plan": selectedPlan ? selectedPlan.type : "",
                        "Plan Selected": selectedPlan ? selectedPlan.type : "",
                        "Original plan": selectedPlan ? selectedPlan.type : "",
                        "Number of users created under firm": user.total_users || 0,
                        'Number of forgiveness applications created': AppCounts.forgiveness,
                        'Number of forgiveness applications completed': AppCounts.forgiveness_completed,
                        'Number of PPP2 applications created': AppCounts.ppp2,
                        'Number of PPP 2 applications completed': AppCounts.ppp2_submitted,
                        'Firm Owner': firm_owner,
                        'Subscription Amount Paid': selectedPlanPrice,
                        'Payment Status': paymentStatus,
                        'Payment Date': paymentDate
                    }

                    finalData.push(cpaAppData);
                }
            }

            if (finalData.length > 0) {
                // Convert json data into csv
                let contents = parser.parse(finalData);

                // Temporary file name
                let attach_fileName = "aicpa-report.csv";

                if (process.env.NODE_ENV == "local") {
                    filePath = path.resolve(attach_fileName);
                } else {
                    filePath = path.resolve("/tmp/" + attach_fileName);
                }

                const writeStream = fs.createWriteStream(filePath);
                writeStream.write(contents);

                writeStream.on("finish", () => {
                    console.log("wrote all data to file");
                });

              writeStream.end();

              let prefixDt = datetime.create();
              prefixDt.offsetInDays(-1);
              let prefixDate = prefixDt.format("Ymd");
              let folderData = prefixDt.format("Y-m-d");
              let splitDate = folderData.split("-");
              let prefix =
                  "reports/aicpa-report/" +
                  process.env.NODE_ENV +
                  "/" +
                  splitDate[0] +
                  "/" +
                  splitDate[1];
              let fileName = prefixDate + "-aicpa-report-cpa-data.csv";
              let bucketName = process.env.BUCKET_NAME + "/" + prefix;
  
              await awsS3.createLogFile(bucketName, fileName, contents);
  
              let attachments = [
                  {
                      filename: fileName,
                      path: filePath,
                  },
              ];

              total_number_paid_cpa_firm = total_number_paid_premium_cpa_firm+total_number_paid_enterprice_cpa_firm + total_number_paid_custom_cpa_firm;
              total_number_unpaid_cpa_firm = total_number_unpaid_premium_cpa_firm+total_number_unpaid_enterprice_cpa_firm+total_number_unpaid_custom_cpa_firm;
              
              let bodyText = "<p>Hi, PFA is the report and find following data.</p>"
              bodyText+= "<p>Total number of CPA firms registered: "+finalData.length+"</p>";
              bodyText+= "<p>Total Subscriptions (Paid + Unpaid) = "+total_number_paid_cpa_firm+" + "+total_number_unpaid_cpa_firm+" = "+(total_number_paid_cpa_firm + total_number_unpaid_cpa_firm)+"</p>"
              bodyText+= "<p>Breakup of Paid Subscriptions by Plan ("+total_number_paid_cpa_firm+")"
              bodyText+= "<ul style='list-style-type:none;'>"
              bodyText+= "<li style='margin-bottom: 1em;'>Premium Paid = "+total_number_paid_premium_cpa_firm+"</li>"
              bodyText+= "<li style='margin-bottom: 1em;'>Enterprise Paid = "+total_number_paid_enterprice_cpa_firm+"</li>"
              bodyText+= "<li style='margin-bottom: 1em;'>Custom Paid = "+total_number_paid_custom_cpa_firm+"</li>"
              bodyText+= "</ul>"
              bodyText+= "</p>"
              bodyText+= "<p>Breakup of Unpaid Subscriptions by Plan ("+total_number_unpaid_cpa_firm+")"
              bodyText+= "<ul style='list-style-type:none;'>"
              bodyText+= "<li style='margin-bottom: 1em;'>Premium Unpaid = "+total_number_unpaid_premium_cpa_firm+"</li>"
              bodyText+= "<li style='margin-bottom: 1em;'>Enterprise Unpaid = "+total_number_unpaid_enterprice_cpa_firm+"</li>"
              bodyText+= "<li style='margin-bottom: 1em;'>Custom Unpaid = "+total_number_unpaid_custom_cpa_firm+"</li>"
              bodyText+= "</ul>"
              bodyText+= "</p>";
              bodyText+= "<p>Total number of PPP2 applications created by CPA verified firms: "+total_number_ppp2_created_by_cpa_verified_firm+"</p>";
              bodyText+= "<p>Total number of PPP2 applications completed by CPA verified firms: "+total_number_ppp2_completed_by_cpa_verified_firm+"</p>";
              bodyText+= "<p>Total number of PPP2 applications created by all firms: "+total_number_ppp2_created_by_all_firm+"</p>";
              bodyText+= "<p>Total number of PPP2 applications completed by all firms: "+total_number_ppp2_completed_by_all_firm+"</p>";
              
              mailData = {
                  from_email: process.env.USER_INFO_EMAIL_FROM,
                  to_email: process.env.USER_INFO_EMAIL_TO_CPA,
                  subject:
                      "PPPForgivenessTool - CPA data as on " +
                      subjectDate,
                  html: bodyText,
                  attachments: attachments,
              };
              if (
                  process.env.USER_INFO_CC_EMAIL != undefined &&
                  process.env.USER_INFO_CC_EMAIL != ""
              ) {
                  mailData["cc"] = process.env.USER_INFO_CC_EMAIL;
              }
          } else {
              mailData = {
                  from_email: process.env.USER_INFO_EMAIL_FROM,
                  to_email: process.env.USER_INFO_EMAIL_TO_CPA,
                  subject:
                      "PPPForgivenessTool - CPA data as on " +
                      subjectDate,
                  text: "Hi, No CPA data was found",
              };
              if (
                  process.env.USER_INFO_CC_EMAIL != undefined &&
                  process.env.USER_INFO_CC_EMAIL != ""
              ) {
                  mailData["cc"] = process.env.USER_INFO_CC_EMAIL;
              }
          }
  
          let notification = await mailer.mailSender(mailData);
  
          fs.unlink(filePath, function (err) {
              if (err) {
                  reject(err);
              }
          });
  
          if (notification) {
              resolve(notification);
          } else {
              throw new Error("Mail not sent");
          }
          
        } catch (error) {
            reject(error);
        }
    }).catch(function (error) {
        throw error;
    });
};

exports.get_PPP_Application_Report = async () => {
    return new Promise(async function (resolve, reject) {
            try {
                let mailData = "";
                let filePath = "";
                const fields = [
                    "App Id",
                    "App Status",
                    // "App Stage",
                    "App Created Date",
                    "App Submitted Date",
                    "Case ID",
                    "Lead ID",
                    "Business Name",
                    "Loan Amount",
                    "Client Name",
                    "Client Email",
                    "CPA Firm",
                    "CPA Name",
                    "CPA Email",
                    "Application Type"
                ];

                const opts = { fields };
                const parser = new Parser(opts);

                 // Subject date
                let subjectDt = datetime.create();
                subjectDt.offsetInDays(-1);
                let subjectDate = subjectDt.format("Ymd");

                const reportData = [];

                const query = [
                    {
                        $match: {
                            is_deleted: {
                                $ne: true
                            },
                            backend_user_id: {
                                $exists: true
                            },
                            product_type: "5f40fb82b365b23a003e3708"
                        }
                    },
                    { $addFields: { id: { $toString: "$_id" } } },
                    {
                        $lookup: {
                            let: {appId: "$id"},
                            from: "service_business",
                            as: "b2c_status_ref",
                            pipeline: [
                                {
                                    $match: {
                                        $expr: {
                                            $eq: ["$$appId", "$app_id"]
                                        },
                                        type: "b2c_status"
                                    }
                                },
                                {
                                    $project: {
                                        _id:0,
                                        type:1,
                                        b2c_ref_id:"$ref_id",
                                        submitted_at: "$created_at"
                                    }
                                }
                            ]
                        }
                    },
                    {
                        $lookup: {
                            let: {appId: "$id"},
                            from: "business_info",
                            as: "business",
                            pipeline: [
                                {
                                    $match: {
                                        $expr: {
                                            $eq: ["$$appId", "$app_id"]
                                        }
                                    }
                                },
                                {
                                    $project: {
                                        business_name:1,
                                        current_state:1,
                                        loan_amount: '$qualified_loan_amount',
                                        _id:0
                                    }
                                }
                            ]
                        }
                    },
                    {
                        $project: {
                            _id: 0,
                            id: { $toString: "$_id" },
                            record_id: 1,
                            product_type: 1,
                            created_at: 1,
                            updated_at: 1,
                            status_id: 1,
                            backend_user_id:1,
                            user_id:1,
                            b2c_ref: { $arrayElemAt: ["$b2c_status_ref", 0] },
                            biz: { $arrayElemAt: ["$business", 0] } 
                        }
                    },
                    {
                        $replaceRoot: {
                            newRoot: {
                                $mergeObjects: ["$$ROOT", "$b2c_ref", "$biz"]
                            }
                        }
                    },
                    {
                        $project: { b2c_ref:0, biz:0 }
                    }
                ];

                const Applications = await application.getAggregate(query);

                 // collect backend_user_ids to find cpa
                // collect user_ids to find client 
                const AppUserBackckendUserGroup  = await application.getAggregate([
                    {$group: {_id: null, user_ids: { $addToSet: "$user_id" }, backend_ids: { $addToSet: "$backend_user_id" } }}
                ]);

                if(AppUserBackckendUserGroup && AppUserBackckendUserGroup.length) {
                    const {user_ids, backend_ids} = AppUserBackckendUserGroup[0];

                    const cpaUsersMap = {};
                    const clientMap = {};
                    if(user_ids && user_ids.length) {
                        const userRecords = await userModel.getAggregate([
                            { $addFields: {id: { $toString: "$_id" }} },
                            { $match: { id: { $in: user_ids } } },
                            { $project: {
                                _id:0,
                                id: {$toString: "$_id"},
                                email_address: 1,
                                name: "$user_data.name"
                            } }
                        ]);

                        if(userRecords && userRecords.length) {
                            userRecords.forEach((user) => {
                               clientMap[user.id] = user; 
                            });
                        }
                    }

                    if(backend_ids && backend_ids.length) {
                        const backendRecords = await backendUser.getAggregate([
                            { $match: {email_address: { $nin: [/@b2cdev/i, /@biz2credit/i] }} },
                            { $addFields: {id: { $toString: "$_id" }} },
                            { $match: { id: { $in: backend_ids } } },
                            { $project: {
                                _id:0,
                                id: {$toString: "$_id"},
                                email_address: 1,
                                name: 1,
                                cpa_firm_name: "$data.cpa_firm_name"
                            } }
                        ]);

                        if(backendRecords && backendRecords.length) {
                            backendRecords.forEach((cpa) => {
                                cpaUsersMap[cpa.id] = cpa; 
                            });
                        }
                    }

                    //get all master status
                    const statusMap = {};
                    const appStatuss = await appStatus.find({}, { _id:1, value:1 });
                    if(appStatuss && appStatuss.length) {
                        appStatuss.forEach((status) => {
                            const s = status.toObject();
                            statusMap[s._id.toString()] = s.value;
                        });
                    }

                    // get all master status
                    const appTypeMap = {};
                    const appTypes = await appTypeModel.find({}, { _id:1, type:1 });
                    if(appTypes && appTypes.length) {
                        appTypes.forEach((aType) => {
                            const type = aType.toObject();
                            appTypeMap[type._id.toString()] = type.type;
                        });
                    }

                    // fetch all b2c_status ref id from service business
                    const b2cReferences = await serviceBusinessModel.getAggregate([
                        {
                            $match: {
                                type: 'b2c_status'
                            }
                         },
                         {
                             $project: {
                                 _id:0,
                                 ref_id: 1,
                             }
                         },
                         {
                             $group: {
                                 _id: null,
                                 ids: {
                                     $push: "$ref_id"
                                 }
                             }
                         }
                    ]);

                    const refLeadMap = {};
                    // get all the leadIds from ref_ids
                    if(b2cReferences && b2cReferences.length && b2cReferences[0].ids && b2cReferences[0].ids.length) {
                        // get all the lead ids

                        const pppLeads = await PPPAppLeadModel.getAggregate([
                            {
                                $addFields: { id: { $toString: "$_id" } }
                            },
                            { 
                                $match: {
                                    id: { $in: b2cReferences[0].ids }
                                }
                            },
                            { $addFields: { len:  {$size: {$ifNull: ["$application_status", []]}}}},
                            {
                                $project: {
                                    id:1, 
                                    _id:0,
                                    request_id:1,
                                    status: { 
                                        $arrayElemAt: ["$application_status", { $subtract: ["$len", 1] }] 
                                    } 
                                }
                            }
                        ]);

                        if(pppLeads && pppLeads.length) {
                            pppLeads.forEach((lead) => {
                                refLeadMap[lead.id] = lead.request_id;
                                refLeadMap[lead.id] = {
                                   request_id: lead.request_id,
                                   status: helper.getStatus(lead.status && lead.status.status?lead.status.status:'default')
                                };
                            });
                        }
                    }

                    for (let index = 0; index < Applications.length; index++) {
                        const app = Applications[index];
                        
                        if(app.backend_user_id && !cpaUsersMap[app.backend_user_id]) {
                            continue;
                        }

                        const appData = {
                            "App Id": `APP${app.record_id}`,
                            "App Status": "",
                            // "App Stage":  "",
                            "App Created Date": helper.formatDate(new Date(app.created_at * 1000)),
                            "App Submitted Date": app.submitted_at ? helper.formatDate(new Date(app.submitted_at * 1000)): '',
                            "Case ID": "",
                            "Lead ID":"",
                            "Business Name": app.business_name,
                            "Loan Amount": app.loan_amount || '',
                            "Client Name":"",
                            "Client Email":"",
                            "CPA Firm":"",
                            "CPA Name":"",
                            "CPA Email":"",
                            "Application Type":""
                        };

                        if(app.b2c_ref_id && refLeadMap[app.b2c_ref_id] && refLeadMap[app.b2c_ref_id].request_id) {
                            const splitted = refLeadMap[app.b2c_ref_id].request_id.split('-');
                            appData['Lead ID'] = splitted[0];
                            appData['Case ID'] = splitted[1];
                            appData['App Status'] = refLeadMap[app.b2c_ref_id].status;
                        }

                        if(app.product_type && appTypeMap[app.product_type]){
                            appData['Application Type'] = appTypeMap[app.product_type];
                        } 

                        if(app.status_id && statusMap[app.status_id]){
                            // appData['App Status'] = statusMap[app.status_id];

                            if(!appData['App Status'] && !app.submitted_at) {
                                
                                if(statusMap[app.status_id] === "Submitted") {
                                    appData['App Status'] = 'Application Completed';
                                    appData["App Submitted Date"] = helper.formatDate(new Date(app.updated_at * 1000));
                                } else if(statusMap[app.status_id] ==="Rejected by SBA") {
                                    appData["App Submitted Date"] = helper.formatDate(new Date(app.updated_at * 1000));
                                    appData['App Status'] = 'Duplicate Application Found';
                               }
                            }
                        } 

                        if(!appData['App Status']) {
                            appData['App Status'] = helper.getAppStage(app.current_state || "", appData['Application Type']);
                        }

                        // appData["App Stage"] = helper.getAppStage(app.current_state || "", appData['Application Type']);

                        if(app.user_id && clientMap[app.user_id]) {
                            appData['Client Name'] = clientMap[app.user_id].name;
                            appData['Client Email'] = clientMap[app.user_id].email_address;
                        } 
                        
                        if(app.backend_user_id && cpaUsersMap[app.backend_user_id]) {
                            appData['CPA Name'] = cpaUsersMap[app.backend_user_id].name;
                            appData['CPA Email'] = cpaUsersMap[app.backend_user_id].email_address;
                            appData['CPA Firm'] = cpaUsersMap[app.backend_user_id].cpa_firm_name;
                        } 

                        reportData.push(appData);
                    };

                }

                if(reportData && reportData.length) {
                    let contents = parser.parse(reportData);
                    // Temporary file name
                    let attach_fileName = "aicpa-application-report.csv";

                    if (process.env.NODE_ENV == "local") {
                        filePath = path.resolve(attach_fileName);
                    } else {
                        filePath = path.resolve("/tmp/" + attach_fileName);
                    }

                    const writeStream = fs.createWriteStream(filePath);
                    writeStream.write(contents);

                    writeStream.on("finish", () => {
                        console.log("wrote all data to file");
                    });

                    writeStream.end();

                    let prefixDt = datetime.create();
                    prefixDt.offsetInDays(-1);
                    let prefixDate = prefixDt.format("Ymd");
                    let folderData = prefixDt.format("Y-m-d");
                    let splitDate = folderData.split("-");
                    let prefix =
                        "reports/aicpa-report/" +
                        process.env.NODE_ENV +
                        "/" +
                        splitDate[0] +
                        "/" +
                        splitDate[1];
                    let fileName = prefixDate + "-aicpa-application-report.csv";
                    let bucketName = process.env.BUCKET_NAME + "/" + prefix;

                    await awsS3.createLogFile(bucketName, fileName, contents);

                    let fileUrl = process.env.BUCKET_URL +"/" + prefix +"/"+ fileName;
                    let bodyText = "<p>Hi, Please download the application level report by clicking the following link.</p></br><p><a href='"+fileUrl+"' target='_blank'>Download Report</a></p>";
                  
                    mailData = {
                        from_email: process.env.USER_INFO_EMAIL_FROM,
                        to_email: process.env.USER_INFO_EMAIL_TO_CPA,
                        subject:
                            "CPALoanPortal - Application data as on " +
                            subjectDate,
                        html: bodyText
                    };
                    if (
                        process.env.USER_INFO_CC_EMAIL != undefined &&
                        process.env.USER_INFO_CC_EMAIL != ""
                    ) {
                        mailData["cc"] = process.env.USER_INFO_CC_EMAIL;
                    }
    
                } else {
                    mailData = {
                        from_email: process.env.USER_INFO_EMAIL_FROM,
                        to_email: process.env.USER_INFO_EMAIL_TO_CPA,
                        subject:
                            "CPALoanPortal - Application data as on " +
                            subjectDate,
                        text: "Hi, No Application data was found",
                    };
                    if (
                        process.env.USER_INFO_CC_EMAIL != undefined &&
                        process.env.USER_INFO_CC_EMAIL != ""
                    ) {
                        mailData["cc"] = process.env.USER_INFO_CC_EMAIL;
                    }
                }

                let notification = await mailer.mailSender(mailData);
  
                fs.unlink(filePath, function (err) {
                    if (err) {
                        reject(err);
                    }
                });
        
                if (notification) {
                    resolve(notification);
                } else {
                    throw new Error("Mail not sent");
                }

            } catch (error) {
                reject(error);
            }
    }).catch(function (error) {
        throw error;
    });
}


exports.get_PPP_Business_Report = async () => {
    return new Promise(async function (resolve, reject) {
            try {
                let mailData = "";
                let filePath = "";
                const fields = [
                    "Case ID",
                    "Business name",
                    "CPA Email address",
                    "CPA case ID",
                    "Total employees entered",
                    "Average monthly payroll",
                    "Total eligibility amount calculated by system",
                    "Current status",
                    "Case Created Date",
                    "Case Submitted Date to Biz2Credit",
                    // "Application Type"
                ];

                const opts = { fields };
                const parser = new Parser(opts);

                 // Subject date
                let subjectDt = datetime.create();
                subjectDt.offsetInDays(-1);
                let subjectDate = subjectDt.format("Ymd");

                const reportData = [];

                const query = [
                    { 
                        $match: { 
                            "eligibility_question.biz_employ_people": "5e8723158f2f4e3ac475fae7" 
                        } 
                    },
                    { 
                        $project: { 
                            _id:0, 
                            business_name:1, 
                            app_id:1, 
                            number_of_employees:1, 
                            average_monthly_payroll:1, 
                            qualified_loan_amount:1, 
                            current_state:1
                        } 
                    },
                    { $addFields: { id: { $toObjectId: "$app_id" } } },
                    {
                        $lookup: {
                            let: {appId: "$id"},
                            from: "application",
                            as: "app",
                            pipeline: [
                                {
                                    $match: {
                                        $expr: {
                                            $eq: ["$$appId", "$_id"]
                                        }
                                    }
                                },
                                {
                                    $project: {
                                        _id:0,
                                        record_id: 1,
                                        product_type: 1,
                                        created_at: 1,
                                        updated_at: 1,
                                        status_id: 1,
                                        backend_user_id:1,
                                        user_id:1,
                                    }
                                }
                            ]
                        }
                    },
                    {
                        $lookup: {
                            let: {appId: "$app_id"},
                            from: "service_business",
                            as: "b2c_status_ref",
                            pipeline: [
                                {
                                    $match: {
                                        $expr: {
                                            $eq: ["$$appId", "$app_id"]
                                        },
                                        type: "b2c_status"
                                    }
                                },
                                {
                                    $project: {
                                        _id:0,
                                        type:1,
                                        b2c_ref_id:"$ref_id",
                                        submitted_at: "$created_at"
                                    }
                                }
                            ]
                        }
                    },
                    {
                        $project: {
                            _id: 0,
                            id: { $toString: "$_id" },
                            record_id: 1,
                            product_type: 1,
                            created_at: 1,
                            updated_at: 1,
                            status_id: 1,
                            backend_user_id:1,
                            user_id:1,
                            business_name:1, 
                            app_id:1, 
                            number_of_employees:1, 
                            average_monthly_payroll:1, 
                            qualified_loan_amount:1, 
                            current_state:1,
                            b2c_ref: { $arrayElemAt: ["$b2c_status_ref", 0] },
                            app: { $arrayElemAt: ["$app", 0] } 
                        }
                    },
                    {
                        $replaceRoot: {
                            newRoot: {
                                $mergeObjects: ["$$ROOT", "$b2c_ref", "$app"]
                            }
                        }
                    },
                    {
                        $project: { b2c_ref:0, app:0 }
                    }
                ];

                const Applications = await businessInfo.getAggregate(query);

                 // collect backend_user_ids to find cpa
                // collect user_ids to find client 
                const AppUserBackckendUserGroup  = await application.getAggregate([
                    {
                        $match: {
                            is_deleted: {
                                $ne: true
                            },
                            backend_user_id: {
                                $exists: true
                            }
                        }
                    },
                    {$group: {_id: null, backend_ids: { $addToSet: "$backend_user_id" } }}
                ]);

                if(AppUserBackckendUserGroup && AppUserBackckendUserGroup.length) {
                    const {backend_ids} = AppUserBackckendUserGroup[0];

                    const cpaUsersMap = {};
                    // const clientMap = {};

                    if(backend_ids && backend_ids.length) {
                        const backendRecords = await backendUser.getAggregate([
                            { $match: {email_address: { $nin: [/@b2cdev/i, /@biz2credit/i] }} },
                            { $addFields: {id: { $toString: "$_id" }} },
                            { $match: { id: { $in: backend_ids } } },
                            { $project: {
                                _id:0,
                                id: {$toString: "$_id"},
                                email_address: 1,
                                name: 1,
                                cpa_firm_name: "$data.cpa_firm_name"
                            } }
                        ]);

                        if(backendRecords && backendRecords.length) {
                            backendRecords.forEach((cpa) => {
                                cpaUsersMap[cpa.id] = cpa; 
                            });
                        }
                    }

                    //get all master status
                    const statusMap = {};
                    const appStatuss = await appStatus.find({}, { _id:1, value:1 });
                    if(appStatuss && appStatuss.length) {
                        appStatuss.forEach((status) => {
                            const s = status.toObject();
                            statusMap[s._id.toString()] = s.value;
                        });
                    }

                    // get all master status
                    const appTypeMap = {};
                    const appTypes = await appTypeModel.find({}, { _id:1, type:1 });
                    if(appTypes && appTypes.length) {
                        appTypes.forEach((aType) => {
                            const type = aType.toObject();
                            appTypeMap[type._id.toString()] = type.type;
                        });
                    }

                    // fetch all b2c_status ref id from service business
                    const b2cReferences = await serviceBusinessModel.getAggregate([
                        {
                            $match: {
                                type: 'b2c_status'
                            }
                         },
                         {
                             $project: {
                                 _id:0,
                                 ref_id: 1,
                             }
                         },
                         {
                             $group: {
                                 _id: null,
                                 ids: {
                                     $push: "$ref_id"
                                 }
                             }
                         }
                    ]);

                    const refLeadMap = {};
                    // get all the leadIds from ref_ids
                    if(b2cReferences && b2cReferences.length && b2cReferences[0].ids && b2cReferences[0].ids.length) {
                        // get all the lead ids

                        const pppLeads = await PPPAppLeadModel.getAggregate([
                            {
                                $addFields: { id: { $toString: "$_id" } }
                            },
                            { 
                                $match: {
                                    id: { $in: b2cReferences[0].ids }
                                }
                            },
                            { $addFields: { len:  {$size: {$ifNull: ["$application_status", []]}}}},
                            {
                                $project: {
                                    id:1, 
                                    _id:0,
                                    request_id:1,
                                    status: { 
                                        $arrayElemAt: ["$application_status", { $subtract: ["$len", 1] }] 
                                    } 
                                }
                            }
                        ]);

                        if(pppLeads && pppLeads.length) {
                            pppLeads.forEach((lead) => {
                                refLeadMap[lead.id] = lead.request_id;
                                refLeadMap[lead.id] = {
                                   request_id: lead.request_id,
                                   status: helper.getStatus(lead.status && lead.status.status?lead.status.status:'default')
                                };
                            });
                        }
                    }

                    for (let index = 0; index < Applications.length; index++) {
                        const app = Applications[index];
                        
                        if(app.backend_user_id && !cpaUsersMap[app.backend_user_id]) {
                            continue;
                        }

                        const appData = {
                            "Case ID": "",
                            "Business name": app.business_name,
                            "CPA Email address": "",
                            "CPA case ID": `APP${app.record_id}`,
                            "Total employees entered": app.number_of_employees,
                            "Average monthly payroll": app.qualified_loan_amount,
                            "Total eligibility amount calculated by system": app.qualified_loan_amount || '',
                            "Current status": "",
                            "Case Created Date": helper.formatDate(new Date(app.created_at * 1000)),
                            "Case Submitted Date to Biz2Credit": app.submitted_at ? helper.formatDate(new Date(app.submitted_at * 1000)): '',
                            "Application Type":""
                        };

                        if(app.b2c_ref_id && refLeadMap[app.b2c_ref_id] && refLeadMap[app.b2c_ref_id].request_id) {
                            const splitted = refLeadMap[app.b2c_ref_id].request_id.split('-');
                            appData['Case ID'] = splitted[1];
                            appData['Current status'] = refLeadMap[app.b2c_ref_id].status;
                        }

                        // if(app.product_type && appTypeMap[app.product_type]){
                        //     appData['Application Type'] = appTypeMap[app.product_type];
                        // } 

                        if(app.status_id && statusMap[app.status_id]){
                            // appData['App Status'] = statusMap[app.status_id];

                            if(!appData['Current status'] && !app.submitted_at) {
                                
                                if(statusMap[app.status_id] === "Submitted") {
                                    appData['Current status'] = 'Application Completed';
                                    appData["Case Submitted Date to Biz2Credit"] = helper.formatDate(new Date(app.updated_at * 1000));
                                } else if(statusMap[app.status_id] ==="Rejected by SBA") {
                                    appData["Case Submitted Date to Biz2Credit"] = helper.formatDate(new Date(app.updated_at * 1000));
                                    appData['Current status'] = 'Duplicate Application Found';
                               }
                            }
                        } 

                        if(!appData['Current status']) {
                            appData['Current status'] = helper.getAppStage(app.current_state || "", 'ppp2');
                        }

                        if(app.backend_user_id && cpaUsersMap[app.backend_user_id]) {
                            // appData['CPA Name'] = cpaUsersMap[app.backend_user_id].name;
                            appData['CPA Email address'] = cpaUsersMap[app.backend_user_id].email_address;
                            // appData['CPA Firm'] = cpaUsersMap[app.backend_user_id].cpa_firm_name;
                        } 

                        reportData.push(appData);
                    };

                }

                if(reportData && reportData.length) {
                    let contents = parser.parse(reportData);
                    // Temporary file name
                    let attach_fileName = "aicpa-business-report.csv";

                    if (process.env.NODE_ENV == "local") {
                        filePath = path.resolve(attach_fileName);
                    } else {
                        filePath = path.resolve("/tmp/" + attach_fileName);
                    }

                    const writeStream = fs.createWriteStream(filePath);
                    writeStream.write(contents);

                    writeStream.on("finish", () => {
                        console.log("wrote all data to file");
                    });

                    writeStream.end();

                    let prefixDt = datetime.create();
                    prefixDt.offsetInDays(-1);
                    let prefixDate = prefixDt.format("Ymd");
                    let folderData = prefixDt.format("Y-m-d");
                    let splitDate = folderData.split("-");
                    let prefix =
                        "reports/aicpa-report/" +
                        process.env.NODE_ENV +
                        "/" +
                        splitDate[0] +
                        "/" +
                        splitDate[1];
                    let fileName = prefixDate + "-aicpa-business-report.csv";
                    let bucketName = process.env.BUCKET_NAME + "/" + prefix;

                    await awsS3.createLogFile(bucketName, fileName, contents);
  
                    let attachments = [
                        {
                            filename: fileName,
                            path: filePath,
                        },
                    ];

                    let bodyText = "<p>Hi, Please find the business report attached.</p>";
                    
                    mailData = {
                        from_email: process.env.USER_INFO_EMAIL_FROM,
                        to_email: process.env.USER_INFO_EMAIL_TO_CPA,
                        subject:
                            "CPALoanPortal - Business data as on " +
                            subjectDate,
                        html: bodyText,
                        attachments: attachments,
                    };
                    if (
                        process.env.USER_INFO_CC_EMAIL != undefined &&
                        process.env.USER_INFO_CC_EMAIL != ""
                    ) {
                        mailData["cc"] = process.env.USER_INFO_CC_EMAIL;
                    }
    
                } else {
                    mailData = {
                        from_email: process.env.USER_INFO_EMAIL_FROM,
                        to_email: process.env.USER_INFO_EMAIL_TO_CPA,
                        subject:
                            "CPALoanPortal - Application data as on " +
                            subjectDate,
                        text: "Hi, No Application data was found",
                    };
                    if (
                        process.env.USER_INFO_CC_EMAIL != undefined &&
                        process.env.USER_INFO_CC_EMAIL != ""
                    ) {
                        mailData["cc"] = process.env.USER_INFO_CC_EMAIL;
                    }
                }

                let notification = await mailer.mailSender(mailData);
  
                fs.unlink(filePath, function (err) {
                    if (err) {
                        reject(err);
                    }
                });
        
                if (notification) {
                    resolve(notification);
                } else {
                    throw new Error("Mail not sent");
                }

            } catch (error) {
                reject(error);
            }
    }).catch(function (error) {
        throw error;
    });
}

exports.cpaFirmReport = async () => {
    return new Promise(async function (resolve, reject) {
        try {
            let mailData = "";
            let filePath = "";
            const fields = [
                "Case ID",
                "Application Type",
                "Loan Number",
                "Business Name",
                "Lender",
                "Funded Date",
                "Funded Amount",
                "Commission",
                "Opt-Out",
                "App Status",
                "Total Amount for CPA Firm",
                "CPA Firm",
                "CPA Email ID",
                "CPA Phone Number",
                "CPA Verified",
                "CPA Firm Subscription",
                "CPA Bank Name",
                "CPA Routing Number",
                "CPA Account Number",
                "CPA Account Type",
                "TAX ID"
            ];

            const opts = { fields };
            const parser = new Parser(opts);

            // Subject date
            let subjectDt = datetime.create();
            subjectDt.offsetInDays(-1);
            let subjectDate = subjectDt.format("Ymd");

            let reportData = [];

            const query = [
                {
                    $match: {
                        is_deleted: {
                            $ne: true
                        },
                        backend_user_id: {
                            $exists: true,
                        },
                        product_type: "5f40fb82b365b23a003e3708",
                        status_id: "5c20bf7e27105c78ad7f9280",
                        backend_user_id: '5ff9dfe55f1d600058bf497f'
                    }
                },
                { $addFields: { id: { $toString: "$_id" } } },
                {
                    $lookup: {
                        let: { appId: "$id" },
                        from: "service_business",
                        as: "b2c_status_ref",
                        pipeline: [
                            {
                                $match: {
                                    $expr: {
                                        $eq: ["$$appId", "$app_id"]
                                    },
                                    type: "b2c_status"
                                }
                            },
                            {
                                $project: {
                                    _id: 0,
                                    type: 1,
                                    b2c_ref_id: "$ref_id",
                                    submitted_at: "$created_at"
                                }
                            }
                        ]
                    }
                },
                {
                    $lookup: {
                        let: { appId: "$id" },
                        from: "business_info",
                        as: "business",
                        pipeline: [
                            {
                                $match: {
                                    $expr: {
                                        $eq: ["$$appId", "$app_id"]
                                    }
                                }
                            },
                            {
                                $project: {
                                    business_name: 1,
                                    current_state: 1,
                                    loan_amount: '$qualified_loan_amount',
                                    sba_loan_no: 1,
                                    _id: 0
                                }
                            }
                        ]
                    }
                },
                {
                    $project: {
                        _id: 0,
                        id: { $toString: "$_id" },
                        record_id: 1,
                        product_type: 1,
                        created_at: 1,
                        updated_at: 1,
                        status_id: 1,
                        backend_user_id: 1,
                        user_id: 1,
                        b2c_ref: { $arrayElemAt: ["$b2c_status_ref", 0] },
                        biz: { $arrayElemAt: ["$business", 0] }
                    }
                },
                {
                    $replaceRoot: {
                        newRoot: {
                            $mergeObjects: ["$$ROOT", "$b2c_ref", "$biz"]
                        }
                    }
                },
                {
                    $project: { b2c_ref: 0, biz: 0 }
                }
            ];

            let Applications = await application.getAggregate(query);
            const appIds = Applications.map(app => app.id);

            // fetch all b2c_status ref id from service business
            const b2cReferences = await serviceBusinessModel.getAggregate([
                {
                    $match: {
                        type: 'b2c_status'
                    }
                },
                {
                    $project: {
                        _id: 0,
                        ref_id: 1,
                    }
                },
                {
                    $group: {
                        _id: null,
                        ids: {
                            $push: "$ref_id"
                        }
                    }
                }
            ]);

            const refLeadMap = {};
            // get all the leadIds from ref_ids
            if (b2cReferences && b2cReferences.length && b2cReferences[0].ids && b2cReferences[0].ids.length) {
                // get all the lead ids

                const pppLeads = await PPPAppLeadModel.getAggregate([
                    {
                        $addFields: { id: { $toString: "$_id" } }
                    },
                    {
                        $match: {
                            id: { $in: b2cReferences[0].ids }
                        }
                    },
                    { $addFields: { len: { $size: { $ifNull: ["$application_status", []] } } } },
                    {
                        $project: {
                            id: 1,
                            _id: 0,
                            request_id: 1,
                            status: {
                                $arrayElemAt: ["$application_status", { $subtract: ["$len", 1] }]
                            }
                        }
                    }
                ]);

                if (pppLeads && pppLeads.length) {
                    pppLeads.forEach((lead) => {
                        refLeadMap[lead.id] = {
                            request_id: lead.request_id,
                            status: helper.getStatus(lead.status && lead.status.status ? lead.status.status : 'default'),
                            sba_loan_number: (lead.status && lead.status.sba_loan_number) ? lead.status.sba_loan_number : '',
                            sba_decision_date: helper.formatDate(helper.getFundedDate(lead)),
                            amount: lead.status ? lead.status.amount : '',
                            commission_amount: lead.status ? helper.calculateCommission(lead.status.amount) : 0
                        };
                    });
                }
            }

            Applications = Applications.filter((app) => {
                if (refLeadMap[app.b2c_ref_id] && refLeadMap[app.b2c_ref_id].status === 'Funded') {
                    return app;
                }
            });

            const appRecords = await appRecordsModel.getAggregate([{
                $match: {
                    $and: [
                        {app_type: { $eq: 'WITH_AGENT_FEE' }},
                        {request_id: { $in: appIds}}
                    ]
                }
                },
                {
                    $project: {
                        app_type: 1,
                        request_id: 1,
                        opt_out: 1
                    }
                }
            ]);
            const optOutMappings = {};
            const AppsToBeMapped = [];
            appRecords.map((app) => {
                AppsToBeMapped.push(app.request_id);
                optOutMappings[app.request_id] = app.opt_out;
            });

            Applications = Applications.filter((app) => {
                if (AppsToBeMapped.indexOf(app.id) > -1) {
                    return app;
                }
            })
            
            const AppUserBackckendUserGroup = await application.getAggregate([
                { $group: { _id: null, backend_ids: { $addToSet: "$backend_user_id" } } }
            ]);

            if (AppUserBackckendUserGroup && AppUserBackckendUserGroup.length) {
                let { backend_ids } = AppUserBackckendUserGroup[0];
                const cpaUsersMap = {};
                const backendAdminMap = {};
                const adminFirmNameMap = {};
                const cpaAdminUsersMap = {};

                const email_addresses = [];
                if (backend_ids && backend_ids.length) {
                    const backendRecords = await backendUser.getAggregate([
                        { $match: { 'data.cpa_firm_name': 'ROB SORUM CPA PC' } },
                        { $match: { email_address: { $nin: [/@b2cdev/i, /@biz2credit/i] } } },
                        { $addFields: { id: { $toString: "$_id" } } },
                        {
                            $match: {
                                id: { $in: backend_ids },
                                is_active: {$ne: false},
                                is_verified: {$ne: false}
                            }
                        },
                        {
                            $project: {
                                _id: 0,
                                id: { $toString: "$_id" },
                                email_address: 1,
                                phone_number: 1,
                                name: 1,
                                cpa_firm_name: "$data.cpa_firm_name",
                                cpa_bank_name: "$data.bank_name",
                                cpa_verified: "$data.cpa_verified",
                                routing_number: '$data.routing_number',
                                account_number: '$data.account_number',
                                account_type: '$data.account_type',
                                tax_number: '$data.tax_id',
                                registration_type: '$data.registration_type'
                            }
                        }
                    ]);

                    if (backendRecords && backendRecords.length) {
                        backendRecords.forEach((cpa) => {
                            cpaUsersMap[cpa.id] = cpa;
                            email_addresses.push(cpa.email_address);

                            // adminFirmNameMap.push(cpa.cpa_firm_name);
                            if(!adminFirmNameMap[cpa.cpa_firm_name]) {
                                adminFirmNameMap[cpa.cpa_firm_name] = cpa.cpa_firm_name
                            }
                            if (cpa.registration_type === 'normal') {
                                backendAdminMap[cpa.cpa_firm_name] = cpa;
                            }
                        });
                    }
                }

                const adminCpaRecords = await backendUser.getAggregate([
                    { $match: { 
                        'data.cpa_firm_name': {$in: Object.keys(adminFirmNameMap)},
                        'data.registration_type': 'normal',
                        is_active: {$ne: false},
                        is_verified: {$ne: false}
                     }},
                    { $addFields: { id: { $toString: "$_id" } } },
                    {
                        $project: {
                            _id: 0,
                            id: { $toString: "$_id" },
                            email_address: 1,
                            phone_number: 1,
                            name: 1,
                            cpa_firm_name: "$data.cpa_firm_name",
                            cpa_bank_name: "$data.bank_name",
                            cpa_verified: "$data.cpa_verified",
                            routing_number: '$data.routing_number',
                            account_number: '$data.account_number',
                            account_type: '$data.account_type',
                            tax_number: '$data.tax_id',
                            registration_type: '$data.registration_type'
                        }
                    }
                ]);

                if (adminCpaRecords && adminCpaRecords.length) {
                    adminCpaRecords.forEach((cpa) => {
                        cpaAdminUsersMap[cpa.cpa_firm_name] = cpa;
                    });
                }

                // perform query to get active plan under the firm
                let activeUserPlans = await userPlans.getAggregate([
                    {
                        $match: {
                            firm_name: { $in: Object.keys(adminFirmNameMap) },
                            // email_address: { $in: email_addresses },
                            is_active: true
                        },
                    },
                    {
                        $lookup: {
                            from: "plans",
                            localField: "plan_id",
                            foreignField: '_id',
                            as: 'plans'
                        }
                    },
                    {
                        $project: {
                            plan_id: 1,
                            firm_name: 1,
                            email_address: 1,
                            plan_price: {
                                $arrayToObject: {
                                    $map: {
                                        input: "$plans",
                                        as: "p",
                                        in: {
                                            k: "plan",
                                            v: "$$p",
                                        }
                                    }
                                }
                            }
                        }
                    },
                    {
                        $replaceRoot: {
                            newRoot: {
                                $mergeObjects: ["$$ROOT", "$plan_price"]
                            }
                        }
                    },
                    {
                        $project: {
                            type: "$plan.type",
                            price: "$plan.price",
                            plan_id: 1,
                            firm_name: 1,
                            email_address: 1,
                        }
                    }
                ]);

                // map plan with email and firm to identify using firm or email address below
                const firmMap = {};
                activeUserPlans.forEach((plan) => {
                    if (plan.firm_name) {
                        firmMap[plan.firm_name] = plan;
                    }
                });

                //get all master status
                const statusMap = {};
                const appStatuss = await appStatus.find({}, { _id: 1, value: 1 });
                if (appStatuss && appStatuss.length) {
                    appStatuss.forEach((status) => {
                        const s = status.toObject();
                        statusMap[s._id.toString()] = s.value;
                    });
                }

                // get all master status
                const appTypeMap = {};
                const appTypes = await appTypeModel.find({}, { _id: 1, type: 1 });
                if (appTypes && appTypes.length) {
                    appTypes.forEach((aType) => {
                        const type = aType.toObject();
                        appTypeMap[type._id.toString()] = type.type;
                    });
                }

                for (let index = 0; index < Applications.length; index++) {
                    const app = Applications[index];

                    if (app.backend_user_id && !cpaUsersMap[app.backend_user_id]) {
                        continue;
                    }

                    const appData = {
                        "Case ID": "",
                        "CPA Firm": "",
                        "CPA Email ID": "",
                        "CPA Phone Number": "",
                        "Application Type": "",
                        "Loan Number": "",
                        "Business Name": app.business_name,
                        "Lender": 'Itria',
                        "Funded Date": "",
                        "Funded Amount": "",
                        "CPA Firm Subscription": "",
                        "CPA Bank Name": "",
                        "Total Amount for CPA Firm": "",
                        "Commission": "",
                        "Opt-Out": optOutMappings[app.id] || false,
                        "App Status": "",
                        "CPA Verified": "",
                        "CPA Routing Number": "",
                        "CPA Account Number": "",
                        "CPA Account Type": "",
                        "TAX ID": ""
                    };

                    if (app.b2c_ref_id && refLeadMap[app.b2c_ref_id] && refLeadMap[app.b2c_ref_id].request_id) {
                        const splitted = refLeadMap[app.b2c_ref_id].request_id.split('-');
                        appData['Case ID'] = splitted[1];
                        appData['App Status'] = refLeadMap[app.b2c_ref_id].status;
                        appData['Loan Number'] = refLeadMap[app.b2c_ref_id].sba_loan_number ? refLeadMap[app.b2c_ref_id].sba_loan_number : app.sba_loan_no;
                        appData['Funded Amount'] = refLeadMap[app.b2c_ref_id].amount;
                        appData['Funded Date'] = refLeadMap[app.b2c_ref_id].sba_decision_date;
                        appData['Commission'] = refLeadMap[app.b2c_ref_id].commission_amount;
                    }

                    if (app.product_type && appTypeMap[app.product_type]) {
                        appData['Application Type'] = appTypeMap[app.product_type];
                    }

                    const adminCpa = backendAdminMap[cpaUsersMap[app.backend_user_id].cpa_firm_name] || cpaAdminUsersMap[cpaUsersMap[app.backend_user_id].cpa_firm_name];
                    if (app.backend_user_id && adminCpa) {
                        const selectedPlan = firmMap[adminCpa.cpa_firm_name];
                        if (selectedPlan && selectedPlan.type !=='free') {
                            appData['CPA Firm'] = adminCpa.cpa_firm_name;
                            appData['CPA Bank Name'] = adminCpa.cpa_bank_name;
                            appData['CPA Verified'] = adminCpa.cpa_verified;
                            
                            appData['CPA Firm Subscription'] = selectedPlan ? selectedPlan.type : "",
                            appData['CPA Routing Number'] = adminCpa.routing_number;
                            appData['CPA Account Number'] = adminCpa.account_number;
                            appData['CPA Account Type'] = adminCpa.account_type;
                            appData['TAX ID'] = adminCpa.tax_number;
                            appData['CPA Email ID'] = adminCpa.email_address;
                            appData['CPA Phone Number'] = adminCpa.phone_number;
                            reportData.push(appData);
                        }
                    }
                };
            }
            const totalCommissionData = {};
            reportData.forEach(data => {
                if (totalCommissionData[data['CPA Firm']]) {
                    totalCommissionData[data['CPA Firm']] += data['Commission'] ? data['Commission'] : 0
                } else {
                    totalCommissionData[data['CPA Firm']] = data['Commission'] ? data['Commission'] : 0
                }
            });
            reportData = reportData.map(report => {
                report['Total Amount for CPA Firm'] = totalCommissionData[report['CPA Firm']];
                return report;
            });


            if (reportData && reportData.length) {
                let contents = parser.parse(reportData);
                // Temporary file name
                let attach_fileName = "ppp-application-report.csv";

                if (process.env.NODE_ENV == "local") {
                    filePath = path.resolve(attach_fileName);
                } else {
                    filePath = path.resolve("/tmp/" + attach_fileName);
                }

                const writeStream = fs.createWriteStream(filePath);
                writeStream.write(contents);

                writeStream.on("finish", () => {
                    console.log("wrote all data to file");
                });

                writeStream.end();
                let prefixDt = datetime.create();
                prefixDt.offsetInDays(-1);
                let prefixDate = prefixDt.format("Ymd");
                let folderData = prefixDt.format("Y-m-d");
                let splitDate = folderData.split("-");
                let prefix =
                    "reports/aicpa-report/" +
                    process.env.NODE_ENV +
                    "/" +
                    splitDate[0] +
                    "/" +
                    splitDate[1];
                let fileName = prefixDate + "-ppp-application-report.csv";
                let bucketName = process.env.BUCKET_NAME + "/" + prefix;

                // await awsS3.createLogFile(bucketName, fileName, contents);

                let fileUrl = process.env.BUCKET_URL + "/" + prefix + "/" + fileName;
                let bodyText = "<p>Hi, Please download the application level report by clicking the following link.</p></br><p><a href='" + fileUrl + "' target='_blank'>Download Report</a></p>";

                mailData = {
                    from_email: process.env.USER_INFO_EMAIL_FROM,
                    to_email: process.env.USER_INFO_EMAIL_TO_CPA,
                    subject:
                        "CPALoanPortal - Application data as on " +
                        subjectDate,
                    html: bodyText
                };
                if (
                    process.env.USER_INFO_CC_EMAIL != undefined &&
                    process.env.USER_INFO_CC_EMAIL != ""
                ) {
                    mailData["cc"] = process.env.USER_INFO_CC_EMAIL;
                }

            } else {
                mailData = {
                    from_email: process.env.USER_INFO_EMAIL_FROM,
                    to_email: process.env.USER_INFO_EMAIL_TO_CPA,
                    subject:
                        "CPALoanPortal - Application data as on " +
                        subjectDate,
                    text: "Hi, No Application data was found",
                };
                if (
                    process.env.USER_INFO_CC_EMAIL != undefined &&
                    process.env.USER_INFO_CC_EMAIL != ""
                ) {
                    mailData["cc"] = process.env.USER_INFO_CC_EMAIL;
                }
            }

            // let notification = await mailer.mailSender(mailData);

            // fs.unlink(filePath, function (err) {
            //     if (err) {
            //         reject(err);
            //     }
            // });

            resolve(reportData);
            // if (notification) {
            //     resolve(notification);
            // } else {
            //     throw new Error("Mail not sent");
            // }

        } catch (error) {
            reject(error);
        }
    }).catch(function (error) {
        throw error;
    });
}

exports.cpaFirmForgivenssReport = async () => {
    return new Promise(async function (resolve, reject) {
        try {
            let mailData = "";
            let filePath = "";
            const fields = [
                "App ID",
                "App Status",
                "App Created At",
                "App Submitted At",
                "Lead ID",
                "Case ID",
                "Business Name",
                "SBA PPP Loan Amount",
                "Actual Forgivable Amount",
                "Application For",
                "Client Name",
                "Client Email",
                "CPA Firm",
                "CPA Name",
                "CPA Email ID",
                "Loan Number",
            ];

            const opts = { fields };
            const parser = new Parser(opts);

            // Subject date
            let subjectDt = datetime.create();
            subjectDt.offsetInDays(-1);
            let subjectDate = subjectDt.format("Ymd");

            let reportData = [];

            const query = [
                {
                    $match: {
                        is_deleted: {
                            $ne: true
                        },
                        product_type: "5cf61ae8a567c9873cbab4d5"
                    }
                },
                { $addFields: { id: { $toString: "$_id" } } },
                {
                    $lookup: {
                        let: { appId: "$id" },
                        from: "service_business",
                        as: "b2c_status_ref",
                        pipeline: [
                            {
                                $match: {
                                    $expr: {
                                        $eq: ["$$appId", "$app_id"]
                                    },
                                    type: "b2c_status_forgiveness"
                                }
                            },
                            {
                                $project: {
                                    _id: 0,
                                    type: 1,
                                    b2c_ref_id: "$ref_id",
                                    submitted_at: "$created_at"
                                }
                            }
                        ]
                    }
                },
                {
                    $lookup: {
                        let: { appId: "$id" },
                        from: "service_business",
                        as: "loan_forgive_ref",
                        pipeline: [
                            {
                                $match: {
                                    $expr: {
                                        $eq: ["$$appId", "$app_id"]
                                    },
                                    type: "loan_forgiveness"
                                }
                            },
                            {
                                $project: {
                                    _id: 0,
                                    forgive_type: 1,
                                    forgive_ref_id: "$ref_id"
                                }
                            }
                        ]
                    }
                },
                {
                    $lookup: {
                        let: { appId: "$id" },
                        from: "business_info",
                        as: "business",
                        pipeline: [
                            {
                                $match: {
                                    $expr: {
                                        $eq: ["$$appId", "$app_id"]
                                    }
                                }
                            },
                            {
                                $project: {
                                    business_name: 1,
                                    current_state: 1,
                                    loan_amount: '$qualified_loan_amount',
                                    sba_ppp_loan_number: 1,
                                    _id: 0,
                                    already_ppp_loan: 1,
                                    sba_ppp_loan_amount: 1
                                }
                            }
                        ]
                    }
                },
                { $addFields: { forgive_ref_len: { $size: { $ifNull: ["$loan_forgive_ref", []] } } } },
                {
                    $project: {
                        _id: 0,
                        id: { $toString: "$_id" },
                        record_id: 1,
                        product_type: 1,
                        created_at: 1,
                        updated_at: 1,
                        status_id: 1,
                        backend_user_id: 1,
                        user_id: 1,
                        b2c_ref: { $arrayElemAt: ["$b2c_status_ref", 0] },
                        biz: { $arrayElemAt: ["$business", 0] },
                        forgive_ref: {$arrayElemAt: ["$loan_forgive_ref", { $subtract: ["$forgive_ref_len", 1] }]}
                    }
                },
                {
                    $replaceRoot: {
                        newRoot: {
                            $mergeObjects: ["$$ROOT", "$b2c_ref", "$biz", "$forgive_ref"]
                        }
                    }
                },
                {
                    $project: { b2c_ref: 0, biz: 0, forgive_ref: 0}
                }
            ];

            let Applications = await application.getAggregate(query);

            /**filter only apps with ref_id */
            const UserIds = [];
            Applications = Applications.filter(app => {
                if (app.b2c_ref_id) {
                    UserIds.push(app.user_id);
                    return true;
                }
            });

            const forgivenessReferences = await serviceBusinessModel.getAggregate([
                {
                    $match: {
                        type: 'loan_forgiveness'
                    }
                },
                {
                    $project: {
                        _id: 0,
                        ref_id: 1,
                    }
                },
                {
                    $group: {
                        _id: null,
                        ids: {
                            $push: "$ref_id"
                        }
                    }
                }
            ]);

            const forgiveRefLeadMap = {};

            if (forgivenessReferences && forgivenessReferences.length && forgivenessReferences[0].ids && forgivenessReferences[0].ids.length) {
                // get all the lead ids
                const forgivenessLeads = await sbaForgivenessModel.getAggregate([
                    {
                        $addFields: { id: { $toString: "$_id" } }
                    },
                    {
                        $match: {
                            id: { $in: forgivenessReferences[0].ids }
                        }
                    },
                    {
                        $project: {
                            id: 1,
                            _id: 0,
                            loan_forgiven_amount: 1
                        }
                    }
                ]);

                if (forgivenessLeads && forgivenessLeads.length) {
                    forgivenessLeads.forEach((lead) => {
                        forgiveRefLeadMap[lead.id] = {
                            loan_forgiven_amount: lead.loan_forgiven_amount
                        };
                    });
                }
            }

            // fetch all b2c_status ref id from service business
            const b2cReferences = await serviceBusinessModel.getAggregate([
                {
                    $match: {
                        type: 'b2c_status_forgiveness'
                    }
                },
                {
                    $project: {
                        _id: 0,
                        ref_id: 1,
                    }
                },
                {
                    $group: {
                        _id: null,
                        ids: {
                            $push: "$ref_id"
                        }
                    }
                }
            ]);

            const refLeadMap = {};
            // get all the leadIds from ref_ids
            if (b2cReferences && b2cReferences.length && b2cReferences[0].ids && b2cReferences[0].ids.length) {
                // get all the lead ids

                const pppLeads = await PPPAppLeadForgivenessModel.getAggregate([
                    {
                        $addFields: { id: { $toString: "$_id" } }
                    },
                    {
                        $match: {
                            id: { $in: b2cReferences[0].ids }
                        }
                    },
                    { $addFields: { len: { $size: { $ifNull: ["$application_status", []] } } } },
                    {
                        $project: {
                            id: 1,
                            _id: 0,
                            request_id: 1,
                            status: {
                                $arrayElemAt: ["$application_status", { $subtract: ["$len", 1] }]
                            }
                        }
                    }
                ]);

                if (pppLeads && pppLeads.length) {
                    pppLeads.forEach((lead) => {
                        refLeadMap[lead.id] = {
                            request_id: lead.request_id,
                            status: helper.getStatus(lead.status && lead.status.status ? lead.status.status : 'default'),
                            sba_loan_number: (lead.status && lead.status.sba_loan_number) ? lead.status.sba_loan_number : '',
                            sba_decision_date: helper.formatDate(helper.getFundedDate(lead)),
                            amount: lead.status ? lead.status.amount : '',
                            commission_amount: lead.status ? helper.calculateCommission(lead.status.amount) : 0
                        };
                    });
                }
            }

            const AppUserBackckendUserGroup = await userModel.getAggregate([
                { $addFields: { id: { $toString: "$_id" } } },
                {
                    $match: {
                        email_address: { $nin: [/@b2cdev/i, /@biz2credit/i] },
                        delete: {$ne: true},
                        id: { $in: UserIds }
                    }
                },
                {
                    $project: {
                        _id: 0,
                        id: 1,
                        email_address: 1,
                        name: '$user_data.name',
                        backend_user_id: {$toObjectId: '$user_data.backend_user_id'}
                    }
                },
                {
                    $lookup: {
                        let: { backendUserId: "$backend_user_id" },
                        as: 'backend_user_data',
                        from: "backend_users",
                        pipeline: [
                            {
                                $match: {
                                    $expr: {
                                        $eq: ["$_id", "$$backendUserId"]
                                    }
                                }
                            },
                            {
                                $project: {
                                    _id: 0,
                                    cpa_email_id: '$email_address',
                                    cpa_firm_name: '$data.cpa_firm_name',
                                    cpa_name: '$name'
                                }
                            }
                        ]
                    }
                },
                {
                    $project: {
                        _id: 0,
                        id: { $toString: "$id" },
                        email_address: 1,
                        name: 1,
                        backend_user_id: 1,
                        backend_user: { $arrayElemAt: ["$backend_user_data", 0] }
                    }
                },
                {
                    $replaceRoot: {
                        newRoot: {
                            $mergeObjects: ["$$ROOT", "$backend_user"]
                        }
                    }
                },
                {
                    $project: { backend_user: 0 }
                }
            ]);

            if (AppUserBackckendUserGroup && AppUserBackckendUserGroup.length) {
                const cpaUsersMap = {};
                AppUserBackckendUserGroup.map(userData => cpaUsersMap[userData.id] = userData);

                for (let index = 0; index < Applications.length; index++) {
                    const app = Applications[index];

                    const appData = {
                        "Case ID": "",
                        "CPA Firm": "",
                        "CPA Email ID": "",
                        "Business Name": app.business_name,
                        "Actual Forgivable Amount": "",
                        "SBA PPP Loan Amount": app.sba_ppp_loan_amount,
                        "App Status": "",
                        "App ID": 'APP' + app.record_id,
                        "App Created At": app.created_at ? helper.formatDate(app.created_at * 1000) : '',
                        "App Submitted At": app.submitted_at ? helper.formatDate(app.submitted_at * 1000) : '',
                        "Lead ID": "",
                        "Application For": "",
                        "Client Name": "",
                        "Client Email": "",
                        "CPA Name": "",
                        "Loan Number": ""
                    };

                    if (app.b2c_ref_id && refLeadMap[app.b2c_ref_id] && refLeadMap[app.b2c_ref_id].request_id) {
                        const splitted = refLeadMap[app.b2c_ref_id].request_id.split('-');
                        appData['Lead ID'] = splitted[0];
                        appData['Case ID'] = splitted[1];
                        appData['App Status'] = refLeadMap[app.b2c_ref_id].status;
                        appData['Application For'] = app.already_ppp_loan === true ? 'Draw 1': 'Draw 2';
                        appData['Loan Number'] = refLeadMap[app.b2c_ref_id].sba_loan_number ? refLeadMap[app.b2c_ref_id].sba_loan_number : app.sba_ppp_loan_number;
                    }

                    if (forgiveRefLeadMap && forgiveRefLeadMap[app.forgive_ref_id]) {
                        appData['Actual Forgivable Amount'] = forgiveRefLeadMap[app.forgive_ref_id].loan_forgiven_amount;
                    }

                    if (app.user_id && cpaUsersMap[app.user_id]) {
                        appData['CPA Firm'] = cpaUsersMap[app.user_id].cpa_firm_name;
                        appData['CPA Name'] = cpaUsersMap[app.user_id].cpa_name;
                        appData['CPA Email ID'] = cpaUsersMap[app.user_id].cpa_email_id;
                        appData["Client Name"] = cpaUsersMap[app.user_id].name;
                        appData["Client Email"] = cpaUsersMap[app.user_id].email_address;
                        reportData.push(appData);
                    }
                };
            }

            if (reportData && reportData.length) {
                let contents = parser.parse(reportData);
                // Temporary file name
                let attach_fileName = "Forgiveness-apps-report.csv";

                if (process.env.NODE_ENV == "local") {
                    filePath = path.resolve(attach_fileName);
                } else {
                    filePath = path.resolve("/tmp/" + attach_fileName);
                }

                const writeStream = fs.createWriteStream(filePath);
                writeStream.write(contents);

                writeStream.on("finish", () => {
                    console.log("wrote all data to file");
                });

                writeStream.end();

                let prefixDt = datetime.create();
                let prefixDate = prefixDt.format("Ymd");
                let folderData = prefixDt.format("Y-m-d");
                let splitDate = folderData.split("-");
                let prefix =
                    "reports/aicpa-report/" +
                    process.env.NODE_ENV +
                    "/" +
                    splitDate[0] +
                    "/" +
                    splitDate[1];
                let fileName = prefixDate + "-Forgiveness-apps-report.csv";
                let bucketName = process.env.BUCKET_NAME + "/" + prefix;

                await awsS3.createLogFile(bucketName, fileName, contents);

                let fileUrl = process.env.BUCKET_URL + "/" + prefix + "/" + fileName;
                let bodyText = "<p>Hi, Please download the application level report by clicking the following link.</p></br><p><a href='" + fileUrl + "' target='_blank'>Download Report</a></p>";

                mailData = {
                    from_email: process.env.USER_INFO_EMAIL_FROM,
                    to_email: process.env.USER_INFO_EMAIL_TO_CPA,
                    subject:
                        "CPALoanPortal - Application data as on " +
                        subjectDate,
                    html: bodyText
                };
                if (
                    process.env.USER_INFO_CC_EMAIL != undefined &&
                    process.env.USER_INFO_CC_EMAIL != ""
                ) {
                    mailData["cc"] = process.env.USER_INFO_CC_EMAIL;
                }

            } else {
                mailData = {
                    from_email: process.env.USER_INFO_EMAIL_FROM,
                    to_email: process.env.USER_INFO_EMAIL_TO_CPA,
                    subject:
                        "CPALoanPortal - Application data as on " +
                        subjectDate,
                    text: "Hi, No Application data was found",
                };
                if (
                    process.env.USER_INFO_CC_EMAIL != undefined &&
                    process.env.USER_INFO_CC_EMAIL != ""
                ) {
                    mailData["cc"] = process.env.USER_INFO_CC_EMAIL;
                }
            }
            let notification = await mailer.mailSender(mailData);

            fs.unlink(filePath, function (err) {
                if (err) {
                    reject(err);
                }
            });

            if (notification) {
                resolve(notification);
            } else {
                throw new Error("Mail not sent");
            }

        } catch (error) {
            reject(error);
        }
    }).catch(function (error) {
        throw error;
    });
}

exports.get_PPP_AICPA_FIRM_Report = async function () {
    return new Promise(async function (resolve, reject) {
        try {
            let mailData = "";
            let filePath = "";

            //let cpaUsers = [];
            let cpaApplication = [];
            let finalData = [];
            const detector = new deviceDetector();
            const APP_SUBMITTED = '5c20bf7e27105c78ad7f9280';
            const PPP2 = '5f40fb82b365b23a003e3708';
            const FORGIVENESS = '5cf61ae8a567c9873cbab4d5';
            // Set header of the csv
            const fields = [
                "CPA Firm Name",
                "CPA user First Name",
                "CPA user last name",
                "Plan Selected",
                "Email Address",
                "Phone Number",
                "SSN",
                "Clear Report Result",
                "CPA License Number",
                "CPA License State",
                "Business Address",
                "City",
                "State",
                "Zipcode",
                "Registered date and time",
                "Original plan",
                "Current Plan",
                "Current Role",
                "AICPA Member Number",
                "AICPA Verification Needed",
                "AICPA - Verified",
                "Number of users created under firm",
                "Number of forgiveness applications created",
                "Number of forgiveness applications completed",
                "Number of PPP2 applications created",
                "Number of PPP 2 applications completed",
                "Firm Owner",
                "Subscription Amount Paid",
                "Payment Status",
                "Payment Date",
                "Is Firm Admin"
            ];

            let total_number_paid_enterprice_cpa_firm = 0;
            let total_number_paid_premium_cpa_firm = 0;
            let total_number_paid_custom_cpa_firm = 0;
            let total_number_paid_cpa_firm = 0;

            let total_number_unpaid_enterprice_cpa_firm = 0;
            let total_number_unpaid_premium_cpa_firm = 0;
            let total_number_unpaid_custom_cpa_firm = 0;
            let total_number_unpaid_cpa_firm = 0;

            let total_number_ppp2_created_by_cpa_verified_firm = 0;
            let total_number_ppp2_completed_by_cpa_verified_firm = 0;
            let total_number_ppp2_created_by_all_firm = 0;
            let total_number_ppp2_completed_by_all_firm = 0;

            const opts = { fields };
            const parser = new Parser(opts);

            // Get start time

            let pastDate = '2020-07-16';

            let pastStartDt = datetime.create(pastDate);
            pastStartDt = pastStartDt.format("Y-m-d");

            let startDt = datetime.create(pastStartDt);
            let startTime = startDt.epoch();

            // Get End time
            let pastEndDt = datetime.create();
            pastEndDt = pastEndDt.format("Y-m-d");
            let endDt = datetime.create(pastEndDt);
            //endDt.offsetInDays(-1);
            let endTime = endDt.epoch();

            // Subject date
            let subjectDt = datetime.create();
            subjectDt.offsetInDays(-1);
            let subjectDate = subjectDt.format("Ymd");

            let queryBuild = [
                {
                    "$match": {
                        '$and': [
                            { created_at: { $lt: endTime } },
                            { created_at: { $gte: startTime } },
                            { email_address: { '$not': /^.*@(b2cdev|biz2credit)\.([a-zA-Z\.]{2,})/ } },
                            { email_address: { '$ne': null } },
                            {delete: {$ne: true}},
                            {'data.cpa_firm_name': {$exists: true}},
                            {is_active: { $ne: false }},
                            {is_verified: { $ne: false }}
                        ],
                    }
                },
                { "$group": { _id: { $toLower: "$data.cpa_firm_name" }, "doc": { "$first": "$$ROOT" }, backend_ids: { $push: { $toString: "$_id" } } } },
                { $project: {firm_name: '$_id', backend_ids: 1} }
            ];

            let cpaUserFirm = await backendUser.getAggregate(queryBuild);

            const firmNames = [];
            const firmBackendIdMap = {};
            cpaUserFirm.forEach((firm) => {
                firmNames.push(firm.firm_name);
                firmBackendIdMap[firm.firm_name.toLowerCase()] = firm.backend_ids;
            });

            const cpaUserQuery = [
                { $match: { delete: { $ne: true } } },
                { $addFields: { firm_name: { $toLower: "$data.cpa_firm_name" } } },
                { $match: { "firm_name": { $in: firmNames } } },
            ];

            let queryModel = backendUser.getBackendUserModel(cpaUserQuery);

            let cpaUserData = await backendUser.getAggregate(queryModel);

            if (cpaUserData.length) {
                const userIds = [];
                const firm_names_regex = [];
                const email_addresses = [];
                cpaUserData.forEach((cpaUser) => {
                    userIds.push(...firmBackendIdMap[cpaUser.data.cpa_firm_name.toLowerCase()]);
                    firm_names_regex.push(new RegExp(cpaUser.data.cpa_firm_name, 'i'));
                    email_addresses.push(cpaUser.email_address);
                });

                const appData = await application.getAggregate([
                    {
                        $match: {
                            backend_user_id: { $in: userIds }
                        }
                    },
                    {
                        $project: {
                            app_id: "$_id",
                            status_id: 1,
                            product_type: 1,
                            backend_user_id: 1
                        }
                    }
                ]);


                const userAppsMap = {};
                // map appData with each user
                appData.forEach((app) => {
                    if (!userAppsMap[app.backend_user_id]) {
                        userAppsMap[app.backend_user_id] = [];
                    }

                    userAppsMap[app.backend_user_id].push(app);
                });

                // perform query to get active plan under the firm
                let activeUserPlans = await userPlans.getAggregate([
                    {
                        $match: {
                            $or: [
                                { email_address: { $in: email_addresses } },
                                { firm_name: { $in: firm_names_regex } }
                            ],
                            is_active: true
                        },
                    },
                    { '$sort': { createdAt: -1 } },
                    { "$group": { _id: "$email_address", "doc": { "$first": "$$ROOT" } } },
                    {
                        "$replaceRoot": { "newRoot": { "$mergeObjects": ["$doc"] } }
                    },
                    {
                        $lookup: {
                            from: "plans",
                            localField: "plan_id",
                            foreignField: '_id',
                            as: 'plans'
                        }
                    },
                    {
                        $project: {
                            plan_id: 1,
                            firm_name: 1,
                            email_address: 1,
                            payment_status: 1,
                            payment_date: 1,
                            payment_amount: 1,
                            createdAt: 1,
                            plan_price: {
                                $arrayToObject: {
                                    $map: {
                                        input: "$plans",
                                        as: "p",
                                        in: {
                                            k: "plan",
                                            v: "$$p",
                                        }
                                    }
                                }
                            }
                        }
                    },
                    {
                        $replaceRoot: {
                            newRoot: {
                                $mergeObjects: ["$$ROOT", "$plan_price"]
                            }
                        }
                    },
                    {
                        $project: {
                            type: "$plan.type",
                            price: "$plan.price",
                            plan_id: 1,
                            firm_name: 1,
                            email_address: 1,
                            payment_status: 1,
                            payment_date: 1,
                            payment_amount: 1
                        }
                    }
                ]);

                // map plan with email and firm to identify using firm or email address below
                const emailMap = {};
                const firmMap = {};
                activeUserPlans.forEach((plan) => {
                    const firmEmail = plan.email_address;
                    const firmName = plan.firm_name;
                    if(!emailMap[firmEmail]){ 
                        emailMap[firmEmail] = plan;
                    } else if(emailMap[firmEmail] && plan.payment_date) {
                        emailMap[firmEmail] = plan;
                    }
 
                    if (firmName) {
                        const firmSmallCase = firmName.toLowerCase();
                        if(!firmMap[firmSmallCase]) {
                            firmMap[firmSmallCase] = plan;
                        } else if(firmMap[firmSmallCase] && plan.payment_date) {
                            firmMap[firmSmallCase] = plan;
                        }
                    }
                });

                const cpaFirmEmailMap = {};
                cpaUserData.forEach(async (user) => {
                    let selectedPlan = firmMap[user.data.cpa_firm_name.toLowerCase()];
                    selectedPlan = selectedPlan || emailMap[user.email_address];
                    let selectedPlanEmail = selectedPlan ? selectedPlan.email_address : "";
                    if (selectedPlanEmail !== "" && selectedPlanEmail !== user.email_address) {
                        cpaFirmEmailMap[selectedPlanEmail] = selectedPlanEmail;
                    }
                });
                let queryB = [
                    {
                        "$match": { email_address: { '$in': Object.keys(cpaFirmEmailMap) } }
                    },
                ];
                let queryM = backendUser.getBackendUserModel(queryB);
                let actualUser = await backendUser.getAggregate(queryM);
                const cpaFirmActualUserMap = {};
                actualUser.forEach(async (user) => {
                    cpaFirmActualUserMap[user.email_address] = user;
                });

                const reportUserEmailMap = {};
                for (let userData of cpaUserData) {

                    const user = {
                        ...userData
                    }

                    let selectedPlan = firmMap[user.data.cpa_firm_name.toLowerCase()];
                    selectedPlan = selectedPlan || emailMap[user.email_address];
                   
                    if(selectedPlan) {
                        user.plan = selectedPlan;
                    }
                    
                    reportUserEmailMap[user.email_address] = true;

                    let registerDate = new Date(user.created_at * 1000);
                    let registerDt = datetime.create(registerDate);
                    let createdDate = registerDt.format("m/d/Y");

                    let firstName = "";
                    let lastName = "";
                    if (user.name) {
                        const fullname = user.name.split(" ");
                        firstName = fullname.slice(0, 1).join(" ");
                        lastName = fullname.slice(1).join(" ");
                    }

                    let selectedPlanType = user.plan && user.plan.type ? user.plan.type : "";
                    let selectedPlanPrice = user.plan && user.plan.payment_amount !== undefined ? user.plan.payment_amount : "";
                    if(selectedPlanPrice === "")
                    {
                        selectedPlanPrice = user.plan && user.plan.price? user.plan.price : 0;
                    }
                    
                    let firm_owner = "No";
                    if (selectedPlanType === "premium" || selectedPlanType === "enterprise") {
                        firm_owner = "Yes";
                    }
                    else {
                        firm_owner = "No";
                    }

                    let paymentStatus = user.plan && user.plan.payment_status ? user.plan.payment_status : "";
                    let paymentDate = "";
                    let aicpa_verification_needed = "";
                    if (paymentStatus === "success") {

                        if(selectedPlanType === "enterprise")
                        {
                            total_number_paid_enterprice_cpa_firm++;
                        }
                        if(selectedPlanType === "premium")
                        {
                            total_number_paid_premium_cpa_firm++;
                        }
                        if(selectedPlanType === "custom")
                        {
                            total_number_paid_custom_cpa_firm++; 
                        }
                        paymentDate = user.plan && user.plan.payment_date ? user.plan.payment_date : "";
                        if(paymentDate)
                        {
                            paymentDate = datetime.create(paymentDate);
                            paymentDate = paymentDate.format("m/d/Y");
                        }                   
                        aicpa_verification_needed = user.data.cpa_verification_needed ? user.data.cpa_verification_needed : "Y";
                    }
                    else{
                        if(selectedPlanType === "enterprise")
                        {
                            total_number_unpaid_enterprice_cpa_firm++;
                        }
                        if(selectedPlanType === "premium")
                        {
                            total_number_unpaid_premium_cpa_firm++;
                        }
                        if(selectedPlanType === "custom")
                        {
                            total_number_unpaid_custom_cpa_firm++;
                        }
                        aicpa_verification_needed = user.data.cpa_verification_needed ? user.data.cpa_verification_needed : "";
                    }

                     const AppCount = {
                        ppp2: 0,
                        forgiveness: 0,
                        ppp2_submitted : 0,
                        forgiveness_completed: 0,
                     }

                        const userApps = userAppsMap[user._id] || [];
                        userApps.forEach((app) => {
                            if (app.product_type === PPP2) {
                                AppCount.ppp2 += 1;
    
                                if (app.status_id === APP_SUBMITTED) {
                                    AppCount.ppp2_submitted += 1;
                                }
                            }
                            if (app.product_type === FORGIVENESS) {
                                AppCount.forgiveness += 1;
    
                                if (app.status_id === APP_SUBMITTED) {
                                    AppCount.forgiveness_completed += 1;
                                }
                            }
                        });

                    user.app_counts = AppCount;

                    let cpaAppData = {
                        "Email Address": user.email_address,
                        "CPA user First Name": firstName,
                        "CPA user last name": lastName,
                        "Phone Number": !user.phone_number || isNaN(user.phone_number) ? "" : parseInt(user.phone_number),
                        "Business Address": user.data.business_address && user.data.business_address.business_address  ? user.data.business_address.business_address : "",
                        "City": user.data.business_address && user.data.business_address.city  ? user.data.business_address.city : "",
                        "State": user.data.business_address && user.data.business_address.state  ? user.data.business_address.state : "",
                        "Zipcode": user.data.business_address && user.data.business_address.zip_code  ? "\t" + user.data.business_address.zip_code : "",
                        "Registered date and time": createdDate,
                        "AICPA Member Number": user.registration_code ? user.registration_code : "",
                        "AICPA Verification Needed": aicpa_verification_needed,
                        "AICPA - Verified": user.data.cpa_verified ? user.data.cpa_verified : "",
                        "CPA Firm Name": user.data.cpa_firm_name ? user.data.cpa_firm_name : "",
                        "SSN": user.data.ssn ? user.data.ssn : "",
                        "Clear Report Result": user.data.clear_report ? "Yes":"No",
                        "CPA License Number":user.data.cpa_licensee_no,
                        "CPA License State":user.data.cpa_licensee_state,
                        "Current Role": user.role_name || "",
                        "Current Plan": selectedPlan ? selectedPlan.type : "",
                        "Plan Selected": selectedPlan ? selectedPlan.type : "",
                        "Original plan": selectedPlan ? selectedPlan.type : "",
                        "Number of users created under firm": user.total_users || 0,
                        'Number of forgiveness applications created': user.app_counts.forgiveness,
                        'Number of forgiveness applications completed': user.app_counts.forgiveness_completed,
                        'Number of PPP2 applications created': user.app_counts.ppp2,
                        'Number of PPP 2 applications completed': user.app_counts.ppp2_submitted,
                        'Firm Owner': firm_owner,
                        'Subscription Amount Paid': selectedPlanPrice,
                        'Payment Status': paymentStatus,
                        'Payment Date': paymentDate,
                        "Is Firm Admin": user.data.registration_type === 'normal' ? 'Yes' : 'No'
                    }

                    finalData.push(cpaAppData);
                }
            }

            if (finalData.length > 0) {
                // Convert json data into csv
                let contents = parser.parse(finalData);

                const dt = new Date();
                const dd = dt.getDate();
                const mm = dt.getMonth() + 1;
                const yyyy = dt.getFullYear();
                // Temporary file name
                let attach_fileName = `${mm}-${dd}-${yyyy}-aicpa-firm-report.csv`;

                if (process.env.NODE_ENV == "local") {
                    filePath = path.resolve(attach_fileName);
                } else {
                    filePath = path.resolve("/tmp/" + attach_fileName);
                }

                const writeStream = fs.createWriteStream(filePath);
                writeStream.write(contents);

                writeStream.on("finish", () => {
                    console.log("wrote all data to file");
                });

              writeStream.end();

              let prefixDt = datetime.create();
              prefixDt.offsetInDays(-1);
              let prefixDate = prefixDt.format("Ymd");
              let folderData = prefixDt.format("Y-m-d");
              let splitDate = folderData.split("-");
              let prefix =
                  "reports/aicpa-report/" +
                  process.env.NODE_ENV +
                  "/" +
                  splitDate[0] +
                  "/" +
                  splitDate[1];
              let fileName = prefixDate + "-aicpa-report-cpa-data.csv";
              let bucketName = process.env.BUCKET_NAME + "/" + prefix;
  
              await awsS3.createLogFile(bucketName, fileName, contents);
  
              let fileUrl = process.env.BUCKET_URL + "/" + prefix + "/" + fileName;
              let bodyText = "<p>Hi, Please download the APICPA firm report by clicking the following link.</p></br><p><a href='" + fileUrl + "' target='_blank'>Download Report</a></p>";
              mailData = {
                  from_email: process.env.USER_INFO_EMAIL_FROM,
                  to_email: process.env.USER_INFO_EMAIL_TO_CPA,
                  subject:
                      "PPPForgivenessTool - CPA data as on " +
                      subjectDate,
                  html: bodyText
              };
              if (
                  process.env.USER_INFO_CC_EMAIL != undefined &&
                  process.env.USER_INFO_CC_EMAIL != ""
              ) {
                  mailData["cc"] = process.env.USER_INFO_CC_EMAIL;
              }
          } else {
              mailData = {
                  from_email: process.env.USER_INFO_EMAIL_FROM,
                  to_email: process.env.USER_INFO_EMAIL_TO_CPA,
                  subject:
                      "PPPForgivenessTool - CPA data as on " +
                      subjectDate,
                  text: "Hi, No CPA data was found",
              };
              if (
                  process.env.USER_INFO_CC_EMAIL != undefined &&
                  process.env.USER_INFO_CC_EMAIL != ""
              ) {
                  mailData["cc"] = process.env.USER_INFO_CC_EMAIL;
              }
          }
  
          let notification = await mailer.mailSender(mailData);
  
          fs.unlink(filePath, function (err) {
              if (err) {
                  reject(err);
              }
          });
  
          if (notification) {
              resolve(notification);
          } else {
              throw new Error("Mail not sent");
          }
          
        } catch (error) {
            reject(error);
        }
    }).catch(function (error) {
        throw error;
    });
};


exports.urgent_firm_report = async function () {
    return new Promise(async function (resolve, reject) {
        try {
            let mailData = "";
            let filePath = "";

            //let cpaUsers = [];
            let cpaApplication = [];
            let finalData = [];
            const detector = new deviceDetector();
            const APP_SUBMITTED = '5c20bf7e27105c78ad7f9280';
            const PPP2 = '5f40fb82b365b23a003e3708';
            const FORGIVENESS = '5cf61ae8a567c9873cbab4d5';
            // Set header of the csv
            const fields = [
                "CPA Firm Name",
                "CPA user First Name",
                "CPA user last name",
                "Plan Selected",
                "Email Address",
                // "Phone Number",
                // "SSN",
                // "Clear Report Result",
                // "CPA License Number",
                // "CPA License State",
                // "Business Address",
                // "City",
                // "State",
                // "Zipcode",
                // "Registered date and time",
                // "Original plan",
                "Current Plan",
                // "Current Role",
                // "AICPA Member Number",
                // "AICPA Verification Needed",
                // "AICPA - Verified",
                // "Number of users created under firm",
                // "Number of forgiveness applications created",
                // "Number of forgiveness applications completed",
                // "Number of PPP2 applications created",
                // "Number of PPP 2 applications completed",
                // "Firm Owner",
                "Subscription Amount Paid",
                "Payment Status",
                "Payment Date",
                'Last Four',
                "Card Type",
                // "Is Firm Admin"
                'Registration Date',

            ];

            let total_number_paid_enterprice_cpa_firm = 0;
            let total_number_paid_premium_cpa_firm = 0;
            let total_number_paid_custom_cpa_firm = 0;
            let total_number_paid_cpa_firm = 0;

            let total_number_unpaid_enterprice_cpa_firm = 0;
            let total_number_unpaid_premium_cpa_firm = 0;
            let total_number_unpaid_custom_cpa_firm = 0;
            let total_number_unpaid_cpa_firm = 0;

            let total_number_ppp2_created_by_cpa_verified_firm = 0;
            let total_number_ppp2_completed_by_cpa_verified_firm = 0;
            let total_number_ppp2_created_by_all_firm = 0;
            let total_number_ppp2_completed_by_all_firm = 0;

            const opts = { fields };
            const parser = new Parser(opts);

            // Get start time

            let pastDate = '2020-07-16';

            let pastStartDt = datetime.create(pastDate);
            pastStartDt = pastStartDt.format("Y-m-d");

            let startDt = datetime.create(pastStartDt);
            let startTime = startDt.epoch();

            // Get End time
            let pastEndDt = datetime.create();
            pastEndDt = pastEndDt.format("Y-m-d");
            let endDt = datetime.create(pastEndDt);
            //endDt.offsetInDays(-1);
            let endTime = endDt.epoch();

            // Subject date
            let subjectDt = datetime.create();
            subjectDt.offsetInDays(-1);
            let subjectDate = subjectDt.format("Ymd");

            let queryBuild = [
                {
                    $match: {
                        'data.cpa_firm_name': {
                            $in: []
                        }
                    }
                },
                {
                    "$match": {
                        '$and': [
                            { created_at: { $lt: endTime } },
                            { created_at: { $gte: startTime } },
                            { email_address: { '$not': /^.*@(b2cdev|biz2credit)\.([a-zA-Z\.]{2,})/ } },
                            { email_address: { '$ne': null } },
                            {delete: {$ne: true}},
                            {'data.cpa_firm_name': {$exists: true}},
                            // {is_active: { $ne: false }},
                            // {is_verified: { $ne: false }}
                        ],
                    }
                },
                { "$group": { _id: { $toLower: "$data.cpa_firm_name" }, "doc": { "$first": "$$ROOT" }, backend_ids: { $push: { $toString: "$_id" } } } },
                { $project: {firm_name: '$_id', backend_ids: 1} }
            ];

            let cpaUserFirm = await backendUser.getAggregate(queryBuild);

            const firmNames = [];
            const firmBackendIdMap = {};
            cpaUserFirm.forEach((firm) => {
                firmNames.push(firm.firm_name);
                firmBackendIdMap[firm.firm_name.toLowerCase()] = firm.backend_ids;
            });

            const cpaUserQuery = [
                { $match: { delete: { $ne: true } } },
                { $addFields: { firm_name: { $toLower: "$data.cpa_firm_name" } } },
                { $match: { "firm_name": { $in: firmNames } } },
            ];

            let queryModel = backendUser.getBackendUserModel(cpaUserQuery);

            let cpaUserData = await backendUser.getAggregate(queryModel);

            if (cpaUserData.length) {
                const userIds = [];
                const firm_names_regex = [];
                const email_addresses = [];
                cpaUserData.forEach((cpaUser) => {
                    userIds.push(...firmBackendIdMap[cpaUser.data.cpa_firm_name.toLowerCase()]);
                    firm_names_regex.push(new RegExp(cpaUser.data.cpa_firm_name, 'i'));
                    email_addresses.push(cpaUser.email_address);
                });

                // const appData = await application.getAggregate([
                //     {
                //         $match: {
                //             backend_user_id: { $in: userIds }
                //         }
                //     },
                //     {
                //         $project: {
                //             app_id: "$_id",
                //             status_id: 1,
                //             product_type: 1,
                //             backend_user_id: 1
                //         }
                //     }
                // ]);


                const userAppsMap = {};
                // map appData with each user
                // appData.forEach((app) => {
                //     if (!userAppsMap[app.backend_user_id]) {
                //         userAppsMap[app.backend_user_id] = [];
                //     }

                //     userAppsMap[app.backend_user_id].push(app);
                // });

                // perform query to get active plan under the firm
                let activeUserPlans = await userPlans.getAggregate([
                    {
                        $match: {
                            $or: [
                                { email_address: { $in: email_addresses } },
                                { firm_name: { $in: firm_names_regex } }
                            ],
                            is_active: true
                        },
                    },
                    { '$sort': { createdAt: -1 } },
                    { "$group": { _id: "$email_address", "doc": { "$first": "$$ROOT" } } },
                    {
                        "$replaceRoot": { "newRoot": { "$mergeObjects": ["$doc"] } }
                    },
                    {
                        $lookup: {
                            from: "plans",
                            localField: "plan_id",
                            foreignField: '_id',
                            as: 'plans'
                        }
                    },
                    {
                        $lookup: {
                          let: {user_plan_id: "$_id"},
                          from :'payment_logs',
                          as:'payments',
                          pipeline: [
                            {
                              $match: {
                                $expr: {
                                  $eq: ["$user_plan_id", "$$user_plan_id"]
                                }
                              }
                            },
                            ...lastFourCardQuery()
                          ]
                        }
                      },
                    {
                        $project: {
                            plan_id: 1,
                            firm_name: 1,
                            email_address: 1,
                            payment_status: 1,
                            payment_date: 1,
                            payment_amount: 1,
                            createdAt: 1,
                            payments:1,
                            plan_price: {
                                $arrayToObject: {
                                    $map: {
                                        input: "$plans",
                                        as: "p",
                                        in: {
                                            k: "plan",
                                            v: "$$p",
                                        }
                                    }
                                }
                            }
                        }
                    },
                    {
                        $replaceRoot: {
                            newRoot: {
                                $mergeObjects: ["$$ROOT", "$plan_price"]
                            }
                        }
                    },
                    {
                        $project: {
                            type: "$plan.type",
                            price: "$plan.price",
                            plan_id: 1,
                            firm_name: 1,
                            email_address: 1,
                            payment_status: 1,
                            payment_date: 1,
                            payment_amount: 1,
                            payments:1
                        }
                    }
                ]);

                // map plan with email and firm to identify using firm or email address below
                const emailMap = {};
                const firmMap = {};
                activeUserPlans.forEach((plan) => {
                    const firmEmail = plan.email_address;
                    const firmName = plan.firm_name;
                    if(!emailMap[firmEmail]){ 
                        emailMap[firmEmail] = plan;
                    } else if(emailMap[firmEmail] && plan.payment_date) {
                        emailMap[firmEmail] = plan;
                    }
 
                    if (firmName) {
                        const firmSmallCase = firmName.toLowerCase();
                        if(!firmMap[firmSmallCase]) {
                            firmMap[firmSmallCase] = plan;
                        } else if(firmMap[firmSmallCase] && plan.payment_date) {
                            firmMap[firmSmallCase] = plan;
                        }
                    }
                });

                const cpaFirmEmailMap = {};
                cpaUserData.forEach(async (user) => {
                    let selectedPlan = firmMap[user.data.cpa_firm_name.toLowerCase()];
                    selectedPlan = selectedPlan || emailMap[user.email_address];
                    let selectedPlanEmail = selectedPlan ? selectedPlan.email_address : "";
                    if (selectedPlanEmail !== "" && selectedPlanEmail !== user.email_address) {
                        cpaFirmEmailMap[selectedPlanEmail] = selectedPlanEmail;
                    }
                });
                let queryB = [
                    {
                        "$match": { email_address: { '$in': Object.keys(cpaFirmEmailMap) } }
                    },
                ];
                let queryM = backendUser.getBackendUserModel(queryB);
                let actualUser = await backendUser.getAggregate(queryM);
                const cpaFirmActualUserMap = {};
                actualUser.forEach(async (user) => {
                    cpaFirmActualUserMap[user.email_address] = user;
                });

                const reportUserEmailMap = {};
                for (let userData of cpaUserData) {

                    const user = {
                        ...userData
                    }

                    let selectedPlan = firmMap[user.data.cpa_firm_name.toLowerCase()];
                    selectedPlan = selectedPlan || emailMap[user.email_address];
                   
                    if(selectedPlan) {
                        user.plan = selectedPlan;
                    }
                    
                    reportUserEmailMap[user.email_address] = true;

                    let registerDate = new Date(user.created_at * 1000);
                    let registerDt = datetime.create(registerDate);
                    let createdDate = registerDt.format("m/d/Y");

                    let firstName = "";
                    let lastName = "";
                    if (user.name) {
                        const fullname = user.name.split(" ");
                        firstName = fullname.slice(0, 1).join(" ");
                        lastName = fullname.slice(1).join(" ");
                    }

                    let selectedPlanType = user.plan && user.plan.type ? user.plan.type : "";
                    let selectedPlanPrice = user.plan && user.plan.payment_amount !== undefined ? user.plan.payment_amount : "";
                    if(selectedPlanPrice === "")
                    {
                        selectedPlanPrice = user.plan && user.plan.price? user.plan.price : 0;
                    }
                    
                    let firm_owner = "No";
                    if (selectedPlanType === "premium" || selectedPlanType === "enterprise") {
                        firm_owner = "Yes";
                    }
                    else {
                        firm_owner = "No";
                    }

                    let paymentStatus = user.plan && user.plan.payment_status ? user.plan.payment_status : "";
                    let paymentDate = "";
                    let aicpa_verification_needed = "";
                    if (paymentStatus === "success") {

                        if(selectedPlanType === "enterprise")
                        {
                            total_number_paid_enterprice_cpa_firm++;
                        }
                        if(selectedPlanType === "premium")
                        {
                            total_number_paid_premium_cpa_firm++;
                        }
                        if(selectedPlanType === "custom")
                        {
                            total_number_paid_custom_cpa_firm++; 
                        }
                        paymentDate = user.plan && user.plan.payment_date ? user.plan.payment_date : "";
                        if(paymentDate)
                        {
                            paymentDate = datetime.create(paymentDate);
                            paymentDate = paymentDate.format("m/d/Y");
                        }                   
                        aicpa_verification_needed = user.data.cpa_verification_needed ? user.data.cpa_verification_needed : "Y";
                    }
                    else{
                        if(selectedPlanType === "enterprise")
                        {
                            total_number_unpaid_enterprice_cpa_firm++;
                        }
                        if(selectedPlanType === "premium")
                        {
                            total_number_unpaid_premium_cpa_firm++;
                        }
                        if(selectedPlanType === "custom")
                        {
                            total_number_unpaid_custom_cpa_firm++;
                        }
                        aicpa_verification_needed = user.data.cpa_verification_needed ? user.data.cpa_verification_needed : "";
                    }

                     const AppCount = {
                        ppp2: 0,
                        forgiveness: 0,
                        ppp2_submitted : 0,
                        forgiveness_completed: 0,
                     }

                        const userApps = userAppsMap[user._id] || [];
                        userApps.forEach((app) => {
                            if (app.product_type === PPP2) {
                                AppCount.ppp2 += 1;
    
                                if (app.status_id === APP_SUBMITTED) {
                                    AppCount.ppp2_submitted += 1;
                                }
                            }
                            if (app.product_type === FORGIVENESS) {
                                AppCount.forgiveness += 1;
    
                                if (app.status_id === APP_SUBMITTED) {
                                    AppCount.forgiveness_completed += 1;
                                }
                            }
                        });

                    user.app_counts = AppCount;
                    
                    let registrationDate;
                    if(user.created_at) {
                        let registerDate = new Date(user.created_at * 1000);
                        registrationDate = datetime.create(registerDate);
                        registrationDate = registrationDate.format("m/d/Y");
                    }
                    
                    let cpaAppData = {
                        "Email Address": user.email_address,
                        "CPA user First Name": firstName,
                        "CPA user last name": lastName,
                        "Phone Number": !user.phone_number || isNaN(user.phone_number) ? "" : parseInt(user.phone_number),
                        // "Business Address": user.data.business_address && user.data.business_address.business_address  ? user.data.business_address.business_address : "",
                        // "City": user.data.business_address && user.data.business_address.city  ? user.data.business_address.city : "",
                        // "State": user.data.business_address && user.data.business_address.state  ? user.data.business_address.state : "",
                        // "Zipcode": user.data.business_address && user.data.business_address.zip_code  ? "\t" + user.data.business_address.zip_code : "",
                        // "Registered date and time": createdDate,
                        // "AICPA Member Number": user.registration_code ? user.registration_code : "",
                        // "AICPA Verification Needed": aicpa_verification_needed,
                        // "AICPA - Verified": user.data.cpa_verified ? user.data.cpa_verified : "",
                        "CPA Firm Name": user.data.cpa_firm_name ? user.data.cpa_firm_name : "",
                        // "SSN": user.data.ssn ? user.data.ssn : "",
                        // "Clear Report Result": user.data.clear_report ? "Yes":"No",
                        // "CPA License Number":user.data.cpa_licensee_no,
                        // "CPA License State":user.data.cpa_licensee_state,
                        // "Current Role": user.role_name || "",
                        "Current Plan": selectedPlan ? selectedPlan.type : "",
                        "Plan Selected": selectedPlan ? selectedPlan.type : "",
                        // "Original plan": selectedPlan ? selectedPlan.type : "",
                        // "Number of users created under firm": user.total_users || 0,
                        // 'Number of forgiveness applications created': user.app_counts.forgiveness,
                        // 'Number of forgiveness applications completed': user.app_counts.forgiveness_completed,
                        // 'Number of PPP2 applications created': user.app_counts.ppp2,
                        // 'Number of PPP 2 applications completed': user.app_counts.ppp2_submitted,
                        'Firm Owner': firm_owner,
                        'Subscription Amount Paid': selectedPlanPrice,
                        'Payment Status': paymentStatus,
                        'Payment Date': paymentDate,
                        'Last Four': selectedPlan && selectedPlan.payments[0] && selectedPlan.payments[0].lastFour ? selectedPlan.payments[0].lastFour: '',
                        'Card Type': selectedPlan && selectedPlan.payments[0] && selectedPlan.payments[0].card_type ? selectedPlan.payments[0].card_type: '',
                        'Registration Date': registrationDate
                        // "Is Firm Admin": user.data.registration_type === 'normal' ? 'Yes' : 'No'
                    }

                    if(user.data.registration_type === 'normal') {
                        finalData.push(cpaAppData);
                    }
                }
            }

            if (finalData.length > 0) {
                // Convert json data into csv
                let contents = parser.parse(finalData);

                const dt = new Date();
                const dd = dt.getDate();
                const mm = dt.getMonth() + 1;
                const yyyy = dt.getFullYear();
                // Temporary file name
                let attach_fileName = `${mm}-${dd}-${yyyy}-aicpa-firm-report.csv`;

                if (process.env.NODE_ENV == "local") {
                    filePath = path.resolve(attach_fileName);
                } else {
                    filePath = path.resolve("/tmp/" + attach_fileName);
                }

                const writeStream = fs.createWriteStream(filePath);
                writeStream.write(contents);

                writeStream.on("finish", () => {
                    console.log("wrote all data to file");
                });

              writeStream.end();

              let prefixDt = datetime.create();
              prefixDt.offsetInDays(-1);
              let prefixDate = prefixDt.format("Ymd");
              let folderData = prefixDt.format("Y-m-d");
              let splitDate = folderData.split("-");
              let prefix =
                  "reports/aicpa-report/" +
                  process.env.NODE_ENV +
                  "/" +
                  splitDate[0] +
                  "/" +
                  splitDate[1];
              let fileName = prefixDate + "-aicpa-report-cpa-data.csv";
              let bucketName = process.env.BUCKET_NAME + "/" + prefix;
  
            //   await awsS3.createLogFile(bucketName, fileName, contents);
  
              let fileUrl = process.env.BUCKET_URL + "/" + prefix + "/" + fileName;
              let bodyText = "<p>Hi, Please download the APICPA firm report by clicking the following link.</p></br><p><a href='" + fileUrl + "' target='_blank'>Download Report</a></p>";
              mailData = {
                  from_email: process.env.USER_INFO_EMAIL_FROM,
                  to_email: process.env.USER_INFO_EMAIL_TO_CPA,
                  subject:
                      "PPPForgivenessTool - CPA data as on " +
                      subjectDate,
                  html: bodyText
              };
              if (
                  process.env.USER_INFO_CC_EMAIL != undefined &&
                  process.env.USER_INFO_CC_EMAIL != ""
              ) {
                  mailData["cc"] = process.env.USER_INFO_CC_EMAIL;
              }
          } else {
              mailData = {
                  from_email: process.env.USER_INFO_EMAIL_FROM,
                  to_email: process.env.USER_INFO_EMAIL_TO_CPA,
                  subject:
                      "PPPForgivenessTool - CPA data as on " +
                      subjectDate,
                  text: "Hi, No CPA data was found",
              };
              if (
                  process.env.USER_INFO_CC_EMAIL != undefined &&
                  process.env.USER_INFO_CC_EMAIL != ""
              ) {
                  mailData["cc"] = process.env.USER_INFO_CC_EMAIL;
              }
          }
  
          let notification = await mailer.mailSender(mailData);
  
        //   fs.unlink(filePath, function (err) {
        //       if (err) {
        //           reject(err);
        //       }
        //   });
  
          if (notification) {
              resolve(notification);
          } else {
              throw new Error("Mail not sent");
          }
          
        } catch (error) {
            reject(error);
        }
    }).catch(function (error) {
        throw error;
    });
};

exports.caseLinkupReport = async () => {
    return new Promise(async function (resolve, reject) {
        try {
            let mailData = "";
            let filePath = "";
            const fields = [
                // "Case ID",
                // "Application Type",
                // "Loan Number",
                // "Business Name",
                // "Lender",
                // "Funded Date",
                // "Funded Amount",
                // "Commission",
                // "Opt-Out",
                // "App Status",
                // "Total Amount for CPA Firm",
                // "CPA Firm",
                // "CPA Email ID",
                // "CPA Phone Number",
                // "CPA Verified",
                // "CPA Firm Subscription",
                // "CPA Bank Name",
                // "CPA Routing Number",
                // "CPA Account Number",
                // "CPA Account Type",
                // "TAX ID"

                "CASE ID",
                "CPA FIRM NAME",
                "CPA NAME",
                "CPA EMAIL ID",
            ];

            const opts = { fields };
            const parser = new Parser(opts);

            // Subject date
            let subjectDt = datetime.create();
            subjectDt.offsetInDays(-1);
            let subjectDate = subjectDt.format("Ymd");

            let reportData = [];

            const query = [
                { $addFields: { app_id: {$toString: "$_id" } } },
                { $addFields: { id: { $toString: "$_id" } } },
                {
                    $lookup: {
                        let: { appId: "$id" },
                        from: "service_business",
                        as: "b2c_status_ref",
                        pipeline: [
                            {
                                $match: {
                                    $expr: {
                                        $eq: ["$$appId", "$app_id"]
                                    },
                                    type: "b2c_status"
                                }
                            },
                            {
                                $project: {
                                    _id: 0,
                                    type: 1,
                                    b2c_ref_id: "$ref_id",
                                    submitted_at: "$created_at"
                                }
                            }
                        ]
                    }
                },
                // {
                //     $lookup: {
                //         let: { appId: "$id" },
                //         from: "business_info",
                //         as: "business",
                //         pipeline: [
                //             {
                //                 $match: {
                //                     $expr: {
                //                         $eq: ["$$appId", "$app_id"]
                //                     }
                //                 }
                //             },
                //             {
                //                 $project: {
                //                     business_name: 1,
                //                     current_state: 1,
                //                     loan_amount: '$qualified_loan_amount',
                //                     sba_loan_no: 1,
                //                     _id: 0
                //                 }
                //             }
                //         ]
                //     }
                // },
                {
                    $project: {
                        _id: 0,
                        id: { $toString: "$_id" },
                        record_id: 1,
                        product_type: 1,
                        created_at: 1,
                        updated_at: 1,
                        status_id: 1,
                        backend_user_id: 1,
                        user_id: 1,
                        b2c_ref: { $arrayElemAt: ["$b2c_status_ref", 0] },
                        // biz: { $arrayElemAt: ["$business", 0] }
                    }
                },
                {
                    $replaceRoot: {
                        newRoot: {
                            $mergeObjects: ["$$ROOT", "$b2c_ref"]
                        }
                    }
                },
                {
                    $project: { b2c_ref: 0 }
                }
            ];

            let Applications = await application.getAggregate(query);
            const appIds = Applications.map(app => app.id);

            // fetch all b2c_status ref id from service business
            const b2cReferences = await serviceBusinessModel.getAggregate([
                {
                    $project: {
                        _id: 0,
                        ref_id: 1,
                    }
                },
                {
                    $group: {
                        _id: null,
                        ids: {
                            $push: "$ref_id"
                        }
                    }
                }
            ]);

            const refLeadMap = {};
            // get all the leadIds from ref_ids
            if (b2cReferences && b2cReferences.length && b2cReferences[0].ids && b2cReferences[0].ids.length) {
                // get all the lead ids

                const pppLeads = await PPPAppLeadModel.getAggregate([
                    {
                        $addFields: { id: { $toString: "$_id" } }
                    },
                    {
                        $match: {
                            id: { $in: b2cReferences[0].ids }
                        }
                    },
                    { $addFields: { len: { $size: { $ifNull: ["$application_status", []] } } } },
                    {
                        $project: {
                            id: 1,
                            _id: 0,
                            request_id: 1,
                            status: {
                                $arrayElemAt: ["$application_status", { $subtract: ["$len", 1] }]
                            }
                        }
                    }
                ]);

                if (pppLeads && pppLeads.length) {
                    pppLeads.forEach((lead) => {
                        refLeadMap[lead.id] = {
                            request_id: lead.request_id,
                            status: helper.getStatus(lead.status && lead.status.status ? lead.status.status : 'default'),
                            // sba_loan_number: (lead.status && lead.status.sba_loan_number) ? lead.status.sba_loan_number : '',
                            // sba_decision_date: helper.formatDate(helper.getFundedDate(lead)),
                            // amount: lead.status ? lead.status.amount : '',
                            // commission_amount: lead.status ? helper.calculateCommission(lead.status.amount) : 0
                        };
                    });
                }
            }

            // Applications = Applications.filter((app) => {
            //     if (refLeadMap[app.b2c_ref_id] && refLeadMap[app.b2c_ref_id].status === 'Funded') {
            //         return app;
            //     }
            // });

            // const appRecords = await appRecordsModel.getAggregate([{
            //     $match: {
            //         $and: [
            //             {app_type: { $eq: 'WITH_AGENT_FEE' }},
            //             {request_id: { $in: appIds}}
            //         ]
            //     }
            //     },
            //     {
            //         $project: {
            //             app_type: 1,
            //             request_id: 1,
            //             opt_out: 1
            //         }
            //     }
            // ]);
            const optOutMappings = {};
            const AppsToBeMapped = [];
            // appRecords.map((app) => {
            //     AppsToBeMapped.push(app.request_id);
            //     optOutMappings[app.request_id] = app.opt_out;
            // });

            // Applications = Applications.filter((app) => {
            //     if (AppsToBeMapped.indexOf(app.id) > -1) {
            //         return app;
            //     }
            // })
            
            const AppUserBackckendUserGroup = await application.getAggregate([
                {$addFields: { app_id: { $toString: "$_id" } }  },
                { $group: { _id: null, backend_ids: { $addToSet: "$backend_user_id" } } }
            ]);

            if (AppUserBackckendUserGroup && AppUserBackckendUserGroup.length) {
                let { backend_ids } = AppUserBackckendUserGroup[0];
                const cpaUsersMap = {};
                const backendAdminMap = {};
                const adminFirmNameMap = {};
                const cpaAdminUsersMap = {};

                const email_addresses = [];
                if (backend_ids && backend_ids.length) {
                    const backendRecords = await backendUser.getAggregate([
                        // { $match: { 'data.cpa_firm_name': 'ROB SORUM CPA PC' } },
                        { $match: { email_address: { $nin: [/@b2cdev/i, /@biz2credit/i] } } },
                        { $addFields: { id: { $toString: "$_id" } } },
                        {
                            $match: {
                                id: { $in: backend_ids },
                                is_active: {$ne: false},
                                is_verified: {$ne: false}
                            }
                        },
                        {
                            $project: {
                                _id: 0,
                                id: { $toString: "$_id" },
                                email_address: 1,
                                phone_number: 1,
                                name: 1,
                                cpa_firm_name: "$data.cpa_firm_name",
                                // cpa_bank_name: "$data.bank_name",
                                // cpa_verified: "$data.cpa_verified",
                                // routing_number: '$data.routing_number',
                                // account_number: '$data.account_number',
                                // account_type: '$data.account_type',
                                // tax_number: '$data.tax_id',
                                registration_type: '$data.registration_type'
                            }
                        }
                    ]);

                    if (backendRecords && backendRecords.length) {
                        backendRecords.forEach((cpa) => {
                            cpaUsersMap[cpa.id] = cpa;
                            email_addresses.push(cpa.email_address);

                            // adminFirmNameMap.push(cpa.cpa_firm_name);
                            if(!adminFirmNameMap[cpa.cpa_firm_name]) {
                                adminFirmNameMap[cpa.cpa_firm_name] = cpa.cpa_firm_name
                            }
                            if (cpa.registration_type === 'normal') {
                                backendAdminMap[cpa.cpa_firm_name] = cpa;
                            }
                        });
                    }
                }

                const adminCpaRecords = await backendUser.getAggregate([
                    { $match: { 
                        'data.cpa_firm_name': {$in: Object.keys(adminFirmNameMap)},
                        'data.registration_type': 'normal',
                        // is_active: {$ne: false},
                        // is_verified: {$ne: false}
                     }},
                    { $addFields: { id: { $toString: "$_id" } } },
                    {
                        $project: {
                            _id: 0,
                            id: { $toString: "$_id" },
                            email_address: 1,
                            phone_number: 1,
                            name: 1,
                            cpa_firm_name: "$data.cpa_firm_name",
                            cpa_bank_name: "$data.bank_name",
                            cpa_verified: "$data.cpa_verified",
                            routing_number: '$data.routing_number',
                            account_number: '$data.account_number',
                            account_type: '$data.account_type',
                            tax_number: '$data.tax_id',
                            registration_type: '$data.registration_type'
                        }
                    }
                ]);

                if (adminCpaRecords && adminCpaRecords.length) {
                    adminCpaRecords.forEach((cpa) => {
                        cpaAdminUsersMap[cpa.cpa_firm_name] = cpa;
                    });
                }

                // perform query to get active plan under the firm
                // let activeUserPlans = await userPlans.getAggregate([
                //     {
                //         $match: {
                //             firm_name: { $in: Object.keys(adminFirmNameMap) },
                //             // email_address: { $in: email_addresses },
                //             is_active: true
                //         },
                //     },
                //     {
                //         $lookup: {
                //             from: "plans",
                //             localField: "plan_id",
                //             foreignField: '_id',
                //             as: 'plans'
                //         }
                //     },
                //     {
                //         $project: {
                //             plan_id: 1,
                //             firm_name: 1,
                //             email_address: 1,
                //             plan_price: {
                //                 $arrayToObject: {
                //                     $map: {
                //                         input: "$plans",
                //                         as: "p",
                //                         in: {
                //                             k: "plan",
                //                             v: "$$p",
                //                         }
                //                     }
                //                 }
                //             }
                //         }
                //     },
                //     {
                //         $replaceRoot: {
                //             newRoot: {
                //                 $mergeObjects: ["$$ROOT", "$plan_price"]
                //             }
                //         }
                //     },
                //     {
                //         $project: {
                //             type: "$plan.type",
                //             price: "$plan.price",
                //             plan_id: 1,
                //             firm_name: 1,
                //             email_address: 1,
                //         }
                //     }
                // ]);

                // map plan with email and firm to identify using firm or email address below
                const firmMap = {};
                // activeUserPlans.forEach((plan) => {
                //     if (plan.firm_name) {
                //         firmMap[plan.firm_name] = plan;
                //     }
                // });

                //get all master status
                const statusMap = {};
                // const appStatuss = await appStatus.find({}, { _id: 1, value: 1 });
                // if (appStatuss && appStatuss.length) {
                //     appStatuss.forEach((status) => {
                //         const s = status.toObject();
                //         statusMap[s._id.toString()] = s.value;
                //     });
                // }

                // get all master status
                const appTypeMap = {};
                // const appTypes = await appTypeModel.find({}, { _id: 1, type: 1 });
                // if (appTypes && appTypes.length) {
                //     appTypes.forEach((aType) => {
                //         const type = aType.toObject();
                //         appTypeMap[type._id.toString()] = type.type;
                //     });
                // }

                for (let index = 0; index < Applications.length; index++) {
                    const app = Applications[index];

                    if (app.backend_user_id && !cpaUsersMap[app.backend_user_id]) {
                        continue;
                    }

                    const appData = {
                        // "Case ID": "",
                        // "CPA Firm": "",
                        // "CPA Email ID": "",
                        // "CPA Phone Number": "",
                        // "Application Type": "",
                        // "Loan Number": "",
                        // "Business Name": app.business_name,
                        // "Lender": 'Itria',
                        // "Funded Date": "",
                        // "Funded Amount": "",
                        // "CPA Firm Subscription": "",
                        // "CPA Bank Name": "",
                        // "Total Amount for CPA Firm": "",
                        // "Commission": "",
                        // "Opt-Out": optOutMappings[app.id] || false,
                        // "App Status": "",
                        // "CPA Verified": "",
                        // "CPA Routing Number": "",
                        // "CPA Account Number": "",
                        // "CPA Account Type": "",
                        // "TAX ID": "",
                        "CASE ID": "",
                        "CPA FIRM NAME": "",
                        "CPA NAME": "",
                        "CPA EMAIL ID": ""
                    };

                    if (app.b2c_ref_id && refLeadMap[app.b2c_ref_id] && refLeadMap[app.b2c_ref_id].request_id) {
                        const splitted = refLeadMap[app.b2c_ref_id].request_id.split('-');
                        appData['CASE ID'] = splitted[1];
                        // appData['App Status'] = refLeadMap[app.b2c_ref_id].status;
                        // appData['Loan Number'] = refLeadMap[app.b2c_ref_id].sba_loan_number ? refLeadMap[app.b2c_ref_id].sba_loan_number : app.sba_loan_no;
                        // appData['Funded Amount'] = refLeadMap[app.b2c_ref_id].amount;
                        // appData['Funded Date'] = refLeadMap[app.b2c_ref_id].sba_decision_date;
                        // appData['Commission'] = refLeadMap[app.b2c_ref_id].commission_amount;
                    }

                    // if (app.product_type && appTypeMap[app.product_type]) {
                    //     appData['Application Type'] = appTypeMap[app.product_type];
                    // }

                    const adminCpa = cpaUsersMap[app.backend_user_id];
                    // const adminCpa = backendAdminMap[cpaUsersMap[app.backend_user_id].cpa_firm_name] || cpaAdminUsersMap[cpaUsersMap[app.backend_user_id].cpa_firm_name];
                    if (app.backend_user_id && adminCpa) {
                        // const selectedPlan = firmMap[adminCpa.cpa_firm_name];
                        // if (selectedPlan && selectedPlan.type !=='free') {
                            appData['CPA FIRM NAME'] = adminCpa.cpa_firm_name;
                            appData['CPA NAME'] = adminCpa.name;
                            // appData['CPA Bank Name'] = adminCpa.cpa_bank_name;
                            // appData['CPA Verified'] = adminCpa.cpa_verified;
                            
                            // appData['CPA Firm Subscription'] = selectedPlan ? selectedPlan.type : "",
                            // appData['CPA Routing Number'] = adminCpa.routing_number;
                            // appData['CPA Account Number'] = adminCpa.account_number;
                            // appData['CPA Account Type'] = adminCpa.account_type;
                            // appData['TAX ID'] = adminCpa.tax_number;
                            appData['CPA EMAIL ID'] = adminCpa.email_address;
                            // appData['CPA Phone Number'] = adminCpa.phone_number;
                            reportData.push(appData);
                        // }
                    }
                };
            }
            // const totalCommissionData = {};
            // reportData.forEach(data => {
            //     if (totalCommissionData[data['CPA Firm']]) {
            //         totalCommissionData[data['CPA Firm']] += data['Commission'] ? data['Commission'] : 0
            //     } else {
            //         totalCommissionData[data['CPA Firm']] = data['Commission'] ? data['Commission'] : 0
            //     }
            // });
            // reportData = reportData.map(report => {
            //     report['Total Amount for CPA Firm'] = totalCommissionData[report['CPA Firm']];
            //     return report;
            // });


            if (reportData && reportData.length) {
                let contents = parser.parse(reportData);
                // Temporary file name
                let attach_fileName = "ppp-caseid-update-report.csv";

                if (process.env.NODE_ENV == "local") {
                    filePath = path.resolve(attach_fileName);
                } else {
                    filePath = path.resolve("/tmp/" + attach_fileName);
                }

                const writeStream = fs.createWriteStream(filePath);
                writeStream.write(contents);

                writeStream.on("finish", () => {
                    console.log("wrote all data to file");
                });

                writeStream.end();
                let prefixDt = datetime.create();
                prefixDt.offsetInDays(-1);
                let prefixDate = prefixDt.format("Ymd");
                let folderData = prefixDt.format("Y-m-d");
                let splitDate = folderData.split("-");
                let prefix =
                    "reports/aicpa-report/" +
                    process.env.NODE_ENV +
                    "/" +
                    splitDate[0] +
                    "/" +
                    splitDate[1];
                let fileName = prefixDate + "-ppp-application-report.csv";
                let bucketName = process.env.BUCKET_NAME + "/" + prefix;

                // await awsS3.createLogFile(bucketName, fileName, contents);

                let fileUrl = process.env.BUCKET_URL + "/" + prefix + "/" + fileName;
                let bodyText = "<p>Hi, Please download the application level report by clicking the following link.</p></br><p><a href='" + fileUrl + "' target='_blank'>Download Report</a></p>";

                mailData = {
                    from_email: process.env.USER_INFO_EMAIL_FROM,
                    to_email: process.env.USER_INFO_EMAIL_TO_CPA,
                    subject:
                        "CPALoanPortal - Application data as on " +
                        subjectDate,
                    html: bodyText
                };
                if (
                    process.env.USER_INFO_CC_EMAIL != undefined &&
                    process.env.USER_INFO_CC_EMAIL != ""
                ) {
                    mailData["cc"] = process.env.USER_INFO_CC_EMAIL;
                }

            } else {
                mailData = {
                    from_email: process.env.USER_INFO_EMAIL_FROM,
                    to_email: process.env.USER_INFO_EMAIL_TO_CPA,
                    subject:
                        "CPALoanPortal - Application data as on " +
                        subjectDate,
                    text: "Hi, No Application data was found",
                };
                if (
                    process.env.USER_INFO_CC_EMAIL != undefined &&
                    process.env.USER_INFO_CC_EMAIL != ""
                ) {
                    mailData["cc"] = process.env.USER_INFO_CC_EMAIL;
                }
            }

            // let notification = await mailer.mailSender(mailData);

            // fs.unlink(filePath, function (err) {
            //     if (err) {
            //         reject(err);
            //     }
            // });

            resolve(reportData);
            // if (notification) {
            //     resolve(notification);
            // } else {
            //     throw new Error("Mail not sent");
            // }

        } catch (error) {
            reject(error);
        }
    }).catch(function (error) {
        throw error;
    });
}

exports.forgiveness_consume_count = async function () {
    return new Promise(async function (resolve, reject) {
        try {
            let mailData = "";
            let filePath = "";

            let finalData = [];
            const APP_SUBMITTED = '5c20bf7e27105c78ad7f9280';
            const PPP2 = '5f40fb82b365b23a003e3708';
            const FORGIVENESS = '5cf61ae8a567c9873cbab4d5';
            // Set header of the csv
            const fields = [
                "CPA Firm Name",
                'Advanced - Forgiveness',
                'Simple - Forgiveness',
                'Advanced - Forgiveness Submitted',
                'Simple - Forgiveness Submitted',
                'Consumed Forgiveness Apps',
                'update'
                
            ];


            const opts = { fields };
            const parser = new Parser(opts);

            // Get start time

            let pastDate = '2020-07-16';

            let pastStartDt = datetime.create(pastDate);
            pastStartDt = pastStartDt.format("Y-m-d");

            let startDt = datetime.create(pastStartDt);
            let startTime = startDt.epoch();

            // Get End time
            let pastEndDt = datetime.create();
            pastEndDt = pastEndDt.format("Y-m-d");
            let endDt = datetime.create(pastEndDt);
            //endDt.offsetInDays(-1);
            let endTime = endDt.epoch();

            // Subject date
            let subjectDt = datetime.create();
            subjectDt.offsetInDays(-1);
            let subjectDate = subjectDt.format("Ymd");


            const firms = []; 
                

            const firmNames = [];
            firms.forEach((firm) => {
                firmNames.push(firm.firm_name);
            });


            let queryBuild = [
                {
                    $match: {
                        'data.cpa_firm_name': {
                            $in: firmNames
                        }
                    }
                },
                {
                    "$match": {
                        '$and': [
                            { email_address: { '$not': /^.*@(b2cdev|biz2credit)\.([a-zA-Z\.]{2,})/ } },
                            { email_address: { '$ne': null } },
                        ],
                    }
                },
                { "$group": { _id: "$data.cpa_firm_name", "doc": { "$first": "$$ROOT" }, backend_ids: { $push: { $toString: "$_id" } } } },
                { $project: {firm_name: '$_id', backend_ids: 1} }
            ];

            let cpaUserFirm = await backendUser.getAggregate(queryBuild);


            const firmBackendIdMap = {};
            const backendIdFirmMap = {};
            cpaUserFirm.forEach((firm) => {
                firmNames.push(firm.firm_name);
                firmBackendIdMap[firm.firm_name.toLowerCase()] = firm.backend_ids;
                firm.backend_ids.forEach((id) => { backendIdFirmMap[id] =  firm.firm_name});
            });

            
            const query = [
                {
                    $match: {
                        is_deleted: {
                            $ne: true
                        },
                        product_type: "5cf61ae8a567c9873cbab4d5",
                        // status_id: APP_SUBMITTED,
                        backend_user_id: { $in: Object.keys(backendIdFirmMap) }
                    }
                },
                { $addFields: { id: { $toString: "$_id" } } },
                {
                    $lookup: {
                        let: { appId: "$id" },
                        from: "business_info",
                        as: "business",
                        pipeline: [
                            {
                                $match: {
                                    $expr: {
                                        $eq: ["$$appId", "$app_id"]
                                    }
                                }
                            },
                            {
                                $project: {
                                    business_name: 1,
                                    current_state: 1,
                                    is3508StOrEZForm: 1
                                }
                            }
                        ]
                    }
                },
                {
                    $project: {
                        _id: 0,
                        id: { $toString: "$_id" },
                        record_id: 1,
                        product_type: 1,
                        created_at: 1,
                        updated_at: 1,
                        status_id: 1,
                        backend_user_id: 1,
                        user_id: 1,
                        biz: { $arrayElemAt: ["$business", 0] }
                    }
                },
               
            ];

            let Applications = await application.getAggregate(query);

            const simpleOrAdvancForgvCount = {};
            Applications.forEach((app) => {
                const firmName = backendIdFirmMap[app.backend_user_id];
                if(!simpleOrAdvancForgvCount[firmName]) {
                    simpleOrAdvancForgvCount[firmName] = {simple: 0, advance: 0, advance_submitted: 0, simple_submitted: 0};
                }

                simpleOrAdvancForgvCount[firmName].simple += (app.biz && app.biz.is3508StOrEZForm === false ? 1: 0);
                simpleOrAdvancForgvCount[firmName].advance += (app.biz && app.biz.is3508StOrEZForm === true ? 1: 0);
                if(app.product_type === '5cf61ae8a567c9873cbab4d5' && app.status_id === APP_SUBMITTED) {
                    simpleOrAdvancForgvCount[firmName].simple_submitted += (app.biz && app.biz.is3508StOrEZForm === false ? 1: 0);
                    simpleOrAdvancForgvCount[firmName].advance_submitted += (app.biz && app.biz.is3508StOrEZForm === true ? 1: 0);
                }

            });


                const firm_names_regex = [];
                firms.forEach((cpaFirm) => {
                    firm_names_regex.push(new RegExp(`^${cpaFirm.lower_firm_name}$`, 'i'));
                });


                // perform query to get active plan under the firm
                let userBoughtPlans = await userPlans.getAggregate([
                    {
                        $match: {
                            $or: [
                                { firm_name: { $in: firm_names_regex } }
                            ]
                        },
                    },
                     {
                        $lookup: {
                          let: {user_plan_id: "$_id"},
                          from :'user_plan_consumes',
                          as:'plan_consumes',
                          pipeline: [
                            {
                              $match: {
                                $expr: {
                                  $eq: ["$user_plan_id", "$$user_plan_id"]
                                }
                              }
                            }
                          ]
                        }
                      },
                    {
                        $project: {
                            plan_id: 1,
                            firm_name: 1,
                            email_address: 1,
                            payment_status: 1,
                            payment_date: 1,
                            payment_amount: 1,
                            createdAt: 1,
                            plan_consumes: 1,
                            is_active:1
                        }
                    }
                ]);

                const forgivenessCount = {};
                const firmPlanMap = {};
                userBoughtPlans.forEach((planBought) => {
                    if(!forgivenessCount[planBought.firm_name]) forgivenessCount[planBought.firm_name] = 0;

                    if(planBought.plan_consumes && planBought.plan_consumes && planBought.plan_consumes[0] && planBought.plan_consumes[0].pp1_forgiveness) {
                        const count = planBought.plan_consumes[0].pp1_forgiveness.application_hard_limit;
                        forgivenessCount[planBought.firm_name] += count; 
                    }

                    if(!firmPlanMap[planBought.firm_name]) {
                        firmPlanMap[planBought.firm_name] = [];
                    }

                    firmPlanMap[planBought.firm_name].push(planBought);
                });
                // map plan with email and firm to identify using firm or email address below


                const updateData = [];
                for (let firm of firms) {

                    const consumed = forgivenessCount[firm.firm_name];
                    const count = simpleOrAdvancForgvCount[firm.firm_name];
                    const advance = count && count.advance !== undefined ? count.advance : '';
                    const simple = count && count.simple !== undefined ? count.simple : '';
                    const simple_submitted = count && count.simple_submitted !== undefined ? count.simple_submitted : '';
                    const advance_submitted = count && count.advance_submitted !== undefined ? count.advance_submitted : '';


                    let cpaAppData = {
                        "CPA Firm Name": firm.firm_name,
                        'Advanced - Forgiveness': advance,
                        'Simple - Forgiveness': simple,
                        'Advanced - Forgiveness Submitted': advance_submitted,
                        'Simple - Forgiveness Submitted': simple_submitted,
                        'Consumed Forgiveness Apps': consumed  
                    }


                    const totalSubmitted = (advance_submitted || 0);
                    // const totalSubmitted = (advance_submitted || 0) + (simple_submitted || 0);
                    if(consumed && consumed > totalSubmitted) {
                        
                        /* 
                        i.e 
                        consumed:10
                            basic: 2
                            premium: 3
                            enterprise: 5

                        totalSubmitted: 1
                            find diff = consumed - totalSubmitted
                                      = 10 - 1  
                                      = 9
                                now find the plan consumed for each plan bought
                                
                                for plan of planBougt
                                    loop:1
                                    enterprise consume: 5, diff 9
                                    if( 9 >= 5) { //check if diff >= enterprise consume
                                        //find new diff
                                        //diff = diff - enterprise consume
                                        //diff = 9-5
                                        diff = 4;
                                        // new update consumed value for enterprise is zero

                                    } 

                                    loop 2: 
                                    premium consume:3, diff: 4
                                    if(4 >= 3) { // check if diff >= premium consume
                                        // find the new diff
                                        //diff = diff-premium
                                        //diff = 4-3
                                        diff = 1;
                                        // new updated value for premium is zero
                                    }

                                    loop 3:
                                    basic consume:2, diff: 1
                                    if(1 >=2 ) { // check if diff >= basic consume
                                        // will not execute
                                    } else {
                                        // will execute as diff is less than the basic plan consume
                                        // find the new diff
                                        //diff = basic consume - diff;
                                        //diff = 2-1;
                                        diff = 1;
                                        // new updated value for basic consume is diff i.e 1
                                    }


                        
                        */

                       let diff = consumed - totalSubmitted;
                       const userPlan = firmPlanMap[firm.firm_name];
                        if(!cpaAppData['update']) {
                            cpaAppData['update'] = [];
                        }
                       if(userPlan && userPlan.length) {
                           for (let index = userPlan.length-1; index >=0; index--) {
                               const pBought = userPlan[index];
                               
                               if(pBought.plan_consumes && pBought.plan_consumes && pBought.plan_consumes[0] && pBought.plan_consumes[0].pp1_forgiveness) {
                                    const appConsumed = pBought.plan_consumes[0].pp1_forgiveness.application_hard_limit;
                                    if(!diff) {
                                        continue;
                                    }
                                    if(diff >= appConsumed) {
                                        // find new diff and use that diff to update the value
                                        diff = diff - appConsumed;
                                        cpaAppData['update'].push({_id:pBought.plan_consumes[0]._id, diff: diff, plan: pBought.plan_id, feature: 'pp1_forgiveness.application_hard_limit', current_value:appConsumed, email_address:pBought.email_address , updated_value:0});
                                    } else {
                                        const value = appConsumed - diff;
                                        diff = 0;
                                        cpaAppData['update'].push({_id:pBought.plan_consumes[0]._id, diff: diff, plan: pBought.plan_id, feature: 'pp1_forgiveness.application_hard_limit', current_value:appConsumed, email_address:pBought.email_address ,  updated_value: value});
                                    }
                               }
                           }
                       }
                    } else if((consumed && consumed <= totalSubmitted) || (!consumed)) {
                        const userPlan = firmPlanMap[firm.firm_name]; 
                        if(!cpaAppData['update']) {
                            cpaAppData['update'] = [];
                        }
                        if(userPlan && userPlan.length) {
                            const pBought = userPlan.filter((plan) => plan.plan_consumes && plan.plan_consumes.length).pop();
                            if(pBought && pBought.plan_consumes && pBought.plan_consumes && pBought.plan_consumes[0]) {
                                const appConsumed = pBought.plan_consumes[0].pp1_forgiveness && pBought.plan_consumes[0].pp1_forgiveness.application_hard_limit ? pBought.plan_consumes[0].pp1_forgiveness.application_hard_limit: 0;
    
                                cpaAppData['update'].push({_id:pBought.plan_consumes[0]._id, plan: pBought.plan_id, feature: 'pp1_forgiveness.application_hard_limit', current_value:appConsumed, email_address:pBought.email_address , updated_value: totalSubmitted});
                            } 
                        }
                    }

                    // cpaAppData['update'] = JSON.stringify(cpaAppData['update']);
                    finalData.push(cpaAppData);

                }

            if (finalData.length > 0) {
                // Convert json data into csv
                let contents = parser.parse(finalData);

                const dt = new Date();
                const dd = dt.getDate();
                const mm = dt.getMonth() + 1;
                const yyyy = dt.getFullYear();
                // Temporary file name
                let attach_fileName = `${mm}-${dd}-${yyyy}-aicpa-forgiveness-app-count-report.csv`;

                if (process.env.NODE_ENV == "local") {
                    filePath = path.resolve(attach_fileName);
                } else {
                    filePath = path.resolve("/tmp/" + attach_fileName);
                }

                const writeStream = fs.createWriteStream(filePath);
                writeStream.write(contents);

                writeStream.on("finish", () => {
                    console.log("wrote all data to file");
                });

              writeStream.end();

              let prefixDt = datetime.create();
              prefixDt.offsetInDays(-1);
              let prefixDate = prefixDt.format("Ymd");
              let folderData = prefixDt.format("Y-m-d");
              let splitDate = folderData.split("-");
              let prefix =
                  "reports/aicpa-report/" +
                  process.env.NODE_ENV +
                  "/" +
                  splitDate[0] +
                  "/" +
                  splitDate[1];
              let fileName = prefixDate + "-aicpa-report-cpa-data.csv";
              let bucketName = process.env.BUCKET_NAME + "/" + prefix;
  
            //   await awsS3.createLogFile(bucketName, fileName, contents);
  
              let fileUrl = process.env.BUCKET_URL + "/" + prefix + "/" + fileName;
              let bodyText = "<p>Hi, Please download the APICPA firm report by clicking the following link.</p></br><p><a href='" + fileUrl + "' target='_blank'>Download Report</a></p>";
              mailData = {
                  from_email: process.env.USER_INFO_EMAIL_FROM,
                  to_email: process.env.USER_INFO_EMAIL_TO_CPA,
                  subject:
                      "PPPForgivenessTool - CPA data as on " +
                      subjectDate,
                  html: bodyText
              };
              if (
                  process.env.USER_INFO_CC_EMAIL != undefined &&
                  process.env.USER_INFO_CC_EMAIL != ""
              ) {
                  mailData["cc"] = process.env.USER_INFO_CC_EMAIL;
              }
          } else {
              mailData = {
                  from_email: process.env.USER_INFO_EMAIL_FROM,
                  to_email: process.env.USER_INFO_EMAIL_TO_CPA,
                  subject:
                      "PPPForgivenessTool - CPA data as on " +
                      subjectDate,
                  text: "Hi, No CPA data was found",
              };
              if (
                  process.env.USER_INFO_CC_EMAIL != undefined &&
                  process.env.USER_INFO_CC_EMAIL != ""
              ) {
                  mailData["cc"] = process.env.USER_INFO_CC_EMAIL;
              }
          }
  
          let notification = await mailer.mailSender(mailData);
  
        //   fs.unlink(filePath, function (err) {
        //       if (err) {
        //           reject(err);
        //       }
        //   });
  
          if (notification) {
              resolve(notification);
          } else {
              throw new Error("Mail not sent");
          }
          
        } catch (error) {
            reject(error);
        }
    }).catch(function (error) {
        throw error;
    });
};


exports.getCoverPeriodReport = async () => {
    return new Promise(async function (resolve, reject) {
        try {
            /*const date = momentTz.utc('05-10-2021').format('ddd, DD MMM YYYY h:mm:ss z');
            resolve({date}); return;*/
            const fields = [
                "App Id",
                "ForgiveApp Id",
                "covered_period_start_date",
                "lead_id",
                "case_id",
                "loan_disburse_date",
                "Business Info Id"
            ];
            let filePath = "";
            const opts = { fields };
            const parser = new Parser(opts);
            const businessInfoData = await businessInfo.getAggregate([
                { $match: { 
                    'replicated.forgiveness_app_id': { $exists: true },
                    // 'replicated.forgiveness_app_id': '606239a95aef7a0028d16d72', //TODO
                 } },
                { $addFields: { id: { $toString: "$_id" } } },
                {
                    $lookup: {
                        let: { appId: { $toObjectId: "$app_id" } },
                        from: "application",
                        as: "forgiveness_app",
                        pipeline: [
                            {
                                $match: {
                                    $expr: {
                                        $eq: ["$$appId", "$_id"]
                                    },
                                    status_id: {$ne: '5c20bf7e27105c78ad7f9280'}
                                }
                            },
                            // {
                            //     $project: {
                            //         _id: 0,
                            //         b2c_ref_id: "$ref_id"
                            //     }
                            // }
                        ]
                    }
                },
                {
                    $project: {
                        ppp_app_id: '$replicated.forgiveness_app_id',
                        covered_period_start_date: 1, 
                        _id: 0, 
                        id: 1, 
                        app_id: 1, 
                        forgiveness_app: 1
                    }
                }
            ]);

            const businessDataMap = {}; // forgiveness_app_id: business info
            const pppAppIdMap = {}; // ppp_app_id: business info 
            businessInfoData.forEach(info => {
                businessDataMap[info.app_id] = info; //forgiveness app Ids
                if (info.forgiveness_app.length > 0) {
                    if (!pppAppIdMap[info.ppp_app_id]) {
                        pppAppIdMap[info.ppp_app_id] = [];
                    }   

                    pppAppIdMap[info.ppp_app_id].push(info);
                }
            });

            // finding ppp apps
            const applicationData = await application.getAggregate([
                { $addFields: { id: { $toString: "$_id" } } },
                { $match: { id: { $in: Object.keys(pppAppIdMap) },
                //  status_id: {$ne: APP_TYPE_SUBMITTED}
                 } },
                {
                    $lookup: {
                        let: { appId: "$id" },
                        from: "service_business",
                        as: "b2c_status_ref",
                        pipeline: [
                            {
                                $match: {
                                    $expr: {
                                        $eq: ["$$appId", "$app_id"]
                                    },
                                    type: "b2c_status"
                                }
                            },
                            {
                                $project: {
                                    _id: 0,
                                    b2c_ref_id: "$ref_id"
                                }
                            }
                        ]
                    }
                },
                {
                    $project: {
                        _id: 0,
                        id: 1,
                        record_id: 1,
                        status_id: 1,
                        b2c_status_ref:1,
                        ref_size: { $size: '$b2c_status_ref' }
                    }
                },
                {
                    $project: {
                        _id: 0,
                        id: 1,
                        record_id: 1,
                        status_id: 1,
                        b2c_ref: { $arrayElemAt: ["$b2c_status_ref", { $cond: { if: { $eq: ['$ref_size', 0] }, then: 0, else: { $subtract:['$ref_size', 1] } } }] }
                    }
                },
                {
                    $replaceRoot: {
                        newRoot: {
                            $mergeObjects: ["$$ROOT", "$b2c_ref"]
                        }
                    }
                },
                {
                    $project: { b2c_ref: 0 }
                }
            ]);

            // ppp app ref ids
            const refIds = applicationData.map(app => mongoose.Types.ObjectId(app.b2c_ref_id));
            // finding ppp application b2c references by ref_ids
            const pppLeadData = await PPPAppLeadModel.getAggregate([
                { 
                    $match: {
                        _id: { $in: refIds }
                    }
                },
                { $addFields: { len:  {$size: {$ifNull: ["$application_status", []]}}}},
                { $addFields: { id: { $toString: "$_id" } } },
                {
                    $project: {
                        id:1, 
                        _id:0,
                        request_id:1,
                        status: { 
                            $arrayElemAt: ["$application_status",  { $cond: { if: { $eq: ['$len', 0] }, then: 0, else: { $subtract: ['$len', 1] } } }] 
                        } 
                    }
                }
            ]);

            const pppLeadMapData = {}; // ref_id: ref
            pppLeadData.map(ppp => pppLeadMapData[ppp.id] = ppp);

            const reportData = [];
            const filteredbusinessDataMap = [];
            // looping ppp apps
            for(let index=0; index < applicationData.length; index++) {
                const pppAPP = applicationData[index];
                const businessData = pppAppIdMap[pppAPP.id];
                const ppp = pppLeadMapData[pppAPP.b2c_ref_id];
                const splitted = ppp.request_id.split('-');
                

                if (!ppp.status.loan_disburse_date) {
                    continue;
                }
                
                const formattedDisbursePeriod = new Date(ppp.status.loan_disburse_dat);
                // const formattedDisbursePeriod = new Date(helper.getActualDate(ppp.status.loan_disburse_date));
                businessData.forEach(business => {
                    // const formattedCoverPeriod = new Date(business.covered_period_start_date);
                    if (!business.covered_period_start_date) {
                        filteredbusinessDataMap.push(business.app_id);
                        reportData.push({
                            "PPPApp Id": 'APP' + pppAPP.record_id,
                            "ForgiveApp Id": business.forgiveness_app[0] ? 'APP' + business.forgiveness_app[0].record_id : '',
                            "covered_period_start_date": business.covered_period_start_date || '',
                            "lead_id": splitted[0],
                            "case_id": splitted[1],
                            "loan_disburse_date": ppp.status.loan_disburse_date ? ppp.status.loan_disburse_date : '',
                            "Business Info Id": business.id,
                            "Date To Update": momentTz.utc(ppp.status.loan_disburse_date).format('ddd, DD MMM YYYY h:mm:ss z')
                        });
                    } else {
                        const formattedCoverPeriod = new Date(business.covered_period_start_date);
                        if (formattedCoverPeriod.getTime() < formattedDisbursePeriod.getTime()) {
                            filteredbusinessDataMap.push(business.app_id);
                            reportData.push({
                                "PPPApp Id": 'APP' + pppAPP.record_id,
                                "ForgiveApp Id": business.forgiveness_app[0] ? 'APP' + business.forgiveness_app[0].record_id : '',
                                "covered_period_start_date": business.covered_period_start_date,
                                "lead_id": splitted[0],
                                "case_id": splitted[1],
                                "loan_disburse_date": ppp.status.loan_disburse_date ? ppp.status.loan_disburse_date : '',
                                "Business Info Id": business.id,
                                "Date To Update": momentTz.utc(ppp.status.loan_disburse_date).format('ddd, DD MMM YYYY h:mm:ss z')
                            });
                        }
                    } 
                });
            }

            const forgivenessAppData = await serviceBusinessModel.getAggregate([
                {
                    $match: {
                        app_id: {
                            $in: filteredbusinessDataMap
                        },
                        is_deleted: {$ne: true},
                        $or: [
                            {response: /form_3508/},
                            {'response.doc_name': 'form_3505'},
                            {type: 'esign-pending'},
                            {type: 'esign-complete'}
                        ]
                        
                    }
                }
            ]);
            resolve({forgivenessAppData, reportData});
            return;

            if (reportData && reportData.length) {
                let contents = parser.parse(reportData);
                // Temporary file name
                let prefixDtDummy = datetime.create();
                let prefixDate2 = prefixDtDummy.format("m-d-Y");
                let attach_fileName = "cover-period-report" + prefixDate2 + ".csv";

                if (process.env.NODE_ENV == "local") {
                    filePath = path.resolve(attach_fileName);
                } else {
                    filePath = path.resolve("/tmp/" + attach_fileName);
                }

                const writeStream = fs.createWriteStream(filePath);
                writeStream.write(contents);

                writeStream.on("finish", () => {
                    console.log("wrote all data to file");
                });

                writeStream.end();
            }
            resolve({reportData});
        } catch (error) {
            reject(error);
        }
    }).catch(function (error) {
        throw error;
    });
}

exports.updateDisburseDate = async () => {
    return new Promise(async function (resolve, reject) {
        try {
            const commissionData = require('../ALL.CLIENTS/update-loan-dis/commission-data.json');
            const updateData = require('../ALL.CLIENTS/update-loan-dis/new-date-file.json');
            const newData = updateData.map(data => {
                const find = commissionData.find(comm => comm['Case ID'] === data['Case ID']);
                if (find) {
                    data['ppp_id'] = find['ref_id'];
                    data['request_id'] = find['request_id'];
                    data['datetime'] = find['datetime'];
                    data['decision_date'] = find['decision_date'];
                }
                return {
                    "Case ID": data['Case ID'],
                    "Loan Number": data["Loan Number"],
                    "1502 Date": data["1502 Date"],
                    "Funded Amount": data["Funded Amount"],
                    "ppp_id": data["ppp_id"],
                    "request_id": data["request_id"],
                    "datetime": data["datetime"],
                    "decision_date": data["decision_date"]
                };
            });
            resolve({newData});
        } catch (error) {
            reject(error);
        }
    }).catch(function (error) {
        throw error;
    });
}


exports.bulk_app_assignment = async function () {
    return new Promise(async function (resolve, reject) {
        try {
            let mailData = "";
            let filePath = "";

            //let cpaUsers = [];
            let cpaApplication = [];
            let finalData = [];
            const detector = new deviceDetector();
            const APP_SUBMITTED = '5c20bf7e27105c78ad7f9280';
            const PPP2 = '5f40fb82b365b23a003e3708';
            const FORGIVENESS = '5cf61ae8a567c9873cbab4d5';
            // Set header of the csv
            const fields = [
                "CPA Firm Name",
                "Source",
                "Subsource",
                "CPA Name",
                "CPA Email Address",
                'Affiliate',
                'track_name',

                'Client Email',
                'Client Name',

                'CPA_login_user_id',
                'CPA_login_user_name',

                'request_id',

                "App Id", // ppp app id
                "App Type", // ppp or forgiveness
                "Loan Amount", // select apps only less then 150k
                "Assigned to borrower", // true or false
                "forgiveness_submitted", // true or false,
                'B2C Status',
                'Business Id'
            ];

            const opts = { fields };
            const parser = new Parser(opts);

            // Get start time

            let pastDate = '2020-07-16';

            let pastStartDt = datetime.create(pastDate);
            pastStartDt = pastStartDt.format("Y-m-d");

            let startDt = datetime.create(pastStartDt);
            let startTime = startDt.epoch();

            // Get End time
            let pastEndDt = datetime.create();
            pastEndDt = pastEndDt.format("Y-m-d");
            let endDt = datetime.create(pastEndDt);
            //endDt.offsetInDays(-1);
            let endTime = endDt.epoch();

            // Subject date
            let subjectDt = datetime.create();
            subjectDt.offsetInDays(-1);
            let subjectDate = subjectDt.format("Ymd");

            let queryBuild = [
                {
                    $match: {
                        'data.cpa_firm_name': {
                            $in: ['Nevada Quickbooks Pro']
                            
                        }
                    }
                },
                {
                    "$match": {
                        '$and': [
                            { created_at: { $lt: endTime } },
                            { created_at: { $gte: startTime } },
                            { email_address: { '$not': /^.*@(b2cdev|biz2credit)\.([a-zA-Z\.]{2,})/ } },
                            { email_address: { '$ne': null } },
                            {delete: {$ne: true}},
                            {'data.cpa_firm_name': {$exists: true}},
                            // {is_active: { $ne: false }},
                            // {is_verified: { $ne: false }}
                        ],
                    }
                },
                { "$group": { _id: { $toLower: "$data.cpa_firm_name" }, "doc": { "$first": "$$ROOT" }, backend_ids: { $push: { $toString: "$_id" } } } },
                { $project: {firm_name: '$_id', backend_ids: 1} }
            ];

            
            let cpaUserFirm = await backendUser.getAggregate(queryBuild);
            
            // const cpaUserMap = {};
            // cpaUserFirm.forEach((firm) => {
            //     cpaUserMap[firm.data.cpa_firm_name] = true;
            // });
            
            // return resolve(cpaUserMap);
            
            
            const firmNames = [];
            const firmBackendIdMap = {};
            cpaUserFirm.forEach((firm) => {
                firmNames.push(firm.firm_name);
                firmBackendIdMap[firm.firm_name.toLowerCase()] = firm.backend_ids;
            });

            const cpaUserQuery = [
                { $match: { delete: { $ne: true } } },
                { $addFields: { firm_name: { $toLower: "$data.cpa_firm_name" } } },
                { $match: { "firm_name": { $in: firmNames } } },
            ];

            let queryModel = backendUser.getBackendUserModel(cpaUserQuery);

            let cpaUserData = await backendUser.getAggregate(queryModel);

            const backendIdUserMap = {};
            if (cpaUserData.length) {
                const userIds = [];
                const firm_names_regex = [];
                const email_addresses = [];
                cpaUserData.forEach((cpaUser) => {
                    userIds.push(...firmBackendIdMap[cpaUser.data.cpa_firm_name.toLowerCase()]);
                    firm_names_regex.push(new RegExp(cpaUser.data.cpa_firm_name, 'i'));
                    email_addresses.push(cpaUser.email_address);
                    if(!backendIdUserMap[cpaUser._id]) {
                        backendIdUserMap[cpaUser._id] = cpaUser;
                    }
                });
// return resolve(cpaUserData);
                // submitted ppp2 apps
                const appData = await application.getAggregate([
                    {
                        $match: {
                            backend_user_id: { $in: userIds },
                            product_type: PPP2,
                            status_id: APP_SUBMITTED,
                            "is_deleted" : { $ne: true }
                        }
                    },
                    {
                        $project: {
                            app_id: { $toString: "$_id"},
                            status_id: 1,
                            product_type: 1,
                            backend_user_id: 1,
                            record_id:1,
                            user_id:1
                        }
                    }
                ]);

                const AppUserMap = {};
                const pppAppMap = {};
                appData.forEach((app) => {
                    if(!pppAppMap[app.app_id]){
                        pppAppMap[app.app_id] = app;
                    }

                    if(!AppUserMap[app.user_id]){
                        AppUserMap[app.user_id] = app;
                    }
                })

                // ppp2 forgiveness app
                const businessdata = await businessInfo.getAggregate([
                    {
                        $match: { is_deleted: { $ne: true }, 'replicated.forgiveness_app_id': { $in: Object.keys(pppAppMap) } }
                    },
                    {
                        $project: {
                            forgiveness_app_id: '$app_id',
                            ppp_app_id: '$replicated.forgiveness_app_id',
                            business_id: '$_id',
                            user_id:'$user_id',
                            firm_name: '$cpa_firm_name',
                            sba_ppp_loan_amount: '$sba_ppp_loan_amount',
                            current_state: '$current_state'
                        }
                    }
                ]);

                const pppBusinessdata = await businessInfo.getAggregate([
                    {
                        $match: { is_deleted: { $ne: true }, 'app_id': { $in: Object.keys(pppAppMap) } }
                    },
                    {
                        $project: {
                            ppp_app_id: '$app_id',
                            business_id: '$_id',
                            user_id:'$user_id',
                            firm_name: '$cpa_firm_name',
                            sba_ppp_loan_amount: '$sba_ppp_loan_amount',
                            current_state: '$current_state',
                            is_forg_borrower:1
                        }
                    }
                ]);

                // ppp app_id and business map
                const pppAppBizMap = {};
                pppBusinessdata.forEach((biz) => {
                    if(!pppAppBizMap[biz.ppp_app_id]) {
                        pppAppBizMap[biz.ppp_app_id] = biz;
                    }
                })

                const forgivenessAppMap = {};
                const forgivenessPPPAppMap = {};
                businessdata.forEach((bi) => {
                    if(!forgivenessAppMap[bi.forgiveness_app_id]) {
                        forgivenessAppMap[bi.forgiveness_app_id] = bi;
                    }

                    if(!forgivenessPPPAppMap[bi.ppp_app_id]) {
                        forgivenessPPPAppMap[bi.ppp_app_id] = bi;
                    }
                });

                // forgiveness app
                const forgivenessAppData = await application.getAggregate([
                    {
                        $match: {
                            _id: { $in: Object.keys(forgivenessAppMap).map((id) => mongoose.Types.ObjectId(id)) },
                            is_deleted: { $ne: true },
                            // status_id: { $ne: APP_SUBMITTED }
                        }
                    },
                    {
                        $project: {
                            forgiveness_app_id: { $toString: "$_id"},
                            status_id: 1,
                            product_type: 1,
                            backend_user_id: 1,
                            record_id:1,
                            user_id: 1
                        }
                    }
                ]);

                // find ppp apps for forgivenessAppData as these are not submitted hence its ppp app can be moved to borrower

                const notSubmittedForgivenessAppMap = {};
                // const notSubmittedForgvTempMap = {};
                forgivenessAppData.forEach((forgivenessApp) => {
                    const forgvBusiness = forgivenessAppMap[forgivenessApp.forgiveness_app_id];

                    if(forgivenessApp.status_id !== APP_SUBMITTED) {
                        notSubmittedForgivenessAppMap[forgvBusiness.ppp_app_id] = forgvBusiness;
                    } 
                    
                    if(forgivenessApp.status_id === APP_SUBMITTED && notSubmittedForgivenessAppMap[forgvBusiness.ppp_app_id]) {
                        delete notSubmittedForgivenessAppMap[forgvBusiness.ppp_app_id];
                    }

                    if(forgivenessApp.status_id === APP_SUBMITTED && !notSubmittedForgivenessAppMap[forgvBusiness.ppp_app_id]) {
                        delete notSubmittedForgivenessAppMap[forgvBusiness.ppp_app_id];
                    }
                })
// return resolve(notSubmittedForgivenessAppMap);

                const clients = await userModel.find({ _id: { $in: Object.keys(AppUserMap).map((id) => mongoose.Types.ObjectId(id)) } }, { email_address:1, 'user_data.name':1, 'user_data.backend_user_id':1 });

                const clientMap = {};
                clients.forEach((client) => {
                    if(!clientMap[client._id]) {
                        clientMap[client._id] = client;
                    }
                })

                // only funded apps out of these apps have to be assign to borrower
                const pppAppsWithoutForgiveness = [];

                appData.forEach((app) => {
                    if(!forgivenessPPPAppMap[app.app_id]) {
                        pppAppsWithoutForgiveness.push(app);
                    }
                });


                const b2cRefs = await serviceBusinessModel.getAggregate([
                    {
                        $match: { type: 'b2c_status', app_id: { $in: Object.keys(pppAppMap) } }
                    }
                ]);

                // map of refid and ppp app id
                const refIdAppIdMap = {};
                const AppIdRefIdMap = {};
                b2cRefs.forEach((ref) => {
                    if(!refIdAppIdMap[ref.ref_id]) {
                        refIdAppIdMap[ref.ref_id] = ref.app_id;
                    }

                    if(!AppIdRefIdMap[ref.app_id]) {
                        AppIdRefIdMap[ref.app_id] = ref.ref_id;
                    }
                });


                  // ppp app ref ids
                const refIds = Object.keys(refIdAppIdMap).map(id => mongoose.Types.ObjectId(id));
                // finding ppp application b2c references by ref_ids
                const pppLeadData = await PPPAppLeadModel.getAggregate([
                    { 
                        $match: {
                            _id: { $in: refIds }
                        }
                    },
                    { $addFields: { len:  {$size: {$ifNull: ["$application_status", []]}}}},
                    { $addFields: { id: { $toString: "$_id" } } },
                    {
                        $project: {
                            id:1, 
                            _id:0,
                            request_id:1,
                            status: { 
                                $arrayElemAt: ["$application_status",  { $cond: { if: { $eq: ['$len', 0] }, then: 0, else: { $subtract: ['$len', 1] } } }] 
                            } 
                        }
                    }
                ]);

                const pppLeadMapData = {}; // ref_id: ref
                pppLeadData.map(ppp => pppLeadMapData[ppp.id] = ppp);

                // find apps from 
// return resolve(pppLeadMapData);
                for (let pppApp of pppAppsWithoutForgiveness) {

                    const client = clientMap[pppApp.user_id].toObject();
                    const cpa = backendIdUserMap[pppApp.backend_user_id];
                    const refId = AppIdRefIdMap[pppApp.app_id];

                    const pppLead = pppLeadMapData[refId];
                    const pppBiz = pppAppBizMap[pppApp.app_id];
                    if(!pppBiz) {
                        console.log(pppApp);
                        return resolve({ pppBiz, refId, pppApp });
                    }
                    
                    let cpaAppData = {
                        "CPA Firm Name": cpa && cpa.data.cpa_firm_name ? cpa.data.cpa_firm_name : '',
                        "Source": cpa && cpa.data.cpa_firm_name ? cpa.data.cpa_firm_name : '',
                        "Subsource": 'PPP',
                        "CPA Name": cpa && cpa.name ? cpa.name : '',
                        "CPA Email Address": cpa && cpa.email_address ? cpa.email_address : '',
                        'Affiliate': 'cpa.com',
                        'track_name': 'CPA Portal API',

                        'Client Email': client && client.email_address ? client.email_address : '',
                        'Client Name': client && client.user_data && client.user_data.name ? client.user_data.name : '',

                        'CPA_login_user_id': pppApp.backend_user_id,
                        'CPA_login_user_name': cpa && cpa.name ? cpa.name : '',

                        'request_id': pppLead && pppLead.request_id ? pppLead.request_id: '',
                        
                        "App Id": 'APP' + pppApp.record_id, // ppp app id
                        "App Type": 'PPP', // ppp or forgiveness
                        "Loan Amount": pppLead && pppLead.status ? pppLead.status.amount: '', // select apps only less then 150k
                        "Assigned to borrower": pppBiz.is_forg_borrower ? 'Yes':'NO', // true or false
                        "forgiveness_submitted": '', // true or false
                        'B2C Status': pppLead && pppLead.status ? pppLead.status.status: '',
                        'Business Id': pppBiz._id
                    }

                   finalData.push(cpaAppData);
                }

                for (let forgvBiz of Object.values(notSubmittedForgivenessAppMap)) {

                    const pppApp = pppAppMap[forgvBiz.ppp_app_id];

                    const client = clientMap[pppApp.user_id].toObject();
                    const cpa = backendIdUserMap[pppApp.backend_user_id];
                    const refId = AppIdRefIdMap[forgvBiz.ppp_app_id];

                    const pppLead = pppLeadMapData[refId];
                    const pppBiz = pppAppBizMap[forgvBiz.ppp_app_id];
               
                    
                    let cpaAppData = {
                        "CPA Firm Name": cpa && cpa.data.cpa_firm_name ? cpa.data.cpa_firm_name : '',
                        "Source": cpa && cpa.data.cpa_firm_name ? cpa.data.cpa_firm_name : '',
                        "Subsource": 'PPP',
                        "CPA Name": cpa && cpa.name ? cpa.name : '',
                        "CPA Email Address": cpa && cpa.email_address ? cpa.email_address : '',
                        'Affiliate': 'cpa.com',
                        'track_name': 'CPA Portal API',

                        'Client Email': client && client.email_address ? client.email_address : '',
                        'Client Name': client && client.user_data && client.user_data.name ? client.user_data.name : '',

                        'CPA_login_user_id': pppApp.backend_user_id,
                        'CPA_login_user_name': cpa && cpa.name ? cpa.name : '',

                        'request_id': pppLead && pppLead.request_id ? pppLead.request_id :'',
                        
                        "App Id": 'APP' + pppApp.record_id, // ppp app id
                        "App Type": 'PPP', // ppp or forgiveness
                        "Loan Amount": pppLead.status ? pppLead.status.amount: '', // select apps only less then 150k
                        "Assigned to borrower": pppBiz.is_forg_borrower ? 'Yes':'NO', // true or false
                        "forgiveness_submitted": '', // true or false
                        'B2C Status': pppLead && pppLead.status ? pppLead.status.status: '',
                        'Business Id': pppBiz._id
                    }

                   finalData.push(cpaAppData);
                }
            }

            if (finalData.length > 0) {
                // Convert json data into csv
                let contents = parser.parse(finalData);

                const dt = new Date();
                const dd = dt.getDate();
                const mm = dt.getMonth() + 1;
                const yyyy = dt.getFullYear();
                // Temporary file name
                let attach_fileName = `${mm}-${dd}-${yyyy}-bulk-assignment-report-all.csv`;

                if (process.env.NODE_ENV == "local") {
                    filePath = path.resolve(attach_fileName);
                } else {
                    filePath = path.resolve("/tmp/" + attach_fileName);
                }

                const writeStream = fs.createWriteStream(filePath);
                writeStream.write(contents);

                writeStream.on("finish", () => {
                    console.log("wrote all data to file");
                });

              writeStream.end();

              let prefixDt = datetime.create();
              prefixDt.offsetInDays(-1);
              let prefixDate = prefixDt.format("Ymd");
              let folderData = prefixDt.format("Y-m-d");
              let splitDate = folderData.split("-");
              let prefix =
                  "reports/aicpa-report/" +
                  process.env.NODE_ENV +
                  "/" +
                  splitDate[0] +
                  "/" +
                  splitDate[1];
              let fileName = prefixDate + "-aicpa-report-cpa-data.csv";
              let bucketName = process.env.BUCKET_NAME + "/" + prefix;
  
            //   await awsS3.createLogFile(bucketName, fileName, contents);
  
              let fileUrl = process.env.BUCKET_URL + "/" + prefix + "/" + fileName;
              let bodyText = "<p>Hi, Please download the APICPA firm report by clicking the following link.</p></br><p><a href='" + fileUrl + "' target='_blank'>Download Report</a></p>";
              mailData = {
                  from_email: process.env.USER_INFO_EMAIL_FROM,
                  to_email: process.env.USER_INFO_EMAIL_TO_CPA,
                  subject:
                      "PPPForgivenessTool - CPA data as on " +
                      subjectDate,
                  html: bodyText
              };
              if (
                  process.env.USER_INFO_CC_EMAIL != undefined &&
                  process.env.USER_INFO_CC_EMAIL != ""
              ) {
                  mailData["cc"] = process.env.USER_INFO_CC_EMAIL;
              }
          } else {
              mailData = {
                  from_email: process.env.USER_INFO_EMAIL_FROM,
                  to_email: process.env.USER_INFO_EMAIL_TO_CPA,
                  subject:
                      "PPPForgivenessTool - CPA data as on " +
                      subjectDate,
                  text: "Hi, No CPA data was found",
              };
              if (
                  process.env.USER_INFO_CC_EMAIL != undefined &&
                  process.env.USER_INFO_CC_EMAIL != ""
              ) {
                  mailData["cc"] = process.env.USER_INFO_CC_EMAIL;
              }
          }
  
          let notification = await mailer.mailSender(mailData);
  
        //   fs.unlink(filePath, function (err) {
        //       if (err) {
        //           reject(err);
        //       }
        //   });
  
          if (notification) {
              resolve(notification);
          } else {
              throw new Error("Mail not sent");
          }
          
        } catch (error) {
            console.log(error);
            reject(error);
        }
    }).catch(function (error) {
        console.log(error);
        throw error;
    });
};

exports.app_assignment_by_caseId = async function (req) {
    return new Promise(async function (resolve, reject) {
        try {
            let mailData = "";
            let filePath = "";

            //let cpaUsers = [];
            let cpaApplication = [];
            let finalData = [];
            const detector = new deviceDetector();
            const APP_SUBMITTED = '5c20bf7e27105c78ad7f9280';
            const PPP2 = '5f40fb82b365b23a003e3708';
            const FORGIVENESS = '5cf61ae8a567c9873cbab4d5';
            // Set header of the csv
            const fields = [
                "CPA Firm Name",
                "Source",
                "Subsource",
                "CPA Name",
                "CPA Email Address",
                'Affiliate',
                'track_name',

                'Client Email',
                'Client Name',

                'CPA_login_user_id',
                'CPA_login_user_name',

                'request_id',

                "App Id", // ppp app id
                "App Type", // ppp or forgiveness
                "Loan Amount", // select apps only less then 150k
                "Assigned to borrower", // true or false
                "forgiveness_submitted", // true or false,
                'B2C Status',
                'Business Id'
            ];

            const opts = { fields };
            const parser = new Parser(opts);

            // Get start time

            let pastDate = '2020-07-16';

            let pastStartDt = datetime.create(pastDate);
            pastStartDt = pastStartDt.format("Y-m-d");

            let startDt = datetime.create(pastStartDt);
            let startTime = startDt.epoch();

            // Get End time
            let pastEndDt = datetime.create();
            pastEndDt = pastEndDt.format("Y-m-d");
            let endDt = datetime.create(pastEndDt);
            //endDt.offsetInDays(-1);
            let endTime = endDt.epoch();

            // Subject date
            let subjectDt = datetime.create();
            subjectDt.offsetInDays(-1);
            let subjectDate = subjectDt.format("Ymd");

            const QUERY = req.query;

            if(!QUERY.caseId) return resolve({error: 'Please specify the caseid'});

            const CASEID = QUERY.caseId;
            const pppLeadData = await PPPAppLeadModel.getAggregate([
                // {
                //     $match: { $and:[{request_id: { $exists: true }}, {request_id: { $ne: null }}] }
                // },
                { 
                    $match: {
                        request_id: new RegExp(`${CASEID}`)
                    }
                },
                { $project: {
                    application_status:1,
                    request_id:1,
                    start: { $indexOfCP: ['$request_id','-'] },
                    end: { $strLenCP: '$request_id' }
                }  },
                {
                    $project: {
                        application_status:1,
                        request_id:1,
                        start:1,
                        end:1,
                        caseId: { $substrCP: ['$request_id', { $add: ['$start', 1] }, '$end'] }
                    }
                },
                { 
                    $match: { caseId: CASEID }
                },
                { $addFields: { len:  {$size: {$ifNull: ["$application_status", []]}}}},
                { $addFields: { id: { $toString: "$_id" } } },
                {
                    $project: {
                        id:1, 
                        _id:0,
                        request_id:1,
                        status: { 
                            $arrayElemAt: ["$application_status",  { $cond: { if: { $eq: ['$len', 0] }, then: 0, else: { $subtract: ['$len', 1] } } }] 
                        } 
                    }
                }
            ]);

            if(!pppLeadData.length) { return resolve([]); }

            const b2cRefs = await serviceBusinessModel.getAggregate([
                {
                    $match: { type: 'b2c_status', ref_id: pppLeadData[0].id }
                }
            ]);
console.log(b2cRefs,'RR');
            if(!b2cRefs.length) { return resolve([]); }
            // map of refid and ppp app id

            const PPP_LEAD = pppLeadData[0];
            const B2C_REF = b2cRefs[b2cRefs.length-1];

            const USER_ID = B2C_REF.user_id;
            const APP_ID = B2C_REF.app_id;
            const REF_ID = B2C_REF.ref_id;      
            
            
            const appData = await application.getAggregate([
                {
                    $match: {
                        _id: { $in: [ mongoose.Types.ObjectId(APP_ID) ] },
                        product_type: PPP2,
                        status_id: APP_SUBMITTED,
                        "is_deleted" : { $ne: true }
                    }
                },
                {
                    $project: {
                        app_id: { $toString: "$_id"},
                        status_id: 1,
                        product_type: 1,
                        backend_user_id: 1,
                        record_id:1,
                        user_id:1
                    }
                }
            ]);
            console.log(appData);
            const AppUserMap = {};
            const pppAppMap = {};
            appData.forEach((app) => {
                if(!pppAppMap[app.app_id]){
                    pppAppMap[app.app_id] = app;
                }

                if(!AppUserMap[app.user_id]){
                    AppUserMap[app.user_id] = app;
                }
            });
            

            const businessdata = await businessInfo.getAggregate([
                {
                    $match: { is_deleted: { $ne: true }, 'replicated.forgiveness_app_id': { $in: Object.keys(pppAppMap) } }
                },
                {
                    $project: {
                        forgiveness_app_id: '$app_id',
                        ppp_app_id: '$replicated.forgiveness_app_id',
                        business_id: '$_id',
                        user_id:'$user_id',
                        firm_name: '$cpa_firm_name',
                        sba_ppp_loan_amount: '$sba_ppp_loan_amount',
                        current_state: '$current_state'
                    }
                }
            ]);
console.log(businessdata,'\BB');
            const pppBusinessdata = await businessInfo.getAggregate([
                {
                    $match: { is_deleted: { $ne: true }, 'app_id': { $in: Object.keys(pppAppMap) } }
                },
                {
                    $project: {
                        ppp_app_id: '$app_id',
                        business_id: '$_id',
                        user_id:'$user_id',
                        firm_name: '$cpa_firm_name',
                        sba_ppp_loan_amount: '$sba_ppp_loan_amount',
                        current_state: '$current_state',
                        is_forg_borrower:1
                    }
                }
            ]);

            // ppp app_id and business map
            const pppAppBizMap = {};
            pppBusinessdata.forEach((biz) => {
                if(!pppAppBizMap[biz.ppp_app_id]) {
                    pppAppBizMap[biz.ppp_app_id] = biz;
                }
            })

            const forgivenessAppMap = {};
            const forgivenessPPPAppMap = {};
            businessdata.forEach((bi) => {
                if(!forgivenessAppMap[bi.forgiveness_app_id]) {
                    forgivenessAppMap[bi.forgiveness_app_id] = bi;
                }

                if(!forgivenessPPPAppMap[bi.ppp_app_id]) {
                    forgivenessPPPAppMap[bi.ppp_app_id] = bi;
                }
            });

            // forgiveness app
            const forgivenessAppData = await application.getAggregate([
                {
                    $match: {
                        _id: { $in: Object.keys(forgivenessAppMap).map((id) => mongoose.Types.ObjectId(id)) },
                        is_deleted: { $ne: true },
                        // status_id: { $ne: APP_SUBMITTED }
                    }
                },
                {
                    $project: {
                        forgiveness_app_id: { $toString: "$_id"},
                        status_id: 1,
                        product_type: 1,
                        backend_user_id: 1,
                        record_id:1,
                        user_id: 1
                    }
                }
            ]);

console.log(forgivenessAppMap);
            const notSubmittedForgivenessAppMap = {};
                // const notSubmittedForgvTempMap = {};
                forgivenessAppData.forEach((forgivenessApp) => {
                    const forgvBusiness = forgivenessAppMap[forgivenessApp.forgiveness_app_id];

                    if(forgivenessApp.status_id !== APP_SUBMITTED) {
                        notSubmittedForgivenessAppMap[forgvBusiness.ppp_app_id] = forgvBusiness;
                    } 
                    
                    if(forgivenessApp.status_id === APP_SUBMITTED && notSubmittedForgivenessAppMap[forgvBusiness.ppp_app_id]) {
                        delete notSubmittedForgivenessAppMap[forgvBusiness.ppp_app_id];
                    }

                })
// return resolve(notSubmittedForgivenessAppMap);

                const clients = await userModel.find({ _id: { $in: Object.keys(AppUserMap).map((id) => mongoose.Types.ObjectId(id)) } }, { email_address:1, 'user_data.name':1, 'user_data.backend_user_id':1 });

                const clientMap = {};
                clients.forEach((client) => {
                    if(!clientMap[client._id]) {
                        clientMap[client._id] = client;
                    }
                })

                // only funded apps out of these apps have to be assign to borrower
                const pppAppsWithoutForgiveness = [];

                appData.forEach((app) => {
                    if(!forgivenessPPPAppMap[app.app_id]) {
                        pppAppsWithoutForgiveness.push(app);
                    }
                });

            let queryBuild = [
                {
                    $match: {
                        '_id': {
                            $in: [ mongoose.Types.ObjectId(clients[0].toObject().user_data.backend_user_id) ]
                        }
                    }
                },
            ];

            
            let cpaUserFirm = await backendUser.getAggregate(queryBuild);

            const backendIdUserMap  = {};
            cpaUserFirm.forEach((cpaUser) => {
                if(!backendIdUserMap[cpaUser._id]) {
                    backendIdUserMap[cpaUser._id] = cpaUser;
                }
            });

            for (let pppApp of pppAppsWithoutForgiveness) {

                const client = clientMap[pppApp.user_id].toObject();
                const cpa = backendIdUserMap[pppApp.backend_user_id];
                const pppLead = PPP_LEAD;
                const pppBiz = pppAppBizMap[pppApp.app_id];
                
                let cpaAppData = {
                    "CPA Firm Name": cpa && cpa.data.cpa_firm_name ? cpa.data.cpa_firm_name : '',
                    "Source": cpa && cpa.data.cpa_firm_name ? cpa.data.cpa_firm_name : '',
                    "Subsource": 'PPP',
                    "CPA Name": cpa && cpa.name ? cpa.name : '',
                    "CPA Email Address": cpa && cpa.email_address ? cpa.email_address : '',
                    'Affiliate': 'cpa.com',
                    'track_name': 'CPA Portal API',

                    'Client Email': client && client.email_address ? client.email_address : '',
                    'Client Name': client && client.user_data && client.user_data.name ? client.user_data.name : '',

                    'CPA_login_user_id': pppApp.backend_user_id,
                    'CPA_login_user_name': cpa && cpa.name ? cpa.name : '',

                    'request_id': pppLead && pppLead.request_id ? pppLead.request_id: '',
                    
                    "App Id": 'APP' + pppApp.record_id, // ppp app id
                    "App Type": 'PPP', // ppp or forgiveness
                    "Loan Amount": pppLead && pppLead.status ? pppLead.status.amount: '', // select apps only less then 150k
                    "Assigned to borrower": pppBiz.is_forg_borrower ? 'Yes':'NO', // true or false
                    "forgiveness_submitted": '', // true or false
                    'B2C Status': pppLead && pppLead.status ? pppLead.status.status: '',
                    'Business Id': pppBiz._id
                }

                finalData.push(cpaAppData);
            }

            for (let forgvBiz of Object.values(notSubmittedForgivenessAppMap)) {

                const pppApp = pppAppMap[forgvBiz.ppp_app_id];

                const client = clientMap[pppApp.user_id].toObject();
                const cpa = backendIdUserMap[pppApp.backend_user_id];

                const pppLead = PPP_LEAD;;
                const pppBiz = pppAppBizMap[forgvBiz.ppp_app_id];
            
                
                let cpaAppData = {
                    "CPA Firm Name": cpa && cpa.data.cpa_firm_name ? cpa.data.cpa_firm_name : '',
                    "Source": cpa && cpa.data.cpa_firm_name ? cpa.data.cpa_firm_name : '',
                    "Subsource": 'PPP',
                    "CPA Name": cpa && cpa.name ? cpa.name : '',
                    "CPA Email Address": cpa && cpa.email_address ? cpa.email_address : '',
                    'Affiliate': 'cpa.com',
                    'track_name': 'CPA Portal API',

                    'Client Email': client && client.email_address ? client.email_address : '',
                    'Client Name': client && client.user_data && client.user_data.name ? client.user_data.name : '',

                    'CPA_login_user_id': pppApp.backend_user_id,
                    'CPA_login_user_name': cpa && cpa.name ? cpa.name : '',

                    'request_id': pppLead && pppLead.request_id ? pppLead.request_id :'',
                    
                    "App Id": 'APP' + pppApp.record_id, // ppp app id
                    "App Type": 'PPP', // ppp or forgiveness
                    "Loan Amount": pppLead.status ? pppLead.status.amount: '', // select apps only less then 150k
                    "Assigned to borrower": pppBiz.is_forg_borrower ? 'Yes':'NO', // true or false
                    "forgiveness_submitted": '', // true or false
                    'B2C Status': pppLead && pppLead.status ? pppLead.status.status: '',
                    'Business Id': pppBiz._id
                }

                finalData.push(cpaAppData);
            }
return resolve(finalData);
            if (finalData.length > 0) {
                // Convert json data into csv
                let contents = parser.parse(finalData);

                const dt = new Date();
                const dd = dt.getDate();
                const mm = dt.getMonth() + 1;
                const yyyy = dt.getFullYear();
                // Temporary file name
                let attach_fileName = `${mm}-${dd}-${yyyy}-bulk-assignment-report-all.csv`;

                if (process.env.NODE_ENV == "local") {
                    filePath = path.resolve(attach_fileName);
                } else {
                    filePath = path.resolve("/tmp/" + attach_fileName);
                }

                const writeStream = fs.createWriteStream(filePath);
                writeStream.write(contents);

                writeStream.on("finish", () => {
                    console.log("wrote all data to file");
                });

              writeStream.end();

              let prefixDt = datetime.create();
              prefixDt.offsetInDays(-1);
              let prefixDate = prefixDt.format("Ymd");
              let folderData = prefixDt.format("Y-m-d");
              let splitDate = folderData.split("-");
              let prefix =
                  "reports/aicpa-report/" +
                  process.env.NODE_ENV +
                  "/" +
                  splitDate[0] +
                  "/" +
                  splitDate[1];
              let fileName = prefixDate + "-aicpa-report-cpa-data.csv";
              let bucketName = process.env.BUCKET_NAME + "/" + prefix;
  
            //   await awsS3.createLogFile(bucketName, fileName, contents);
  
              let fileUrl = process.env.BUCKET_URL + "/" + prefix + "/" + fileName;
              let bodyText = "<p>Hi, Please download the APICPA firm report by clicking the following link.</p></br><p><a href='" + fileUrl + "' target='_blank'>Download Report</a></p>";
              mailData = {
                  from_email: process.env.USER_INFO_EMAIL_FROM,
                  to_email: process.env.USER_INFO_EMAIL_TO_CPA,
                  subject:
                      "PPPForgivenessTool - CPA data as on " +
                      subjectDate,
                  html: bodyText
              };
              if (
                  process.env.USER_INFO_CC_EMAIL != undefined &&
                  process.env.USER_INFO_CC_EMAIL != ""
              ) {
                  mailData["cc"] = process.env.USER_INFO_CC_EMAIL;
              }
          } else {
              mailData = {
                  from_email: process.env.USER_INFO_EMAIL_FROM,
                  to_email: process.env.USER_INFO_EMAIL_TO_CPA,
                  subject:
                      "PPPForgivenessTool - CPA data as on " +
                      subjectDate,
                  text: "Hi, No CPA data was found",
              };
              if (
                  process.env.USER_INFO_CC_EMAIL != undefined &&
                  process.env.USER_INFO_CC_EMAIL != ""
              ) {
                  mailData["cc"] = process.env.USER_INFO_CC_EMAIL;
              }
          }
  
          let notification = await mailer.mailSender(mailData);
  
        //   fs.unlink(filePath, function (err) {
        //       if (err) {
        //           reject(err);
        //       }
        //   });
  
          if (notification) {
              resolve(notification);
          } else {
              throw new Error("Mail not sent");
          }
          
        } catch (error) {
            console.log(error);
            reject(error);
        }
    }).catch(function (error) {
        console.log(error);
        throw error;
    });
};

exports.covered_period_end_date = async () => {
    return new Promise(async function (resolve, reject) {
        try {
            /*const date = momentTz.utc('05-10-2021').format('ddd, DD MMM YYYY h:mm:ss z');
            resolve({date}); return;*/
            const fields = [
                "App Id",
                "ForgiveApp Id",
                "lead_id",
                "case_id",
                "loan_disburse_date",
                "Business Info Id",
                "covered_period_end_date", 
                "Calculated End Date",
                "disbursement_date",
                "covered_period_length",
                "covered_period_start_date",
                "is_submitted",
                "current_state",
                "status",

                "formatted_covered_period_end_date", 
                "formatted_Calculated End Date",
                "formatted_disbursement_date",
                "formatted_covered_period_start_date",
            ];
            let filePath = "";
            const opts = { fields };
            const parser = new Parser(opts);
            const businessInfoData = await businessInfo.getAggregate([
                { $match: { 
                    'replicated.forgiveness_app_id': { $exists: true },
                    // 'replicated.forgiveness_app_id': '606239a95aef7a0028d16d72', //TODO
                 } },
                { $addFields: { id: { $toString: "$_id" } } },
                {
                    $lookup: {
                        let: { appId: { $toObjectId: "$app_id" } },
                        from: "application",
                        as: "forgiveness_app",
                        pipeline: [
                            {
                                $match: {
                                    $expr: {
                                        $eq: ["$$appId", "$_id"]
                                    },
                                    // status_id: {$ne: '5c20bf7e27105c78ad7f9280'}
                                }
                            },
                        ]
                    }
                },
                {
                    $project: {
                        ppp_app_id: '$replicated.forgiveness_app_id',
                        covered_period_end_date: 1, 
                        disbursement_date:1,
                        covered_period_length:1,
                        covered_period_start_date: 1,
                        _id: 0, 
                        id: 1, 
                        forgiveness_app_id: '$app_id', 
                        forgiveness_app: 1,
                        current_state: 1
                    }
                }
            ]);

            const businessDataMap = {}; // forgiveness_app_id: business info
            const pppAppIdMap = {}; // ppp_app_id: business info 
            businessInfoData.forEach(info => {
                businessDataMap[info.forgiveness_app_id] = info; //forgiveness app Ids
                if (info.forgiveness_app.length > 0) {
                    if (!pppAppIdMap[info.ppp_app_id]) {
                        pppAppIdMap[info.ppp_app_id] = [];
                    }   

                    pppAppIdMap[info.ppp_app_id].push(info);
                }
            });

            // finding ppp apps
            const applicationData = await application.getAggregate([
                { $addFields: { id: { $toString: "$_id" } } },
                { $match: { id: { $in: Object.keys(pppAppIdMap) },
                //  status_id: {$ne: APP_TYPE_SUBMITTED}
                 } },
                {
                    $lookup: {
                        let: { appId: "$id" },
                        from: "service_business",
                        as: "b2c_status_ref",
                        pipeline: [
                            {
                                $match: {
                                    $expr: {
                                        $eq: ["$$appId", "$app_id"]
                                    },
                                    type: "b2c_status"
                                }
                            },
                            {
                                $project: {
                                    _id: 0,
                                    b2c_ref_id: "$ref_id"
                                }
                            }
                        ]
                    }
                },
                {
                    $project: {
                        _id: 0,
                        id: 1,
                        record_id: 1,
                        status_id: 1,
                        b2c_status_ref:1,
                        ref_size: { $size: '$b2c_status_ref' }
                    }
                },
                {
                    $project: {
                        _id: 0,
                        id: 1,
                        record_id: 1,
                        status_id: 1,
                        b2c_ref: { $arrayElemAt: ["$b2c_status_ref", { $cond: { if: { $eq: ['$ref_size', 0] }, then: 0, else: { $subtract:['$ref_size', 1] } } }] }
                    }
                },
                {
                    $replaceRoot: {
                        newRoot: {
                            $mergeObjects: ["$$ROOT", "$b2c_ref"]
                        }
                    }
                },
                {
                    $project: { b2c_ref: 0 }
                }
            ]);

            // ppp app ref ids
            const refIds = applicationData.map(app => mongoose.Types.ObjectId(app.b2c_ref_id));
            // finding ppp application b2c references by ref_ids
            const pppLeadData = await PPPAppLeadModel.getAggregate([
                { 
                    $match: {
                        _id: { $in: refIds }
                    }
                },
                { $addFields: { len:  {$size: {$ifNull: ["$application_status", []]}}}},
                { $addFields: { id: { $toString: "$_id" } } },
                {
                    $project: {
                        id:1, 
                        _id:0,
                        request_id:1,
                        status: { 
                            $arrayElemAt: ["$application_status",  { $cond: { if: { $eq: ['$len', 0] }, then: 0, else: { $subtract: ['$len', 1] } } }] 
                        } 
                    }
                }
            ]);

            const pppLeadMapData = {}; // ref_id: ref
            pppLeadData.map(ppp => pppLeadMapData[ppp.id] = ppp);

            const reportData = [];
            const filteredbusinessDataMap = [];
            // looping ppp apps
            for(let index=0; index < applicationData.length; index++) {
                const pppAPP = applicationData[index];
                const businessData = pppAppIdMap[pppAPP.id];
                const ppp = pppLeadMapData[pppAPP.b2c_ref_id];
                const splitted = ppp.request_id.split('-');
                

                // if (!ppp.status.loan_disburse_date) {
                //     continue;
                // }
                
                // const formattedDisbursePeriod = new Date(ppp.status.loan_disburse_dat);
                // const formattedDisbursePeriod = new Date(helper.getActualDate(ppp.status.loan_disburse_date));
                const APP_SUBMITTED = '5c20bf7e27105c78ad7f9280';
                

                businessData.forEach(business => {
                    // const formattedCoverPeriod = new Date(business.covered_period_start_date);
                        // filteredbusinessDataMap.push(business.app_id);
                        let calculatedEndDate = '';
                        // mm/dd/yyyy
                        if(business.covered_period_start_date && business.covered_period_length) {
                            const a = moment(business.covered_period_start_date); 
                            calculatedEndDate = a.add(business.covered_period_length, 'week'); 
                        }
                        reportData.push({
                            "PPPApp Id": 'APP' + pppAPP.record_id,
                            "ForgiveApp Id": business.forgiveness_app[0] ? 'APP' + business.forgiveness_app[0].record_id : '',
                            "lead_id": splitted[0],
                            "case_id": splitted[1],
                            "loan_disburse_date": ppp.status.loan_disburse_date ? ppp.status.loan_disburse_date : '',
                            "Business Info Id": business.id,
                            "covered_period_end_date": business.covered_period_end_date || '', 
                            "Calculated End Date": calculatedEndDate,
                            "disbursement_date": business.disbursement_date || '',
                            "covered_period_length": business.covered_period_length || '',
                            "covered_period_start_date": business.covered_period_start_date || '',
                            "is_submitted": business.forgiveness_app[0].status_id === APP_SUBMITTED ? 'Yes': 'No',
                            "current_state": business.current_state,
                            "status": ppp.status.status || '',

                            "formatted_covered_period_end_date": moment(business.covered_period_end_date, 'ddd, DD MMM YYYY h:mm:ss z').format('MM/DD/YYYY') || '', 
                            "formatted_Calculated End Date": moment(calculatedEndDate, 'ddd, DD MMM YYYY h:mm:ss z').format('MM/DD/YYYY'),
                            "formatted_disbursement_date": moment(business.disbursement_date, 'ddd, DD MMM YYYY h:mm:ss z').format('MM/DD/YYYY') || '',
                            "formatted_covered_period_start_date": moment(business.covered_period_start_date, 'ddd, DD MMM YYYY h:mm:ss z').format('MM/DD/YYYY') || '',
                        });
                });
            }


            if (reportData && reportData.length) {
                let contents = parser.parse(reportData);
                // Temporary file name
                let prefixDtDummy = datetime.create();
                let prefixDate2 = prefixDtDummy.format("m-d-Y");
                let attach_fileName = "cover-period-end-date-report" + prefixDate2 + ".csv";

                if (process.env.NODE_ENV == "local") {
                    filePath = path.resolve(attach_fileName);
                } else {
                    filePath = path.resolve("/tmp/" + attach_fileName);
                }

                const writeStream = fs.createWriteStream(filePath);
                writeStream.write(contents);

                writeStream.on("finish", () => {
                    console.log("wrote all data to file");
                });

                writeStream.end();
            }
            resolve({reportData});
        } catch (error) {
            reject(error);
        }
    }).catch(function (error) {
        throw error;
    });
}

exports.get_CPA_App_Report = async () => {
    return new Promise(async function (resolve, reject) {
            try {
                let mailData = "";
                let filePath = "";
                const fields = [
                    "App Id",
                    "App Status",
                    // "App Stage",
                    "App Created Date",
                    "App Submitted Date",
                    "Case ID",
                    "Lead ID",
                    "CPA Firm",
                    "CPA Name",
                    "CPA Email",
                    "Application Type"
                ];

                const opts = { fields };
                const parser = new Parser(opts);

                 // Subject date
                let subjectDt = datetime.create();
                subjectDt.offsetInDays(-1);
                let subjectDate = subjectDt.format("Ymd");

                const reportData = [];

                // find backend users from firm name
                // find last login for cpuser

                // find cilent from backend ids
                // find apps for those clients
                // find caseid lead id and status for ppp apps
                // find caseid lead id and status for forgiveness apps

                let queryBuild = [
                    {
                        "$match": {'data.cpa_firm_name': 'Nevada Quickbooks Pro'},
                    },
                    { "$group": { _id: { $toLower: "$data.cpa_firm_name" }, "doc": { "$first": "$$ROOT" }, backend_ids: { $push: { $toString: "$_id" } } } },
                    { $project: {firm_name: '$_id', backend_ids: 1} }
                ];
    
                let cpaUserFirm = await backendUser.getAggregate(queryBuild);
    
                const firmNames = [];
                const firmBackendIdMap = {};
                cpaUserFirm.forEach((firm) => {
                    firmNames.push(firm.firm_name);
                    firmBackendIdMap[firm.firm_name.toLowerCase()] = firm.backend_ids;
                });
    
                const cpaUserQuery = [
                    { $match: { delete: { $ne: true } } },
                    { $addFields: { firm_name: { $toLower: "$data.cpa_firm_name" } } },
                    { $match: { "firm_name": { $in: firmNames } } },
                ];
    
                let queryModel = backendUser.getBackendUserModel(cpaUserQuery);
    
                let cpaUserData = await backendUser.getAggregate(queryModel);
                if (cpaUserData.length) {
                    const backend_user_ids = [];
                    const firm_names_regex = [];
                    const email_addresses = [];
                    const CPAuserMap = {};
                    cpaUserData.forEach((cpaUser) => {
                        backend_user_ids.push(...firmBackendIdMap[cpaUser.data.cpa_firm_name.toLowerCase()]);
                        firm_names_regex.push(new RegExp(cpaUser.data.cpa_firm_name, 'i'));
                        email_addresses.push(cpaUser.email_address);
                        CPAuserMap[cpaUser._id] = cpaUser;
                    });

                    const cpaClients = await userModel.getAggregate([
                        { $match: { 'user_data.backend_user_id': { $in: backend_user_ids } } },
                        { $project: {
                            _id:0,
                            id: {$toString: "$_id"},
                            email_address: 1,
                            name: "$user_data.name",
                            backend_user_id: '$user_data.backend_user_id'
                        } }
                    ]);

                    const clientIds = [];
                    const ClientCPAMap = {};
                    cpaClients.forEach((client) => {
                        clientIds.push(client.id);
                        ClientCPAMap[client.id] = client.backend_user_id
                    });
    
                    const appData = await application.getAggregate([
                        {
                            $match: {
                                user_id: { $in: clientIds }
                            }
                        },
                        {
                            $project: {
                                app_id: "$_id",
                                status_id: 1,
                                product_type: 1,
                                backend_user_id: 1,
                                user_id: 1,
                                record_id:1,
                                created_at:1,
                                updated_at:1
                            }
                        }
                    ]);
    

                    const userAppsMap = {};
                    const appIds = [];
                    // map appData with each user
                    appData.forEach((app) => {
                        if (!userAppsMap[app.backend_user_id]) {
                            userAppsMap[app.backend_user_id] = [];
                        }
    
                        userAppsMap[app.backend_user_id].push(app);
                        appIds.push(app.app_id.toString());
                    });


                    //get all master status
                    const statusMap = {};
                    const appStatuss = await appStatus.find({}, { _id:1, value:1 });
                    if(appStatuss && appStatuss.length) {
                        appStatuss.forEach((status) => {
                            const s = status.toObject();
                            statusMap[s._id.toString()] = s.value;
                        });
                    }


                    // get all master status
                    const appTypeMap = {};
                    const appTypes = await appTypeModel.find({}, { _id:1, type:1 });
                    if(appTypes && appTypes.length) {
                        appTypes.forEach((aType) => {
                            const type = aType.toObject();
                            appTypeMap[type._id.toString()] = type.type;
                        });
                    }

                    // fetch all b2c_status ref id from service business
                    const pppb2cReferences = await serviceBusinessModel.getAggregate([
                        {
                            $match: {
                                type: 'b2c_status',
                                app_id:{ $in: appIds }
                            }
                         },
                         {
                             $project: {
                                 _id:0,
                                 ref_id: 1,
                                 app_id: 1,
                                 submitted_at: '$created_at'
                             }
                         },
                        //  {
                        //      $group: {
                        //          _id: null,
                        //          ids: {
                        //              $push: "$ref_id"
                        //          }
                        //      }
                        //  }
                    ]);

                    const pppRefIds = [];
                    const appIdLeadIdMap = {};
                    pppb2cReferences.forEach((ref) => {
                        pppRefIds.push(ref.ref_id);
                        appIdLeadIdMap[ref.app_id] = ref;
                    });


                    const refLeadMap = {};
                    // get all the leadIds from ref_ids
                    if(pppb2cReferences && pppb2cReferences.length) {
                        // get all the lead ids

                        const pppLeads = await PPPAppLeadModel.getAggregate([
                            {
                                $addFields: { id: { $toString: "$_id" } }
                            },
                            { 
                                $match: {
                                    id: { $in: pppRefIds }
                                }
                            },
                            { $addFields: { len:  {$size: {$ifNull: ["$application_status", []]}}}},
                            {
                                $project: {
                                    id:1, 
                                    _id:0,
                                    request_id:1,
                                    status: { 
                                        $arrayElemAt: ["$application_status", { $subtract: ["$len", 1] }] 
                                    } 
                                }
                            }
                        ]);

                        if(pppLeads && pppLeads.length) {
                            pppLeads.forEach((lead) => {
                                // refLeadMap[lead.id] = lead.request_id;
                                refLeadMap[lead.id] = {
                                   request_id: lead.request_id,
                                   status: helper.getStatus(lead.status && lead.status.status?lead.status.status:'default')
                                };
                            });
                        }
                    }

                    // fetch all b2c_status ref id from service business
                    const forgivenessb2cReferences = await serviceBusinessModel.getAggregate([
                        {
                            $match: {
                                type: 'b2c_status_forgiveness',
                                app_id:{ $in: appIds }
                            }
                         },
                         {
                             $project: {
                                 _id:0,
                                 ref_id: 1,
                                 app_id: 1,
                                 submitted_at: '$created_at'
                             }
                         },
                        //  {
                        //      $group: {
                        //          _id: null,
                        //          ids: {
                        //              $push: "$ref_id"
                        //          }
                        //      }
                        //  }
                    ]);

                    const forgvRefIds = [];
                    forgivenessb2cReferences.forEach((ref) => {
                        forgvRefIds.push(ref.ref_id);
                        appIdLeadIdMap[ref.app_id] = ref;
                    });

                    const forgivenessb2cRefLeadMap = {};
                    // get all the leadIds from ref_ids
                    if(forgivenessb2cReferences && forgivenessb2cReferences.length) {
                        // get all the lead ids

                        const forgivenessLeads = await PPPAppLeadModel.getAggregate([
                            {
                                $addFields: { id: { $toString: "$_id" } }
                            },
                            { 
                                $match: {
                                    id: { $in: forgvRefIds }
                                }
                            },
                            { $addFields: { len:  {$size: {$ifNull: ["$application_status", []]}}}},
                            {
                                $project: {
                                    id:1, 
                                    _id:0,
                                    request_id:1,
                                    status: { 
                                        $arrayElemAt: ["$application_status", { $subtract: ["$len", 1] }] 
                                    } 
                                }
                            }
                        ]);

                        if(forgivenessLeads && forgivenessLeads.length) {
                            forgivenessLeads.forEach((lead) => {
                                forgivenessb2cRefLeadMap[lead.id] = lead.request_id;
                                forgivenessb2cRefLeadMap[lead.id] = {
                                   request_id: lead.request_id,
                                   status: helper.getStatus(lead.status && lead.status.status?lead.status.status:'default')
                                };
                            });
                        }
                    }
                    

                    for (let index = 0; index < appData.length; index++) {
                        const app = appData[index];

                        

                        
                        const data = {
                            "App Id": `APP${app.record_id}`,
                            "App Status": "",
                            "App Submitted Date": app.submitted_at ? helper.formatDate(new Date(app.submitted_at * 1000)): '',
                            "Case ID": "",
                            "Lead ID":"",
                            "CPA Firm":"",
                            "CPA Name":"",
                            "CPA Email":"",
                            "Application Type":""
                        };

                        if(appIdLeadIdMap[app.app_id] && appIdLeadIdMap[app.app_id].ref_id ) {
                            const pppLead = refLeadMap[appIdLeadIdMap[app.app_id].ref_id];
                            if(pppLead && pppLead.request_id) {
                                const splitted = pppLead.request_id.split('-');
                                data['Lead ID'] = splitted[0];
                                data['Case ID'] = splitted[1];
                                data['App Status'] = pppLead.status;
                                data["App Submitted Date"] =  appIdLeadIdMap[app.app_id].submitted_at ? helper.formatDate(new Date(appIdLeadIdMap[app.app_id].submitted_at * 1000)): '';
                            }
                        }

                        if(app.product_type && appTypeMap[app.product_type]){
                            data['Application Type'] = appTypeMap[app.product_type];
                        } 

                        if(app.status_id && statusMap[app.status_id]){
                            // data['App Status'] = statusMap[app.status_id];

                            if(!data['App Status'] && !data["App Submitted Date"]) {
                                
                                if(statusMap[app.status_id] === "Submitted") {
                                    data['App Status'] = 'Application Completed';
                                    data["App Submitted Date"] = helper.formatDate(new Date(app.updated_at * 1000));
                                } else if(statusMap[app.status_id] ==="Rejected by SBA") {
                                    data["App Submitted Date"] = helper.formatDate(new Date(app.updated_at * 1000));
                                    data['App Status'] = 'Duplicate Application Found';
                               }
                            }
                        } 

                        if(!data['App Status']) {
                            data['App Status'] = helper.getAppStage(app.current_state || "", data['Application Type']);
                        }

                        // data["App Stage"] = helper.getAppStage(app.current_state || "", data['Application Type']);

                        // if(app.user_id && clientMap[app.user_id]) {
                        //     data['Client Name'] = clientMap[app.user_id].name;
                        //     data['Client Email'] = clientMap[app.user_id].email_address;
                        // } 
                        const cpa = CPAuserMap[ClientCPAMap[app.user_id]];
                        if(cpa) {
                            data['CPA Name'] = cpa.name;
                            data['CPA Email'] = cpa.email_address;
                            data['CPA Firm'] = cpa.data.cpa_firm_name;
                        } 

                        reportData.push(data);
                    };


                }

                if(reportData && reportData.length) {
                    let contents = parser.parse(reportData);
                    // Temporary file name
                    let attach_fileName = "cpa-app-report.csv";

                    if (process.env.NODE_ENV == "local") {
                        filePath = path.resolve(attach_fileName);
                    } else {
                        filePath = path.resolve("/tmp/" + attach_fileName);
                    }

                    const writeStream = fs.createWriteStream(filePath);
                    writeStream.write(contents);

                    writeStream.on("finish", () => {
                        console.log("wrote all data to file");
                    });

                    writeStream.end();

                    let prefixDt = datetime.create();
                    prefixDt.offsetInDays(-1);
                    let prefixDate = prefixDt.format("Ymd");
                    let folderData = prefixDt.format("Y-m-d");
                    let splitDate = folderData.split("-");
                    let prefix =
                        "reports/aicpa-report/" +
                        process.env.NODE_ENV +
                        "/" +
                        splitDate[0] +
                        "/" +
                        splitDate[1];
                    let fileName = prefixDate + "-cpa-app-report.csv";
                    let bucketName = process.env.BUCKET_NAME + "/" + prefix;

                    await awsS3.createLogFile(bucketName, fileName, contents);

                    let fileUrl = process.env.BUCKET_URL +"/" + prefix +"/"+ fileName;
                    let bodyText = "<p>Hi, Please download the application level report by clicking the following link.</p></br><p><a href='"+fileUrl+"' target='_blank'>Download Report</a></p>";
                  
                    mailData = {
                        from_email: process.env.USER_INFO_EMAIL_FROM,
                        to_email: process.env.USER_INFO_EMAIL_TO_CPA,
                        subject:
                            "CPALoanPortal - Application data as on " +
                            subjectDate,
                        html: bodyText
                    };
                    if (
                        process.env.USER_INFO_CC_EMAIL != undefined &&
                        process.env.USER_INFO_CC_EMAIL != ""
                    ) {
                        mailData["cc"] = process.env.USER_INFO_CC_EMAIL;
                    }
    
                } else {
                    mailData = {
                        from_email: process.env.USER_INFO_EMAIL_FROM,
                        to_email: process.env.USER_INFO_EMAIL_TO_CPA,
                        subject:
                            "CPALoanPortal - Application data as on " +
                            subjectDate,
                        text: "Hi, No Application data was found",
                    };
                    if (
                        process.env.USER_INFO_CC_EMAIL != undefined &&
                        process.env.USER_INFO_CC_EMAIL != ""
                    ) {
                        mailData["cc"] = process.env.USER_INFO_CC_EMAIL;
                    }
                }

                // let notification = await mailer.mailSender(mailData);
  
                // fs.unlink(filePath, function (err) {
                //     if (err) {
                //         reject(err);
                //     }
                // });
        
                resolve(reportData);
                // if (notification) {
                // } else {
                //     throw new Error("Mail not sent");
                // }

            } catch (error) {
                reject(error);
            }
    }).catch(function (error) {
        throw error;
    });
}