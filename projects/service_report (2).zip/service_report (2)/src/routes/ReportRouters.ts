import {Router} from 'express';
import ReportController from '../controllers/ReportController';

class ReportRouter {
    public router: any;

    constructor(ExpressRouter: Router) {
        this.router = ExpressRouter;
        this.getRoutes();
    }

    getRoutes() {
        this.router.get('/uptime', ReportController.getUptime);
        this.router.get('/callingAgentReport', ReportController.getCallingAgentReport);
    }

}

export default ReportRouter;
