## **Configuration Service**

[API V1](./doc/Lender.MD)

# Security

### IP Whitelisting

IP whitelisting allows us to create lists of trusted IP addresses or IP ranges from which our users can access our domains. IP whitelist is a security feature often used for limiting and controlling access only to trusted users. So, at the time of configuration, we would white list user public IP on our firewall, so our web-services would be called by the authorized user server only. Similarly, user also would have to white list our public IP to call the web services.

### SSL Data Transport

All data must be transported over the Transport Layer Security (TLS) version 1.2.

# Prerequisites

a) The consumer (or client) is already set up at API Gateway level.
b) The consumer (or client) is already subscribed to API services.
c) The lender is already set up at API Gateway level.

On onboarding lender, the API box credentials will be provided. It will contain Client ID, Client Secret, Username, Password, Product Correlation ID and Web server URL.

# Authentication

The authentication of client(s) requests to API is managed by Biz2x API Gateway using Client Credentials Grant Type.

### The Consumer Key & Consumer Secret and Access Token

As stated, the authorization data (Consumer Key and Consumer Secret) should have been setup in API gateway by Biz2x for integration clients to obtain the authentication
token. If the client is successfully authenticated, an access token will be returned.

#### Step #01

The Consumer Key and Consumer Secret combination will be created for LOS system as illustrated below in the example:

Client: Client
Consumer Key:100
Consumer Secret: 8adb5fa4-3f62-492c-8ef6-772bde9929f4

#### Step #02

Invoke the Token API to generate the access token using the grant type, along with the Consumer Key and Consumer Secret combination in the format of **consumer-key:consumer-secret**, encoded
in base64. The following portal can be used to generate the encoded base64 string:
<https://www.base64encode.org/>.

**consumer-key:consumer-secret** = 100:8adb5fa4-3f62-492c-8ef6-772bde9929f4

**Encoded String:**
YjBiZTMyYWEtMDhiNi00ZWU4LWE2ZWQtNDI5YjBjMjk1YzJlOjhhZGI1ZmE0LTNmNjIt
NDkyYy04ZWY2LTc3MmJkZTk5MjlmNA==

The authorization server will respond with a JSON object containing; <br/>

- token type with the value Bearer,
- expires in with an integer representing the TTL(Time-To-Live) of the access token and
- access token, a JWT signed with the authorization server’s private key.

**Request:**
**URI:**
Staging: <https://{{webserver}}/token>

**Header Keys**
Authorization: Basic YjBiZTMyYWEtMDhiNi00ZWU4LWE2ZWQtNDI5YjBjMjk1YzJlOjhhZGI1ZmE0LTNmNjItNDkyYy04ZWY2LTc3MmJkZTk5MjlmNA==

Version: 1.0

Note: The above base64 encoded value passed in the authorization header should be replaced by the actual value related to the client application

**Parameters**

| Name       | Data Type    | Validations      | Mandatory | Description                              |
| ---------- | ------------ | ---------------- | --------- | ---------------------------------------- |
| username   | AlphaNumeric |                  | yes       | client username                          |
| password   | AlphaNumeric |                  | yes       | client password                          |
| scope      | String       | enum: openid api | yes       | scope value will be only "openid api"    |
| grant_type | String       | enum: password   | yes       | grant_type value will be only "password" |

**Body** raw

```json
{
  "username": "username",
  "password": "password",
  "scope": "openid api",
  "grant_type": "password"
}
```

**Success Response:**
Access token is obtained in the response.

```json
{
  "code": 200,
  "message": "Success",
  "data": {
    "access_token": "U2FsdGVkX183kBkvv1TxDKo1wzVhrgO8UkB6ouXkhnOEVCQCHYZer6BLxuQq2KMkKVFo/jzJW4PXR0Y7+kIENdqdImzR+9f2hA1Lg52Fw0FJ+Ojx1U2tausPsl7TnS4cR8UThMgGlfL14s8Tj+JeBpkQZHbiAn44x4ubq7HcLhLSaTpBHBEEpwDfxP2MWg0src8lIVjk0ghvST+BxJyLyL1sdzCiGm7wGOCtT2KtHC2220Y+lmNgRq8TsOkw++3M",
    "token_type": "Bearer",
    "expires_in": "7d"
  }
}
```

**Sample Error Response 1**

```json
{
  "code": 400,
  "message": "Bad Request",
  "errors": ["invalid_client"],
  "correlation_id": "d50wRqrLbIqAp3EfuzpD8"
}
```

**Sample Error Response 2**

```json
{
  "code": 400,
  "message": "Bad Request",
  "errors": ["grant_type must be one of the following values: password"],
  "correlation_id": "kDXAF-DZblr8ZVQOM_knx"
}
```

# APIs Exposed in API Gateway

The following APIs have been currently exposed via API Gateway for LOS System to consume:

Staging
| API | URI | METHOD |
|-------|--------------------------------------|---|
| Leads | <https://{{webserver}}/api/leads/:id> | GET |

The following highlights the steps required to invoke Lead API

1. Generated Access Token should be sent in the HTTP header in the request
2. Lender Token and Product Token should be sent in the HTTP header in the request
3. The JSON payload based on the request type will be passed as a parameter.

**Header**
The token generated in section 3.1 should be added in the authorization header of the request.

| Key           | Value                                                                                                       |
| ------------- | ----------------------------------------------------------------------------------------------------------- |
| Authorization | Bearer YjBiZTMyYWEtMDhiNi00ZWU4LWE2ZWQtNDI5YjBjMjk1YzJlOjhhZGI1ZmE0LTNmNjItNDkyYy04ZWY2LTc3MmJkZTk5MjlmNA== |
| Version       | 1.0                                                                                                         |

**Parameters**

| Name | Data Type | Validations | Mandatory | Description     |
| ---- | --------- | ----------- | --------- | --------------- |
| id   | Numeric   |             | Yes       | Lead id of Lead |

**Success Response:**

```json
{
  "borrower_first_name": "XYZ",
  "borrower_last_name": "User",
  "primary_email_id": "xyz_user@b2cdev.com",
  "pan": "ABCTY1234D",
  "aadhar_id": "999999990019",
  "borrower_type": "ORGANIZATION",
  "primary_phone_number": 9876543214,
  "additional_phone_number": 9876543212,
  "additional_email_id": "additional@email.com",
  "date_of_birth": "23-06-1987",
  "gender": "MALE",
  "preferred_language": "en",
  "product_opportunity_id": "23v8lx5e",
  "lead_status": "NEW",
  "partner_ref_no": "65rfc",
  "business_name": "Zoomfitness",
  "business_pincode": 654321,
  "business_state": "up",
  "business_pan": "ABCTY1234D",
  "additional": {
    "gst": 987656789567665,
    "monthly_total_sales": 0,
    "monthly_payout_1": 0,
    "monthly_payout_2": 0,
    "monthly_payout_3": 0,
    "monthly_payout_4": 0,
    "monthly_payout_5": 0,
    "monthly_payout_6": 0,
    "monthly_payout_7": 0,
    "monthly_payout_8": 0,
    "retailer_name": "test",
    "address_of_the_shop": "123 ABC Landmark",
    "entity_type": "sole",
    "drug_license_number": "8735.NU",
    "date_of_first_transaction": 0,
    "distributor_codes": "8735.NU",
    "cumulative_12_months": 0,
    "total_number_of_invoices": 0,
    "volumes_of_invoicing": 0,
    "os_as_on_last_date_of_month": 0
  }
}
```

**Sample Error Response 1**

```json
{
  "code": 403,
  "message": "Forbidden",
  "errors": ["jwt malformed"],
  "correlation_id": "yY7iiiDhWzEKvzusSbk6t"
}
```

Staging
| API | URI | METHOD |
|-------|--------------------------------------|---|
| Lead Status | <https://{{webserver}}/api/leads/status/:id> | PUT |

The following highlights the steps required to invoke Lead API

1. Generated Access Token should be sent in the HTTP header in the request
2. Lender Token and Product Token should be sent in the HTTP header in the request
3. The JSON payload based on the request type will be passed as a parameter.

**Header**
The token generated in section 3.1 should be added in the authorization header of the request.

| Key           | Value                                                                                                       |
| ------------- | ----------------------------------------------------------------------------------------------------------- |
| Authorization | Bearer YjBiZTMyYWEtMDhiNi00ZWU4LWE2ZWQtNDI5YjBjMjk1YzJlOjhhZGI1ZmE0LTNmNjItNDkyYy04ZWY2LTc3MmJkZTk5MjlmNA== |
| Version       | 1.0                                                                                                         |

**Parameters**

| Name                   | Data Type | Validations                    | Mandatory | Description            |
| ---------------------- | --------- | ------------------------------ | --------- | ---------------------- |
| id                     | Numeric   |                                | Yes       | Lead id of Lead        |
| proposed_limit         | Numeric   |                                | Yes       | Lead proposed limit    |
| product_opportunity_id | String    |                                |           | Product Opportunity Id |
| borrower_first_name    | String    |                                | Yes       | Borrower First Name    |
| borrower_last_name     | String    |                                | Yes       | Borrower Last Name     |
| lead_status            | String    | enum: [WHITELISTED , REJECTED] | Yes       | Borrower Last Name     |

**Body** raw

```json
{
  "proposed_limit": 1234,
  "product_opportunity_id": "23v8lx5e",
  "borrower_first_name": "Lender",
  "borrower_last_name": "Singh",
  "lead_status": "WHITELISTED"
}
```

**Success Response:**

```json
{
  "code": 200,
  "message": "Success",
  "data": {
    "id": 127839062437
  }
}
```

**Sample Error Response 1**

```json
{
  "code": 403,
  "message": "Forbidden",
  "errors": ["jwt malformed"],
  "correlation_id": "yY7iiiDhWzEKvzusSbk6t"
}
```

Staging
| API | URI | METHOD |
|-------|--------------------------------------|---|
| Approve Limit | <https://{{webserver}}/api/application/approve-limit> | POST |

The following highlights the steps required to invoke Lead API

1. Generated Access Token should be sent in the HTTP header in the request
2. Lender Token and Product Token should be sent in the HTTP header in the request
3. The JSON payload based on the request type will be passed as a parameter.

**Header**
The token generated in section 3.1 should be added in the authorization header of the request.

| Key           | Value                                                                                                       |
| ------------- | ----------------------------------------------------------------------------------------------------------- |
| Authorization | Bearer YjBiZTMyYWEtMDhiNi00ZWU4LWE2ZWQtNDI5YjBjMjk1YzJlOjhhZGI1ZmE0LTNmNjItNDkyYy04ZWY2LTc3MmJkZTk5MjlmNA== |
| Version       | 1.0                                                                                                         |

**Parameters**

| Name                | Data Type | Validations                                                                                           | Mandatory | Description                                  |
| ------------------- | --------- | ----------------------------------------------------------------------------------------------------- | --------- | -------------------------------------------- |
| application_id      | Numeric   |                                                                                                       | Yes       | Application id of Lead                       |
| loan_account_number | Numeric   |                                                                                                       | Yes       | Loan Account Number allocated to the lead    |
| approved_limit      | String    |                                                                                                       | Yes       | Limit that has been approved by the Lender   |
| sanctioned_limit    | String    |                                                                                                       |           | Limit that has been Sanctioned by the Lender |
| limit_expiry_date   | String    |                                                                                                       | Yes       | Date on which the limit will expire          |
| limit_status        | String    | enum: [PENDING, APPROVED, Sanctioned, ACTIVATED, TEMPORARY_BLOCK, TEMPORARY_UNBLOCK, PERMENANT_BLOCK] | Yes       | Status of Limit                              |
| lead_status         | String    | enum: [APPROVED, REJECTED]                                                                            | Yes       | Status of the Lead after underwriting        |

**Body** raw

```json
{
  "application_id": 82968821732,
  "loan_account_number": 876565757,
  "approved_limit": 2000,
  "sanctioned_limit": 2000,
  "limit_expiry_date": "12-05-2032",
  "lead_status": "APPROVED",
  "limit_status": "APPROVED"
}
```

**Success Response:**

```json
{
  "code": 201,
  "message": "Successfully Created"
}
```

**Sample Error Response 1**

```json
{
  "code": 403,
  "message": "Forbidden",
  "errors": ["jwt malformed"],
  "correlation_id": "yY7iiiDhWzEKvzusSbk6t"
}
```

Staging
| API | URI | METHOD |
|-------|--------------------------------------|---|
| Disbursement Response | <https://{{webserver}}/api/application/disbursement/response> | POST |

The following highlights the steps required to invoke Lead API

1. Generated Access Token should be sent in the HTTP header in the request
2. Lender Token and Product Token should be sent in the HTTP header in the request
3. The JSON payload based on the request type will be passed as a parameter.

**Header**
The token generated in section 3.1 should be added in the authorization header of the request.

| Key           | Value                                                                                                       |
| ------------- | ----------------------------------------------------------------------------------------------------------- |
| Authorization | Bearer YjBiZTMyYWEtMDhiNi00ZWU4LWE2ZWQtNDI5YjBjMjk1YzJlOjhhZGI1ZmE0LTNmNjItNDkyYy04ZWY2LTc3MmJkZTk5MjlmNA== |
| Version       | 1.0                                                                                                         |

**Parameters**

| Name                                      | Data Type | Validations         | Mandatory | Description                                               |
| ----------------------------------------- | --------- | ------------------- | --------- | --------------------------------------------------------- |
| application_id                            | Number    |                     | Yes       | Application id of Lead                                    |
| disbursement_unique_id                    | Number    |                     | Yes       | Unique ID of disbursement record                          |
| disbursement_response_timestamp           | String    | DD-MM-YYYY HH:mm:ss | Yes       | Date and time of the disbursement request                 |
| retailer_name                             | String    |                     | Yes       | Name of the Retailer                                      |
| loan_account_number                       | String    |                     | Yes       | Loan Account Number allocated to lead                     |
| available_credit_limit                    | Number    |                     | Yes       | Available credit limit of the Retailer                    |
| total_disbursement_amount                 | Number    |                     | Yes       | Total disbursement amount Retailer                        |
| balance_credit_limit                      | Number    |                     | Yes       | credit limit post disbursement of the Retailer            |
| transanction_id                           | String    |                     | Yes       | Transanction ID of the disbursement                       |
| due_date_without_grace                    | String    | DD-MM-YYYY          | Yes       | Due date of disbursement without grace period             |
| final_due_date_with_grace                 | String    | DD-mm-YYYY          |           | Due date of disbursement with grace period                |
| without_grace_principal_os_as_on_due_date | Number    |                     |           | Principal Outstanding as of due date without grace period |
| without_grace_interest_os_as_on_due_date  | Number    |                     |           | Interest Outstanding as of due date without grace period  |
| without_grace_penalty_os_as_on_due_date   | Number    |                     |           | Penalty Outstanding as of due date without grace period   |
| without_grace_total_os_as_on_due_date     | Number    |                     |           | Total Outstanding as of due date without grace period     |
| with_grace_principal_os_as_on_due_date    | Number    |                     |           | Principal Outstanding as of due date with grace period    |
| with_grace_interest_os_as_on_due_date     | Number    |                     |           | Interest Outstanding as of due date with grace period     |
| with_grace_penalty_os_as_on_due_date      | Number    |                     |           | Penalty Outstanding as of due date with grace period      |
| with_grace_total_os_as_on_due_date        | Number    |                     |           | Total Outstanding as of due date with grace period        |
| dpd                                       | Number    |                     |           | DPD count of the lead as per Lender                       |
| invoices                                  | Array     |                     | Yes       | Invoice histry in array                                   |

**invoices**

| Name                    | Data Type | Validations                                             | Mandatory | Description                                                                   |
| ----------------------- | --------- | ------------------------------------------------------- | --------- | ----------------------------------------------------------------------------- |
| distributor_unique_code | String    |                                                         | Yes       | Unique code of the distributor                                                |
| invoice_no              | String    |                                                         | Yes       | Invoice Number against which credit is requested                              |
| payee_account_number    | String    |                                                         | Yes       | Account number of the distributor against which disbursement needs to be made |
| disbursed_date          | String    | DD-MM-YYYY                                              | Yes       | Date of Disbursement                                                          |
| disbursement_status     | String    | enum:[DISBURSED , PENDING, FAILED, PARTIALLY_DISBURSED] | Yes       | Status of disbursement                                                        |
| disbursement_amount     | Number    |                                                         | Yes       | Amount disbursed against disbursement ID                                      |

**Body** raw

```json
{
  "application_id": 82968821732,
  "disbursement_unique_id": 987654345,
  "disbursement_response_timestamp": "01-02-2015 23:04:59",
  "retailer_name": "Retail",
  "loan_account_number": "1487676754464543",
  "invoices": [
    {
      "invoice_no": "142344as",
      "distributor_unique_code": "142344as",
      "payee_account_number": "87654334567654",
      "disbursement_amount": 401,
      "disbursed_date": "22-10-2022",
      "disbursement_status": "PENDING"
    }
  ],
  "available_credit_limit": 1401,
  "total_disbursement_amount": 6543,
  "balance_credit_limit": 41,
  "transanction_id": "sffgg5432",
  "due_date_without_grace": "12-03-2002",
  "final_due_date_with_grace": "12-03-2002",
  "without_grace_principal_os_as_on_due_date": 876565757,
  "without_grace_interest_os_as_on_due_date": 876565757,
  "without_grace_penalty_os_as_on_due_date": 876565757,
  "without_grace_total_os_as_on_due_date": 876565757,
  "with_grace_principal_os_as_on_due_date": 876565757,
  "with_grace_interest_os_as_on_due_date": 876565757,
  "with_grace_penalty_os_as_on_due_date": 876565757,
  "with_grace_total_os_as_on_due_date": 876565757,
  "dpd": 876565757
}
```

**Success Response:**

```json
{
  "code": 201,
  "message": "Successfully Created",
  "data": {
    "id": 7019712432
  }
}
```

**Sample Error Response 1**

```json
{
  "code": 403,
  "message": "Forbidden",
  "errors": ["jwt malformed"],
  "correlation_id": "yY7iiiDhWzEKvzusSbk6t"
}
```

Staging
| API | URI | METHOD |
|-------|--------------------------------------|---|
| Disbursement Response Reconciliation | <https://{{webserver}}/api/application/disbursement/response/reconciliation> | POST |

The following highlights the steps required to invoke Lead API

1. Generated Access Token should be sent in the HTTP header in the request
2. Lender Token and Product Token should be sent in the HTTP header in the request
3. The JSON payload based on the request type will be passed as a parameter.

**Header**
The token generated in section 3.1 should be added in the authorization header of the request.

| Key           | Value                                                                                                       |
| ------------- | ----------------------------------------------------------------------------------------------------------- |
| Authorization | Bearer YjBiZTMyYWEtMDhiNi00ZWU4LWE2ZWQtNDI5YjBjMjk1YzJlOjhhZGI1ZmE0LTNmNjItNDkyYy04ZWY2LTc3MmJkZTk5MjlmNA== |
| Version       | 1.0                                                                                                         |

**Parameters**

| Name                     | Data Type | Validations                | Mandatory | Description                                      |
| ------------------------ | --------- | -------------------------- | --------- | ------------------------------------------------ |
| application_id           | Number    |                            | Yes       | Application id of Lead                           |
| disbursement_unique_id   | Number    |                            | Yes       | Unique ID of disbursement record                 |
| transanction_id          | String    |                            | Yes       | Transanction ID of the disbursement              |
| disbursed_date           | String    | DD-MM-YYYY                 | Yes       | Date of Disbursement                             |
| disbursement_status      | String    | enum:[DISBURSED , PENDING] | Yes       | Disbursement Status                              |
| aggregator_interest_rate | Number    |                            | Yes       | Rate of Interest charged by Lender to aggregator |

**Body** raw

```json
{
  "application_id": 82968821732,
  "disbursement_unique_id": 1234,
  "transanction_id": "abd4562",
  "disbursed_date": "16-02-2023",
  "disbursement_status": "DISBURSED",
  "aggregator_interest_rate": 32
}
```

**Success Response:**

```json
{
  "code": 201,
  "message": "Successfully Created",
  "data": {
    "id": 7019712432
  }
}
```

**Sample Error Response 1**

```json
{
  "code": 403,
  "message": "Forbidden",
  "errors": ["jwt malformed"],
  "correlation_id": "yY7iiiDhWzEKvzusSbk6t"
}
```

Staging
| API | URI | METHOD |
|-------|--------------------------------------|---|
| Repayment Response | <https://{{webserver}}/api/application/repayment/response> | POST |

The following highlights the steps required to invoke Lead API

1. Generated Access Token should be sent in the HTTP header in the request
2. Lender Token and Product Token should be sent in the HTTP header in the request
3. The JSON payload based on the request type will be passed as a parameter.

**_Header_**

The token generated in section 3.1 should be added in the authorization header of the request.

| Key           | Value                                                                                                       |
| ------------- | ----------------------------------------------------------------------------------------------------------- |
| Authorization | Bearer YjBiZTMyYWEtMDhiNi00ZWU4LWE2ZWQtNDI5YjBjMjk1YzJlOjhhZGI1ZmE0LTNmNjItNDkyYy04ZWY2LTc3MmJkZTk5MjlmNA== |
| Version       | 1.0                                                                                                         |

**Parameters**

| Name                                                   | Data Type | Validations                              | Mandatory | Description                                                                            |
| ------------------------------------------------------ | --------- | ---------------------------------------- | --------- | -------------------------------------------------------------------------------------- |
| application_id                                         | Number    |                                          | Yes       | Application id of Lead                                                                 |
| repayment_unique_id                                    | number    |                                          | Yes       | Unique ID of repayment record                                                          |
| retailer_name                                          | String    |                                          | Yes       | Name of the Retailer                                                                   |
| loan_account_number                                    | String    |                                          | Yes       | Loan Account Number allocated to lead                                                  |
| repayment_timestamp                                    | String    | DD-MM-YYYY HH:mm:ss                      | Yes       | Date and time of repayment                                                             |
| total_repayment_received                               | Number    |                                          | Yes       | total repayment received                                                               |
| payment_status                                         | String    | should be one of 'RECEIVED' or 'ON_HOLD' | Yes       | status of payment                                                                      |
| pending_repayment_amount                               | Number    |                                          | Yes       | Amount of repayment pending                                                            |
| available_credit_limit                                 | Number    |                                          | Yes       | available credit limit                                                                 |
| updated_credit_limit                                   | Number    |                                          | Yes       | updated credit limit                                                                   |
| disbursement_unique_id                                 | Number    |                                          | no        | Unique ID of disbursement record                                                       |
| status_of_tranche_repayment                            | string    | ['PAID', 'PARTIAL', 'PENDING']           | no        | Status of repayment - Paid, Partial, Pending                                           |
| total_payment_requested                                | Number    |                                          | no        | Total disbursement amount requested for all invoices (collated amount of all invoices) |
| total_principal_deduction                              | Number    |                                          | no        | Principal deducted against tranche from repayment amount                               |
| total_interest_deduction                               | Number    |                                          | no        | Interest deducted against tranche from repayment amount                                |
| total_penalty_deduction                                | Number    |                                          | no        |
| Penalty deducted against tranche from repayment amount |
| total_invoice_deduction                                | Number    |                                          | no        | Total deduction against tranche from repayment amount                                  |
| tranche_principal_os                                   | Number    |                                          | no        | Principal outstanding against tranche                                                  |
| tranche_interest_os                                    | Number    |                                          | no        | Interest outstanding against tranche                                                   |
| tranche_penalty_os                                     | Number    |                                          | no        | Penalty outstanding against tranche                                                    |
| total_tranche_outstanding                              | Number    |                                          | no        | Total deduction outstanding against tranche                                            |
| invoices                                               | Array     |                                          | no        | An Array of objects describing different invoice details                               |

**invoices**

| Name                        | Data Type | Validations                                      | Mandatory | Description                                              |
| --------------------------- | --------- | ------------------------------------------------ | --------- | -------------------------------------------------------- |
| invoice_no                  | String    |                                                  | Yes       | Invoice no.                                              |
| status_of_invoice_repayment | String    | should be one of 'PAID', 'PARTIAL' and 'PENDING' | Yes       | Status of invoice repayment                              |
| disbursement_amount         | Number    |                                                  | Yes       | Amount of disbursement                                   |
| invoice_principal_deduction | Number    |                                                  | Yes       | Principal deducted against invoice from repayment amount |
| invoice_interest_deduction  | Number    |                                                  | Yes       | Interest deducted against invoice from repayment amount  |
| invoice_penalty_deduction   | Number    |                                                  | Yes       | Penalty deducted against invoice from repayment amount   |
| total_invoice_deduction     | Number    |                                                  | Yes       | Total deduction against invoice from repayment amount    |
| principal_os                | Number    |                                                  | Yes       | Principal outstanding against invoice                    |
| interest_os                 | Number    |                                                  | Yes       | Interest outstanding against invoice                     |
| penalty_os                  | Number    |                                                  | Yes       | Penalty outstanding against invoice                      |
| total_invoice_outstanding   | Number    |                                                  | Yes       | Total deduction outstanding against invoice              |

**Body 1** raw

```json
{
  "application_id": 121185321431,
  "repayment_unique_id": 4562,
  "repayment_timestamp": "09-08-2022 02:13:45",
  "retailer_name": "ABC",
  "loan_account_number": "1234abcd",
  "total_repayment_received": 20000,
  "payment_status": "RECEIVED",
  "pending_repayment_amount": 30000,
  "available_credit_limit": 10000,
  "updated_credit_limit": 25000,
  "invoices": [
    {
      "invoice_no": "APBH1234",
      "status_of_invoice_repayment": "PAID",
      "disbursement_amount": 1100000,
      "invoice_principal_deduction": 25000,
      "invoice_interest_deduction": 1500,
      "invoice_penalty_deduction": 2000,
      "total_invoice_deduction": 4000,
      "principal_os": 50000,
      "interest_os": 1000,
      "penalty_os": 2000,
      "total_invoice_outstanding": 20000
    }
  ]
}
```

**Body 2** raw

```json
{
  "application_id": 121185321431,
  "repayment_unique_id": 4562,
  "repayment_timestamp": "09-08-2022 02:13:45",
  "retailer_name": "ABC",
  "loan_account_number": "1234abcd",
  "total_repayment_received": 20000,
  "payment_status": "RECEIVED",
  "pending_repayment_amount": 30000,
  "available_credit_limit": 10000,
  "updated_credit_limit": 25000,
  "disbursement_unique_id": 12564,
  "status_of_tranche_repayment": "PAID",
  "total_payment_requested": 50000,
  "total_principal_deduction": 1000,
  "total_interest_deduction": 2000,
  "total_penalty_deduction": 3000,
  "total_invoice_deduction": 2000,
  "tranche_principal_os": 200,
  "tranche_interest_os": 450,
  "tranche_penalty_os": 456,
  "total_tranche_outstanding": 2000
}
```

**Success Response 1**

```json
{
  "code": 201,
  "message": "Successfully Created",
  "data": {
    "application_id": 124748541154,
    "repayment_unique_id": 4562,
    "repayment_timestamp": "09-09-2022 09:34:45",
    "retailer_name": "ABC",
    "loan_account_number": "1234abcd",
    "total_repayment_received": 20000,
    "payment_status": "RECEIVED",
    "pending_repayment_amount": 30000,
    "available_credit_limit": 10000,
    "updated_credit_limit": 25000,
    "invoices": [
      {
        "invoice_no": "APBH1234",
        "status_of_invoice_repayment": "PAID",
        "disbursement_amount": 1100000,
        "invoice_principal_deduction": 25000,
        "invoice_interest_deduction": 1500,
        "invoice_penalty_deduction": 2000,
        "total_invoice_deduction": 4000,
        "principal_os": 50000,
        "interest_os": 1000,
        "penalty_os": 2000,
        "total_invoice_outstanding": 20000,
        "maadhyam_invoice_date": "20-04-2022 23:04:59",
        "maadhyam_invoice_disbursement_date": "12-04-2022",
        "maadhyam_invoice_lender_due_date": "15-04-2022",
        "maadhyam_invoice_repayment_date": "09-07-2022 09:33:45",
        "maadhyam_borrower_repayment_amount": 4000,
        "maadhyam_borrower_repayment_principal": 25000,
        "maadhyam_borrower_repayment_charges": 2000,
        "maadhyam_borrower_os_repayment_amount": 20000,
        "maadhyam_borrower_os_principal": 50000,
        "maadhyam_borrower_os_interest": 1000,
        "maadhyam_borrower_os_charges": 2000,
        "maadhyam_aggregator_repayment_amount": 4000,
        "maadhyam_aggregator_repayment_principal": 25000,
        "maadhyam_aggregator_repayment_charges": 2000,
        "maadhyam_invoice_fination_due_date": "04-06-2022 11:04:59",
        "maadhyam_borrower_repayment_interest": 1082.191780821918,
        "maadhyam_aggregator_repayment_interest": 482.19178082191786
      },
      {
        "invoice_no": "APBH1235",
        "status_of_invoice_repayment": "PAID",
        "disbursement_amount": 1100000,
        "invoice_principal_deduction": 25000,
        "invoice_interest_deduction": 1500,
        "invoice_penalty_deduction": 2000,
        "total_invoice_deduction": 4000,
        "principal_os": 50000,
        "interest_os": 1000,
        "penalty_os": 2000,
        "total_invoice_outstanding": 20000,
        "maadhyam_invoice_date": "21-04-2022 23:04:59",
        "maadhyam_invoice_disbursement_date": "12-04-2022",
        "maadhyam_invoice_lender_due_date": "15-04-2022",
        "maadhyam_invoice_repayment_date": "09-07-2022 09:33:45",
        "maadhyam_borrower_repayment_amount": 4000,
        "maadhyam_borrower_repayment_principal": 25000,
        "maadhyam_borrower_repayment_charges": 2000,
        "maadhyam_borrower_os_repayment_amount": 20000,
        "maadhyam_borrower_os_principal": 50000,
        "maadhyam_borrower_os_interest": 1000,
        "maadhyam_borrower_os_charges": 2000,
        "maadhyam_aggregator_repayment_amount": 4000,
        "maadhyam_aggregator_repayment_principal": 25000,
        "maadhyam_aggregator_repayment_charges": 2000,
        "maadhyam_invoice_fination_due_date": "05-06-2022 11:04:59",
        "maadhyam_borrower_repayment_interest": 1068.4931506849316,
        "maadhyam_aggregator_repayment_interest": 482.19178082191786
      }
    ],
    "id": 124751601254
  }
}
```

**Success Response 2**

```json
{
  "code": 201,
  "message": "Successfully Created",
  "data": {
    "application_id": 124748541154,
    "repayment_unique_id": 4562,
    "repayment_timestamp": "09-09-2022 09:34:45",
    "retailer_name": "ABC",
    "loan_account_number": "1234abcd",
    "total_repayment_received": 20000,
    "payment_status": "RECEIVED",
    "pending_repayment_amount": 30000,
    "available_credit_limit": 10000,
    "updated_credit_limit": 25000,
    "disbursement_unique_id": 12564,
    "status_of_tranche_repayment": "PAID",
    "total_payment_requested": 50000,
    "total_principal_deduction": 1000,
    "total_interest_deduction": 2000,
    "total_penalty_deduction": 3000,
    "total_invoice_deduction": 2000,
    "tranche_principal_os": 200,
    "tranche_interest_os": 450,
    "tranche_penalty_os": 456,
    "total_tranche_outstanding": 2000,
    "id": 148962481956
  }
}
```

**Sample Error Response 1**

```json
{
  "code": 403,
  "message": "Forbidden",
  "errors": ["jwt malformed"],
  "correlation_id": "yY7iiiDhWzEKvzusSbk6t"
}
```

**Sample Error Response 2**

```json
{
  "code": 400,
  "message": "Bad Request",
  "errors": [
    "updated_credit_limit must be a number conforming to the specified constraints"
  ],
  "correlation_id": "bMHFeVhyC7IOR_JT8BiwM"
}
```

Staging
| API | URI | METHOD |
|-------|--------------------------------------|---|
| Lead profile | <https://{{webserver}}/api/leads/summary/:lead_id> | GET |

The following highlights the steps required to invoke Lead API

1. Generated Access Token should be sent in the HTTP header in the request
2. Lender Token and Product Token should be sent in the HTTP header in the request
3. The JSON payload based on the request type will be passed as a parameter.

**_Header_**

The token generated in section 3.1 should be added in the authorization header of the request.

| Key           | Value                                                                                                       |
| ------------- | ----------------------------------------------------------------------------------------------------------- |
| Authorization | Bearer YjBiZTMyYWEtMDhiNi00ZWU4LWE2ZWQtNDI5YjBjMjk1YzJlOjhhZGI1ZmE0LTNmNjItNDkyYy04ZWY2LTc3MmJkZTk5MjlmNA== |
| Version       | 1.0                                                                                                         |

**Parameters**

| Name    | Data Type | Validations | Mandatory | Description     |
| ------- | --------- | ----------- | --------- | --------------- |
| lead_id | Number    |             | Yes       | lead_id of lead |

**Success Response**

```json
{
  "code": 200,
  "message": "Success",
  "data": {
    "lead_id": 13622329845,
    "application_id": 12469618849,
    "lead_status": "APPROVED",
    "application_status": "LIMIT_SANCTIONED",
    "proposed_limit": null,
    "approved_limit": 200000,
    "sanctioned_limit": 200000,
    "allocated_limit": null,
    "loan_account_number": 123456789,
    "current_limit": 198000,
    "limit_status": "SANCTIONED",
    "limit_expiry_date": "22-05-2022",
    "total_disbursement_count": 2,
    "last_disbursement_date": "01-04-2022",
    "last_disbursement_amount": 50000,
    "last_repayment_date": "06-04-2022 18:23:45",
    "last_repayment_amount": 50000,
    "pending_repayment_amount": 50000,
    "total_repayment_count": 2
  }
}
```

**Sample Error Response 1**

```json
{
  "code": 403,
  "message": "Forbidden",
  "errors": ["jwt malformed"],
  "correlation_id": "yY7iiiDhWzEKvzusSbk6t"
}
```

**Sample Error Response 2**

```json
{
  "code": 400,
  "message": "Bad Request",
  "errors": ["invalid lead_id"],
  "correlation_id": "JtySMiVvFm9c1Ohg8Iijw"
}
```

Staging
| API | URI | METHOD |
|-------|--------------------------------------|---|
| Invoice Summary | https://{{webserver}}/application/transaction_info/:id | GET |

The following highlights the steps required to invoke Lead API

1. Generated Access Token should be sent in the HTTP header in the request
2. Lender Token and Product Token should be sent in the HTTP header in the request
3. The JSON payload based on the request type will be passed as a parameter.

**_Header_**

The token generated in section 3.1 should be added in the authorization header of the request.

| Key           | Value                                                                                                       |
| ------------- | ----------------------------------------------------------------------------------------------------------- |
| Authorization | Bearer YjBiZTMyYWEtMDhiNi00ZWU4LWE2ZWQtNDI5YjBjMjk1YzJlOjhhZGI1ZmE0LTNmNjItNDkyYy04ZWY2LTc3MmJkZTk5MjlmNA== |
| Version       | 1.0                                                                                                         |

**Parameters**

| Name | Data Type | Validations | Mandatory | Description    |
| ---- | --------- | ----------- | --------- | -------------- |
| id   | string    |             | Yes       | transaction id |

**Success Response**

```json
{
  "code": 200,
  "message": "Success",
  "data": [
    {
      "type": "disbursement_response",
      "disbursement_unique_id": 12345678910,
      "disbursement_response_timestamp": "12-04-2022 15:50:50",
      "retailer_name": "Retail6747",
      "invoices": [
        {
          "disbursed_date": "12-04-2022",
          "disbursement_status": "DISBURSED",
          "disbursement_amount": 50000,
          "distributor_unique_code": "DIST002",
          "invoice_no": "APBH1234",
          "payee_account_number": "98765432345676542"
        },
        {
          "disbursed_date": "12-04-2022",
          "disbursement_status": "DISBURSED",
          "disbursement_amount": 50000,
          "distributor_unique_code": "DIST001",
          "invoice_no": "APBH1235",
          "distributor_name": "distone",
          "payee_account_number": "98765432345676541"
        }
      ],
      "loan_account_number": "1487676754464543",
      "available_credit_limit": 100000,
      "total_disbursement_amount": 100000,
      "balance_credit_limit": 0,
      "interest_rate": 4,
      "aggregator_interest_rate": 10,
      "transanction_id": "tran34245344",
      "due_date_without_grace": "13-04-2022",
      "final_due_date_with_grace": "15-04-2022",
      "id": 25658052555
    }
  ]
}
```

**Sample Error Response 1**

```json
{
  "code": 403,
  "message": "Forbidden",
  "errors": ["jwt malformed"],
  "correlation_id": "yY7iiiDhWzEKvzusSbk6t"
}
```

**Sample Error Response 2**

```json
{
  "code": 400,
  "message": "Bad Request",
  "errors": ["invalid transaction id"],
  "correlation_id": "CT-3lVdFUVWSDOKgeSAFi"
}
```

Staging
| API | URI | METHOD |
|-------|--------------------------------------|---|
| Get Application | https://{{webserver}}/application | GET |

The following highlights the steps required to invoke Lead API

1. Generated Access Token should be sent in the HTTP header in the request
2. Lender Token and Product Token should be sent in the HTTP header in the request
3. The JSON payload based on the request type will be passed as a parameter.

**_Header_**

The token generated in section 3.1 should be added in the authorization header of the request.

| Key           | Value                                                                                                       |
| ------------- | ----------------------------------------------------------------------------------------------------------- |
| Authorization | Bearer YjBiZTMyYWEtMDhiNi00ZWU4LWE2ZWQtNDI5YjBjMjk1YzJlOjhhZGI1ZmE0LTNmNjItNDkyYy04ZWY2LTc3MmJkZTk5MjlmNA== |
| Version       | 1.0                                                                                                         |

**Parameters**

| Name | Data Type | Validations | Mandatory | Description    |
| ---- | --------- | ----------- | --------- | -------------- |
| id   | string    |             | Yes       | application id |

**Success Response**

```json
{
  "code": 200,
  "message": "Success",
  "data": {
    "building_name": "ggdggdgdggd",
    "street_name": "Harley st",
    "street_no": "600B",
    "location": "Noida",
    "door_number": "18",
    "state": "Delhi",
    "district": "NewDelhi",
    "city": "Delhi",
    "floor_number": "2nd",
    "pin_code": 110056,
    "latitude": 89,
    "longitude": 120,
    "nature_of_business": "Trading",
    "sub_industry": "vegetable_and_melon_farming",
    "business_industry": "agriculture",
    "cin": 96843,
    "pan": "ABCTY1234D",
    "date_of_incorporation": "10-06-2022",
    "borrower_address_type": "PRIMARY",
    "product_type": "SKbZDloB",
    "owners": [
      {
        "owner_unique_id": "ABCTY1234D",
        "owner_pan": "ABCTY1234D",
        "business_type": "ONE_PERSON_COMPANY",
        "owner_role": "OWNER",
        "owner_first_name": "Rakesh",
        "owner_last_name": "kumar",
        "ownership_percentage": 100,
        "owner_ownership_status": "OWNED",
        "owner_email": "rel45@gmail.com",
        "owner_dob": "28-10-2023",
        "owner_aadhar": 3468468463486,
        "owner_mobile_number": 7878676767,
        "owner_latitude": 85,
        "owner_longitude": 120,
        "owner_state": "delhi",
        "owner_pin_code": 110023,
        "owner_city": "new Delhi",
        "owner_cibil_score": 768,
        "owner_experian_score": 556,
        "level": 1
      },
      {
        "owner_unique_id": "ABCTU1234D",
        "owner_pan": "ABCTY1284D",
        "owner_role": "GUARANTOR",
        "owner_first_name": "Rakesh",
        "business_type": "ONE_PERSON_COMPANY",
        "owner_aadhar": 3468468463486,
        "owner_mobile_number": 7878676767,
        "owner_email": "rel45@gmail.com",
        "owner_last_name": "awasthi",
        "ownership_percentage": 100,
        "owner_ownership_status": "OWNED",
        "owner_dob": "28-09-2023",
        "owner_latitude": 85,
        "owner_longitude": 120,
        "owner_state": "delhi",
        "owner_pin_code": 110023,
        "owner_city": "new Delhi",
        "owner_cibil_score": 768,
        "owner_experian_score": 556,
        "level": 1
      }
    ],
    "disbursement_request": {
      "type": "disbursement_request",
      "disbursement_unique_id": 987654345,
      "payment_request_timestamp": "01-02-2015 23:04:59",
      "retailer_name": "Retail 1",
      "loan_account_number": "142344",
      "available_credit_limit": 5432,
      "total_invoice_amount": 2345,
      "total_payment_requested": 5343,
      "total_invoices": 5,
      "invoices": [
        {
          "invoice_no": "APBH1234",
          "invoice_timestamp": "20-04-2022 23:04:59",
          "distributor_unique_code": "142344as",
          "distributor_name": "asdfg",
          "invoice_amount": 5432,
          "payment_requested": 5432,
          "payee_account_number": "98765432345676543",
          "payee_bank_name": "PNB",
          "payee_bank_ifsc": "PUNB000231"
        },
        {
          "invoice_no": "APBH1235",
          "invoice_timestamp": "21-04-2022 23:04:59",
          "distributor_unique_code": "142344as",
          "distributor_name": "asdfg",
          "invoice_amount": 5432,
          "payment_requested": 5432,
          "payee_account_number": "98765432345676543",
          "payee_bank_name": "PNB",
          "payee_bank_ifsc": "PUNB000231"
        }
      ]
    },
    "disbursement_response": {
      "type": "disbursement_response",
      "disbursement_unique_id": 12345678910,
      "disbursement_response_timestamp": "12-04-2022 15:50:50",
      "retailer_name": "Retail6747",
      "invoices": [
        {
          "disbursed_date": "12-04-2022",
          "disbursement_status": "DISBURSED",
          "disbursement_amount": 50000,
          "distributor_unique_code": "DIST002",
          "invoice_no": "APBH1234",
          "payee_account_number": "98765432345676542"
        },
        {
          "disbursed_date": "12-04-2022",
          "disbursement_status": "DISBURSED",
          "disbursement_amount": 50000,
          "distributor_unique_code": "DIST001",
          "invoice_no": "APBH1235",
          "distributor_name": "distone",
          "payee_account_number": "98765432345676541"
        }
      ],
      "loan_account_number": "1487676754464543",
      "available_credit_limit": 100000,
      "total_disbursement_amount": 100000,
      "balance_credit_limit": 0,
      "interest_rate": 4,
      "aggregator_interest_rate": 10,
      "transanction_id": "tran34245344",
      "due_date_without_grace": "13-04-2022",
      "final_due_date_with_grace": "15-04-2022"
    },
    "repayment_request": {
      "type": "repayment_request",
      "repayment_unique_id": 4562,
      "repayment_timestamp": "09-07-2022 09:33:45",
      "retailer_name": "ABC",
      "loan_account_number": "1234abcd",
      "repayment_category": "INVOICE",
      "repayment_type": "FULL",
      "repayment_amount": 500000,
      "invoices": [
        {
          "invoice_no": "asT123",
          "invoice_timestamp": "09-08-2022 01:23:45"
        },
        {
          "invoice_no": "asT124",
          "invoice_timestamp": "10-08-2022 01:23:45"
        }
      ]
    },
    "id": 115271922552
  }
}
```

**Sample Error Response 1**

```json
{
  "code": 403,
  "message": "Forbidden",
  "errors": ["jwt malformed"],
  "correlation_id": "yY7iiiDhWzEKvzusSbk6t"
}
```

**Sample Error Response 2**

```json
{
  "code": 400,
  "message": "Bad Request",
  "errors": ["invalid application_id"],
  "correlation_id": "CT-3lVdFUVWSDOKgeSAFi"
}
```

# Send Notification via Webhooks

Web hooks are a way to push notifications to your own servers, in real-time, as data you are interested in is created and modified, without the disadvantages of polling.

- We’ve written and maintain the code that pushes notifications to your servers as the bank selects which client to interact with.
- We send your servers the data (lead data), in real-time, as it comes into our system.
- We only send the data when something changes.
- Your resources are used just for receiving and processing the data.

## Supported event list

**1. lead_assigned**

**Event Name**: lead_assigned
Every time an event occurs, for example, if lead_assigned event occurs, biz2credit will access the callback URL provided by lender and pass on the data. In return of this information biz2credit expects a 200 status code from lender as a token of successfully acceptance of lead.

## Failure handling mechanism

In case callback URL doesn’t return 200 status in first time, biz2credit will try 2 more times (in total 3trials) in interval.

# Webhook Error Handling

To ensure Webhooks are delivered successfully, it’s important to build a system that will retry Webhook delivery on errors. Platform retries failed deliveries up to three times: once immediately, and then one minute later, and finally five minutes later. Further, if the endpoint continues to return errors for 95% of requests, Platform stops sending events to that Webhook endpoint and notifies.
