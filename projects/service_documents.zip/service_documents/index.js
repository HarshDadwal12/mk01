const express = require('express');
const cors = require('cors');

const docRoutes = require('./src/routes/v1/document');
const imageRoutes = require('./src/routes/v1/image');
const healthRoutes = require('./src/routes/v1/health');
const mtiffRoutes = require('./src/routes/v1/mtiff');
const docRoutesV2 = require('./src/routes/v2/document');
const docRoutesV3 = require('./src/routes/v3/document')
const httpNotFound = require('./src/exceptions/HttpNotFound');
const multitenant = require('./src/middleware/multitenant');

const app = express();

app.use(express.json({ limit: '150mb' }));
app.use(express.urlencoded({ limit: '150mb', extended: true }));
app.use(cors());

app.use(multitenant);


// Doc Service routes
app.use('/health', healthRoutes);
app.use('/api/v1/doc', docRoutes);

// Doc Service routes
app.use('/api/v1/mtiff', mtiffRoutes);

// Doc Service routes Version 2
app.use('/api/v2/doc', docRoutesV2);

//Doc Service routes version 3
app.use('/api/v3/doc', docRoutesV3);

// Image Upload Routes
app.use('/api/v1/image', imageRoutes);

// If route does not exist
app.use(httpNotFound);

const port = process.env.PORT || 3050;
app.set("port", port);

app.listen(port, () => {
    console.log(`Running on port ${port}`);
});