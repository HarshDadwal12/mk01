import { ApiProperty } from '@nestjs/swagger';
import { IsIn, IsNotEmpty, IsString } from 'class-validator';

export class TokenDto {
  @IsNotEmpty()
  @IsString()
  @ApiProperty()
  username: string;

  @IsNotEmpty()
  @IsString()
  @ApiProperty()
  password: string;

  @IsNotEmpty()
  @IsString()
  @IsIn(['password'])
  @ApiProperty()
  grant_type: string;

  @IsNotEmpty()
  @IsString()
  @IsIn(['openid api'])
  @ApiProperty()
  scope: string;
}
