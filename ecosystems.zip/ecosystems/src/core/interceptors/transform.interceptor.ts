import {
  Injectable,
  NestInterceptor,
  ExecutionContext,
  CallHandler,
} from '@nestjs/common';
import { Observable } from 'rxjs';
import { map, switchMap } from 'rxjs/operators';
import { EventEmitter2 } from '@nestjs/event-emitter';
import * as _ from 'lodash';

import { HttpResponse } from 'src/config/http-response';
import { IServiceResult, ISuccessResponse } from '../types';
import { CommonService } from '../services/common.service';
import { RequestLogEvent } from '../events/request-log.event';
import { WebHookEvent } from '../events/web-hook.event';
import { config } from 'src/config/constant.config';

/**
 * Interceptor to transform response globally.
 */
@Injectable()
export class TransformInterceptor<T>
  implements NestInterceptor<T, ISuccessResponse<any>>
{
  constructor(
    private readonly commonService: CommonService,
    private eventEmitter: EventEmitter2,
  ) {}
  intercept(
    ctx: ExecutionContext,
    next: CallHandler,
  ): Observable<ISuccessResponse<any>> {
    const response = ctx.switchToHttp().getResponse();
    const request = ctx.switchToHttp().getRequest();
    return next.handle().pipe(
      switchMap(async (res: IServiceResult) => {
        console.log('in interceptor');
        
        let globleFilter = true;
        let hookData = _.assign({}, res);
        if (res?.data) {
          if (res?.filter) {
            const data = await this.commonService.getUserSetting(
              res?.key,
              request,
            );
            if (data?.response_keys) {
              globleFilter = false;
              res.data = this.commonService.modifyResponse(
                res.data,
                data.response_keys,
              );
            }
          }

          if (globleFilter && config.FILTER_DATA?.[res?.key]) {
            res.data = this.commonService.modifyResponse(
              res.data,
              config.FILTER_DATA[res?.key],
            );
          }
          res.data = this.commonService.hideAndRenameData(res.data, res?.key);
        }

        if (res?.hook) {
          const webHookEvent = new WebHookEvent();
          if(globleFilter) webHookEvent.resData = res;
          else {
            if(hookData?.data){
              if(config.FILTER_DATA[hookData?.key]){
                hookData.data = this.commonService.modifyResponse(
                  hookData.data,
                  config.FILTER_DATA[hookData?.key],
                );
              }
            hookData.data = this.commonService.hideAndRenameData(hookData.data, hookData?.key);
            console.log('hookdata---',hookData);
            
            webHookEvent.resData = hookData;
            }
          }
          this.eventEmitter.emit('web.hook', webHookEvent);
        }

        console.log('in interceptor switch---',res);
        
        return res;
      }),
      map((res: IServiceResult) => {
        const data: any = {
          ...HttpResponse[response.statusCode],
          total: res?.total,
          data: res?.data,
        };

        request.response = data;
        const requestLogEvent = new RequestLogEvent();
        requestLogEvent.data = request;
        this.eventEmitter.emit('request.log', requestLogEvent);
        console.log('in interceptor map-----',data);
        
        return data;
      }),
    );
  }
}
