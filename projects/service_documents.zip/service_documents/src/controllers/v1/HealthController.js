const redis = require("../../config/redis.config");
const s3 = require("../../config/s3.config");

module.exports.checkHealth = async (req, res) => {
	try {
		const redisConnection = redis.getInstance();
		let tenant = req.headers["x-tenant-id"];
		let aws = await checkAWS(tenant);
		const body = {
			database: global[tenant]["db"].readyState === 1,
			redis: redisConnection.isConnect || false,
      aws:aws
		};
		return res.status(200).send(body);
	} catch (error) {
		const error_msg = error.message || error;
		return res.status(500).send(error_msg);
	}
};

checkAWS = async (tenant) => {
	try {
		const s3Client = s3.getS3Client(tenant);
		const Bucket = s3.downloadParams(tenant).Bucket;
		await s3Client.headBucket({ Bucket }).promise();
    return true
	} catch (error) {
    return false
  }
};
