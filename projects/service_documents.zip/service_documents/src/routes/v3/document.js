/** @format */

const express = require("express");
const DocController = require("../../controllers/v3/docController");
const { pdfValidator, docTypeValidator } = require("../../validators/filetype.validator");
const multerConfig = require("../../config/multer.config");
const upload = new multerConfig().upload;

const {
	dataReqValidator,
	docIdValidator,
	singleUploadReqValidator,
	docTypeIdValidator,
	appIdValidator,
	docIdsValidator,
	removeExifDataValidator,
	removeExifDataValidatorForBase64,
} = require("../../validators/request.validator");

const routes = express.Router();

routes.post(
	"/data_upload",
	dataReqValidator,
	appIdValidator,
	docTypeIdValidator,
	docTypeValidator,
	removeExifDataValidatorForBase64,
	DocController.doDataUpload
);

routes.post(
	"/upload",
	upload.single("file"),
	singleUploadReqValidator,
	appIdValidator,
	docTypeIdValidator,
	pdfValidator,
	removeExifDataValidator,
	DocController.doSingleUpload
);

routes.get("/get/:doc_id", docIdValidator, DocController.get);
routes.post("/getByIds", docIdsValidator, DocController.getByIds);

routes.delete("/delete/:doc_id", docIdValidator, DocController.doDelete);

routes.get("/download/:doc_id", docIdValidator, DocController.doDownload);
routes.get("/downloadJson/:doc_id", docIdValidator, DocController.doDownloadJson);

module.exports = routes;
