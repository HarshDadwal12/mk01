import { BadRequestException, Injectable } from '@nestjs/common';
import { nanoid } from 'nanoid';
import * as _ from 'lodash';

import apiModel from 'src/database/models/api.model';
import requestLogModel from 'src/database/models/request-log.model';
import { HttpRequestService } from './http-request.service';
import { QueryService } from './query.service';
import userMappingModel from 'src/database/models/user-mapping.model';
import { config } from 'src/config/constant.config';

@Injectable()
export class CommonService {
  constructor(
    private readonly httpRequestService: HttpRequestService,
    private readonly queryService: QueryService,
  ) {}

  async callApiByName(name: string, reqData: any = {}) {
    try {
      const apiData: any = await apiModel.findOne({ name }).lean();
      if (!apiData) throw new Error('Api config not found');

      let apiResponse;
      switch (apiData.method_type) {
        case 'get':
          apiResponse = await this.httpRequestService.get({
            req: reqData,
            data: apiData,
          });
          break;
        case 'delete':
          apiResponse = await this.httpRequestService.deleteFunction({
            req: reqData,
            data: apiData,
          });
          break;
        case 'post':
          apiResponse = await this.httpRequestService.post({
            req: reqData,
            data: apiData,
          });
          console.log('callBYapiname----',apiResponse);
          
          break;
        case 'put':
          apiResponse = await this.httpRequestService.put({
            req: reqData,
            data: apiData,
          });
          break;
        case 'patch':
          apiResponse = await this.httpRequestService.patch({
            req: reqData,
            data: apiData,
          });
          break;
      }

      return apiResponse;
    } catch (error) {
      throw error;
    }
  }

  modifyResponse(data, filter) {
    if (Array.isArray(data)) {
      const responseData = [];
      for (const d of data) {
        responseData.push(
          Object.keys(filter).reduce((previousValue: any, currentValue) => {
            const obj = _.get(d, filter[currentValue]);
            for (const key in config?.RENAME_KEYS[filter]) {
              if (key in obj) {
                obj[config?.RENAME_KEYS[key]] = obj[key];
                delete obj[key];
              }
            }
            return {
              ...previousValue,
              [currentValue]: obj,
            };
          }, {}),
        );
      }
      return responseData;
    } else {
      const responseData = Object.keys(filter).reduce(
        (previousValue: any, currentValue) => ({
          ...previousValue,
          [currentValue]: _.get(data, filter[currentValue]),
        }),
        {},
      );
      return responseData;
    }
  }

  hideAndRenameData(data, filter) {
    if (Array.isArray(data)) {
      const responseData = [];
      for (const d of data) {
        for (const key in config?.RENAME_KEYS[filter]) {
          if (key in d) {
            d[config?.RENAME_KEYS[filter][key]] = d[key];
            delete d[key];
          }
        }
        responseData.push(_.omit(d, config.HIDE_DATA[filter]));
      }
      return responseData;
    } else {
      for (const key in config?.RENAME_KEYS[filter]) {
        if (key in data) {
          data[config?.RENAME_KEYS[filter][key]] = data[key];
          delete data[key];
        }
      }
      return _.omit(data, config.HIDE_DATA[filter]);
    }
  }

  getUserSetting(filter: string, req) {
    return this.queryService.findOne({
      modelName: userMappingModel,
      condition: {
        user_id: req.user._id,
        identifier: filter,
        is_active: true,
      },
    });
  }

  requestLog(request) {
    const correlation_id = nanoid();
    this.queryService.create({
      modelName: requestLogModel,
      data: {
        correlation_id: request.correlation_id,
        request_url: request.baseUrl + request.url,
        method: request.method,
        request_ip: request.ip,
        request_header: request.headers,
        request_body: request.body,
        response: request.response,
      },
    });
    return correlation_id;
  }

  async getFrontendUser(endPoint: string) {
    try {
      const userDetails: any = await this.httpRequestService.getUserData(
        endPoint,
      );
      const user = userDetails?.[0] || userDetails;
      return user;
    } catch (error) {
      throw new BadRequestException(error);
    }
  }

  async getAppWithBusiness(app_id: number) {
    const endPoint = `api/v1/application?auto_id=${app_id}&child_ref=business`;
    return this.httpRequestService.getCaseData(endPoint);
  }

  async getApplication(endPoint) {
    return this.httpRequestService.getCaseData(endPoint);
  }

  async getLeadStatus(limit_status: string) {
    const endPoint = `v1/lead_status?type=${limit_status}`;
    const limitData: any = await this.httpRequestService.getMasterData(
      endPoint,
    );
    return limitData?.[0];
  }

  async getAppStatus(limit_status: string) {
    const endPoint = `v1/app_status?type=${limit_status}`;
    const limitData: any = await this.httpRequestService.getMasterData(
      endPoint,
    );
    return limitData?.[0];
  }

  async getLimitStatus(limit_status: string) {
    const endPoint = `v1/limit_status?type=${limit_status}`;
    const limitData: any = await this.httpRequestService.getMasterData(
      endPoint,
    );
    return limitData?.[0];
  }

  async getLender(url) {
    return await this.httpRequestService.getUserData(url);
  }

  async checkAppStatus(status_id: string) {
    const endPoint = `v1/app_status`;
    const masterAppStatus: any = await this.httpRequestService.getMasterData(
      endPoint,
    );
    const rejectAppStatus = _.find(masterAppStatus, ['value', 'Rejected']);
    if (status_id === rejectAppStatus.id)
      throw new Error('Action on rejected application is not allowed');
  }
}
