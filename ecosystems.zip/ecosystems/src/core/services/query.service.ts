import { Injectable } from '@nestjs/common';
import { Aggregate, Create, FindOne, Update } from '../types';

@Injectable()
export class QueryService {
  findOne({
    modelName,
    condition,
    populate = {},
    project = {},
  }: FindOne): Promise<any> {
    const query = modelName.findOne(condition, project);
    if (Object.keys(populate).length) query.populate(populate);
    return query.exec();
  }

  find({
    modelName,
    condition,
    populate = {},
    project = {},
  }: FindOne): Promise<any> {
    const query = modelName.find(condition, project);
    if (Object.keys(populate).length) query.populate(populate);
    return query.exec();
  }

  create({ modelName, data }: Create): Promise<any> {
    return modelName.create(data);
  }

  update({ modelName, data, condition, multiple }: Update): Promise<any> {
    if (multiple) {
      return modelName.updateMany(condition, data);
    }
    return modelName.updateOne(condition, data);
  }

  delete({modelName , data , multiple}): Promise<any> {
    if (multiple) {
      return modelName.deleteMany({user_id : data})
    }
    return modelName.deleteOne({_id : data})
  }

  aggregate({ modelName, pipline }: any): Promise<any> {
    return modelName.aggregate(pipline);
  }
}
