const helper = require('../../helpers/helper');
const s3 = require('../../config/s3.config.js');
const config = require('../../../config/config');
const fileValidations = require('../../config/files.config');
const DocumentLog = require('../../models/DocumentLog');
const uuidv4 = require('uuid/v4');
const fs = require('fs');
const { exec } = require("child_process");
const os = require('os');
const rimraf = require('rimraf');



module.exports = {
    /**
     * @description Generate tiff
     * 
     * @author Sujendra Kumar <sujendra.kumar@biz2credit.com>
     * 
     * @param req
     * @param res
     * 
     * @returns string
     */
    async doPdfToTiff(req, res) {
        try {
            const { buffer: data, size: file_size, originalname } = req.file;
            const file_name = originalname.replace(".pdf", "");
            const currentTime = Date.now();
            const outputDir = os.tmpdir() + "/" + currentTime;
            rimraf.sync(outputDir);
            fs.mkdirSync(outputDir);
            fs.chmodSync(outputDir, 0777);
            console.log('outputdir=', outputDir);
            let source_file_path = outputDir + "/" + currentTime + "_" + file_name + ".pdf"
            await fs.writeFileSync(source_file_path, data);
            let target_file_path = outputDir + "/" + currentTime + "_" + file_name + '.tiff';
            //convert -size 1024x1024 -density 300x300 -units PixelsPerInch -depth 6 
            exec(`convert -size 768x512 -density 150x150 -units PixelsPerInch -depth 6 ${source_file_path} ${target_file_path}`, (error, stdout, stderr) => {
                if (error) {
                    console.log(`error: ${error.message}`);
                    return helper.getErrorResponse(req, res);
                }
                if (stderr) {
                    console.log(`stderr: ${stderr}`);
                    return helper.getErrorResponse(req, res);
                }

                let buffer = fs.readFileSync(target_file_path);
                rimraf.sync(outputDir);
                //console.log(buffer);
                //return res.send(data);
                return res.json({ data: buffer.toString('base64') });
            });
        } catch (error) {
            console.log(error);
            return helper.getErrorResponse(req, res);
        }

    },


    /**
     * @description Upload tiff
     * 
     * @author Sujendra Kumar <sujendra.kumar@biz2credit.com>
     * 
     * @param req
     * @param res
     * 
     * @returns string
     */
    async doUploadTiff(req, res) {
        try {
            let tenant = req.headers['x-tenant-id']
            const s3Client = s3.getS3Client(tenant);
            const { buffer: data, size: file_size, originalname } = req.file;
            const file_name = originalname.replace(".pdf", "");
            const currentTime = Date.now();
            const outputDir = os.tmpdir() + "/" + currentTime;
            rimraf.sync(outputDir);
            fs.mkdirSync(outputDir);
            fs.chmodSync(outputDir, 0777);

            let source_file_path = outputDir + "/" + currentTime + "_" + file_name + ".pdf"
            await fs.writeFileSync(source_file_path, data);

            let target_file_path = outputDir + "/" + currentTime + "_" + file_name + '.tiff';
            exec(`convert ${source_file_path} ${target_file_path}`, (error, stdout, stderr) => {
                if (error) {
                    console.log(`error: ${error.message}`);
                    return helper.getErrorResponse(req, res);
                }
                if (stderr) {
                    console.log(`stderr: ${stderr}`);
                    return helper.getErrorResponse(req, res);
                }

                let buffer = fs.readFileSync(target_file_path);

                /**
                 * Upload file to s3 and update document log
                 */
                let originalname = file_name + '.tiff';

                const params = {
                    ...s3.uploadParams(tenant),
                    Key : config.BUCKET_BASEFOLDER ? config.BUCKET_BASEFOLDER + '/' + uuidv4() + '-' + originalname : uuidv4() + '-' + originalname,
                    Body: buffer
                }
                
                s3Client.upload(params, (err, data) => {
                    if (err) {
                        return helper.getErrorResponse(req, res);
                    } else {
                        rimraf.sync(outputDir);
                        let modelName = global[tenant]['dbModel'][DocumentLog.name];
                        let Doc = new modelName({
                            doc_key: params.Key,
                            doc_type_id: req.body.doc_type_id,
                            doc_type_key: req.body.doc_type_key,
                            is_deleted: fileValidations.is_deleted_false
                        });
                        Doc.save()
                            .then((doc) => {
                                return helper.getSuccessResponse(req, res, doc);
                            })
                            .catch((err) => {
                                return helper.getErrorResponse(req, res);
                            });
                    }
                });

            });

        } catch (error) {
            console.log(error);
            return helper.getErrorResponse(req, res);
        }

    },

};