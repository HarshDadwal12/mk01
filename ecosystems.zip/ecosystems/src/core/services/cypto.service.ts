import { Injectable } from '@nestjs/common';
import * as CryptoJS from 'crypto-js';

import { config } from 'src/config/constant.config';

@Injectable()
export class CryptoService {
  /**
   * Encrypt string on basis of the hash
   *
   * @param
   */
  encrypt = (val: string) => {
    return CryptoJS.AES.encrypt(val, config.COMMON_HASH_SALT).toString();
  };

  /**
   * Decrypt string on basis of the key provided
   *
   * @param val
   */
  decrypt = (val: string) => {
    return CryptoJS.AES.decrypt(val, config.COMMON_HASH_SALT).toString(
      CryptoJS.enc.Utf8,
    );
  };
}
