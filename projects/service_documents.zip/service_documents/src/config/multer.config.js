const multer = require('multer');

// Store files in memory until they are uploaded to S3 

function multerConfig() {
    const storage = multer.memoryStorage();
    this.upload = multer({
        storage: storage
    });
}

// let storage = multer.memoryStorage();
// let upload = multer({
//     storage: storage
// });
 
module.exports = multerConfig;