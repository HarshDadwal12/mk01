import { model, Schema } from 'mongoose';

const ApiSchema = new Schema(
  {
    name: { type: String, required: true, unique: true, indexes: true },
  },
  { strict: false, versionKey: false },
);

export default model('Api', ApiSchema, 'apis');
