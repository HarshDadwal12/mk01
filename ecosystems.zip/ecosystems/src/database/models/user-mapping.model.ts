import { model, Schema } from 'mongoose';
import { BASE_SCHEMA } from './base.model';
import { config } from 'src/config/constant.config';

const UserMappingModel = new Schema(
  {
    identifier: { type: String, enum: config.IDENTIFIER, index: true },
    user_id: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    response_keys: { type: Object },
    hook: { type: Boolean, default: false },
  },
  { versionKey: false },
).add(BASE_SCHEMA);

export default model('UserMapping', UserMappingModel, 'user-mappings');
