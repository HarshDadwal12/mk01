/** @format */

const express = require("express");
const multerConfig = require("../../config/multer.config");
const upload = new multerConfig().upload;
const { pdfValidator } = require("../../validators/filetype.validator");
const DocController = require("../../controllers/v2/docController");
const {
	singleUploadReqValidator,
	docIdValidator,
	docIdsValidator,
	docTypeIdValidator,
	dataReqValidator,
	genPdfValidator,
} = require("../../validators/request.validator");

const routes = express.Router();

// Document Service Provided Endpoints

routes.post(
	"/upload",
	upload.single("file"),
	singleUploadReqValidator,
	docTypeIdValidator,
	pdfValidator,
	DocController.doSingleUpload
);
routes.post("/data_upload", dataReqValidator, DocController.doDataUpload);

routes.get("/download/:doc_id?", docIdValidator, DocController.doDownload);
routes.get("/downloadJson/:doc_id?", docIdValidator, DocController.doDownloadJson);

routes.get("/get/:doc_id?", docIdValidator, DocController.get);
routes.post("/getByIds", docIdsValidator, DocController.getByIds);

routes.get("/view/:doc_id?", docIdValidator, DocController.viewDoc);

routes.delete("/delete/:doc_id?", docIdValidator, DocController.doDelete);

routes.post("/generatePdf", genPdfValidator, DocController.generatePdf);

routes
	.route("/document-files")
	.get(DocController.doDownloadMultiple)
	.post(DocController.doDownloadMultiple);


	routes
	.route("/download-all-json")
	.get(DocController.doDownloadZipJSON)
	.post(DocController.doDownloadZipJSON);


module.exports = routes;
