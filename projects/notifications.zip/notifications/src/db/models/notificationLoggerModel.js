'use strict';

const db = require('..');
const document_collection_name = 'notification_logs';
const conn = new db.connectionFactory(
  process.env.MONGO_DB_URL,
  document_collection_name,
  './schemas/notificationSchema'
);

module.exports = {
  find: async function (condition) {
    const Collection = conn.model(document_collection_name);
    return Collection.find(condition);
  },

  create: async function (data) {
    const Collection = conn.model(document_collection_name);
    return await Collection.create(data);
  },
};
