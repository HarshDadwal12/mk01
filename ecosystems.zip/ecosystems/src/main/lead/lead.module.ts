import { Module } from '@nestjs/common';
import { CoreModule } from 'src/core/core.module';

import { LeadController } from './lead.controller';
import { LeadService } from './lead.service';

@Module({
  imports: [CoreModule],
  controllers: [LeadController],
  providers: [LeadService],
})
export class LeadModule {}
