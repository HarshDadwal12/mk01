'use strict';

const { create } = require('../db/models/notificationLoggerModel');
const {
  getLead,
  webHook,
  getClientConfig,
  getApplication,
  getLeadById,
  getAnalysis,
  getApplicationById,
} = require('../utils/notificationUtil');
const _ = require('lodash');

module.exports.processNotification = async function (body) {
  try {
    const { event, data: payload, key } = body;
    if (event === 'lead.created') {
      for (const lead of payload) {
        const leadData = await getLead(lead.id);
        const lender_id = leadData.lender_id;
        const lender = await getClientConfig('&backend_user_ids=' + lender_id);
        // sending direct queue payload data
        await consumeHook({ event, payload: lead, userData: lender, key });
      }
    } else if (event === 'lead.status.update') {
      const leadData = await getLead(payload.id);
      const aggConfig = await getClientConfig(
        '&customer_key=' + leadData.customer_key,
      );
      // sending direct queue payload data
      await consumeHook({ event, payload, key, userData: aggConfig });
    } else if (
      [
        'application.created',
        'application.gst.created',
        'application.gst.updated',
        'application.additional.updated',
        'application.additional.created',
        'application.document.upload',
      ].includes(event)
    ) {
      const appData = await getApplication(payload.id);
      const leadData = await getLeadById(appData.user_id);
      const lender_ids = leadData.lender_id;
      const lender = await getClientConfig('&backend_user_ids=' + lender_ids);
      // sending direct queue payload data
      await consumeHook({ event, payload, userData: lender, key });
    } else if (event === 'application.approve.limit.lender') {
      const appData = await getApplication(payload.id);
      const aggregator = await getClientConfig(
        '&backend_user_ids=' + appData.backend_user_id,
      );
      // sending direct queue payload data
      await consumeHook({
        event: 'application.approve.limit',
        payload,
        userData: aggregator,
        key,
      });
    } else if (event === 'application.approve.limit.aggregator') {
      const appData = await getApplication(payload.id);
      const leadData = await getLeadById(appData.user_id);
      const lender_id = leadData.lender_id;
      const lender = await getClientConfig('&backend_user_ids=' + lender_id);
      // sending direct queue payload data
      await consumeHook({
        event: 'application.approve.limit',
        payload,
        userData: lender,
        key,
      });
    } else if (
      [
        'disbursement.request',
        'repayment.request',
        'repayment.request.reconciliation',
      ].includes(event)
    ) {
      const analysis = await getAnalysis(`auto_id=${payload.id}`);
      const appData = await getApplicationById(analysis.app_id);
      const leadData = await getLeadById(appData.user_id);
      const lender_id = leadData.lender_id;
      const lender = await getClientConfig('&backend_user_ids=' + lender_id);
      // sending direct queue payload data
      await consumeHook({ event, payload, userData: lender, key });
    } else if (
      [
        'disbursement.response',
        'disbursement.response.reconciliation',
      ].includes(event)
    ) {
      const analysisRes = await getAnalysis(`auto_id=${payload.id}`);
      const analysis = await getAnalysis(
        `disbursement_unique_id=${analysisRes.disbursement_unique_id}&type=disbursement_request`,
      );
      const appData = await getApplicationById(analysisRes.app_id);
      const agg = await getClientConfig(
        '&backend_user_ids=' + appData.backend_user_id,
      );
      // sending dusbursement request id
      await consumeHook({
        event,
        payload: { id: analysis.auto_id },
        userData: agg,
        key,
      });
    } else if (['repayment.response'].includes(event)) {
      const analysisRes = await getAnalysis(`auto_id=${payload.id}`);
      const analysis = await getAnalysis(
        `repayment_unique_id=${analysisRes.repayment_unique_id}&type=repayment_request`,
      );
      const appData = await getApplicationById(analysis.app_id);
      const agg = await getClientConfig(
        '&backend_user_ids=' + appData.backend_user_id,
      );
      // sending repayment request id
      await consumeHook({
        event,
        payload: { id: analysis.auto_id },
        userData: agg,
        key,
      });
    }
  } catch (error) {
    throw error;
  }
};

async function consumeHook({ event, payload, userData, key }) {
  const user_mapping = _.findLast(userData['user-mappings'], {
    identifier: key,
  });
  if (user_mapping) {
    const data = {
      id: payload.id,
      resource: event.split('.')[0],
      event,
    };
    const webResponse = await webHook(user_mapping, data, userData);
    await create({
      backend_user_id: userData.backend_user_id,
      data,
      response: webResponse,
      status: 'success',
    });
  }
}
