const helper = require('../helpers/helper');
const messages = require('../lang/en/messages');

// Custom HTTP Not Found Exception 

module.exports = (req, res) => {
    return helper.getErrorResponse(req, res, [messages.keys.resource_not_found], messages.codes.resource_not_found);
};