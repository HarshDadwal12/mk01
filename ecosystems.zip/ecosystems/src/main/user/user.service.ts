import { BadRequestException, Injectable } from '@nestjs/common';
import { QueryService } from 'src/core/services/query.service';
import userMappingModel from 'src/database/models/user-mapping.model';

import roleInfoModel from '../../database/models/role.model';
import userInfoModel from '../../database/models/user.model';
import { CryptoService } from 'src/core/services/cypto.service';
import { nanoid } from 'nanoid';
import { Types } from 'mongoose';
import * as _ from 'lodash';
import constant from './constants';

@Injectable()
export class UserService {
  constructor(
    private queryService: QueryService,
    private cryptoService: CryptoService,
  ) {}

  getUserMapping(user_id) {
    return this.queryService.find({
      condition: { user_id },
      modelName: userMappingModel,
    });
  }

  saveUserMapping(body , user_id ?: string) {
    if(user_id){
      const userMappingArr = [];
      body.mappings.forEach(mapping => {
        userMappingArr[userMappingArr.length] = _.assign({ user_id }, mapping);
      });
      return this.queryService.create({
        data: userMappingArr,
        modelName: userMappingModel,
      });
    }
    return this.queryService.create({
      data: body,
      modelName: userMappingModel,
    });
  }

  updateUserMapping(body, _id) {
    return this.queryService.update({
      data: body,
      modelName: userMappingModel,
      condition: { _id },
      multiple: false,
    });
  }

  async createRole(body) {
    return this.queryService.create({
      modelName: roleInfoModel,
      data: {
        user_id: new Types.ObjectId(body.user_id),
        path: body.path,
        method: body.method,
      },
    });
  }

  async updateRole(body, role_id) {
    return this.queryService.update({
      modelName: roleInfoModel,
      data: body,
      condition: { _id: role_id },
    });
  }

  async deleteRole(role_id ,multiple) {
    return this.queryService.delete({
      modelName: roleInfoModel,
      data : role_id,
      multiple : multiple
    });
  }

  getRole(user_id) {
    return this.queryService.find({
      condition: { user_id },
      modelName: roleInfoModel,
    });
  }

  createUser(body) {
    return this.queryService.create({
      modelName: userInfoModel,
      data: {
        name: body.name,
        backend_user_id: body.backend_user_id,
        user_type: body.user_type,
        address: body.address,
        username: body.username,
        password: this.cryptoService.encrypt(
          Buffer.from(body.password).toString('base64'),
        ),
        customer_key: body.customer_key,
        customer_secret: nanoid(36),
        products: body.products,
        hook_config : body.hook_config,
      },
    });
  }

  getUser(query) {
    let { expands, backend_user_ids, customer_key } = query;

    const pipline: any = [];

    if (backend_user_ids) {
      backend_user_ids = backend_user_ids.split(',');
      pipline.push({
        $match: { backend_user_id: { $in: backend_user_ids } },
      });
    }

    if (customer_key) {
      pipline.push({
        $match: { customer_key },
      });
    }

    if (expands) {
      for (let ex of expands.split(',')) {
        pipline.push({
          $lookup: {
            from: ex,
            localField: '_id',
            foreignField: 'user_id',
            as: ex,
          },
        });
      }
    }

    return this.queryService.aggregate({
      modelName: userInfoModel,
      pipline,
    });
  }

  updateUserPatch(body, _id) {
    return this.queryService.update({
      data: body,
      modelName: userInfoModel,
      condition: { _id },
    });
  }

  getRoutes(query) {
    const { type } = query;
    if (type) {
      let apis = {};
      if (type == 'lender') {
        const {
          GET_LEAD,
          GET_APPLICATION,
          UPDATE_LEAD,
          CREATE_APPROVE_LIMIT,
          CREATE_DISBURSEMENT_RESPONSE,
          CREATE_DISBURSEMENT_RESPONSE_RECONCILIATION,
          CREATE_REPAYMENT_RESPONSE,
          LEAD_SUMMARY,
          TRANSACTION_INFO,
          APPLICATION_SUMMARY,
        } = constant;
        apis = {
          GET_LEAD,
          GET_APPLICATION,
          UPDATE_LEAD,
          CREATE_APPROVE_LIMIT,
          CREATE_DISBURSEMENT_RESPONSE,
          CREATE_DISBURSEMENT_RESPONSE_RECONCILIATION,
          CREATE_REPAYMENT_RESPONSE,
          LEAD_SUMMARY,
          TRANSACTION_INFO,
          APPLICATION_SUMMARY,
        };
        return apis;
      } else if (type == 'aggregator') {
        const {
          CREATE_DISBURSEMENT_RESPONSE,
          CREATE_DISBURSEMENT_RESPONSE_RECONCILIATION,
          CREATE_REPAYMENT_RESPONSE,
          UPDATE_LEAD,
          ...additional
        } = constant;
        apis = { ...additional };
        return apis;
      }
    }
    return constant;
  }
}
