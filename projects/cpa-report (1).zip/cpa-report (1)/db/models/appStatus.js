"use strict";

// Import module for mongo-db conection
const db = require("../db");
const conn = new db.connectionFactory(
    process.env.MONGO_MASTER_DB_URL,
    "app_statuses",
    "./schemas/appStatusSchema"
);
var ObjectId = require("mongoose").Types.ObjectId;
const request_collection_name = "app_statuses";

module.exports = {
    findByStatusId: async function (status_id) {
        return new Promise(async function (resolve, reject) {
            try {
                let Collection = conn.model(request_collection_name);

                await Collection.findOne({ _id: new ObjectId(status_id) }, function (err, data) {
                    // return document data
                    if (!err) return resolve(data);
                    // return error
                    else return reject(err);
                });
            } catch (error) {
                return reject(error);
            }
        });
    },
    find: async function (json_data, project = {}) {
        return new Promise(async function (resolve, reject) {
            try {
                let Collection = conn.model(request_collection_name);

               const data =  await Collection.find(json_data, {...project});
               resolve(data);
            } catch (error) {
                return reject(error);
            }
        });
    },
};
