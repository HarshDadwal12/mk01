/** @format */
const puppeteer = require("puppeteer");

const helper = require("../helpers/helper");
const DocumentLog = require("../models/DocumentLog");
const s3 = require("../config/s3.config");
const fileValidations = require("../config/files.config");
const messages = require("../lang/en/messages");
const { pdfConfig } = require("../config/pdf.config");
const Jimp = require('jimp');
const uuidv4 = require("uuid/v4");
const axios = require("axios");
const https = require('https')

module.exports = {
	/**
	 * Upload Docs to s3 bucket and save document related data in documents
	 *
	 * @param {*} req
	 * @param {*} params
	 * @param {*} body
	 */
	async docUpload(req, params, body) {
		try {
			let tenant = req.headers["x-tenant-id"];
			const s3Client = s3.getS3Client(tenant);
			let modelName = global[tenant]["dbModel"][DocumentLog.name];

			await s3Client.upload(params).promise();

			const Doc = new modelName({
				doc_key: params.Key,
				...body,
			});

			return Doc.save();
		} catch (error) {
			throw error;
		}
	},
	/**
	 * Get the FileData From the S3 Bucket
	 * @param {*} req
	 */
	async docDownload(req, res, signed_url = false) {
		try {
			let doc_id = req.params.doc_id;
			let tenant = req.headers["x-tenant-id"];
			const s3Client = s3.getS3Client(tenant);
			let modelName = global[tenant]["dbModel"][DocumentLog.name];
			let params = await modelName.findOneDoc({_id: doc_id}, req.query.key, tenant);
			if (signed_url) {
        const preSignedUrl = await s3Client.getSignedUrl('getObject', {
          ...params,
          Expires: 60 * 15
        });
        return  { preSignedUrl }
      }
			res.attachment(params.Key);
			return s3Client.getObject(params).promise();
		} catch (error) {
			throw error;
		}
	},

	async downloadDocJson(req, modifyFileName = false) {
		try {
			const doc_id = req.params.doc_id;
			const tenant = req.headers["x-tenant-id"];
			const s3Client = s3.getS3Client(tenant);
			const modelName = global[tenant]["dbModel"][DocumentLog.name];
			const params = await modelName.findOneDoc({_id: doc_id}, req.query.key, tenant);

			if (!params) return false;

			let data = await s3Client.getObject(params).promise();
			return {
				filename: modifyFileName ? params.Key.replace(/([^\_]*\_){2}/, "") : params.Key,
				content_type: data.ContentType,
				content_length: data.ContentLength,
				accept_ranges: data.AcceptRanges,
				body: data.Body.toString("base64"),
			};
		} catch (error) {
			throw error;
		}
	},

	/**
	 * Get the doc related document by id from db
	 * @param {*} req
	 */
	getDoc(req) {
		try {
			const doc_id = req.params.doc_id;
			const tenant = req.headers["x-tenant-id"];
			const modelName = global[tenant]["dbModel"][DocumentLog.name];
			return modelName.findOne({ _id: doc_id, is_deleted: 0 });
		} catch (error) {
			throw error;
		}
	},

	getDocByIds(req) {
		try {
			const doc_ids = req.body.doc_ids;
			let tenant = req.headers["x-tenant-id"];
			let modelName = global[tenant]["dbModel"][DocumentLog.name];
			return modelName.find({ _id: { $in: doc_ids } });
		} catch (error) {
			throw error;
		}
	},

	/**
	 * View The data of File saved on the s3 bucket
	 * @param {*} req
	 * @param {*} res
	 */
	docView(req, res) {
		try {
			let doc_id = req.params.doc_id;
			let tenant = req.headers["x-tenant-id"];
			const s3Client = s3.getS3Client(tenant);
			let modelName = global[tenant]["dbModel"][DocumentLog.name];
			modelName
				.findOneDoc({_id: doc_id}, req.query.key, tenant)
				.then((params) => {
					s3Client
						.getObject(params)
						.createReadStream()
						.on("error", function (err) {
							console.log(err);
							return helper.getErrorResponse(req, res);
						})
						.pipe(res);
					helper.prepareSuccessResponse(req);
				})
				.catch((err) => {
					return helper.getErrorResponse(
						req,
						res,
						[messages.keys.resource_not_found],
						messages.codes.resource_not_found
					);
				});
		} catch (error) {
			throw error;
		}
	},
	/**
	 * Document Clone from one Application to other Application.
	 * @param {*} req
	 * @returns
	 */
	async docClone(req) {
		try {
			const doc_ids = req.body.doc_ids;
			const keySuffix = req.body.ref_id;
			const tenant = req.headers["x-tenant-id"];
			const s3Client = s3.getS3Client(tenant);

			const modelName = global[tenant]["dbModel"][DocumentLog.name];
			const docs = await modelName.find({
				_id: { $in: doc_ids },
				is_deleted: fileValidations.is_deleted_false,
			});
			const bucket = global[tenant]["envConfig"].BUCKET;
			const body = [];
			let key = "";
			for (const doc of docs) {
				key = `${keySuffix}/${keySuffix}_${doc.doc_key.replace(/([^\_]*\_){1}/, "")}`;
				// copy file from one location to other
				const copyParams = {
					Bucket: bucket,
					Key: key,
					CopySource: `${bucket}/${doc.doc_key}`,
				};
				body.push({
					doc_key: key,
					doc_type_id: doc.doc_type_id,
					doc_type_key: doc.doc_type_key,
					is_deleted: doc.is_deleted,
				});
				await s3Client.copyObject(copyParams).promise();
			}
			return await modelName.create(body)
		} catch (error) {
			throw error;
		}
	},
	/**
	 * Delete The docs from the db and move the deleted file from 1 folder to deleted folder.
	 * Or Simply soft delete the doc
	 * @param {*} req
	 * @param {*} deleteDocFlag
	 * @returns
	 */
	async docDelete(req, deleteDocFlag = false) {
		try {
			const doc_id = req.params.doc_id;
			const tenant = req.headers["x-tenant-id"];
			const modelName = global[tenant]["dbModel"][DocumentLog.name];
			const s3Client = s3.getS3Client(tenant);

			if (!deleteDocFlag) {
				return modelName.updateOne(
					{ _id: doc_id },
					{ is_deleted: fileValidations.is_deleted_true }
				);
			}

			let doc = await modelName.findOne({
				_id: doc_id,
				is_deleted: fileValidations.is_deleted_false,
			});

			if (!doc) return false;

			// copy file from one location to other
			const copyParams = s3.copyParams(tenant, messages, doc);
			await s3Client.copyObject(copyParams).promise();

			// delete file file from previous place
			await modelName.updateOne({ _id: doc_id }, { is_deleted: fileValidations.is_deleted_true });
			const deleteParams = {
				...s3.downloadParams(tenant),
				Key: doc.doc_key,
			};
			return s3Client.deleteObject(deleteParams).promise();
		} catch (error) {
			throw error;
		}
	},

	async docPdfGenerate(req, v2 = false) {
		try {
			const browser = await puppeteer.launch({ args: ["--no-sandbox"] });
			const page = await browser.newPage();
			await page.setContent(req.body.content);
			if (req.body.style) {
				await page.addStyleTag({ content: req.body.style });
			}
			let buffer;
			if (v2) {
				let margin = {
					top: "30px",
					bottom: "30px",
					left: "50px",
					right: "50px",
				};
				if (req.body.margin) {
					margin = req.body.margin;
				}

				buffer = await page.pdf({
					format: "Letter",
					margin: margin,
				});
			} else {
				if (req.body.sef_config) {
					buffer = await page.pdf(req.body.sef_config);
				} else {
					buffer = await page.pdf(pdfConfig(req));
				}
			}
			browser.close();
			return Buffer.from(buffer).toString("base64");
		} catch (error) {
			throw error;
		}
	},
	/**
	 * Upload Docs to s3 bucket only
	 *
	 * @param {*} req
	 * @param {*} params
	 * @param {*} body
	 */
	 async UploadToS3(req, params) {
		try {
			let tenant = req.headers["x-tenant-id"];
			const s3Client = s3.getS3Client(tenant);
			return await s3Client.upload(params).promise();
		} catch (error) {
			throw error;
		}
	},
	/**
	 * Save document related data in documents
	 *
	 * @param {*} req
	 * @param {*} params
	 * @param {*} body
	 */
	 async saveDoc(req, params, body) {
		try {
			let tenant = req.headers["x-tenant-id"];
			let modelName = global[tenant]["dbModel"][DocumentLog.name];

			const Doc = new modelName({
				doc_key: params.Key,
				...body,
			});
			return Doc.save();
		} catch (error) {
			throw error;
		}
	},
	async imageUpload(req, allResolutions, fileData, result = []) {

		const {fileName, fileNameExt, keySuffix, buffer} = fileData;

		async function processImage(resolutions) {
			if(!resolutions.length) {
				return result;
			}
	
			const resolution = resolutions.pop();

			const splitted = resolution.split(/[:x]/); //['small', '100', '100']

			const data = {
				size: splitted[0],
				height: splitted[1] ? +splitted[1]: Jimp.AUTO,
				width: splitted[2] ? +splitted[2]: Jimp.AUTO,
			};

			let imageName = `${uuidv4()}-${fileName}-${data.height.toString().replace('-', '')}x${data.width.toString().replace('-', '')}.${fileNameExt}`;

			data.image = keySuffix ? `${keySuffix}/${imageName}`: imageName;

			const img = await Jimp.read(buffer);

			const imgBuffer = await img.resize(data.width, data.height).getBufferAsync(Jimp.AUTO);
	
			const params = {
				...s3.uploadParams(req.headers["x-tenant-id"]),
				Key: data.image,
				Body: imgBuffer,
			};
	
			let tenant = req.headers["x-tenant-id"];
			const s3Client = s3.getS3Client(tenant);
			const uploaded = await s3Client.upload(params).promise();
	
			result.push(data);
	
		   return await processImage(resolutions);
		}

		return await processImage(allResolutions);
    },
	async downloadDocByUrl(url){
		const agent = new https.Agent({  
			rejectUnauthorized: false
		});

		return await axios.get(url, { httpsAgent: agent, responseType: 'arraybuffer' })
			.then(resp => {
				return Buffer.from(resp.data, 'binary').toString('base64')
			}).catch(error => {
				throw error
			});
	}
};
