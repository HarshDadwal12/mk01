'use strict';
const mongoose = require('mongoose');
const { post, put, get, patch } = require('../client/httpRequest');

const BulkModel = require('../db/models/bulkLoggerModel');
const fileRecord = require('../db/models/fileRecordModel');

const constant = require('./constant');
const _ = require('lodash');
const {
  formatLeadData,
  formatApplicationData,
  formatRepaymentData,
  formatDisbursementData,
} = require('./dataFormation');

const AWS = require('aws-sdk');
const { v4: uuidv4 } = require('uuid');

const sqs = new AWS.SQS({ region: 'us-east-1' });

/**
 * @description error handler
 * @author Ravi Pratap Singh <ravi.singh@biz2credit.com>
 * @param {*} error
 * @returns error response
 */

module.exports.errorHandler = function (error) {
  if (
    error instanceof TypeError ||
    error instanceof ReferenceError ||
    error instanceof SyntaxError ||
    error instanceof Error
  ) {
    return {
      statusCode: 400,
      body: JSON.stringify({
        status: 'failed',
        code: 400,
        message: error.message,
      }),
    };
  } else {
    return {
      statusCode: 503,
      body: JSON.stringify({
        status: 'failed',
        code: 503,
        message: 'Something went wrong',
      }),
    };
  }
};

/**
 * @description document log
 * @author Ravi Pratap Singh <ravi.singh@biz2credit.com>
 * @param {*} data
 * @returns Promise
 */

module.exports.bulkLog = async function (data) {
  return BulkModel.create(data);
};

/**
 * @description docs insert
 * @author Naman jain <naman.jain@biz2credit.com>
 * @param {*} data
 * @returns Promise
 */

module.exports.fileRecord = async function (data) {
  return fileRecord.create(data);
};

/**
 * @description document log
 * @author Ravi Pratap Singh <ravi.singh@biz2credit.com>
 * @returns Promise
 */

module.exports.checkDBConnection = function () {
  return new Promise(async function (resolve, reject) {
    try {
      mongoose.connect(process.env.MONGO_DB_URL, function (error) {
        if (error) {
          console.log(error);
          throw error;
        } else {
          console.log('Database connected');
          resolve('Database connected');
        }
      });
    } catch (error) {
      console.log('---1', error);
      return reject(error);
    }
  }).catch(function (error) {
    console.log('---2', error);
    throw error;
  });
};

/**
 * @description Construct Ecosystem API header
 * @author Ravi Pratap Singh <ravi.singh@biz2credit.com>
 * @param {*} backend_user_id
 * @returns Object
 */
module.exports.getEcoApiConfig = function (backend_user_id = '') {
  const headers = { version: '1.0', 'access-key': constant.ACCESS_KEY };
  if (backend_user_id) {
    headers['internal'] = true;
    headers['backend-user-id'] = backend_user_id;
  }

  return { headers };
};

/**
 * @description Construct API data , URL and identifier
 * @author Ravi Pratap Singh <ravi.singh@biz2credit.com>
 * @param {*} type
 * @param {*} data
 * @returns Object
 */

module.exports.formatDataAndUrl = function (type, data, staticData = {}) {
  let formatedData;
  switch (type) {
    case 'lead':
      formatedData = formatLeadData(data, staticData);
      break;
    case 'application':
      formatedData = formatApplicationData(data);
      break;
    case 'disbursement':
      formatedData = formatDisbursementData(data);
      break;
    case 'repayment':
      formatedData = formatRepaymentData(data);
      break;
  }

  return { formatedData };
};

module.exports.updatedRecordInUserMapping = async (body, data) => {
  try {
    let url = `${constant.ORCH_API}/v2/tasks?slug=update_bulk_upload_history&type=doc&internal=true`;
    const { doc_id, totalSuccess, total, totalFail } = data;
    let uploadHistory = {
      doc_id,
      totalSuccess,
      total,
      totalFail,
      user_mapping_id: body.user_mapping_id,
    };
    return await post({
      url,
      data: uploadHistory,
    });
  } catch (error) {
    throw error;
  }
};

const formatPayload = (data) => {
  delete data.url;
  delete data.identifier;
  delete data.stage;
  return data;
};

module.exports.pushInQueue = async (queueData, i, totalSuccess, totalFail) => {
  const params = {
    QueueUrl: constant.QUEUE_BULK_UPLOAD_URL,
    MessageBody: JSON.stringify({
      ...queueData,
      start: i,
      totalSuccess,
      totalFail,
    }),
    MessageGroupId: uuidv4(),
  };
  const data = await sqs.sendMessage(params).promise();
  console.log('SQS MessageId ----> ', data.MessageId, params);
  return data;
};

const appInvalidStage = async (stage, sqsData) => {
  try {
    throw new Error('invalid stage.');
  } catch (error) {
    console.log('================>Application', error);
    const errorData = {
      ...sqsData,
      body: { stage },
      response: { error, message: error.message },
      type: sqsData.type,
      status: 'failed',
    };
    await BulkModel.create(errorData).catch(console.log);
    throw error;
  }
};

const appCreate = async (
  url,
  config,
  excelData,
  upload_type,
  sqsData,
  stage,
  identifier,
) => {
  try {
    let lead_id = excelData.application.lead_id;
    if (!lead_id) throw new Error('Invalid lead id.');
    let lead_url = `${constant.USER_API}/api/v1/users?record_id=${excelData.application.lead_id}`;
    const leadlist = await get({ url: lead_url });
    if (_.isEmpty(leadlist)) throw new Error('Invalid lead id.');
    let lead_appl_url = `${constant.CASE_API}/api/v1/application?user_id=${leadlist[0].id}`;
    const applist = await get({ url: lead_appl_url, config });
    if (!applist.length && upload_type === constant.STAGE_APPLICATION.UPDATE)
      throw new Error(
        'Application does not exist, please send application as new in update_type',
      );

    if (applist.length && upload_type === constant.STAGE_APPLICATION.NEW)
      throw new Error(
        'Application already exists, please send application as update in update_type',
      );
    if (upload_type === constant.STAGE_APPLICATION.NEW) {
      const application = {
        ...excelData.application,
        owners: excelData.owners,
      };
      const appData = await post({ url, data: application, config });
      if (excelData.gst) {
        const gst = { application_id: appData.id, ...excelData.gst };
        await post({
          url: constant.ECOSYSTEM_API + constant.CREATE_GST,
          data: gst,
          config,
        });
      }
      if (excelData.additional) {
        const additional = {
          application_id: appData.id,
          ...excelData.additional,
        };
        return await post({
          url: constant.ECOSYSTEM_API + constant.CREATE_ADDITIONAL,
          data: additional,
          config,
        });
      }
      return appData;
    } else if (upload_type === constant.STAGE_APPLICATION.UPDATE) {
      let auto_id = applist[0].auto_id;
      let app_url = `${constant.CASE_API}/api/v1/application?auto_id=${auto_id}&expands=analysis`;
      const app_data = await get({ url: app_url });
      let gst_update_flag = false,
        add_update_flag = false;
      for (let _ of app_data[0].analysis) {
        if (_.type == 'application_gst') gst_update_flag = true;
        if (_.type == 'application_addition') add_update_flag = true;
      }
      if (Object.keys(excelData.application).length > 1) {
        delete excelData.application.lead_id;
        const application = {
          ...excelData.application,
          application_id: auto_id,
        };
        await patch({
          url: constant.ECOSYSTEM_API + constant.CREATE_APPLICATION,
          data: application,
          config,
        });
      }
      if (excelData.owners.length) {
        const owners = {
          application_id: auto_id,
          owners: excelData.owners,
        };
        await patch({
          url: constant.ECOSYSTEM_API + constant.CREATE_APPLICATION,
          data: owners,
          config,
        });
      }

      if (excelData.gst) {
        let gst = { ...excelData.gst, application_id: auto_id };
        if (gst_update_flag)
          await patch({
            url: constant.ECOSYSTEM_API + constant.CREATE_GST,
            data: gst,
            config,
          });
        else {
          await post({
            url: constant.ECOSYSTEM_API + constant.CREATE_GST,
            data: gst,
            config,
          });
        }
      }

      if (excelData.additional) {
        let additional = { ...excelData.additional, application_id: auto_id };
        if (add_update_flag)
          await patch({
            url: constant.ECOSYSTEM_API + constant.CREATE_ADDITIONAL,
            data: additional,
            config,
          });
        else {
          await post({
            url: constant.ECOSYSTEM_API + constant.CREATE_ADDITIONAL,
            data: additional,
            config,
          });
        }
      }
    } else {
      throw new Error('Invalid Upload type.');
    }
    return { lead_id };
  } catch (error) {
    console.log('================>Application', error);
    const errorData = {
      ...sqsData,
      body: { ...excelData, stage },
      identifier: excelData[identifier],
      response: { error, message: error.message },
      type: sqsData.type,
      status: 'failed',
    };
    await BulkModel.create(errorData).catch(console.log);
    throw error;
  }
};

const appApprove = async (
  excelData,
  url,
  config,
  sqsData,
  stage,
  identifier,
) => {
  let res;
  try {
    res = await post({
      url,
      data: excelData,
      config,
    });
    return res;
  } catch (error) {
    console.log('================>Application', error);
    const errorData = {
      ...sqsData,
      body: { ...excelData, stage },
      identifier: excelData[identifier],
      response: { error, message: error.message },
      type: sqsData.type,
      status: 'failed',
    };
    await BulkModel.create(errorData).catch(console.log);
    throw error;
  }
};

/**
 *
 * @param {*} excelData
 * @param {*} sqsData
 * @returns Boolen
 */
module.exports.checkOppurtunityId = async function ({
  data,
  body,
  identifier,
}) {
  if (data.product_opportunity_id != body.product_id) {
    let stage = data.stage,
      message;
    if (stage == constant.STAGE_LEAD.LEAD_STATUS) {
      identifier = data[identifier];
    }
    if (
      stage != constant.STAGE_LEAD.LEAD_CREATE &&
      stage != constant.STAGE_LEAD.LEAD_STATUS
    ) {
      message = {
        message: 'Invalid Stage.',
      };
    } else {
      message = {
        message: 'Product Opportunity Id  is different from portfolio.',
      };
    }
    data = formatPayload(data);
    const errorData = {
      ...body,
      body: { ...data, stage, identifier },
      identifier,
      response: message,
      type: body.type,
      status: 'failed',
    };
    await BulkModel.create(errorData);
    return false;
  }
  return true;
};

/**
 *
 * @param {*} param0
 * @returns
 */
module.exports.processLeadStage = async function ({
  excelData,
  sqsData,
  config,
  url,
  identifier,
}) {
  let stage = excelData.stage,
    res;
  try {
    identity = 'identifier';
    let idenValue = excelData.identifier;
    excelData = formatPayload(excelData);
    if (stage == constant.STAGE_LEAD.LEAD_STATUS) {
      identity = identifier;
      res = await put({
        url: `${url}/${excelData.lead_id}`,
        data: excelData,
        config,
      });
      return res;
    } else if (stage == constant.STAGE_LEAD.LEAD_CREATE) {
      excelData['identifier'] = idenValue;
      res = await post({ url, data: excelData, config });
      return res;
    }
  } catch (error) {
    console.log('================>', error);
    const errorData = {
      ...sqsData,
      body: { ...excelData, stage },
      identifier: excelData[identity],
      response: error,
      type: sqsData.type,
      status: 'failed',
    };
    await BulkModel.create(errorData);
    throw error;
  }
};

/**
 *
 * @param {*} param0
 */
module.exports.applicationCreate = async function ({
  excelData,
  sqsData,
  config,
  url,
  identifier,
}) {
  let res;
  try {
    identity = identifier;
    let stage = excelData.stage;
    let upload_type = excelData.upload_type;
    delete excelData.upload_type;
    excelData = formatPayload(excelData);
    let approve_stages = [
      constant.STAGE_APPLICATION.APPROVE_LIMIT,
      constant.STAGE_APPLICATION.APPROVE_LIMIT_RESPONSE,
      constant.STAGE_APPLICATION.SANCTIONED_LIMIT,
    ];
    if (stage === constant.STAGE_APPLICATION.CREATE) {
      excelData['lead_id'] = excelData.application.lead_id;
      res = await appCreate(
        url,
        config,
        excelData,
        upload_type,
        sqsData,
        stage,
        identifier,
      );
      return res;
    } else if (approve_stages.includes(stage)) {
      res = await appApprove(
        excelData,
        url,
        config,
        sqsData,
        stage,
        identifier,
      );
      return res;
    } else {
      res = await appInvalidStage(stage, sqsData);
      return res;
    }
  } catch (error) {
    throw error;
  }
};

/**
 *
 * @param {*} param0
 */

module.exports.commonUpload = async function ({
  excelData,
  sqsData,
  config,
  url,
  identifier,
}) {
  let stage = excelData.stage;
  let res;
  try {
    let stages = [
      constant.STAGE_DISBURSEMENT.DISBURSEMENT_REQUEST,
      constant.STAGE_DISBURSEMENT.DISBURSEMENT_RESPONSE,
      constant.STAGE_DISBURSEMENT.REQUEST_RECONCILIATION,
      constant.STAGE_DISBURSEMENT.RESPONSE_RECONCILIATION,
      constant.STAGE_REPAYMENT.REPAYMENT_REQUEST,
      constant.STAGE_REPAYMENT.REPAYMENT_RESPONSE,
    ];
    if (stages.includes(stage)) {
      identity = identifier;
      excelData = formatPayload(excelData);
      res = await post({ url, data: excelData, config });
      return res;
    } else {
      throw new Error('Invalid Stage.');
    }
  } catch (error) {
    console.log('================>', error);
    const errorData = {
      ...sqsData,
      body: { ...excelData, stage },
      identifier: excelData[identifier],
      response: { error, message: error.message },
      type: sqsData.type,
      status: 'failed',
    };
    await BulkModel.create(errorData);
    throw error;
  }
};
