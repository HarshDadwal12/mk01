import { SQSClient } from '@aws-sdk/client-sqs';
import { Injectable } from '@nestjs/common';
import { config } from 'src/config/constant.config';

@Injectable()
export class Queue {
  client?: SQSClient;
  constructor() {
    this.client = new SQSClient({
      credentials: {
        accessKeyId: config.AWS_ACCESS_KEY,
        secretAccessKey: config.AWS_SECRET_ACCESS_KEY,
      },
      region: config.AWS_REGION,
    });
  }
}
