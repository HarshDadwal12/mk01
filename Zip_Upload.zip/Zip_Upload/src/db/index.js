'use strict';

const mongoose = require('mongoose');

exports.connectionFactory = function (db_url, model_name, schema_path) {
  console.log(db_url);

  const conn = mongoose.createConnection(db_url, {
    useUnifiedTopology: true,
    useNewUrlParser: true,
    maxIdleTimeMS: 270000,
    minPoolSize: 2,
    maxPoolSize: 4,
  });
  conn.model(model_name, require(schema_path));
  return conn;
};
