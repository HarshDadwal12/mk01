import { Module } from '@nestjs/common';
import { AppRoutingModule } from './app-routing.module';
import { CoreModule } from './core/core.module';
import { DatabaseModule } from './database/database.module';
import { AuthModule } from './main/auth/auth.module';
import { LeadModule } from './main/lead/lead.module';
import { UserModule } from './main/user/user.module';
import { ApplicationModule } from './main/application/application.module';
import { RepaymentModule } from './main/repayment/repayment.module';
import { TestNotificationsModule } from './main/test_notifications/test_notifications.module';

@Module({
  imports: [
    DatabaseModule,
    CoreModule,
    AuthModule,
    LeadModule,
    AppRoutingModule,
    ApplicationModule,
    RepaymentModule,
    UserModule,
    TestNotificationsModule
  ],
  controllers: [],
  providers: [],
})
export class AppModule {}
