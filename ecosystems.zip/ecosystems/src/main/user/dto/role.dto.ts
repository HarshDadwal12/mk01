import { ApiProperty } from '@nestjs/swagger';
import {
  IsNotEmpty,
  IsString,
  ArrayNotEmpty,
  ArrayMinSize,
  IsOptional,
  ValidateNested,
  IsArray
} from 'class-validator';

import { Type } from 'class-transformer';

class RoleDto {
  @IsNotEmpty()
  @IsString()
  @ApiProperty()
  user_id: string;

  @IsNotEmpty()
  @IsString()
  @ApiProperty()
  path: string;

  @ArrayNotEmpty()
  @ArrayMinSize(1)
  @ApiProperty({ type: [String] })
  method: string[];
}

export class UserRoleDto{
  @IsNotEmpty()
  @IsArray()
  @ArrayNotEmpty()
  @ArrayMinSize(1)
  @ValidateNested({ each: true })
  @Type(() => RoleDto)
  @ApiProperty()
  roles: RoleDto[];
}

export class RoleDtoUpdate {
  @IsOptional()
  @IsString()
  @ApiProperty()
  user_id: string;

  @IsOptional()
  @IsString()
  @ApiProperty()
  path: string;

  @IsOptional()
  @ArrayMinSize(1)
  @ApiProperty({ type: [String] })
  method: string[];
}
