const helper = require("../../helpers/helper");
const s3 = require("../../config/s3.config.js");
const fileValidations = require("../../config/files.config");
const messages = require("../../lang/en/messages");
const DocumentLog = require("../../models/DocumentLog");
const FileLog = require("../../models/FileLog");
const uuidv4 = require("uuid/v4");
const fs = require("fs");
const puppeteer = require("puppeteer");
const config = require("../../../config/config");
const docUtils = require("../../utils/docUtils.js");

const { pdfConfig } = require("../../config/pdf.config");

module.exports = {
	/**
	 * @description Upload single file on s3 bucket
	 *
	 * @author Tanuj Chawla <tanuj.chawla@biz2credit.com>
	 *
	 * @param req
	 * @param res
	 *
	 * @returns string
	 */
	async doSingleUpload(req, res) {
		try {
			const { doc_type_id, doc_type_key, updated_file_name } = req.body;
			const keySuffix = req.body.base_folder
				? req.body.base_folder
				: config.BUCKET_BASEFOLDER
				? config.BUCKET_BASEFOLDER
				: null;
			const params = {
				...s3.uploadParams(req.headers["x-tenant-id"]),
				Key: keySuffix
					? keySuffix + "/" + uuidv4() + "-" + req.file.originalname
					: uuidv4() + "-" + req.file.originalname,
				Body: req.file.buffer,
			};
			let body = {
				doc_type_id,
				doc_type_key,
				updated_file_name,
				is_deleted: fileValidations.is_deleted_false,
			};

			let doc = await docUtils.docUpload(req, params, body);
			return helper.getSuccessResponse(req, res, doc);
		} catch (err) {
			console.log("error:::", err);
			return helper.getErrorResponse(req, res);
		}
	},

	/**
	 * @description Upload single file from base64 on s3 bucket
	 *
	 * @author Tanuj Chawla <tanuj.chawla@biz2credit.com>
	 *
	 * @param req
	 * @param res
	 *
	 * @returns string
	 */
	async doDataUpload(req, res) {
		try {
			let data = req.body.data;
			let doc_type_id = req.body.doc_type_id;
			const doc_type_key = req.body.doc_type_key || "offer_doc";
			let filename = req.body.filename;
			let updated_file_name = req.body.updated_file_name;
			let app_id = req.body.app_id;
			let buffer = Buffer.from(data, "base64");
			let fileKey;
			if (app_id) {
				fileKey = config.BUCKET_BASEFOLDER
					? `${config.BUCKET_BASEFOLDER}/${app_id}/${uuidv4()}-${filename}`
					: `${app_id}/${uuidv4()}-${filename}`;
			} else {
				fileKey = config.BUCKET_BASEFOLDER
					? `${config.BUCKET_BASEFOLDER}/${uuidv4()}-${filename}`
					: `${uuidv4()}-${filename}`;
			}

			const params = {
				...s3.uploadParams(req.headers["x-tenant-id"]),
				Key: fileKey,
				Body: buffer,
			};
			let body = {
				doc_type_id,
				doc_type_key,
				updated_file_name,
				is_deleted: fileValidations.is_deleted_false,
			};
			let doc = await docUtils.docUpload(req, params, body);
			return helper.getSuccessResponse(req, res, doc);
		} catch (err) {
			console.log(err);
			return helper.getErrorResponse(req, res);
		}
	},

	/**
	 * @description Download File from s3 bucket
	 *
	 * @author Tanuj Chawla <tanuj.chawla@biz2credit.com>
	 *
	 * @param req
	 * @param res
	 *
	 * @returns string
	 */
	async doDownload(req, res) {
		try {
			let data = await docUtils.docDownload(req, res);
			res.send(data.Body);
			return helper.prepareSuccessResponse(req);
		} catch (err) {
			console.log("error:::", err);
			return helper.getErrorResponse(req, res);
		}
	},

	/**
	 * @description Download File as JSON from s3 bucket
	 *
	 * @author Sujendra Kumar <sujendra.kumar@biz2credit.com>
	 *
	 * @param req
	 * @param res
	 *
	 * @returns string
	 */
	async doDownloadJson(req, res) {
		try {
			const data = await docUtils.downloadDocJson(req);
			if (!data) {
				return helper.getErrorResponse(
					req,
					res,
					[messages.keys.resource_not_found],
					messages.codes.resource_not_found
				);
			}
			return helper.sendSuccessResponse(req, res, data);
		} catch (err) {
			console.log("error:::", err);
			return helper.getErrorResponse(req, res);
		}
	},

	/**
	 * @description View file in browser from s3 bucket
	 *
	 * @author Tanuj Chawla <tanuj.chawla@biz2credit.com>
	 *
	 * @param req
	 * @param res
	 *
	 * @returns string
	 */
	viewDoc(req, res) {
		try {
			return docUtils.docView(req, res);
		} catch (err) {
			return helper.getErrorResponse(req, res);
		}
	},

	/**
	 * @description Delete a file on s3 bucket
	 *
	 * @author Tanuj Chawla <tanuj.chawla@biz2credit.com>
	 *
	 * @param req
	 * @param res
	 *
	 * @returns string
	 */
	async doDelete(req, res) {
		try {
			const result = await docUtils.docDelete(req);

			if (!result) {
				return helper.getErrorResponse(
					req,
					res,
					[messages.keys.resource_not_found],
					messages.codes.resource_not_found
				);
			}

			return helper.getSuccessResponse(req, res);
		} catch (err) {
			console.log("error:::", err);
			return helper.getErrorResponse(req, res);
		}
	},

	/**
	 * @description Get record info by doc_id
	 *
	 * @author Tanuj Chawla <tanuj.chawla@biz2credit.com>
	 *
	 * @param req
	 * @param res
	 *
	 * @returns string
	 */
	async get(req, res) {
		try {
			const doc = await docUtils.getDoc(req);
			if (!doc) return helper.getSuccessResponse(req, res, []);
			return helper.getSuccessResponse(req, res, doc);
		} catch (err) {
			return helper.getErrorResponse(req, res);
		}
	},
	/**
	 * @description Generate Pdf and return base64
	 *
	 * @author Tanuj Chawla <tanuj.chawla@biz2credit.com>
	 *
	 * @param {*} req
	 * @param {*} res
	 *
	 * @returns string
	 */
	async generatePdf(req, res) {
		try {
			let data = await docUtils.docPdfGenerate(req);
			return helper.sendSuccessResponse(req, res, data);
		} catch (err) {
			console.log("error:::", err);
			return helper.getErrorResponse(req, res);
		}
	},

	/**
	 * @description Get multiple record by doc_ids
	 * @author Sujendra Kumar <sujendra.kumar@biz2credit.com>
	 * @param req
	 * @param res
	 * @returns string
	 */
	async getByIds(req, res) {
		try {
			let doc_ids = req.body.doc_ids;
			if (!Array.isArray(doc_ids) && !doc_ids.length) {
				return helper.getErrorResponse(req, res);
			}
			const doc = await docUtils.getDocByIds(req);
			if (!doc) {
				return helper.getSuccessResponse(req, res, []);
			}
			return helper.getSuccessResponse(req, res, doc);
		} catch (err) {
			console.log("error:::", err);
			return helper.getErrorResponse(req, res);
		}
	},

	/**
	 * @description Get pre signed url for file upload
	 *
	 * @author Tanuj Chawla <tanuj.chawla@biz2credit.com>
	 *
	 * @param {*} req
	 * @param {*} res
	 *
	 * @returns string
	 */
	getPreSignedUrl(req, res) {
		try {
			let tenant = req.headers["x-tenant-id"];
			const timeout = req.body.timeout ? 60 * Number(req.body.timeout) : 60 * 5;

			const keySuffix = req.body.base_folder
				? req.body.base_folder
				: config.BUCKET_BASEFOLDER
				? config.BUCKET_BASEFOLDER
				: null;

			const key = keySuffix
				? keySuffix + "/" + uuidv4() + "-" + req.body.filename
				: uuidv4() + "-" + req.body.filename;

			const s3Client = s3.getS3Client(tenant);

			const params = {
				...s3.downloadParams(tenant),
				Key: key,
				ContentType: "application/octet-stream",
				Expires: timeout,
			};

			const signedURL = s3Client.getSignedUrl("putObject", params);

			const doc = {
				signed_url: signedURL,
				doc_key: key,
			};

			return helper.getSuccessResponse(req, res, doc);
		} catch (err) {
			console.log("error:::", err);
			return helper.getErrorResponse(req, res);
		}
	},

	/**
	 * @description Save Document Refs
	 *
	 * @author Tanuj Chawla <tanuj.chawla@biz2credit.com>
	 *
	 * @param {*} req
	 * @param {*} res
	 *
	 * @returns string
	 */
	saveDocRef(req, res) {
		try {
			let doc_refs = req.body.doc_refs;

			doc_refs.forEach((ref) => {
				ref.is_deleted = fileValidations.is_deleted_false;
			});

			let tenant = req.headers["x-tenant-id"];
			let modelName = global[tenant]["dbModel"][DocumentLog.name];

			modelName
				.insertMany(doc_refs)
				.then((docs) => {
					if (!docs) {
						return helper.getErrorResponse(req, res);
					}
					return helper.getSuccessResponse(req, res, docs);
				})
				.catch((err) => {
					console.log("error:::", err);
					return helper.getErrorResponse(req, res);
				});
		} catch (err) {
			console.log("error:::", err);
			return helper.getErrorResponse(req, res);
		}
	},
	/**
	 * @description update document Name
	 *
	 * @author Amit Kishore <amit.kishore@biz2credit.com>
	 *
	 * @param req
	 * @param res
	 *
	 * @returns string
	 */
	updateDocName(req, res) {
		try {
			const doc_id = req.params.doc_id;
			const { updated_file_name } = req.body;
			let tenant = req.headers["x-tenant-id"];
			let modelName = global[tenant]["dbModel"][DocumentLog.name];
			modelName
				.findByIdAndUpdate(doc_id, { updated_file_name: updated_file_name })
				.then((doc) => {
					if (!doc) {
						return helper.getErrorResponse(
							req,
							res,
							[messages.keys.resource_not_found],
							messages.codes.resource_not_found
						);
					}
					return helper.getSuccessResponse(req, res);
				})
				.catch((err) => {
					console.log("error:::", err);
					return helper.getErrorResponse(req, res);
				});
		} catch (err) {
			console.log("error:::", err);
			return helper.getErrorResponse(req, res);
		}
	},
	/**
	 * @description Get document signed url
	 *
	 * @author Ravi Pratap Singh <ravi.singh@biz2credit.com>
	 *
	 * @param req
	 * @param res
	 *
	 * @returns string
	 */
	getSignedUrl(req, res) {
		try {
			const doc_id = req.params.doc_id;
			const tenant = req.headers["x-tenant-id"];
			const s3Client = s3.getS3Client(tenant);
			const modelName = global[tenant]["dbModel"][DocumentLog.name];

			modelName
				.findDoc(doc_id, tenant)
				.then((params) => {
					const preSignedUrl = s3Client.getSignedUrl("getObject", {
						...params,
						Expires: 60 * 15,
					});

					return helper.getSuccessResponse(req, res, {
						signed_url: preSignedUrl,
						doc_key: params.Key,
					});
				})
				.catch((err) => {
					return helper.getErrorResponse(
						req,
						res,
						[messages.keys.resource_not_found],
						messages.codes.resource_not_found
					);
				});
		} catch (err) {
			console.log("error:::", err);
			return helper.getErrorResponse(req, res);
		}
	},
	async pdfByUrl(req, res) {
		try {
			const tenant = req.headers["x-tenant-id"];
			const {
				doc_type_id,
				filename,
				pdf_url,
				identifier,
				doc_type_key,
				tag_name,
				html_content,
				instant,
			} = req.body;
			const pdfModelName = global[tenant]["dbModel"][FileLog.name];

			if (instant) {
				helper.sendSuccessResponse(req, res);
			}

			if (identifier && instant) {
				await pdfModelName.updateOne({ identifier }, { status: "processing" }, { upsert: true });
			}
			const browser = await puppeteer.launch({
				args: ["--no-sandbox"],
				waitUntil: "load",
				timeout: 0,
			});
			const page = await browser.newPage();
			await page.goto(pdf_url);
			let data;
			if (tag_name) {
				await page.waitForSelector(tag_name, {
					visible: true,
					timeout: 0,
				});
				if (html_content == "base64") {
					data = await page.$eval(tag_name, (t) => t.textContent);
				} else {
					let htmlContent = await page.$eval(tag_name, (t) => t.innerHTML);
					await page.setContent(htmlContent);
					data = await page.pdf();
				}
			} else {
				data = await page.pdf();
			}
			await browser.close();

			if (data == "ERROR") {				
				if (identifier && instant) {
					return await pdfModelName.replaceOne({ identifier }, {identifier, status: "failed" });
				}else{
					return helper.getErrorResponse(
						req,
						res,
						[messages.keys.pdf_not_found],
						messages.codes.bad_request
					);
				}
			
			}

			const s3Client = s3.getS3Client(tenant);
			const buffer = Buffer.from(data, "base64");
			const params = {
				...s3.uploadParams(tenant),
				Key: config.BUCKET_BASEFOLDER
					? `${config.BUCKET_BASEFOLDER}/${uuidv4()}-${filename}`
					: `${uuidv4()}-${filename}`,
				Body: buffer,
			};

			await s3Client.upload(params).promise();
			const modelName = global[tenant]["dbModel"][DocumentLog.name];

			const doc = await modelName.create({
				doc_key: params.Key,
				doc_type_id: doc_type_id,
				doc_type_key: doc_type_key,
				is_deleted: fileValidations.is_deleted_false,
			});

			if (identifier && instant) {
				await pdfModelName.updateOne({ identifier }, { status: "completed", document_id: doc._id });
			}

			if (!instant) {
				helper.sendSuccessResponse(req, res, doc);
			}
			return;
		} catch (error) {
			console.log("error:::", error);
			return helper.getErrorResponse(req, res);
		}
	},
	async getFileStatus(req, res) {
		try {
			const tenant = req.headers["x-tenant-id"];
			const identifier = req.params.identifier;
			const fileModelName = global[tenant]["dbModel"][FileLog.name];
			let docData = await fileModelName.findOne({ identifier }).populate("document_id");
			let doc = {};
			if (docData) {
				if (docData.document_id) {
					doc = {
						[messages.doc_id]: docData.document_id[messages.mongo_id],
						[messages.filename]: docData.document_id.doc_key.replace(/([^\-]*\-){5}/, ""),
						[messages.doc_key]: docData.document_id.doc_key,
						[messages.doc_type_key]: docData.document_id[messages.doc_type_key],
						[messages.created_at]: docData.document_id[messages.createdAt],
						[messages.updated_at]: docData.document_id[messages.updatedAt],
					};
				}
				doc[messages.status] = docData[messages.status];
			}

			return helper.sendSuccessResponse(req, res, doc);
		} catch (error) {
			console.log("error:::", error);
			return helper.getErrorResponse(req, res);
		}
	},
	async updateFileStatus(req, res) {
		try {
			const tenant = req.headers["x-tenant-id"];
			const identifier = req.params.identifier;
			const body = req.body;
			const fileModelName = global[tenant]["dbModel"][FileLog.name];

			await fileModelName.updateOne({ identifier }, { $set: body }, { upsert: true });
			return helper.sendSuccessResponse(req, res);
		} catch (error) {
			console.log("error:::", error);
			return helper.getErrorResponse(req, res);
		}
	},
	async cloneDocument(req, res){
		try {
			const docs = await docUtils.docClone(req);
			return helper.getSuccessResponse(req, res, docs, 200, true);
		} catch (error) {
			console.log("error:::", error);
			return helper.getErrorResponse(req, res);
		}
	},
	async downloadDocByUrl(req, res) {
		try {
			const { url } = req.query;
			if(!url){
				return helper.getErrorResponse(
					req,
					res,
					[messages.keys.resource_not_found],
					messages.codes.resource_not_found
				);
			}

			const resp = await docUtils.downloadDocByUrl(url);
			if (!resp) {
				return helper.getErrorResponse(
					req,
					res,
					[messages.keys.resource_not_found],
					messages.codes.resource_not_found
				);
			}
			return helper.sendSuccessResponse(req, res, resp);
		} catch (err) {
			console.log("errr:::", err);
			return helper.getErrorResponse(req, res);
		}
	}
};
