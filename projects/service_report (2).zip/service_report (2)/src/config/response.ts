/** @format */

const RESPONSE = {
	SUCCESS_CREATE: {
		STATUS: 201,
		STATUS_TEXT: 'created',
		MESSAGE: 'Successfully Created.',
	},
	SUCCESS: {
		STATUS: 200,
		STATUS_TEXT: 'success',
		MESSAGE: 'Successfully.',
	},
	SUCCESS_DELETE: {
		STATUS: 200,
		STATUS_TEXT: 'success',
		MESSAGE: 'Successfully Deleted.',
	},
	INVALID: {
		STATUS: 400,
		TYPE: 'FIELD_INVALID',
		MESSAGE: 'The value of the field is invalid.',
	},
	REQUIRED: {
		STATUS: 400,
		TYPE: 'FIELD_REQUIRED',
		MESSAGE: 'This action requires the field to be specified',
	},
	RESOURCE_NOT_FOUND: {
		STATUS: 404,
		TYPE: 'RESOURCE_NOT_FOUND',
		MESSAGE: 'Resource does not exist or has been removed',
	},
	BAD_REQUEST: {
		STATUS: 400,
		TYPE: 'BAD_REQUEST',
		MESSAGE: ' The resource you tried config is not available in master.',
	},
	DEFAULT_ERROR: {
		STATUS_TEXT: 'failed',
		STATUS: 400,
		MESSAGE: 'Something went wrong. Please try again.',
	},
	CONSENT_PENDING: {
		STATUS: 400,
		TYPE: 'CONSENT_PENDING',
		MESSAGE: 'The resource has not yet received the required action.',
	},
	TOO_MANY_REQUEST: {
		STATUS: 429,
		TYPE: 'TOO_MANY_REQUEST',
		MESSAGE: 'The rate limit for this action was reached.',
	},
	TOKEN_EXPIRED: {
		STATUS: 401,
		TYPE: 'TOKEN_EXPIRED',
		MESSAGE: 'The token provided has been expired.',
	},
	FIELD_DUPLICATE: {
		STATUS: 400,
		TYPE: 'BAD_REQUEST',
		MESSAGE: 'duplicate owner email error',
	},
};

export default RESPONSE;
