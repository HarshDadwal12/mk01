'use strict';

const { get } = require('../client/httpRequest');
const constant = require('./constant');
const {
  getEcoApiConfig,
  bulkLog,
  checkOppurtunityId,
  applicationCreate,
  commonUpload,
  processLeadStage,
  updatedRecordInUserMapping,
  pushInQueue,
} = require('./helper');
const { find, deleteFileRecords } = require('../db/models/fileRecordModel');

/**
 * @description get file to document service
 * @author Ravi Pratap Singh <ravi.singh@biz2credit.com>
 * @param {*} doc_id
 * @returns promise
 */
module.exports.getDocument = function (doc_id) {
  const url = constant.DOCUMENT_API + constant.GET_DOCUMENT + doc_id;
  return get({ url });
};

/**
 * @description Create Lead
 * @author Ravi Pratap Singh <ravi.singh@biz2credit.com>
 * @param {*} body
 * @param {*} { data }
 * @returns promise
 */

module.exports.createData = async function (body) {
  let {
    type,
    start = 0,
    totalSuccess = 0,
    totalFail = 0,
    totalRecords = 0,
    doc_id,
  } = body;
  let doc = await find({ doc_id, start });
  let payload = doc ? doc.data : [];
  let config, i;
  for (i = 0; i < payload.length; i++) {
    let data = payload[i];
    if (data) {
      global.identity = {};
      let stage = data.stage;
      let response;
      config = getEcoApiConfig(
        body[constant.USER_ID_CONFIG_MAPPING[type][data.stage]],
      );
      if (type == 'lead') {
        const isOppurtunityValid = await checkOppurtunityId({
          data,
          body,
          identifier: data.identifier,
        });
        if (!isOppurtunityValid) {
          totalFail += 1;
          continue;
        }
        response = await processLeadStage({
          excelData: data,
          sqsData: body,
          config,
          url: data.url,
          identifier: data.identifier,
        }).catch(() => {
          totalFail += 1;
        });
      } else if (type == 'application') {
        response = await applicationCreate({
          excelData: data,
          sqsData: body,
          config,
          url: data.url,
          identifier: data.identifier,
        }).catch(() => {
          totalFail += 1;
        });
      } else {
        response = await commonUpload({
          excelData: data,
          sqsData: body,
          config,
          url: data.url,
          identifier: data.identifier,
        }).catch(() => {
          totalFail += 1;
        });
      }
      if (response) {
        totalSuccess += 1;
        await bulkLog({
          ...body,
          body: { ...data, stage },
          identifier: data[identity],
          type,
          response,
          status: 'success',
        });
      }
    }
  }

  if (start + i < totalRecords) {
    start += constant.CHUNK_SIZE;
    await pushInQueue(body, start, totalSuccess, totalFail);
  } else if (start + i == totalRecords) {
    const log = await bulkLog({
      ...body,
      status: 'success',
      type: 'doc',
      docType: type,
      total: totalRecords,
      totalSuccess,
      totalFail,
    });
    if (body.user_mapping_id) {
      await updatedRecordInUserMapping(body, log);
    }
    await deleteFileRecords({ doc_id });
  }
};
