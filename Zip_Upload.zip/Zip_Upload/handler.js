'use strict';

const { post } = require('./src/client/httpRequest');
const { zip, getZip } = require('./src/controllers/zip.controller');

module.exports.zipUpload = async (event) => {
  let Body = JSON.parse(event.Records[0].body);
  try {
    await zip(Body);

    const response = {
      statusCode: 200,
      body: JSON.stringify({
        message: 'Zipped',
      }),
    };
    return response;
  } catch (error) {
    const response = {
      statusCode: 400,
      body: JSON.stringify({
        message: `Zipped failed: ${error}`,
      }),
    };
    await post({ url: Body.callback_url, data: response });
    return response;
  }
};

module.exports.zipDownload = async (event) => {
  try {
    let Body = JSON.parse(event.body);

    const res = await getZip(Body);

    const response = {
      statusCode: 200,
      body: JSON.stringify({
        message: 'Success',
        response: res,
      }),
    };
    return response;
  } catch (error) {
    const response = {
      statusCode: 404,
      body: JSON.stringify({
        message: `Failed: ${error}`,
      }),
    };
    return response;
  }
};

// serverless invoke local --function zipUpload -p test.json
