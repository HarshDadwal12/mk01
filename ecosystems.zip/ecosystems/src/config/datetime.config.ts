//@ts-ignore
export function getDateUnixTimestamp() {
  return Math.floor(Date.now() / 1000);
}

export function convertTimestampToIsoDate(timestamp: any) {
  return new Date(timestamp * 1000).toISOString();
}
