"use strict";
const reportController = require("./controllers/reportController");
const userInfoController = require("./controllers/userInfoController");
const appController = require("./controllers/appController");
const consController = require("./controllers/consolidatedController");
const helper = require("./lib/helper");

const in_array = require("in_array");

module.exports.ppp_report = async (event) => {
	try {
		let result = await reportController.createReport();
		let respone = {
			status: "success",
			code: 200,
			result: result,
		};
		return {
			statusCode: 200,
			body: JSON.stringify(respone),
		};
	} catch (error) {
		if (error instanceof TypeError) {
			return {
				statusCode: error.statusCode,
				body: JSON.stringify({
					message: error.message,
				}),
			};
		} else if (error instanceof Error) {
			return {
				statusCode: 400,
				body: JSON.stringify({
					message: error.message,
				}),
			};
		} else {
			return {
				statusCode: 400,
				body: JSON.stringify({
					message: error.message,
				}),
			};
		}
	}
};

module.exports.ppp_user_report = async (event) => {
	try {
		// Call Controller
		let result = await userInfoController.getPPPUserReport();

		// Prepare response
		let respone = {
			status: "success",
			code: 200,
			result: result,
			message: "Mail has been sent successfully",
		};

		// Send response
		return {
			statusCode: 200,
			body: JSON.stringify(respone),
		};
	} catch (error) {
		console.log(error);

		// Error handler
		let errors = await helper.errorHandler(error);

		return errors;
	}
};

module.exports.ppp_cpa_user_report = async (event) => {
	try {
		// Call Controller
		let result = await userInfoController.getPPPCPAUserReport();

		// Prepare response
		let respone = {
			status: "success",
			code: 200,
			result: result,
			message: "Mail has been sent successfully",
		};

		// Send response
		return {
			statusCode: 200,
			body: JSON.stringify(respone),
		};
	} catch (error) {
		console.log(error);

		// Error handler
		let errors = await helper.errorHandler(error);

		return errors;
	}
};

module.exports.ppp_aicpa_report = async (event) => {
	try {
		// Call Controller
		let result = await appController.getPPPAICPAReport();

		// Prepare response
		let respone = {
			status: "success",
			code: 200,
			result: result,
			message: "Mail has been sent successfully",
		};

		// Send response
		return {
			statusCode: 200,
			body: JSON.stringify(respone),
		};
	} catch (error) {
		console.log(error);

		// Error handler
		let errors = await helper.errorHandler(error);

		return errors;
	}
};

module.exports.get_PPP_AICPA_FIRM_Report = async (event) => {
	try {
		// Call Controller
		let result = await appController.get_PPP_AICPA_FIRM_Report();

		// Prepare response
		let respone = {
			status: "success",
			code: 200,
			result: result,
			message: "Mail has been sent successfully",
		};

		// Send response
		return {
			statusCode: 200,
			// body: JSON.stringify(respDone),
			body: respone,
		};
	} catch (error) {
		console.log(error);

		// Error handler
		let errors = await helper.errorHandler(error);

		return errors;
	}
};

module.exports.ppp_consolidated_user_report = async (event) => {
	try {
		// Call Controller
		let result = await consController.getPPPConsUserReport();

		// Prepare response
		let respone = {
			status: "success",
			code: 200,
			result: result,
			message: "Mail has been sent successfully",
		};

		// Send response
		return {
			statusCode: 200,
			body: JSON.stringify(respone),
		};
	} catch (error) {
		console.log(error);

		// Error handler
		let errors = await helper.errorHandler(error);

		return errors;
	}
};

module.exports.ppp_consolidated_cpa_user_report = async (event) => {
	try {
		// Call Controller
		let result = await consController.getPPPConsCPAUserReport();

		// Prepare response
		let respone = {
			status: "success",
			code: 200,
			result: result,
			message: "Mail has been sent successfully",
		};

		// Send response
		return {
			statusCode: 200,
			body: JSON.stringify(respone),
		};
	} catch (error) {
		console.log(error);

		// Error handler
		let errors = await helper.errorHandler(error);

		return errors;
	}
};

module.exports.ppp_aicpa_cpa_report = async (event) => {
	try {
		// Call Controller
		let result = await appController.get_PPP_AICPA_CPA_Report();

		// Prepare response
		let respone = {
			status: "success",
			code: 200,
			result: result,
			message: "Mail has been sent successfully",
		};

		// Send response
		return {
			statusCode: 200,
			body: respone,
			// body: JSON.stringify(respone),
		};
	} catch (error) {
		console.log(error);

		// Error handler
		let errors = await helper.errorHandler(error);

		return errors;
	}
};

module.exports.ppp_application_report = async (event) => {
	try {
		let result = await appController.get_PPP_Application_Report();

		// Prepare response
		let respone = {
			status: "success",
			code: 200,
			result: result,
			message: "Mail has been sent successfully",
		};

		// Send response
		return {
			statusCode: 200,
			body: JSON.stringify(respone),
		};
	} catch (error) {
		console.log(error);
		// Error handler
		let errors = await helper.errorHandler(error);
		return errors;
	}
};

module.exports.get_PPP_Business_Report = async (event) => {
	try {
		let result = await appController.get_PPP_Business_Report();

		// Prepare response
		let respone = {
			status: "success",
			code: 200,
			result: result,
			message: "Mail has been sent successfully",
		};

		// Send response
		return {
			statusCode: 200,
			body: JSON.stringify(respone),
		};
	} catch (error) {
		console.log(error);
		// Error handler
		let errors = await helper.errorHandler(error);
		return errors;
	}
};

module.exports.cpaFirmReport = async (event) => {
	try {
		let result = await appController.cpaFirmReport();

		// Prepare response
		let respone = {
			status: "success",
			code: 200,
			result: result,
			message: "Mail has been sent successfully",
		};

		// Send response
		return {
			statusCode: 200,
			body: JSON.stringify(respone),
		};
	} catch (error) {
		console.log(error);
		// Error handler
		let errors = await helper.errorHandler(error);
		return errors;
	}
};

module.exports.urgent_firm_report = async (event) => {
	try {
		let result = await appController.urgent_firm_report();

		// Prepare response
		let respone = {
			status: "success",
			code: 200,
			result: result,
			message: "Mail has been sent successfully",
		};

		// Send response
		return {
			statusCode: 200,
			body: JSON.stringify(respone),
		};
	} catch (error) {
		console.log(error);
		// Error handler
		let errors = await helper.errorHandler(error);
		return errors;
	}
};

module.exports.case_linkup_report = async (event) => {
	try {
		let result = await appController.caseLinkupReport();

		// Prepare response
		let respone = {
			status: "success",
			code: 200,
			result: result,
			message: "Mail has been sent successfully",
		};

		// Send response
		return {
			statusCode: 200,
			body: JSON.stringify(respone),
		};
	} catch (error) {
		console.log(error);
		// Error handler
		let errors = await helper.errorHandler(error);
		return errors;
	}
};

module.exports.forgiveness_consume_count = async (event) => {
	try {
		let result = await appController.forgiveness_consume_count();

		// Prepare response
		let respone = {
			status: "success",
			code: 200,
			result: result,
			message: "Mail has been sent successfully",
		};

		// Send response
		return {
			statusCode: 200,
			body: respone,
		};
	} catch (error) {
		console.log(error);
		// Error handler
		let errors = await helper.errorHandler(error);
		return errors;
	}
};

module.exports.getCoverPeriodReport = async (event) => {
	try {
		let result = await appController.getCoverPeriodReport();

		// Prepare response
		let respone = {
			status: "success",
			code: 200,
			result: result,
			message: "Mail has been sent successfully",
		};

		// Send response
		return {
			statusCode: 200,
			body: respone,
		};
	} catch (error) {
		console.log(error);
		// Error handler
		let errors = await helper.errorHandler(error);
		return errors;
	}
};

module.exports.bulk_app_assignment = async (event) => {
	try {
		let result = await appController.bulk_app_assignment();

		// Prepare response
		let respone = {
			status: "success",
			code: 200,
			result: result,
			message: "Mail has been sent successfully",
		};

		// Send response
		return {
			statusCode: 200,
			body: respone,
		};
	} catch (error) {
		console.log(error);
		// Error handler
		let errors = await helper.errorHandler(error);
		return errors;
	}
};
module.exports.app_assignment_by_caseId = async (event) => {
	try {
		let result = await appController.app_assignment_by_caseId(event);

		// Prepare response
		let respone = {
			status: "success",
			code: 200,
			result: result,
			message: "Mail has been sent successfully",
		};

		// Send response
		return {
			statusCode: 200,
			body: respone,
		};
	} catch (error) {
		console.log(error);
		// Error handler
		let errors = await helper.errorHandler(error);
		return errors;
	}
};
module.exports.covered_period_end_date = async (event) => {
	try {
		let result = await appController.covered_period_end_date(event);

		// Prepare response
		let respone = {
			status: "success",
			code: 200,
			result: result,
			message: "Mail has been sent successfully",
		};

		// Send response
		return {
			statusCode: 200,
			body: respone,
		};
	} catch (error) {
		console.log(error);
		// Error handler
		let errors = await helper.errorHandler(error);
		return errors;
	}
};
module.exports.get_CPA_App_Report = async (event) => {
	try {
		let result = await appController.get_CPA_App_Report(event);

		// Prepare response
		let respone = {
			status: "success",
			code: 200,
			result: result,
			message: "Mail has been sent successfully",
		};

		// Send response
		return {
			statusCode: 200,
			body: respone,
		};
	} catch (error) {
		console.log(error);
		// Error handler
		let errors = await helper.errorHandler(error);
		return errors;
	}
};
