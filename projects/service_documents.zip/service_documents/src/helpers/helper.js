const messages = require('../lang/en/messages');
const RequestResponseLog = require('../models/RequestResponseLog');

// General methods used multiple times in the service

module.exports = {
	/**
	 * @description Prepare and return success response for all apis
	 *
	 * @author Tanuj Chawla <tanuj.chawla@biz2credit.com>
	 *
	 * @param req
	 * @param res
	 * @param {mongo_objectId} [doc_id=null] (OPTIONAL)
	 * @param {number} [code=200] (OPTIONAL)
	 *
	 * @returns string
	 */
	getSuccessResponse(req, res, doc = null, code = 200, flag = false) {
		let response = new Object({
			status: messages.success,
			code: code,
		});

		if (Array.isArray(doc) && doc.length === 0) {
			response.data = [];
		} else if (Array.isArray(doc) && doc.length > 0) {
			let temp = [];
			doc.filter((val, key) => {
				temp.push(
					new Object({
						[messages.doc_id]: val[messages.mongo_id],
						[messages.filename]: flag
							? val.doc_key.replace(/([^\_]*\_){3}/, "")
							: val.doc_key.replace(/([^\-]*\-){5}/, ""),
						[messages.doc_key]: val.doc_key,
						[messages.doc_type_key]: val[messages.doc_type_key],
						[messages.created_at]: val[messages.createdAt],
						[messages.updated_at]: val[messages.updatedAt],
						[messages.keys.file_size]: val[messages.keys.file_size],
						[messages.keys.updated_file_name]: val[messages.keys.updated_file_name],
						[messages.keys.images]: val[messages.keys.images],
					})
				);
			});

			response.data = temp;
		} else if (doc !== null && doc.signed_url && doc.doc_key) {
			response.data = new Object({
				[messages.doc_key]: doc.doc_key,
				[messages.signed_url]: doc.signed_url,
			});
		} else if (doc !== null) {
			response.data = new Object({
				[messages.doc_id]: doc[messages.mongo_id],
				[messages.filename]:
					req.file !== undefined
						? req.file.originalname
						: flag
						? doc.doc_key.replace(/([^\_]*\_){3}/, "")
						: doc.doc_key.replace(/([^\-]*\-){5}/, ""),
				[messages.doc_key]: doc.doc_key,
				[messages.doc_type_key]: doc[messages.doc_type_key],
				[messages.created_at]: doc[messages.createdAt],
				[messages.updated_at]: doc[messages.updatedAt],
				[messages.keys.file_size]: doc[messages.keys.file_size],
				[messages.keys.updated_file_name]: doc[messages.keys.updated_file_name],
				[messages.keys.images]: doc[messages.keys.images],
			});
		}

		this.saveRequestResponseLog(req, response);
		return res.status(code).send(response);
	},

	sendSuccessResponse(req, res, data = null, code = 200) {
		let response = new Object({
			status: messages.success,
			code: code,
		});

		if (data) {
			response.data = data;
		}

		this.saveRequestResponseLog(req, response);
		return res.status(code).send(response);
	},
	modifyOriginalFileName(actualFileName, doc_identifier) {
		const dateObj = new Date();
		const year = dateObj.getFullYear();
		const month = dateObj.getMonth() + 1;
		const date = dateObj.getDate();
		const hours = dateObj.getHours();
		const min = dateObj.getMinutes();
		const sec = dateObj.getSeconds();
		const millisec = dateObj.getMilliseconds();
		return `${year}${month}${date}T${hours}${min}${sec}${millisec}_${doc_identifier}_${actualFileName}`;
	},

	/**
	 * @description Save every requests' log
	 *
	 * @author Tanuj Chawla <tanuj.chawla@biz2credit.com>
	 *
	 * @param req
	 * @param {object} response
	 *
	 * @returns void
	 */
	async saveRequestResponseLog(req, response) {
		if (req.url == "/data_upload") delete req.body.data;
		let tenant = req.headers["x-tenant-id"];
		let modelName = global[tenant]["dbModel"][RequestResponseLog.name];
		let ReqResLog = new modelName({
			request_url: req.baseUrl + req.url,
			method: req.method,
			request_IP: req.ip,
			request_header: req.headers,
			request_body: req.body,
			response: response,
			status_code: response.code,
		});
		return await ReqResLog.save();
	},
	/**
	 * @description Prepare and  return error response for all apis
	 *
	 * @author Tanuj Chawla <tanuj.chawla@biz2credit.com>
	 *
	 * @param req
	 * @param res
	 * @param {array} [keys=['action_failed']] (OPTIONAL)
	 * @param {number} [code=500] (OPTIONAL)
	 *
	 * @returns string
	 */
	getErrorResponse(req, res, keys = ["action_failed"], code = 500) {
		let response = new Object({
			status: messages.failed,
			code: code,
			errors: [],
		});

		keys.forEach((key) => {
			response.errors.push(messages[key]);
		});

		this.saveRequestResponseLog(req, response);
		return res.status(code).send(response);
	},
	/**
	 * @description Prepare success reponse to log it where response is not sent back in json
	 *
	 * @author Tanuj Chawla <tanuj.chawla@biz2credit.com>
	 *
	 * @param req
	 * @param {number} [code=200] (OPTIONAL)
	 *
	 * @returns void
	 */
	prepareSuccessResponse(req, code = 200) {
		let response = new Object({
			status: messages.success,
			code: code,
		});

		this.saveRequestResponseLog(req, response);
	},
	/**
	 * @description Prepare database connection string
	 *
	 * @author Ravi Pratap Singh <ravi.singh@biz2credit.com>
	 *
	 * @param envConfig
	 *
	 * @returns void
	 */
	connectionUrl(envConfig) {
		let mongoUrl;
		if (envConfig.DB_HAV) {
			mongoUrl = envConfig.MONGO_HAV_URI;
		} else {
			mongoUrl = envConfig.MONGO_URI;
		}

		mongoUrl = mongoUrl.replace(/%2f/g, '/').replace(/%26/g, '&');
		console.log(mongoUrl);
		return mongoUrl;
	},
	/**
	 * @description check file name is valid or not
	 *
	 * @author Ravi Pratap Singh <ravi.singh@biz2credit.com>
	 *
	 * @param envConfig
	 *
	 * @returns void
	 */
	isValidFilename(string) {
		if (!string || string.length > 255) {
			return false;
		}
	
		if (/[<>:"/\\|?*\u0000-\u001F]/g.test(string) || /^(con|prn|aux|nul|com\d|lpt\d)$/i.test(string)) {
			return false;
		}
	
		if (string === '.' || string === '..') {
			return false;
		}
	
		return true;
	},
	/**
	 * @description Build DB Query condition form query param
	 *
	 * @author Amit Kishore <amit.kishore@biz2credit.com>
	 *
	 * @param query Object
	 *
	 * @returns void
	 */
	 buildQuery(query, condition) {
		if(query && Object.keys(query).length) {
			Object.keys(query).forEach((key) => {
				condition[key] = query[key];
			});
		}
	
		return condition;
	}
};
