'use strict';
require('dotenv').config();

const helper = require('./src/utils/helper');
const {
  processData,
  getBulkUploadLog,
} = require('./src/controllers/bulkUploadController');
const {
  processNotification,
} = require('./src/controllers/notificationController');

module.exports.health = async () => {
  try {
    let checkDbConnection = await helper.checkDBConnection();

    let response = {
      status: 'success',
      code: 200,
      result: checkDbConnection,
    };
    return {
      statusCode: 200,
      body: JSON.stringify(response),
    };
  } catch (error) {
    console.log(error);
    let errors = await helper.errorHandler(error);
    return errors;
  }
};

module.exports.bulk_upload_logs = async (event) => {
  try {
    const query = event.queryStringParameters;
    if (!query || !query.uploaded_by)
      throw new Error('uploaded_by is required');
    const logs = await getBulkUploadLog(query);
    return {
      statusCode: 200,
      body: JSON.stringify({
        status: 'success',
        code: 200,
        result: logs,
      }),
    };
  } catch (error) {
    console.log(error);
    let errors = await helper.errorHandler(error);
    return errors;
  }
};

module.exports.process_bulk_upload = async (event) => {
  try {
    let body = JSON.parse(event.Records[0].body);
    if (!body) {
      throw new Error('Bad Request');
    }

    await processData(body);

    return {
      statusCode: 200,
      body: { status: 'success', code: 200 },
    };
  } catch (error) {
    console.log('->>>> Error', error);
    const errors = await helper.errorHandler(error);
    await helper.bulkLog({ ...error });
    return errors;
  }
};

module.exports.process_notification = async (event) => {
  try {
    let body = JSON.parse(event.Records[0].body);
    if (!body) {
      throw new Error('Bad Request');
    }
    await processNotification(body);
  } catch (error) {
    console.log('->>>> Error', error);
    const errors = await helper.errorHandler(error);
    return errors;
  }
};

// serverless invoke local --function process_bulk_upload -p tmp/bulk_data.json --region=us-east-1
// serverless invoke local --function process_notification -p tmp/notification.json
