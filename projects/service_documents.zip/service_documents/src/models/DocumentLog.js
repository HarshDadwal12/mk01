const mongoose = require('mongoose');
const s3 = require('../config/s3.config.js');
const collections = require('../config/collections.config');
const fileValidations = require('../config/files.config');
const Schema = mongoose.Schema;

// Document Log Model to keep record of all uploaded documents

const DocumentLogSchema = new Schema({
    doc_key: {
        type: String,
        required: true
    },
    doc_type_id: {
        type: String,
        required: true
    },
    doc_type_key: {
        type: String,
        required: true
    },
    updated_file_name: {
        type: String
    },
    is_deleted: {
        type: Number,
        required: true
    },
    file_size: {
        type: Number
    },
    images: {
        type: Schema.Types.Mixed
    }
}, {
    timestamps: true
});

/**
 * @description Find a document for given docId
 * 
 * @author Tanuj Chawla <tanuj.chawla@biz2credit.com>
 * 
 * @param {mongo_objectId} docId
 * 
 * @returns Promise
 */
DocumentLogSchema.statics.findDoc = function (docId,tenant) {
    const Doc = this;

    return Doc.findById(docId)
        .then((doc) => {
            if (!doc) {
                return Promise.reject();
            } else if (doc.is_deleted === fileValidations.is_deleted_true) {
                return Promise.reject();
            }
            const params ={
                ...s3.downloadParams(tenant),
                Key : doc.doc_key
            };

            return Promise.resolve(params);
        });
};

/**
 * @description Find a document for given condition
 * 
 * @author Amit Kishore <amit.kishore@biz2credit.com>
 * 
 * @param {condition} Object
 * 
 * @returns Promise
 */
DocumentLogSchema.statics.findOneDoc = function (condition, key, tenant) {
    const Doc = this;

    return Doc.findOne(condition)
        .then((doc) => {
            if (!doc) {
                return Promise.reject();
            } else if (doc.is_deleted === fileValidations.is_deleted_true) {
                return Promise.reject();
            }
            const params ={
                ...s3.downloadParams(tenant),
                Key : key && doc.images && doc.images[key] ? doc.images[key] : doc.doc_key
            };

            return Promise.resolve(params);
        });
};

module.exports = { schema: DocumentLogSchema, name: collections.document_log }

