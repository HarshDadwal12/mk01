import {
  Injectable,
} from '@nestjs/common';
import { QueryService } from 'src/core/services/query.service';
import testNotificationsModel from '../../database/models/test-notifications.model';

@Injectable()
export class TestNotificationsService {
  constructor(
    private queryService: QueryService,
  ) {}

  async createNotifications(type : string , body: any) {
    try {
        return this.queryService.create({
          modelName: testNotificationsModel,
          data: {
            type: type,
            data : body
          },
        });
    } catch (error) {
      throw error;
    }
  }
}
