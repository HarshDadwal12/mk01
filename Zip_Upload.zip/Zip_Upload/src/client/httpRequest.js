'use strict';

const axios = require('axios');

module.exports.post = function ({ url, data }) {
  console.log('--> post', url, '--> data', data);
  return axios.post(url, data);
};

module.exports.get = function ({ url }) {
  console.log('--> get', url);
  return axios.get(url);
};
