const mongoose = require('mongoose');
const collections = require('../config/collections.config');
const Schema = mongoose.Schema;

const FileLogSchema = new Schema({
    identifier: {
        type: String,
        required: true
    },
    document_id:{
        type: Schema.Types.ObjectId, ref: collections.document_log
    },
    status: {
        type: String,
        enum : ["processing","completed","failed"],
        required: true
    }
}, {
    timestamps: true
});

module.exports = { schema: FileLogSchema, name: collections.file_log }