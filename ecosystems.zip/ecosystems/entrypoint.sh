#! /bin/bash
cd /usr/src/app/
sed -i "s/db_host/${db_host}/g" /usr/src/app/.env
sed -i "s/db_user/${db_user}/g" /usr/src/app/.env
sed -i "s/db_password/${db_password}/g" /usr/src/app/.env
sed -i "s/db_port/${db_port}/g" /usr/src/app/.env
sed -i "s/db_provider/${db_provider}/g" /usr/src/app/.env
sed -i "s/database/${database}/g" /usr/src/app/.env
sed -i "s/app_env/${app_env}/g" /usr/src/app/.env
sed -i "s/service_port/${service_port}/g" /usr/src/app/.env
sed -i "s/common_hash_salt/${common_hash_salt}/g" /usr/src/app/.env
sed -i "s/access_token_expiry_time/${access_token_expiry_time}/g" /usr/src/app/.env
sed -i "s/access_token_secret/${access_token_secret}/g" /usr/src/app/.env
sed -i "s/access_key/${access_key}/g" /usr/src/app/.env
sed -i "s/user_url/${user_url}/g" /usr/src/app/.env
sed -i "s/master_url/${master_url}/g" /usr/src/app/.env
sed -i "s/case_url/${case_url}/g" /usr/src/app/.env
sed -i "s/offer_url/${offer_url}/g" /usr/src/app/.env
sed -i "s/document_url/${document_url}/g" /usr/src/app/.env
sed -i "s/queue_url/${queue_url}/g" /usr/src/app/.env
sed -i "s/aws_bucket/${aws_bucket}/g" /usr/src/app/.env
sed -i "s/aws_region/${aws_region}/g" /usr/src/app/.env
sed -i "s/s3_id/${s3_id}/g" /usr/src/app/.env
sed -i "s/s3_value/${s3_value}/g" /usr/src/app/.env

npm run seed
pm2 start processes.json --no-daemon
