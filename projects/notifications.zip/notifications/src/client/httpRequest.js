'use strict';
const axios = require('axios');

const RETRY_TIMEOUT = 1000;
const RETRY_COUNT = 3;

axios.interceptors.request.use((config) => {
  return config;
});

axios.interceptors.response.use(
  (response) => {
    const parseResponse = isJson(response.data);

    let success = ['success', 'created'];
    if (
      response &&
      response.data &&
      response.data.data &&
      response.data.data.statusText &&
      !success.includes(response.data.data.statusText)
    ) {
      return Promise.reject(response.data.data);
    }

    const { status: statusText = 'success', data, total } = parseResponse;
    const modifiedResponse = {
      headerStatus: response.status,
      statusText,
      data: data || parseResponse,
    };

    if (total) modifiedResponse.total = total;
    // return modifiedResponse;
    return data || parseResponse;
  },
  async (error) => {
    // console.log('error*****',error);
    let obj = {};
    const { response } = error;
    const { data } = response || obj;
    const { message, status } = data ? isJson(data) : obj;
    let { code: headerStatus, errors } = data ? isJson(data) : obj;
    error.config['retryCount'] = (error.config && error.config['retryCount']) || 0;

    if (error.config && error.config['retryCount'] < RETRY_COUNT && !error.response) {
      error.config['retryCount'] += 1;
      console.log(error.config['retryCount']);
      await sleep(RETRY_TIMEOUT * error.config['retryCount']);
      return axios.request(error.config);
    }

    if (error.code == 'ECONNREFUSED') {
      headerStatus = 503;
      errors = [
        {
          type: 'server_not_reachable',
          message: 'Server is not available of returning the request.',
        },
      ];
    }
    const errordata = {
      headerStatus,
      statusText: message || status || 'failed',
      errors,
      message: error.message,
    };
    return Promise.reject(errordata);
  }
);

module.exports.get = function ({ url, config }) {
  console.log('--> GET', url, '--> Config', config);
  return axios.get(url, config);
};

module.exports.post = function ({ url, data, config }) {
  console.log('--> POST', url, '--> Config', config, '--> data', data);

  return axios.post(url, data, config);
};

module.exports.patch = function ({ url, data, config }) {
  console.log('--> PATCH', url, '--> Config', config, '--> data', data);
  return axios.patch(url, data, config);
};

module.exports.put = function ({ url, data, config }) {
  console.log('--> PUT', url, '--> Config', config, '--> data', data);
  return axios.put(url, data, config);
};

module.exports.delete_req = function ({ url, data, config }) {
  console.log('--> DELETE', url, '--> Config', config, '--> data', data);
  return axios.delete(url, data, config);
};

/**
 * @description Used to block the code for time
 * @author Ravi Pratap Singh <ravi.singh@biz2credit.com>
 * @param {*} string
 * @returns Promise
 */
const sleep = function (ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
};

/**
 * @description Check is JSON
 * @author Ravi Pratap Singh <ravi.singh@biz2credit.com>
 * @param {*} string
 * @returns JSON
 */
const isJson = function (str) {
  try {
    return JSON.parse(str);
  } catch (e) {
    return str;
  }
};
