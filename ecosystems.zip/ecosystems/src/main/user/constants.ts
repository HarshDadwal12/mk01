const constant= {
  CREATE_LEAD: {api:'/api/leads',method:['POST']},
  CREATE_APPLICATION: { api: '/api/application',method: ['POST'] },
  CREATE_OWNER: { api: '/api/application/owners',method: ['POST'] },
  ADDITIONAL: { api: '/api/application/additional',method: ['POST','PATCH'] },
  GST: { api: '/api/application/gst',method: ['POST','PATCH'] },
  CREATE_APPROVE_LIMIT: { api: '/api/application/approve-limit',method: ['POST'] },
  CREATE_DISBURSEMENT_REQUEST: { api: '/api/application/disbursement/request',method: ['POST'] },
  CREATE_REPAYMENT_REQUEST: { api: '/api/application/repayment/request',method: ['POST'] },
  CREATE_REPAYMENT_RESPONSE: { api: '/api/application/repayment/response',method: ['POST'] },
  CREATE_REPAYMENT_REQUEST_RECONCILIATION:
    { api: '/api/application/repayment/request/reconciliation',method: ['POST'] },
  CREATE_DISBURSEMENT_REQUEST_RECONCILIATION:
    { api: '/api/application/disbursement/request/reconciliation',method: ['POST'] },
  CREATE_DISBURSEMENT_RESPONSE_RECONCILIATION:
    { api: '/api/application/disbursement/response/reconciliation',method: ['POST'] },
  CREATE_DISBURSEMENT_RESPONSE: { api: '/api/application/disbursement/response',method: ['POST'] },
  CREATE_DOCUMENT:{API:'/api/application/document',method:['POST']},
  GET_LEAD:{api:'/api/leads/:id',method:['GET']},
  UPDATE_LEAD: { api: '/api/leads/status/:id', method: ['PUT'] },
  GET_APPLICATION:{api:'api/application/:id',method:['GET']},
  LEAD_SUMMARY:{api:'/api/leads/summary/:id',method:['GET']},
  TRANSACTION_INFO:{api:'/api/application/transaction_info/:id',method:['GET']},
  APPLICATION_SUMMARY:{api:'/api/application/summary/:id',method:['GET']},
  DOCUMENT_METADATA:{API:'/api/application/document/metadata',method:['GET']},
  INVOICE_TRANCHE:{API:'api/application/invoice/tranche',method:['GET']}
};

export default constant;