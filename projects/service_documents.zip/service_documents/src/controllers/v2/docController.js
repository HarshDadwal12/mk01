const uuidv4 = require("uuid/v4");
const fs = require("fs");
const archiver = require("archiver");
const { pipeline } = require("stream");
const { promisify } = require('util');
const pipelineAsync  = promisify(pipeline)

const helper = require("../../helpers/helper");
const s3 = require("../../config/s3.config.js");
const fileValidations = require("../../config/files.config");
const messages = require("../../lang/en/messages");
const DocumentLog = require("../../models/DocumentLog");
const config = require("../../../config/config");
const docUtils = require("../../utils/docUtils.js");

module.exports = {
	/**
	 * @description Upload single file on s3 bucket
	 *
	 * @author Praveen Verma <praveen.verma@biz2credit.com>
	 *
	 * @param req
	 * @param res
	 *
	 * @returns string
	 */
	async doSingleUpload(req, res) {
		try {
			const { buffer: data, size: file_size, originalname } = req.file;
			const { doc_type_id, doc_type_key, updated_file_name } = req.body;

			const keySuffix = req.body.base_folder
				? req.body.base_folder
				: config.BUCKET_BASEFOLDER
				? config.BUCKET_BASEFOLDER
				: null;
			const params = {
				...s3.uploadParams(req.headers["x-tenant-id"]),
				Key: keySuffix ? `${keySuffix}/${uuidv4()}-${originalname}` : `${uuidv4()}-${originalname}`,
				Body: Buffer.from(data, "base64"),
			};
			let body = {
				doc_type_id,
				doc_type_key,
				file_size,
				updated_file_name,
				is_deleted: fileValidations.is_deleted_false,
			};
			let doc = await docUtils.docUpload(req, params, body);
			return helper.getSuccessResponse(req, res, doc);
		} catch (err) {
			console.log("errr:::", err);
			return helper.getErrorResponse(req, res);
		}
	},

	/**
	 * @description Upload single file from base64 on s3 bucket
	 *
	 * @author Tanuj Chawla <tanuj.chawla@biz2credit.com>
	 *
	 * @param req
	 * @param res
	 *
	 * @returns string
	 */
	async doDataUpload(req, res) {
		try {
			const {
				doc_type_key = req.body.doc_type_key || "offer_doc",
				doc_type_id,
				filename,
				data,
				updated_file_name,
			} = req.body;

			const { originalname = filename } = req.file || {};
			const buffer = Buffer.from(data, "base64");
			const params = {
				...s3.uploadParams(req.headers["x-tenant-id"]),
				Key: config.BUCKET_BASEFOLDER
					? `${config.BUCKET_BASEFOLDER}/${uuidv4()}-${originalname}`
					: `${uuidv4()}-${originalname}`,
				Body: buffer,
			};
			let body = {
				doc_type_id,
				doc_type_key,
				updated_file_name,
				is_deleted: fileValidations.is_deleted_false,
			};
			let doc = await docUtils.docUpload(req, params, body);
			return helper.getSuccessResponse(req, res, doc);
		} catch (err) {
			console.log("errr:::", err);
			return helper.getErrorResponse(req, res);
		}
	},

	/**
	 * @description Download File from s3 bucket
	 *
	 * @author Tanuj Chawla <tanuj.chawla@biz2credit.com>
	 *
	 * @param req
	 * @param res
	 *
	 * @returns string
	 */
	async doDownload(req, res) {
		try {
			if(req.query.signed_url){
				let data = await docUtils.docDownload(req, res, true);
				res.send(data);
			}else{
				let data = await docUtils.docDownload(req, res);
				res.send(data.Body.toString("base64"));
			}

			return helper.prepareSuccessResponse(req);
		} catch (err) {
			console.log("errr:::", err);
			return helper.getErrorResponse(req, res);
		}
	},

	/**
	 * @description View file in browser from s3 bucket
	 *
	 * @author Tanuj Chawla <tanuj.chawla@biz2credit.com>
	 *
	 * @param req
	 * @param res
	 *
	 * @returns string
	 */
	viewDoc(req, res) {
		try {
			return docUtils.docView(req, res);
		} catch (err) {
			console.log("errr:::", err);
			return helper.getErrorResponse(req, res);
		}
	},

	/**
	 * @description Delete a file on s3 bucket
	 *
	 * @author Tanuj Chawla <tanuj.chawla@biz2credit.com>
	 *
	 * @param req
	 * @param res
	 *
	 * @returns string
	 */
	async doDelete(req, res) {
		try {
			const result = await docUtils.docDelete(req);

			if (!result) {
				return helper.getErrorResponse(
					req,
					res,
					[messages.keys.resource_not_found],
					messages.codes.resource_not_found
				);
			}

			return helper.getSuccessResponse(req, res);
		} catch (err) {
			console.log("errr:::", err);
			return helper.getErrorResponse(req, res);
		}
	},

	/**
	 * @description Get record info by doc_id
	 *
	 * @author Tanuj Chawla <tanuj.chawla@biz2credit.com>
	 *
	 * @param req
	 * @param res
	 *
	 * @returns string
	 */
	async get(req, res) {
		try {
			const doc = await docUtils.getDoc(req);
			if (!doc) return helper.getSuccessResponse(req, res, []);
			return helper.getSuccessResponse(req, res, doc);
		} catch (err) {
			console.log("errr:::", err);
			return helper.getErrorResponse(req, res);
		}
	},
	/**
	 * @description Generate Pdf and return base64
	 *
	 * @author Tanuj Chawla <tanuj.chawla@biz2credit.com>
	 *
	 * @param {*} req
	 * @param {*} res
	 *
	 * @returns string
	 */
	async generatePdf(req, res) {
		try {
			let data = await docUtils.docPdfGenerate(req, true);
			return helper.sendSuccessResponse(req, res, data);
		} catch (err) {
			console.log("error:::", err);
			return helper.getErrorResponse(req, res);
		}
	},

	/**
	 * @description Download File as JSON from s3 bucket
	 *
	 * @author Sujendra Kumar <sujendra.kumar@biz2credit.com>
	 *
	 * @param req
	 * @param res
	 *
	 * @returns string
	 */
	async doDownloadJson(req, res) {
		try {
			const data = await docUtils.downloadDocJson(req);
			if (!data) {
				return helper.getErrorResponse(
					req,
					res,
					[messages.keys.resource_not_found],
					messages.codes.resource_not_found
				);
			}
			return helper.sendSuccessResponse(req, res, data);
		} catch (err) {
			console.log("errr:::", err);
			return helper.getErrorResponse(req, res);
		}
	},
	/**
	 * @description Get multiple record by doc_ids
	 * @author Sujendra Kumar <sujendra.kumar@biz2credit.com>
	 * @param req
	 * @param res
	 * @returns string
	 */
	async getByIds(req, res) {
		try {
			let doc_ids = req.body.doc_ids;
			if (!Array.isArray(doc_ids) && !doc_ids.length) {
				return helper.getErrorResponse(req, res);
			}
			const doc = await docUtils.getDocByIds(req);
			if (!doc) {
				return helper.getSuccessResponse(req, res, []);
			}
			return helper.getSuccessResponse(req, res, doc);
		} catch (err) {
			return helper.getErrorResponse(req, res);
		}
	},
	/**
	 * @description Download File from s3 bucket
	 *
	 * @author Praveen Kumar Verma <praveen.verma@biz2credit.com>
	 *
	 * @param req
	 * @param res
	 *
	 * @returns string
	 */
	async doDownloadMultiple(req, res) {
		try {
			const { ids } = req.method === "POST" ? req.body : req.query;
			const doc_ids = Array.isArray(ids) ? ids : ids.split(",");

			if (!doc_ids.length) {
				return helper.getSuccessResponse(req, res, []);
			}
			let tenant = req.headers["x-tenant-id"];
			const s3Client = s3.getS3Client(tenant);
			let modelName = global[tenant]["dbModel"][DocumentLog.name];
			const params = await modelName.find({ _id: { $in: doc_ids } });
			const bucket = s3.downloadParams(tenant);

			const files =
			params &&
			params.map(({ doc_key }) => {
				return {
					stream: s3Client.getObject({ ...bucket, Key: doc_key }).createReadStream(),
					filename: doc_key,
				};
			});
			const archive = archiver("zip");
			

			files.forEach((itm) => archive.append(itm.stream, { name: itm.filename }));

			archive.finalize();
			res.set("content-type", "application/x-zip-compressed");
			pipelineAsync(archive, res)
		} catch (err) {
			console.log(err);
			return helper.getErrorResponse(req, res);
		}
	},
	/**
	 * @description Download Zip File as Base64  from s3 bucket
	 *
	 * @author Ankit Chaudhary <ankit.chaudhary@biz2credit.com>
	 *
	 * @param req
	 * @param res
	 *
	 * @returns string
	 */
	async doDownloadZipJSON(req, res) {
		try {
			const { ids, actual_file_name } = req.method === "POST" ? req.body : req.query;
			const doc_ids = Array.isArray(ids) ? ids : ids.split(",");

			if (!doc_ids.length) {
				return helper.getSuccessResponse(req, res, []);
			}

			let tenant = req.headers["x-tenant-id"];
			const s3Client = s3.getS3Client(tenant);
			let modelName = global[tenant]["dbModel"][DocumentLog.name];
			const params = await modelName.find({ _id: { $in: doc_ids } }).lean(true);
			const bucket = s3.downloadParams(tenant);
		
			const files =	params.map(({ doc_key }) => {
				return {
					stream: s3Client.getObject({ ...bucket, Key: doc_key }).createReadStream(),
					filename: actual_file_name
						? doc_key.replace(/([^\_]*\_){3}/, "")
						: doc_key.replace(/([^\-]*\-){5}/, ""),
				};
			});

			if (!fs.existsSync("./temp")) fs.mkdirSync("./temp");
			const fileName = "./temp/" + uuidv4() + ".zip";
			const output = fs.createWriteStream(fileName);
			const archive = archiver("zip");
			pipelineAsync(archive , output).catch(console.log)
			const savedDocuments = []
			files.forEach((itm) => {
				let tempFile = itm.filename
				let name = itm.filename
				if(savedDocuments.includes(name)){
					count = 0;
					for(let sDoc of savedDocuments){
						if (sDoc === name) {
							count++;
					}
					}
					name = `(${count}) ${name}`
				}
				savedDocuments.push(tempFile)
				return archive.append(itm.stream, { name })
			});
			archive.finalize();
			output.on("close", function () {
				const data = fs.readFileSync(fileName);
				fs.unlinkSync(fileName);
				return res
					.status(200)
					.send({ status: "success", code: 200, data: { fileData: data.toString("base64") } });
			});
		} catch (err) {
			console.log(err);
			return helper.getErrorResponse(req, res);
		}
	},
};
