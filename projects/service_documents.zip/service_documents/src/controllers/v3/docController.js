/** @format */

const s3 = require("../../config/s3.config.js");
const helper = require("../../helpers/helper");
const fileValidations = require("../../config/files.config");
const docUtils = require("../../utils/docUtils.js");
const messages = require("../../lang/en/messages.js");

module.exports = {
	async doSingleUpload(req, res) {
		try {
			const { buffer: data, size: file_size, originalname } = req.file;
			const { doc_type_id, doc_type_key, updated_file_name, doc_identifier } = req.body;
			const keySuffix = req.body.ref_id;
			const params = {
				...s3.uploadParams(req.headers["x-tenant-id"]),
				Key: `${keySuffix}/${keySuffix}_${helper.modifyOriginalFileName(
					originalname,
					doc_identifier
				)}`,
				Body: Buffer.from(data, "base64"),
			};
			let body = {
				doc_type_id,
				doc_type_key,
				file_size,
				updated_file_name: updated_file_name,
				is_deleted: fileValidations.is_deleted_false,
			};

			let doc = await docUtils.docUpload(req, params, body);
			return helper.getSuccessResponse(req, res, doc, 200, true);
		} catch (err) {
			console.log("errr:::", err);
			return helper.getErrorResponse(req, res);
		}
	},
	async doDataUpload(req, res) {
		try {
			const {
				doc_type_key = req.body.doc_type_key || "offer_doc",
				doc_type_id,
				filename,
				data,
				updated_file_name,
				doc_identifier,
			} = req.body;
			const { originalname = filename } = req.file || {};
			const buffer = Buffer.from(data, "base64");
			const keySuffix = req.body.ref_id;
			const params = {
				...s3.uploadParams(req.headers["x-tenant-id"]),
				Key: `${keySuffix}/${keySuffix}_${helper.modifyOriginalFileName(
					originalname,
					doc_identifier
				)}`,
				Body: buffer,
			};
			let body = {
				doc_type_id,
				doc_type_key,
				updated_file_name: updated_file_name,
				is_deleted: fileValidations.is_deleted_false,
			};

			let doc = await docUtils.docUpload(req, params, body);
			return helper.getSuccessResponse(req, res, doc, 200, true);
		} catch (err) {
			console.log("errr:::", err);
			return helper.getErrorResponse(req, res);
		}
	},
	async doDelete(req, res) {
		try {
			const result = await docUtils.docDelete(req, true);

			if (!result) {
				return helper.getErrorResponse(
					req,
					res,
					[messages.keys.resource_not_found],
					messages.codes.resource_not_found
				);
			}

			return helper.getSuccessResponse(req, res);
		} catch (err) {
			console.log("errr:::", err);
			return helper.getErrorResponse(req, res);
		}
	},
	async get(req, res) {
		try {
			const doc = await docUtils.getDoc(req);
			if (!doc) return helper.getSuccessResponse(req, res, []);
			return helper.getSuccessResponse(req, res, doc, 200, true);
		} catch (err) {
			console.log("errr:::", err);
			return helper.getErrorResponse(req, res);
		}
	},
	async getByIds(req, res) {
		try {
			let doc_ids = req.body.doc_ids;
			if (!Array.isArray(doc_ids) && !doc_ids.length) {
				return helper.getErrorResponse(req, res);
			}
			const doc = await docUtils.getDocByIds(req);
			if (!doc) {
				return helper.getSuccessResponse(req, res, []);
			}
			return helper.getSuccessResponse(req, res, doc, 200, true);
		} catch (err) {
			return helper.getErrorResponse(req, res);
		}
	},
		/**
	 * @description Download File from s3 bucket
	 *
	 * @author Tanuj Chawla <tanuj.chawla@biz2credit.com>
	 *
	 * @param req
	 * @param res
	 *
	 * @returns string
	 */
		 async doDownload(req, res) {
			try {
				let data = await docUtils.docDownload(req, res);
				res.send(data.Body);
				return helper.prepareSuccessResponse(req);
			} catch (err) {
				console.log("error:::", err);
				return helper.getErrorResponse(req, res);
			}
		},
	/**
	 * @description Download File as JSON from s3 bucket
	 *
	 * @author Sujendra Kumar <sujendra.kumar@biz2credit.com>
	 *
	 * @param req
	 * @param res
	 *
	 * @returns string
	 */
	async doDownloadJson(req, res) {
		try {
			const data = await docUtils.downloadDocJson(req, true);
			if (!data) {
				return helper.getErrorResponse(
					req,
					res,
					[messages.keys.resource_not_found],
					messages.codes.resource_not_found
				);
			}
			return helper.sendSuccessResponse(req, res, data);
		} catch (err) {
			console.log("errr:::", err);
			return helper.getErrorResponse(req, res);
		}
	},
};
