export interface IResponse<T = any> {
  code: number | string;
  status: string;
  message: string;
  success: boolean;
}

export interface IErrorResponse<T = any> extends IResponse<T> {
  errors: T;
  correlation_id?: string;
}

export interface ISuccessResponse<T = any> extends IResponse<T> {
  data: T;
  correlation_id?: string;
}
