import {
  BadRequestException,
  Body,
  Controller,
  Headers,
  HttpCode,
  Post,
} from '@nestjs/common';

import { AuthService } from './auth.service';
import { TokenDto } from './dto/token.dto';

@Controller()
export class AuthController {
  constructor(private authService: AuthService) {}

  @Post('token')
  @HttpCode(200)
  async getToken(
    @Body()
    body: TokenDto,
    @Headers('authorization') authorization: string,
  ) {
    try {
      if (!authorization || !body.grant_type) {
        throw new BadRequestException(['invalid_client']);
      }
      const paresedToken = this.authService.parseToken(authorization);
      const customer = await this.authService.checkUser(body);

      const token = await this.authService.generateToken(
        paresedToken[0],
        paresedToken[1],
        customer,
      );
      return { data: token };
    } catch (error) {
      throw error;
    }
  }
}
