const mongoose = require('mongoose');
const collections = require('../config/collections.config');
const Schema = mongoose.Schema;

// Request Response Log model to keep record of all requests made to the service

const ReqResLogSchema = new Schema({
    request_url : {
        type    : String, 
        required: true
    },
    method : {
        type    : String,                                          
        required: true
    },
    request_IP : {
        type    : String, 
        required: true
    },
    request_header : {
        type    : Object, 
        required: true
    },
    request_body : {
        type : Object, 
    },
    response : {
        type    : Object, 
        required: true
    },
    status_code : {
        type    : Number, 
        required: true
    },
}, {
    timestamps : true
}); 

module.exports = { schema: ReqResLogSchema, name: collections.request_response_log }