const aws = require("aws-sdk");
const fs = require("fs");
//const Archiver = require("archiver");
const output=fs.readFileSync('test01.json')

aws.config.update({
  accessKeyId: "AKIAJWHJDCEGUH7RXUXQ",
  secretAccessKey: "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",
  region: "us-east-1",
});

const s3 = new aws.S3();

const uploadParams = {//change to private as per requirement
  Body: output,
  Key: "test01.json",
  Bucket: "tmypracticeawsbucketc",
  StorageClass: "STANDARD",
};

// const s3Upload = s3.upload(uploadParams, (err, data) => {
//   console.log("in s3upload");
//   if (err) console.error("upload error", err);
//   else console.log("upload done", data);
// });

(async function () {
    s3.getObject(uploadParams, (err, data) => {
        console.log("in s3upload");
        if (err) console.error("upload error", err);
        else console.log("upload done", data);
      });
} )();