const Stream = require('stream');
const { post } = require('../client/httpRequest');
const { s3_Config, Archive } = require('../client/s3.config');
const db = require('./save.db');

module.exports.zipCreate = async (s3Object, doc, prefix, cb) => {
  try {
    const streamPassThrough = new Stream.PassThrough();

    const uploadParams = s3_Config.s3UploadParams(
      s3Object.zippedFileKey,
      streamPassThrough,
    );

    const s3Upload = s3_Config.s3UploadData(uploadParams);
    const archive = Archive.archiver();

    archive.on('error', (error) => {
      throw error;
    });

    archive.on('warning', function (err) {
      if (err.code === 'ENOENT') {
        console.log('warning');
      } else {
        throw err;
      }
    });

    s3Upload.on('httpUploadProgress', (progress) => {
      console.log(progress);
    });

    await new Promise((resolve, reject) => {
      s3Upload.on('close', resolve());
      s3Upload.on('end', reject());
      s3Upload.on('error', reject());

      archive.pipe(streamPassThrough);
      doc.forEach((s3FileDwnldStream) => {
        archive.append(s3FileDwnldStream.stream, {
          name: s3FileDwnldStream.fileName,
        });
      });
      archive.finalize();
    }).catch((error) => {
      throw new Error(`${error.code} ${error.message} ${error.data}`);
    });

    await s3Upload.promise().then(async (data) => {
      const res = await db.create(prefix, data);
      await post({ url: cb, data: { id: res._id.toString() } });
    });
  } catch (error) {
    throw error;
  }
};
