export interface Update {
  modelName: any;
  data: Record<string, any>;
  condition: Record<string, any>;
  multiple?: true | false;
}

export interface Aggregate {
  modelName: any;
  pipline: Record<string, any>[];
}

export interface Create {
  modelName: any;
  data: Record<string, any>;
}

export interface FindOne {
  modelName: any;
  condition: Record<string, any>;
  populate?: Record<string, any>;
  project?: Record<string, any>;
}
