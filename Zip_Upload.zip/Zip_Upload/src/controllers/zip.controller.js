const { zipCreate } = require('../utils/helper.js');
const { s3_Config } = require('../client/s3.config');

module.exports.zip = async (inputs) => {
  try {
    let { ignore_files, app_id, callback_url } = inputs;

    const s3Object = await s3_Config.getS3Object(app_id);

    s3Object.zippedFileKey = 'zip/zippedFile.zip';

    const s3FileDwnldStreams = s3Object.Contents.map((item) => {
      if (!ignore_files.includes(item.Key)) {
        const stream = s3_Config.getS3CreateReadstream(item.Key);
        return {
          stream,
          fileName: item.Key,
        };
      }
    }).filter((notUndefined) => notUndefined !== undefined);

    await zipCreate(s3Object, s3FileDwnldStreams, app_id, callback_url);
  } catch (error) {
    throw error;
  }
};

module.exports.getZip = async () => {
  try {
    return s3_Config.preSignedUrl();
  } catch (error) {
    throw error;
  }
};
