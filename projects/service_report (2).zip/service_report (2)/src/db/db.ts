// Import mongoose module
//const mongoose = require("mongoose").set("debug", true);
const mongoose = require("mongoose"); 
mongoose.pluralize(null);

/**
 * Method for connect mongo-db.
 *
 * @return connection
 */
// exports.connectionFactory = function (db_url, model_name, schema_path) {
//   const conn = mongoose.createConnection(db_url, { useNewUrlParser: true });
//   conn.model(model_name, require(schema_path));
//   return conn;
// };

class ConnectionFactory {
  static createConnection(db_url: any, model_name: any, schema_path: any) {
    const conn = mongoose.createConnection(db_url, { useNewUrlParser: true });
    conn.model(model_name, require(schema_path));
    return conn;
  }
}

export default ConnectionFactory;