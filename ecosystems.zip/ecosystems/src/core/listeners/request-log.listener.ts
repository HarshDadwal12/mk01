import { Injectable } from '@nestjs/common';
import { OnEvent } from '@nestjs/event-emitter';
import { RequestLogEvent } from '../events/request-log.event';
import { CommonService } from '../services/common.service';

@Injectable()
export class RequestLogListener {
  constructor(private readonly commonService: CommonService) {}
  @OnEvent('request.log')
  async handleRequestLogEvent(event: RequestLogEvent) {
    await this.commonService.requestLog(event.data);
  }
}
