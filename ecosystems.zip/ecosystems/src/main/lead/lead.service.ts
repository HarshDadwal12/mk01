import { BadRequestException, Injectable } from '@nestjs/common';
import { config } from 'src/config/constant.config';
import { CommonService } from 'src/core/services/common.service';
import { HttpRequestService } from 'src/core/services/http-request.service';
import * as _ from 'lodash';

@Injectable()
export class LeadService {
  constructor(
    private httpRequestService: HttpRequestService,
    private commonService: CommonService,
  ) {}

  async createLead(user, body) {
    try {
      const isValid = await this.checkProduct(
        body.product_opportunity_id,
        user.products,
      );
      if (!isValid) {
        throw new BadRequestException('invalid product_opportunity_id');
      }
      const leadStatusId = await this.commonService.getLeadStatus(
        body.lead_status,
      );
      if (!leadStatusId) {
        throw new BadRequestException('invalid lead_status');
      }
      body.lead_status = leadStatusId?.id;

      body = {
        ...body,
        customer_key: user.customer_key,
        name: body.borrower_first_name + ' ' + body.borrower_last_name,
      };
      const finalRes = [];
      if (body.lender_id) {
        const url = `api/backend/v1/users?record_id=${body.lender_id}`;
        const lenders = await this.commonService.getLender(url);

        const res = await this.commonService.callApiByName('lead_created', {
          body: { ...body, lender_id: lenders[0].id },
        });
        finalRes.push(res);
      } else {
        const url = `api/v1/user_mappings?aggregator_id=${user.backend_user_id}&type=aggregator_lender_allocation&lender_products.product_id=${body.product_opportunity_id}`;
        const lenders: any = await this.commonService.getLender(url);
        if (lenders.length < 1)
          throw new BadRequestException('currently no lender is onboarded for this product');

        const res = await this.commonService.callApiByName('lead_created', {
          body: { ...body, lender_id: lenders[0].lender_id },
        });
        console.log('res----',res);
        
        if (res.id) {
          await this.createUserActivity(res.id, {
            action: 'create',
            lead_status: { current_status: body.lead_status },
          });
        }
        finalRes.push(res);
      }
      return finalRes;
    } catch (error) {
      throw error;
    }
  }

  async getLead(query) {
    try {
      query = { ...query };
      console.log('query---',query);
      
      const res = await this.commonService.callApiByName('lead_get', {
        query,
      });
      if(res.total === 0){
        throw new BadRequestException('invalid lead_id');
      }
      return res;
    } catch (error) {
      throw new BadRequestException(error);
    }
  }

  async createUserActivity(id, data) {
    try {
      const body = {
        user_id: id,
        ...data,
      };
      const res = await this.commonService.callApiByName(
        'create_user_activity',
        {
          body,
        },
      );
      return res;
    } catch (error) {
      throw new BadRequestException(error);
    }
  }

  async updateLeadStatus(data, lead_id) {
    try {
      const leadStatusId = await this.commonService.getLeadStatus(
        data.lead_status,
      );

      if (!leadStatusId) throw new BadRequestException('invalid lead_status');
      const userEndPoint = `api/v1/users?record_id=${lead_id}`;
      const { id, lead_status } = await this.commonService.getFrontendUser(
        userEndPoint,
      );
      if (!id) throw new BadRequestException('invalid lead_id');

      const body = { ...data, lead_status: leadStatusId?.id, id };
      const res = await this.commonService.callApiByName('update_lead', {
        body,
      });
      if (lead_status !== leadStatusId?.id) {
        await this.createUserActivity(id, {
          action: 'update',
          lead_status: {
            current_status: leadStatusId?.id,
            previous_status: lead_status,
          },
        });
      }
      return res;
    } catch (error) {
      throw new BadRequestException(error);
    }
  }

  async checkProduct(product_type, products: []) {
    try {
      const endPoint = `api/v1/products?product_id=${product_type}`;
      const productConfig: any = await this.httpRequestService.getUserData(
        endPoint,
      );

      return products.includes(productConfig[0]?.id as never);
    } catch (error) {
      throw new BadRequestException(error);
    }
  }

  async getProfile(params) {
    try {
      let offerData: any,
        analysisData: any,
        finalRes: any = {},
        finalResWithApplication: any = {};
      const userEndPoint = `api/v1/users?record_id=${params.lead_id}`;
      const user = await this.commonService.getFrontendUser(userEndPoint);
      if (!user?.id) throw new BadRequestException('invalid lead_id');
      const user_id = user.id;
      const masterEndPoint = `v1/multiple?model=app_status,limit_status,lead_status`;
      const masterData: any = await this.httpRequestService.getMasterData(
        masterEndPoint,
      );
      finalRes.lead_id = +params.lead_id;
      if (masterData?.lead_status) {
        finalRes.lead_status = user?.lead_status
          ? _.find(masterData.lead_status, ['id', user.lead_status])
            ? _.find(masterData.lead_status, ['id', user.lead_status])?.type
            : null
          : null;
      }
      if (user?.proposed_limit) {
        finalRes.proposed_limit = user?.proposed_limit ?? null;
      }
      const applicationEndPoint = `api/v1/application?user_id=${user_id}`;
      const [appData]: any = await this.commonService.getApplication(
        applicationEndPoint,
      );
      if (appData?._id) {
        const offerEndPoint = `api/v1/offers/all?app_id=${appData._id}`;
        offerData = await this.getOfferData(offerEndPoint);
        const analysisEndPoint = `api/v1/analysis?app_id=${appData._id}`;
        analysisData = await this.getCaseData(analysisEndPoint);
        finalResWithApplication = await this.prepareProfileRes(
          masterData,
          appData,
          analysisData,
          offerData,
        );
      }
      return { ...finalRes, ...finalResWithApplication };
    } catch (error) {
      throw new BadRequestException(error);
    }
  }

  async prepareProfileRes(
    masterData: any,
    appData: any,
    analysisData: any,
    offerData: any,
  ) {
    try {
      let res: any = {};
      let latestOfferData: any = {};
      res.application_id = appData?.auto_id ? appData?.auto_id : null;

      if (masterData?.app_status) {
        res.application_status = appData.status_id
          ? _.find(masterData.app_status, ['id', appData.status_id])
            ? _.find(masterData.app_status, ['id', appData.status_id])?.type
            : null
          : null;
      }

      if (offerData?.length) {
        if (masterData.limit_status) {
          // res.proposed_limit = _.find(masterData.limit_status, [
          //   'value',
          //   'Proposed',
          // ])
          //   ? _.find(offerData, [
          //       'limit_status',
          //       _.find(masterData.limit_status, ['value', 'Proposed']).id,
          //     ])
          //     ? _.find(offerData, [
          //         'limit_status',
          //         _.find(masterData.limit_status, ['value', 'Proposed']).id,
          //       ]).amount
          //     : null
          //   : null;
          res.approved_limit = _.find(masterData.limit_status, [
            'value',
            'Approved',
          ])
            ? _.find(offerData, [
                'limit_status',
                _.find(masterData.limit_status, ['value', 'Approved']).id,
              ])
              ? _.find(offerData, [
                  'limit_status',
                  _.find(masterData.limit_status, ['value', 'Approved']).id,
                ]).amount
              : null
            : null;
          res.sanctioned_limit = _.find(masterData.limit_status, [
            'value',
            'Sanctioned',
          ])
            ? _.find(offerData, [
                'limit_status',
                _.find(masterData.limit_status, ['value', 'Sanctioned']).id,
              ])
              ? _.find(offerData, [
                  'limit_status',
                  _.find(masterData.limit_status, ['value', 'Sanctioned']).id,
                ]).amount
              : null
            : null;
          res.allocated_limit = _.find(masterData.limit_status, [
            'value',
            'Allocated',
          ])
            ? _.find(offerData, [
                'limit_status',
                _.find(masterData.limit_status, ['value', 'Allocated']).id,
              ])
              ? _.find(offerData, [
                  'limit_status',
                  _.find(masterData.limit_status, ['value', 'Allocated']).id,
                ]).amount
              : null
            : null;
          let offerIndex: any;
          if (
            _.some(offerData, (offer, index) => {
              if (offer.loan_account_number) {
                offerIndex = index;
                return true;
              }
              return false;
            })
          ) {
            res.loan_account_number = offerData[offerIndex]?.loan_account_number
              ? offerData[offerIndex].loan_account_number
              : null;
          }
          if (analysisData?.length) {
            const current_limit = await this.getCurrentLimit(
              analysisData,
              offerData,
            );
            res.current_limit = current_limit ? current_limit : null;
          }
          latestOfferData = offerData.pop();
          res.limit_status = latestOfferData.limit_status
            ? _.find(masterData.limit_status, [
                'id',
                latestOfferData.limit_status,
              ])
              ? _.find(masterData.limit_status, [
                  'id',
                  latestOfferData.limit_status,
                ])?.type
              : null
            : null;
          res.limit_expiry_date = latestOfferData.limit_expiry_date
            ? latestOfferData.limit_expiry_date
            : null;
        }
      }
      if (analysisData?.length) {
        const analysisCountData = _.countBy(analysisData, 'type');
        if (analysisCountData['disbursement_response']) {
          res.total_disbursement_count = 0;

          _.forEach(analysisData, (analysis) => {
            if (analysis?.type == 'disbursement_response') {
              if (analysis?.invoices?.length) {
                const invoiceCountData = _.countBy(
                  analysis.invoices,
                  'disbursement_status',
                );
                res.total_disbursement_count = invoiceCountData['DISBURSED']
                  ? res.total_disbursement_count + invoiceCountData['DISBURSED']
                  : res.total_disbursement_count;
              }
            }
          });
        }
        const disbursementResData = _.findLast(analysisData, [
          'type',
          'disbursement_response',
        ]);
        if (disbursementResData) {
          res.last_disbursement_date = disbursementResData?.invoices?.length
            ? disbursementResData?.invoices[
                disbursementResData?.invoices?.length - 1
              ]?.disbursed_date
            : null;
          res.last_disbursement_amount =
            disbursementResData?.total_disbursement_amount
              ? disbursementResData.total_disbursement_amount
              : null;
        }
        const repaymentResData = _.findLast(analysisData, [
          'type',
          'repayment_response',
        ]);
        if (repaymentResData) {
          res.last_repayment_date = repaymentResData?.repayment_timestamp
            ? repaymentResData.repayment_timestamp
            : '';
          res.last_repayment_amount = repaymentResData?.total_repayment_received
            ? repaymentResData.total_repayment_received
            : null;
          res.pending_repayment_amount =
            repaymentResData?.pending_repayment_amount
              ? repaymentResData.pending_repayment_amount
              : null;
          // if (repaymentResData?.invoices?.length) {
          //   res.total_principal_os = 0;
          //   res.total_interest_os = 0;
          //   res.total_penalty_os = 0;
          //   _.forEach(repaymentResData?.invoices, function (invoice) {
          //     if (invoice.principal_os)
          //       res.total_principal_os += invoice.principal_os;
          //     if (invoice.interest_os)
          //       res.total_interest_os += invoice.interest_os;
          //     if (invoice.penalty_os)
          //       res.total_penalty_os += invoice.penalty_os;
          //   });
          // }
          if (analysisCountData['repayment_response']) {
            res.total_repayment_count = 0;

            _.forEach(analysisData, (analysis) => {
              if (analysis?.type == 'repayment_response') {
                if (analysis?.invoices?.length) {
                  const invoiceCountData = _.countBy(
                    analysis.invoices,
                    'status_of_invoice_repayment',
                  );
                  res.total_repayment_count = invoiceCountData['PAID']
                    ? res.total_repayment_count + invoiceCountData['PAID']
                    : res.total_repayment_count;
                }
                if (
                  analysis?.disbursement_unique_id &&
                  analysis?.status_of_tranche_repayment === 'PAID'
                ) {
                  res.total_repayment_count += 1;
                }
              }
            });
          }
        }
      } else {
        res.total_disbursement_count = 0;
      }
      return res;
    } catch (error) {
      throw new BadRequestException(error);
    }
  }

  async getOfferData(endPoint: string) {
    try {
      return this.httpRequestService.getOfferData(endPoint);
    } catch (error) {
      throw new BadRequestException(error);
    }
  }
  async getCaseData(endPoint: string) {
    try {
      return this.httpRequestService.getCaseData(endPoint);
    } catch (error) {
      throw new BadRequestException(error);
    }
  }

  async calculateCurrentLimit(sanctioned_amount: any, analysisData: any) {
    try {
      let totalLimitAmount = sanctioned_amount;
      let subtractAmount = 0;
      let total_invoice_principal_deduction = 0;
      if (analysisData?.length) {
        let disubrsement_list = analysisData.filter(
          (data) =>
            data.disbursement_unique_id &&
            data.type == config.RESPONSE_TYPE.DISBURSEMENT_TYPE.response,
        );
        let repayment_list = analysisData.filter(
          (data) =>
            data.repayment_unique_id &&
            data.type == config.RESPONSE_TYPE.REPAYMENT_TYPE.response,
        );
        for (let data of disubrsement_list) {
          subtractAmount += +data.total_disbursement_amount;
        }
        for (let data of repayment_list) {
          if (data?.invoices?.length) {
            for (let invoice of data.invoices) {
              total_invoice_principal_deduction +=
                +invoice.invoice_principal_deduction || 0;
            }
          }
        }
        totalLimitAmount -= subtractAmount;
        totalLimitAmount += total_invoice_principal_deduction;
      }
      return totalLimitAmount;
    } catch (error) {
      throw new BadRequestException(error);
    }
  }

  async getCurrentLimit(analysisData: any, offerData: any) {
    try {
      let sanctiondOffer = await this.getSanctionedOffer(offerData);
      if (sanctiondOffer) {
        return await this.calculateCurrentLimit(
          +sanctiondOffer.amount,
          analysisData,
        );
      }
      return null;
    } catch (error) {
      throw new BadRequestException(error);
    }
  }

  async getSanctionedOffer(offerData: any) {
    try {
      let offer_data = null;
      for (let offer of offerData) {
        if (
          [
            config.LIMIT_STATUS.sanctioned,
            config.LIMIT_STATUS.allocated,
          ].includes(offer.limit_status)
        ) {
          offer_data = offer;
        }
      }
      return offer_data ? offer_data : null;
    } catch (error) {
      throw new BadRequestException(error);
    }
  }
}
