import {
  BadRequestException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { CommonService } from 'src/core/services/common.service';
import { HttpRequestService } from 'src/core/services/http-request.service';
import * as _ from 'lodash';
import * as moment from 'moment';
import { config } from 'src/config/constant.config';
import { off } from 'process';

@Injectable()
export class RepaymentService {
  constructor(
    private httpRequestService: HttpRequestService,
    private commonService: CommonService,
  ) {}

  async createAnalysis(data, api) {
    const appData = await this.commonService.getAppWithBusiness(
      data.application_id,
    );
    const app_id = appData?.[0]?._id;
    if (!app_id) throw new BadRequestException('invalid application id');
    await this.commonService.checkAppStatus(appData?.[0]?.status_id);
    if (api == 'repayment_request' || api == 'repayment_response') {
      await this.implementRepaymentIdValidation(
        app_id,
        data.type,
        data.repayment_unique_id,
      );
    }

    const body: any = {
      app_id,
      lender_id: appData?.[0]?.lender_id,
      ...data,
    };
    return this.commonService.callApiByName(api, { body });
  }

  async implementRepaymentRequestValidations(body: any) {
    try {
      const appData = await this.commonService.getAppWithBusiness(
        body.application_id,
      );
      const app_id = appData?.[0]?._id;
      const analysisEndPoint: string = `api/v1/analysis?app_id=${app_id}&start=0&limit=-1&type=disbursement_response&disbursement_unique_id=${body?.disbursement_unique_id}`;
      const data: any = await this.httpRequestService.getCaseData(
        analysisEndPoint,
      );
      if (!data?.length) {
        throw new BadRequestException('Disbursement response records not found against provided disbursement_unique_id');
      }
    } catch (error) {
      throw new BadRequestException(error);
    }
  }

  async implementRepaymentIdValidation(
    app_id: string,
    type: string,
    repayment_unique_id: string,
  ) {
    const analysisEndPoint: string = `api/v1/analysis?app_id=${app_id}&start=0&limit=1&sort_by=-created_at&type=${type}&repayment_unique_id=${repayment_unique_id}`;
    const repaymentData: any = await this.httpRequestService.getCaseData(
      analysisEndPoint,
    );
    if (repaymentData?.length) {
      throw new BadRequestException('repayment_unique_id must be unique');
    }
  }
  async performInterestCalculations(data: any) {
    const appData = await this.commonService.getAppWithBusiness(
      data.application_id,
    );
    const app_id = appData?.[0]?._id;
    if (!app_id) throw new BadRequestException('invalid application id');
    await this.commonService.checkAppStatus(appData?.[0]?.status_id);
    const analysisEndPoint = `api/v1/analysis?app_id=${app_id}&start=0&limit=100&sort_by=-created_at`;
    const analysisData: any = await this.getCaseData(analysisEndPoint);
    if (!analysisData?.length)
      throw new NotFoundException('Records not found on server');
    const offerEndPoint = `api/v1/offers/all?app_id=${app_id}`;
    const offerData = await this.httpRequestService.getOfferData(offerEndPoint);
    if (data.disbursement_unique_id) {
      await this.processTrancheInterestCalculations(
        data,
        analysisData,
        appData,
        offerData,
      );
    } else {
      await this.processBorrowerRepaymentInterestCalculations(
        data,
        analysisData,
        appData,
      );
      await this.processAggregatorRepaymentInterestCalculations(
        data,
        analysisData,
        offerData,
      );
    }
    return data;
  }

  async processTrancheInterestCalculations(
    data: any,
    analysisData: any,
    appData: any,
    offerData: any,
  ) {
    const disbursementResponseData = _.find(analysisData, {
      type: 'disbursement_response',
      disbursement_unique_id: data.disbursement_unique_id,
    });
    const disbursementRequestData = _.find(analysisData, {
      type: 'disbursement_request',
      disbursement_unique_id: data.disbursement_unique_id,
    });
    const repaymentRequestData = _.find(analysisData, {
      type: 'repayment_request',
      disbursement_unique_id: data.disbursement_unique_id,
    });
    if (!disbursementResponseData || !disbursementRequestData)
      throw new NotFoundException('Disbursement records not found on server');
    if (!repaymentRequestData)
      throw new NotFoundException(
        'Repayment request records not found on server',
      );
    let [borrower_repayment_interest, aggregator_repayment_interest] =
      await this.aggregatorBorrowerInterestCalculations(
        appData,
        repaymentRequestData,
        disbursementRequestData,
        disbursementResponseData,
        offerData,
      );
    data['maadhyam_tranche_date'] =
      disbursementRequestData?.payment_request_timestamp ?? null;
    data['maadhyam_tranche_disbursement_date'] =
      disbursementResponseData?.disbursement_response_timestamp ?? null;
    data['maadhyam_tranche_due_date'] =
      disbursementResponseData?.final_due_date_with_grace ?? null;
    data['maadhyam_tranche_repayment_date'] =
      repaymentRequestData?.repayment_timestamp ?? null;
    data['maadhyam_tranche_borrower_repayment_amount'] =
      data?.total_tranche_deduction ?? null;
    data['maadhyam_tranche_borrower_repayment_principal'] =
      data?.total_principal_deduction ?? null;
    data['maadhyam_tranche_borrower_repayment_interest'] =
      borrower_repayment_interest ?? null;
    data['maadhyam_tranche_borrower_repayment_charges'] =
      data?.total_penalty_deduction ?? null;
    data['maadhyam_tranche_borrower_os_repayment_amount'] =
      data?.total_tranche_outstanding ?? null;
    data['maadhyam_tranche_borrower_os_principal'] =
      data?.tranche_principal_os ?? null;
    data['maadhyam_tranche_borrower_os_interest'] =
      data?.tranche_interest_os ?? null;
    data['maadhyam_tranche_borrower_os_charges'] =
      data?.tranche_penalty_os ?? null;
    data['maadhyam_tranche_aggregator_repayment_amount'] =
      data?.total_tranche_deduction ?? null;
    data['maadhyam_tranche_aggregator_repayment_principal'] =
      data?.total_principal_deduction ?? null;
    data['maadhyam_tranche_aggregator_repayment_interest'] =
      aggregator_repayment_interest ?? null;
    data['maadhyam_tranche_aggregator_repayment_charges'] =
      data?.total_penalty_deduction ?? null;
  }

  async aggregatorBorrowerInterestCalculations(
    appData: any,
    repaymentRequestData: any,
    disbursementRequestData: any,
    disbursementResponseData: any,
    offerData: any,
  ) {
    let repayment_date = repaymentRequestData.repayment_timestamp
      .slice(0, 10)
      .split('-')
      .reverse()
      .join('-');
    let borrower_interest = 0,
      aggregator_interest = 0,
      lender_interest_rate = 0;
    for (let _ of offerData) {
      if (_.lender_interest_rate) {
        lender_interest_rate = _.lender_interest_rate;
        break;
      }
    }

    for (let invoice of disbursementRequestData.invoices) {
      let invoice_date = invoice.invoice_timestamp
        .slice(0, 10)
        .split('-')
        .reverse()
        .join('-');
      let diff =
        Math.floor(Date.parse(repayment_date) - Date.parse(invoice_date)) /
        (24 * 60 * 60 * 1000);
      for (let _ of disbursementResponseData.invoices) {
        if (invoice.invoice_no === _.invoice_no) {
          aggregator_interest +=
            ((diff * lender_interest_rate) / 365) * _.disbursement_amount;
          if (diff > 45) {
            borrower_interest +=
              ((diff * appData[0].business[0].retailer_interest_rate) / 365) *
              _.disbursement_amount;
          }
        }
      }
    }
    borrower_interest = Math.round(borrower_interest) / 100;
    aggregator_interest = Math.round(aggregator_interest) / 100;
    return [borrower_interest, aggregator_interest];
  }

  async processBorrowerRepaymentInterestCalculations(
    data: any,
    analysisData: any,
    appData: any,
  ) {
    const disbursementResponseData = _.find(analysisData, [
      'type',
      'disbursement_response',
    ]);
    const disbursementRequestData = _.find(analysisData, [
      'type',
      'disbursement_request',
    ]);
    const repaymentRequestData = _.find(analysisData, [
      'type',
      'repayment_request',
    ]);
    if (!disbursementResponseData || !disbursementRequestData)
      throw new NotFoundException('Disbursement records not found on server');
    if (!repaymentRequestData)
      throw new NotFoundException(
        'Repayment request records not found on server',
      );

    const retailer_interest_rate = appData?.[0]?.business?.[0]
      ?.retailer_interest_rate
      ? appData?.[0]?.business?.[0]?.retailer_interest_rate / 100
      : 0;

    _.each(data?.invoices, (invoice) => {
      const repayment_req_invoice_data = _.find(repaymentRequestData.invoices, [
        'invoice_no',
        invoice.invoice_no,
      ]);
      // console.log("repayment_req_invoice_data",repayment_req_invoice_data);
      const disbursement_res_invoice_data = _.find(
        disbursementResponseData.invoices,
        ['invoice_no', invoice.invoice_no],
      );
      const disbursement_req_invoice_data = _.find(
        disbursementRequestData.invoices,
        ['invoice_no', invoice.invoice_no],
      );
      // console.log(
      //   'disbursement_req_invoice_data',
      //   disbursement_req_invoice_data,
      // );
      // console.log(
      //   'disbursement_res_invoice_data',
      //   disbursement_res_invoice_data,
      // );
      invoice.maadhyam_invoice_date =
        disbursement_req_invoice_data?.invoice_timestamp
          ? disbursement_req_invoice_data?.invoice_timestamp
          : null;
      invoice.maadhyam_invoice_disbursement_date =
        disbursement_res_invoice_data?.disbursed_date
          ? disbursement_res_invoice_data?.disbursed_date
          : null;
      invoice.maadhyam_invoice_lender_due_date =
        disbursementResponseData?.final_due_date_with_grace
          ? disbursementResponseData?.final_due_date_with_grace
          : null;
      invoice.maadhyam_invoice_repayment_date =
        repaymentRequestData?.repayment_timestamp
          ? repaymentRequestData?.repayment_timestamp
          : null;

      invoice.maadhyam_borrower_repayment_amount =
        invoice?.total_invoice_deduction ? invoice?.total_invoice_deduction : 0;
      invoice.maadhyam_borrower_repayment_principal =
        invoice?.invoice_principal_deduction
          ? invoice?.invoice_principal_deduction
          : 0;
      invoice.maadhyam_borrower_repayment_charges =
        invoice?.invoice_penalty_deduction
          ? invoice?.invoice_penalty_deduction
          : 0;
      invoice.maadhyam_borrower_os_repayment_amount =
        invoice?.total_invoice_outstanding
          ? invoice?.total_invoice_outstanding
          : 0;
      invoice.maadhyam_borrower_os_principal = invoice?.principal_os
        ? invoice?.principal_os
        : 0;
      invoice.maadhyam_borrower_os_interest = invoice?.interest_os
        ? invoice?.interest_os
        : 0;
      invoice.maadhyam_borrower_os_charges = invoice?.penalty_os
        ? invoice?.penalty_os
        : 0;
      invoice.maadhyam_aggregator_repayment_amount =
        invoice?.total_invoice_deduction ? invoice?.total_invoice_deduction : 0;
      invoice.maadhyam_aggregator_repayment_principal =
        invoice?.invoice_principal_deduction
          ? invoice?.invoice_principal_deduction
          : 0;
      invoice.maadhyam_aggregator_repayment_charges =
        invoice?.invoice_penalty_deduction
          ? invoice?.invoice_penalty_deduction
          : 0;
      const maadhyam_invoice_fination_due_date = moment(
        invoice.maadhyam_invoice_date,
        'DD-MM-YYYY hh:mm:ss',
      )
        .add(45, 'd')
        .format('DD-MM-YYYY hh:mm:ss');
      invoice.maadhyam_invoice_fination_due_date =
        maadhyam_invoice_fination_due_date
          ? maadhyam_invoice_fination_due_date
          : null;
      const invoice_date: any = disbursement_req_invoice_data?.invoice_timestamp
        ? moment(
            disbursement_req_invoice_data?.invoice_timestamp,
            'DD-MM-YYYY hh:mm:ss',
          )
        : 0;
      // console.log('invoice_date', invoice_date.valueOf());
      const disbursement_amount =
        disbursement_res_invoice_data?.disbursement_amount
          ? disbursement_res_invoice_data?.disbursement_amount
          : 0;
      const repayment_date: any = repaymentRequestData?.repayment_timestamp
        ? moment(
            repaymentRequestData?.repayment_timestamp,
            'DD-MM-YYYY hh:mm:ss',
          )
        : 0;
      console.log(
        'repayment date',
        repayment_date.valueOf(),
        repayment_req_invoice_data,
      );
      const repayment_amount = invoice?.total_invoice_deduction
        ? invoice?.total_invoice_deduction
        : 0;
      const no_interest_time_period_in_days = config.NO_INTEREST_PERIOD_IN_DAYS;
      const repayment_due_date =
        moment.isMoment(invoice_date) && invoice_date?.isValid()
          ? moment(invoice_date.valueOf()).add(
              no_interest_time_period_in_days,
              'd',
            )
          : 0;
      // console.log('repayment due date', repayment_due_date.valueOf());
      if (
        moment?.isMoment(repayment_date) &&
        repayment_date?.isValid() &&
        moment.isMoment(repayment_due_date) &&
        repayment_due_date.isValid()
      ) {
        // console.log(
        //   'dates are valid',
        //   repayment_date.isBefore(repayment_due_date),
        // );
        if (repayment_date.isBefore(repayment_due_date)) {
          // console.log('repayment done before due date');
          invoice.maadhyam_borrower_repayment_interest = 0;
        } else {
          console.log('repayment done after due date');
          if (moment?.isMoment(invoice_date) && invoice_date?.isValid()) {
            const interest_on_days = repayment_date.diff(invoice_date, 'days');
            // console.log('interest on days ', interest_on_days);
            // console.log("disbursement amount",disbursement_amount);
            // console.log("retailer interest rate",retailer_interest_rate);
            invoice.maadhyam_borrower_repayment_interest =
              interest_on_days && retailer_interest_rate && disbursement_amount
                ? interest_on_days *
                  (retailer_interest_rate / 365) *
                  disbursement_amount
                : 0;
            // console.log(
            //   'final borrower interest',
            //   invoice.maadhyam_borrower_repayment_interest,
            // );
          } else {
            invoice.maadhyam_borrower_repayment_interest = 0;
          }
        }
      } else {
        // console.log('some data is missing ');
        invoice.maadhyam_borrower_repayment_interest = 0;
      }
    });
    return data;
  }

  async processAggregatorRepaymentInterestCalculations(
    data: any,
    analysisData: any,
    offerData: any,
  ) {
    const disbursementResponseData = _.find(analysisData, [
      'type',
      'disbursement_response',
    ]);
    const disbursementRequestData = _.find(analysisData, [
      'type',
      'disbursement_request',
    ]);
    const repaymentRequestData = _.find(analysisData, [
      'type',
      'repayment_request',
    ]);

    if (!disbursementResponseData || !disbursementRequestData)
      throw new NotFoundException('Disbursement records not found on server');
    if (!repaymentRequestData)
      throw new NotFoundException(
        'Repayment request records not found on server',
      );
    const lender_interest_rate =
      offerData?.length &&
      _.find(offerData, ['limit_status', '6231e7b1f6b8346b07e5c693'])
        ?.lender_interest_rate
        ? _.find(offerData, ['limit_status', '6231e7b1f6b8346b07e5c693'])
            ?.lender_interest_rate / 100
        : 0;
    _.each(data?.invoices, (invoice) => {
      const disbursement_res_invoice_data: any = _.find(
        disbursementResponseData.invoices,
        ['invoice_no', invoice.invoice_no],
      );
      const repayment_req_invoice_data: any = _.find(
        repaymentRequestData.invoices,
        ['invoice_no', invoice.invoice_no],
      );
      const disbursement_date: any =
        disbursement_res_invoice_data?.disbursed_date
          ? moment(
              disbursement_res_invoice_data?.disbursed_date,
              'DD-MM-YYYY',
              true,
            )
          : 0;
      const disbursement_amount: any =
        disbursement_res_invoice_data?.disbursement_amount
          ? disbursement_res_invoice_data?.disbursement_amount
          : 0;
      const repayment_due_date_with_grace: any =
        disbursementResponseData?.final_due_date_with_grace
          ? moment(
              disbursementResponseData?.final_due_date_with_grace,
              'DD-MM-YYYY',
              true,
            )
          : 0;
      const repayment_date: any = repaymentRequestData?.repayment_timestamp
        ? moment(
            repaymentRequestData?.repayment_timestamp,
            'DD-MM-YYYY hh:mm:ss',
          )
        : 0;
      const repayment_amount = invoice?.total_invoice_deduction
        ? invoice?.total_invoice_deduction
        : 0;
      // console.log("in aggregator ",repayment_date,disbursement_date,moment.isMoment(disbursement_date));
      if (
        moment?.isMoment(repayment_date) &&
        repayment_date?.isValid() &&
        moment.isMoment(disbursement_date) &&
        disbursement_date.isValid()
      ) {
        // console.log('dates are valid in aggregator calculations');
        const interest_on_days = repayment_date.diff(disbursement_date, 'days');
        console.log(
          'interest on days in aggregator calculations',
          interest_on_days,
          lender_interest_rate,
          disbursement_amount,
        );
        invoice.maadhyam_aggregator_repayment_interest =
          interest_on_days && lender_interest_rate && disbursement_amount
            ? interest_on_days *
              (lender_interest_rate / 365) *
              disbursement_amount
            : 0;
      } else {
        // console.log('some data is missing');
        invoice.maadhyam_aggregator_repayment_interest = 0;
      }
    });
  }

  async getCaseData(endPoint: string) {
    try {
      return this.httpRequestService.getCaseData(endPoint);
    } catch (error) {
      throw new BadRequestException(error);
    }
  }
}
