
// File validation criteria

const file_validations = {
    max_allowed_file_size: {
        pdf : 20000000 
    },
    allowed_file_types   :{
        pdf : /pdf/ 
    },
    is_deleted_true : 1,
    is_deleted_false : 0 
};

module.exports = file_validations;