export class RequestLogEvent {
  data: any;
}
