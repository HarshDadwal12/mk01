import * as dotenv from 'dotenv';
dotenv.config();

interface EnvData {
  MONGO_URL: string;
  PORT: Number;
  BUG_SNAG_KEY: string;
  APP_ENV: string;
  ACCESS_DOMAIN: string;
  REDIS_URL: string;
  REDIS_EXPIRE_TIME_MIN?: Number;
}

const envData = {
  MONGO_URL: process.env.MONGO_URL || '',
  PORT: Number(process.env.PORT) || 4000,
  BUG_SNAG_KEY: process.env.BUG_SNAG_KEY || '',
  APP_ENV: process.env.APP_ENV || '',
  ACCESS_DOMAIN: process.env.ACCESS_DOMAIN || '*',
  REDIS_URL: process.env.REDIS_URL || "",
  REDIS_EXPIRE_TIME_MIN: Number(process.env.REDIS_EXPIRE_TIME_MIN) || 30
};

export const updateConfig = function (env: EnvData) {
  envData.MONGO_URL = env.MONGO_URL || '';
  envData.PORT = Number(env.PORT) || 4000;
  envData.BUG_SNAG_KEY = env.BUG_SNAG_KEY || '';
  envData.APP_ENV = env.APP_ENV || '';
  envData.ACCESS_DOMAIN = env.ACCESS_DOMAIN || '*';
  envData.REDIS_URL =  env.REDIS_URL || "",
  envData.REDIS_EXPIRE_TIME_MIN = Number(env.REDIS_EXPIRE_TIME_MIN) || 30;
};

export default envData;
