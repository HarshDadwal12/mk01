const axios = require("axios");
const helper = require("../helpers/helper");
const config = require("../../config/config");
const messages = require("../lang/en/messages");
const redis = require("../config/redis.config");
const util = require("util");
const exif = require("../utils/exif");

module.exports = {
	/**
	 * @description Check is file is selected or not
	 *
	 * @author Tanuj Chawla <tanuj.chawla@biz2credit.com>
	 *
	 * @param req
	 * @param res
	 * @param {callback function} next
	 *
	 * @returns string
	 */
	singleUploadReqValidator(req, res, next) {
		if (!req.file && !req.body.doc_type_id) {
			return helper.getErrorResponse(
				req,
				res,
				[messages.keys.file_required, messages.keys.doc_type_required],
				messages.codes.bad_request
			);
		}
		if (!req.file) {
			return helper.getErrorResponse(
				req,
				res,
				[messages.keys.file_required],
				messages.codes.bad_request
			);
		}
		if (!req.body.doc_type_id) {
			return helper.getErrorResponse(
				req,
				res,
				[messages.keys.doc_type_required],
				messages.codes.bad_request
			);
		}

		let doc_type_id = req.body.doc_type_id;

		if (!/^[a-f\d]{24}$/.test(doc_type_id)) {
			return helper.getErrorResponse(
				req,
				res,
				[messages.keys.doc_type_invalid],
				messages.codes.bad_request
			);
		}

		next();
	},
	/**
	 * @description Check is file is selected or not
	 *
	 * @author Nitesh Meena <nitesh.meena@biz2credit.com>
	 *
	 * @param req
	 * @param res
	 * @param {callback function} next
	 *
	 * @returns string
	 */
	singleFileValidator(req, res, next) {
		if (!req.file) {
			return helper.getErrorResponse(
				req,
				res,
				[messages.keys.file_required],
				messages.codes.bad_request
			);
		}
		next();
	},

	/**
	 * @description Validate doc_id
	 *
	 * @author Tanuj Chawla <tanuj.chawla@biz2credit.com>
	 *
	 * @param req
	 * @param res
	 * @param {callback function} next
	 *
	 * @returns string
	 */
	docIdValidator(req, res, next) {
		let doc_id = req.params.doc_id;

		if (!doc_id) {
			return helper.getErrorResponse(
				req,
				res,
				[messages.keys.doc_id_required],
				messages.codes.bad_request
			);
		}

		if (!/^[a-f\d]{24}$/.test(doc_id)) {
			return helper.getErrorResponse(
				req,
				res,
				[messages.keys.doc_id_invalid],
				messages.codes.bad_request
			);
		}
		next();
	},

	/**
	 * @description Check is request method is allowed or not
	 *
	 * @author Tanuj Chawla <tanuj.chawla@biz2credit.com>
	 *
	 * @param req
	 * @param res
	 * @param {callback function} next
	 *
	 * @returns string
	 */
	reqMethodValidator(req, res, next) {
		let routes = Object.keys(messages.allowed_route_methods);
		let current_route = req.url;
		let method = "";
		routes.forEach((route) => {
			if (current_route.includes(route)) {
				method = messages.allowed_route_methods[route];
			}
		});
		if (req.method !== method) {
			return helper.getErrorResponse(
				req,
				res,
				[messages.keys.method_not_supported],
				messages.codes.method_not_supported
			);
		}
		next();
	},

	/**
	 * @description Check for valid doc_type_id from master_data
	 *
	 * @author Tanuj Chawla <tanuj.chawla@biz2credit.com>
	 *
	 * @param req
	 * @param res
	 * @param {callback function} next
	 *
	 * @returns string
	 */
	async docTypeIdValidator(req, res, next) {
		try {
			const tenant = req.headers["x-tenant-id"];
			const envConfig = global[tenant]["envConfig"];
			let doc_type_id = req.body.doc_type_id;
			const redisKey = `${envConfig.MASTER_COLLECTION}_${doc_type_id}`;

			const redisClient = redis.getInstance().client;
			redisClient.get = util.promisify(redisClient.get);

			let doc_type = await redisClient.get(redisKey);

			let tempUrl =
				envConfig.MASTER_URL +
				"/" +
				config.VERSION +
				"/" +
				config.MASTER_ENDPOINT +
				"/" +
				doc_type_id;
			let masterUrl = tempUrl.replace(/"/g, "");
			if (!doc_type) {
				let configParams = {};
				if (tenant != "&default&") {
					configParams.headers = { "x-tenant-id": tenant };
				}
				axios
					.get(masterUrl, configParams)
					.then((response) => {
						if (!response.data.data) {
							return helper.getErrorResponse(
								req,
								res,
								[messages.keys.doc_type_invalid],
								messages.codes.bad_request
							);
						}
						let data = response.data.data;
						let file_types = data.allowed_file_type.split(", ");
						let doc_type_key = data.key;
						if (data && data.doc_identifier) {
							req.body.doc_identifier = data.doc_identifier;
						}
						req.body.filetypes = file_types;
						req.body.doc_type_key = doc_type_key;

						next();
					})
					.catch((error) => {
						return helper.getErrorResponse(
							req,
							res,
							[messages.keys.doc_type_invalid],
							messages.codes.bad_request
						);
					});
			} else {
				doc_type = JSON.parse(doc_type);
				let file_types = doc_type.allowed_file_type.split(", ");
				req.body.filetypes = file_types;
				req.body.doc_type_key = doc_type.key;
				if (doc_type && doc_type.doc_identifier) {
					req.body.doc_identifier = doc_type.doc_identifier;
				}
				next();
			}
		} catch (error) {
			// console.log(error)
			return helper.getErrorResponse(
				req,
				res,
				[messages.keys.doc_type_invalid],
				messages.codes.bad_request
			);
		}
	},

	dataReqValidator(req, res, next) {
		if (!req.body.data && !req.body.doc_type_id && !req.body.filename) {
			return helper.getErrorResponse(
				req,
				res,
				[
					messages.keys.data_required,
					messages.keys.doc_type_required,
					messages.keys.filename_required,
				],
				messages.codes.bad_request
			);
		}
		if (!req.body.data) {
			return helper.getErrorResponse(
				req,
				res,
				[messages.keys.data_required],
				messages.codes.bad_request
			);
		}
		if (!req.body.doc_type_id) {
			return helper.getErrorResponse(
				req,
				res,
				[messages.keys.doc_type_required],
				messages.codes.bad_request
			);
		}

		if (!req.body.filename) {
			return helper.getErrorResponse(
				req,
				res,
				[messages.keys.filename_required],
				messages.codes.bad_request
			);
		}

		if (!helper.isValidFilename(req.body.filename)) {
			return helper.getErrorResponse(
				req,
				res,
				[messages.keys.filename_invalid],
				messages.codes.bad_request
			);
		}

		let doc_type_id = req.body.doc_type_id;

		if (!/^[a-f\d]{24}$/.test(doc_type_id)) {
			return helper.getErrorResponse(
				req,
				res,
				[messages.keys.doc_type_invalid],
				messages.codes.bad_request
			);
		}

		next();
	},

	appIdValidator(req, res, next) {
		if (!req.body.ref_id) {
			return helper.getErrorResponse(
				req,
				res,
				[messages.keys.ref_id_required],
				messages.codes.bad_request
			);
		}
		next();
	},

	urlPdfReqValidator(req, res, next) {
		if (!req.body.pdf_url) {
			return helper.getErrorResponse(
				req,
				res,
				[messages.keys.pdf_url_required],
				messages.codes.bad_request
			);
		}

		if (!req.body.doc_type_id) {
			return helper.getErrorResponse(
				req,
				res,
				[messages.keys.doc_type_required],
				messages.codes.bad_request
			);
		}

		if (!req.body.filename) {
			return helper.getErrorResponse(
				req,
				res,
				[messages.keys.filename_required],
				messages.codes.bad_request
			);
		}

		let doc_type_id = req.body.doc_type_id;

		if (!/^[a-f\d]{24}$/.test(doc_type_id)) {
			return helper.getErrorResponse(
				req,
				res,
				[messages.keys.doc_type_invalid],
				messages.codes.bad_request
			);
		}

		next();
	},
	genPdfValidator(req, res, next) {
		if (!req.body.content) {
			return helper.getErrorResponse(
				req,
				res,
				[messages.keys.content_required],
				messages.codes.bad_request
			);
		}
		next();
	},

	/**
	 * @description Validate doc_ids
	 *
	 * @author Sujendra Kumar <sujendra.kumar@biz2credit.com>
	 *
	 * @param req
	 * @param res
	 * @param {callback function} next
	 *
	 * @returns JSON
	 */
	docIdsValidator(req, res, next) {
		let doc_ids = req.body.doc_ids || req.query.doc_ids;

		if (!Array.isArray(doc_ids)) {
			return helper.getErrorResponse(
				req,
				res,
				[messages.keys.doc_id_required],
				messages.codes.bad_request
			);
		}

		if (doc_ids.length == 0) {
			return helper.getErrorResponse(
				req,
				res,
				[messages.keys.doc_id_required],
				messages.codes.bad_request
			);
		}

		next();
	},

	/**
	 * remove exif data
	 * @param {*} req
	 * @param {*} res
	 * @param {*} next
	 */
	removeExifDataValidator(req, res, next) {
		if (req.body.removeExif) {
			if (!Buffer.isBuffer(req.file.buffer))
				return helper.getErrorResponse(
					req,
					res,
					[messages.keys.buffer_invalid],
					messages.codes.bad_request
				);

			if (!req.file.buffer)
				return helper.getErrorResponse(
					req,
					res,
					[messages.keys.buffer_invalid],
					messages.codes.bad_request
				);

			req.file.buffer = exif(req.file.buffer);
		}
		next();
	},
	/**
	 * remove exif data
	 * @param {*} req
	 * @param {*} res
	 * @param {*} next
	 */
	removeExifDataValidatorForBase64(req, res, next) {
		if (req.body.removeExif) {
			const data = Buffer.from(req.body.data, "base64");
			req.body.data = exif(data).toString("base64");
		}
		next();
	},
	/**
	 * @description Validate pr signed url request
	 *
	 * @author Tanuj Chawla <tanuj.chawla@biz2credit.com>
	 *
	 * @param req
	 * @param res
	 * @param {callback function} next
	 *
	 * @returns string
	 */
	preSignedReqValidator(req, res, next) {
		if (!req.body.filename) {
			return helper.getErrorResponse(
				req,
				res,
				[messages.keys.filename_required],
				messages.codes.bad_request
			);
		}

		next();
	},

	/**
	 * @description Validate Doc Refs
	 *
	 * @author Tanuj Chawla <tanuj.chawla@biz2credit.com>
	 *
	 * @param req
	 * @param res
	 * @param {callback function} next
	 *
	 * @returns string
	 */
	docRefsValidator(req, res, next) {
		let doc_refs = req.body.doc_refs;

		if (!doc_refs) {
			return helper.getErrorResponse(
				req,
				res,
				[messages.keys.doc_refs_required],
				messages.codes.bad_request
			);
		}

		if (!Array.isArray(doc_refs)) {
			return helper.getErrorResponse(
				req,
				res,
				[messages.keys.doc_refs_invalid],
				messages.codes.bad_request
			);
		}

		if (doc_refs.length == 0) {
			return helper.getErrorResponse(
				req,
				res,
				[messages.keys.doc_refs_required],
				messages.codes.bad_request
			);
		}

		let error_codes = [];

		for (let i = 0; i < doc_refs.length; i++) {
			if (!doc_refs[i]["doc_key"]) {
				error_codes.push(messages.keys.doc_key_required);
			}

			if (!doc_refs[i]["doc_type_id"]) {
				error_codes.push(messages.keys.doc_type_required);
			}

			if (!doc_refs[i]["doc_type_key"]) {
				error_codes.push(messages.keys.doc_type_key_required);
			}
		}

		if (error_codes.length > 0) {
			return helper.getErrorResponse(req, res, error_codes, messages.codes.bad_request);
		}

		next();
	},

	/**
	 * @description Validate updated_file_name
	 *
	 * @author Amit Kishore <amit.kishore@biz2credit.com>
	 *
	 * @param req
	 * @param res
	 * @param {callback function} next
	 *
	 * @returns string
	 */
	updatedFileNameValidator(req, res, next) {
		let fileName = req.body.updated_file_name;

		if (!fileName) {
			return helper.getErrorResponse(
				req,
				res,
				[messages.keys.updated_file_name],
				messages.codes.bad_request
			);
		}

		if (!/^[\s\S]{4,255}$/.test(fileName)) {
			return helper.getErrorResponse(
				req,
				res,
				[messages.keys.updated_file_name],
				messages.codes.bad_request
			);
		}
		next();
	},
	/**
	 * @description Validate doc_data
	 *
	 * @author Ravi Pratap Singh <ravi.singh@biz2credit.com>
	 *
	 * @param req
	 * @param res
	 * @param {callback function} next
	 *
	 * @returns string
	 */
	docVisibilityValidator(req, res, next) {
		let { doc_data } = req.body;
		if (!doc_data) {
			return helper.getErrorResponse(
				req,
				res,
				[messages.keys.doc_data_required],
				messages.codes.bad_request
			);
		}

		if (!Array.isArray(doc_data)) {
			return helper.getErrorResponse(
				req,
				res,
				[messages.keys.doc_data_invalid],
				messages.codes.bad_request
			);
		}

		for (doc of doc_data) {
			if (!doc.doc_type_key || !doc.value)
				return helper.getErrorResponse(
					req,
					res,
					[messages.keys.doc_data_invalid],
					messages.codes.bad_request
				);
		}

		next();
	},
	/**
	 * @description Validate zipper Payload
	 *
	 * @author Ravi Pratap Singh <ravi.singh@biz2credit.com>
	 *
	 * @param req
	 * @param res
	 * @param {callback function} next
	 *
	 * @returns string
	 */
	zipperValidator(req, res, next) {
		let { ref_id, doc_ids } = req.body;

		if (!ref_id && !doc_ids) {
			return helper.getErrorResponse(
				req,
				res,
				[messages.keys.resource_not_found],
				messages.codes.bad_request
			);
		}

		if (doc_ids) {
			if (!Array.isArray(doc_ids)) {
				return helper.getErrorResponse(
					req,
					res,
					[messages.keys.doc_id_invalid],
					messages.codes.bad_request
				);
			}
			for (doc of doc_ids) {
				if (!/^[a-f\d]{24}$/.test(doc)) {
					return helper.getErrorResponse(
						req,
						res,
						[messages.keys.doc_id_invalid],
						messages.codes.bad_request
					);
				}
			}
		} else {
			if (!/^[a-f\d]{24}$/.test(ref_id)) {
				return helper.getErrorResponse(
					req,
					res,
					[messages.keys.ref_id_required],
					messages.codes.bad_request
				);
			}
		}

		next();
	},
	/**
	 * @description Validate clone Payload
	 *
	 * @author Ravi Pratap Singh <ravi.singh@biz2credit.com>
	 *
	 * @param req
	 * @param res
	 * @param {callback function} next
	 *
	 * @returns string
	 */
	cloneValidator(req, res, next) {
		let { ref_id, doc_ids } = req.body;

		if (!ref_id && !doc_ids) {
			return helper.getErrorResponse(
				req,
				res,
				[messages.keys.resource_not_found],
				messages.codes.bad_request
			);
		}

		if (doc_ids) {
			if (!Array.isArray(doc_ids)) {
				return helper.getErrorResponse(
					req,
					res,
					[messages.keys.doc_ids_invalid],
					messages.codes.bad_request
				);
			}
			for (doc of doc_ids) {
				if (!/^[a-f\d]{24}$/.test(doc)) {
					return helper.getErrorResponse(
						req,
						res,
						[messages.keys.doc_ids_invalid],
						messages.codes.bad_request
					);
				}
			}
		}
		if (!ref_id) {
			return helper.getErrorResponse(
				req,
				res,
				[messages.keys.ref_id_required],
				messages.codes.bad_request
			);
		}

		next();
	},
};
